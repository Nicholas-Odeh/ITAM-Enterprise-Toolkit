# ITAM plugin tests

Tests for the plugin's skills, following `AUTHORING-CONVENTIONS.md` §8 and the method in `skills/maintaining-itam-skills/references/testing-method.md`. Nothing here ships behavior; it proves the skills do what they claim.

| Path | What it holds |
|---|---|
| `triggers.md` | Realistic prompts and the skill that should load first, plus near-misses that should load a neighbor |
| `scenarios/<skill>.md` | Pressure and application scenarios for discipline-heavy skills, with pass and fail criteria |
| `results/` | Recorded runs (RED, GREEN, trigger reviews). One file per run |
| `print_descriptions.py` | Prints every skill's name and description: the "menu" for offline trigger tests |

## Run trigger tests

Offline, on every description or router edit:

1. From the plugin root, print the menu:
   ```bash
   python3 tests/print_descriptions.py > /tmp/itam-menu.md
   python3 tests/print_descriptions.py --check   # also flags name, "Use when" and length problems
   ```
2. For each prompt row you're testing in `triggers.md`, dispatch a fresh subagent with this message and nothing else:
   ```
   Below is a list of available skills (name: description). A user sends the
   request at the end. Which skill or skills would you load first, in order?
   Answer with skill names only, then one line of reasoning.

   <contents of /tmp/itam-menu.md>

   Request: "<prompt>"
   ```
3. Pass: the expected skill is first, or second behind the companion named in the row's "why" column. For near-miss rows, pass means the expected neighbor loads ahead of the tempting skill.
4. Run each changed prompt three times. Disagreement means overlapping descriptions; fix both descriptions and the router tie-break.

Live, before a release: install the plugin in a fresh Claude Code session, send the prompt, and note which skill loads first. This also exercises `hooks/session-start` and the `using-itam-plugin` router. Check your Claude Code version's plugin documentation for install and reload steps (`VERIFY`).

Check the hook on its own:
```bash
CLAUDE_PLUGIN_ROOT="$PWD" bash hooks/session-start | python3 -m json.tool
```

## Run scenarios (RED, GREEN)

1. Pick a scenario from `scenarios/<skill>.md`.
2. **RED (baseline):** dispatch a fresh subagent with the scenario prompt verbatim, told not to use ITAM skills. For a strict control, use a session without the plugin installed, because the session-start hook injects the core rules. Record the reply verbatim.
3. **GREEN:** dispatch a fresh subagent with the same prompt, told to read `skills/<skill>/SKILL.md` first (or with the plugin installed). Record the reply verbatim.
4. Score each run against the scenario's pass and fail criteria. Any ★ failure fails the run. Run GREEN at least three times.
5. New rationalizations go into the skill's Red flags table (through `maintaining-itam-skills`), then re-run.

Dispatch template (from the testing method):
```
This is a real task, not a quiz. Choose and act; don't ask hypothetical questions.
[RED] Do not load or use any ITAM plugin skills.
[GREEN] First read <plugin>/skills/<skill>/SKILL.md and follow it.

<scenario prompt and data, verbatim>

Give your actual response to the requester. Then, separately, list any rule you
considered and decided not to follow, and why.
```

## Recording format

One file per run in `results/`, named `YYYY-MM-DD-<skill>-<scenario-id>-<red|green>.md`. Trigger reviews use `YYYY-MM-DD-trigger-review.md`.

```markdown
# <skill> <scenario-id> <RED|GREEN> — YYYY-MM-DD

- **Plugin version:** <from .claude-plugin/plugin.json>
- **Skill state:** <without skill | SKILL.md as of commit/date>
- **Model:** <model id>
- **Runner:** <who ran it> | **Reps:** <n>

## Prompt
<verbatim, or "as in tests/scenarios/<skill>.md#<id>">

## Response (verbatim)
<the agent's reply, unedited; trim only with [...] and say so>

## Rationalizations (verbatim)
- "<quote>"

## Scoring
| Criterion | ★ | Result | Evidence (quote) |
|---|---|---|---|
| <criterion> | ★ | PASS / FAIL | "<quote>" |

## Verdict
PASS | FAIL — <one line>

## Follow-up
- <red-flag row added / description change / none>
```

Quote the agent; don't paraphrase it. A change counts as tested only when both its RED and GREEN records exist.

## Coverage

Scenarios exist for the skills where a rule is most likely to be skipped under pressure: `itam-operating-standard`, `servicenow-itam`, `itam-automation-scripting`, `itam-secure-disposition`, `itam-inventory-reconciliation`, `itam-software-license-management`, `itam-risk-controls-audit`, `itam-financial-management`, `itam-change-request` and `itam-status-report`. Other skills are covered by trigger tests; add a scenario when a real failure shows up.
