# Trigger tests

Each row is a realistic user prompt and the skill that should load **first**. Rows marked **NM** are near-misses: the prompt resembles this section's skill, but a neighbor should win. Run them as described in `tests/README.md`. Prompts use synthetic names and numbers.

Many prompts need a domain skill and a method or platform skill together (the router loads them domain → method → platform). The expected skill is the one the prompt is mainly about; where the "why" column names a companion, a run also passes if the companion loads first and the expected skill second. A near-miss passes only if the tempting skill is not loaded ahead of the expected one.

## Contents

| Section | Skill | Rows |
|---|---|---|
| RTR | using-itam-plugin | RTR-1 … RTR-5 |
| MNT | maintaining-itam-skills | MNT-1 … MNT-6 |
| OPS | itam-operating-standard | OPS-1 … OPS-6 |
| GOV | itam-program-governance | GOV-1 … GOV-6 |
| SOP | itam-sop-documentation | SOP-1 … SOP-6 |
| LIF | itam-hardware-lifecycle | LIF-1 … LIF-7 |
| REC | itam-inventory-reconciliation | REC-1 … REC-7 |
| DAT | itam-data-analysis-reporting | DAT-1 … DAT-6 |
| IMG | endpoint-imaging-provisioning | IMG-1 … IMG-7 |
| LOG | itam-logistics-warehouse | LOG-1 … LOG-7 |
| LIC | itam-software-license-management | LIC-1 … LIC-7 |
| DIS | itam-secure-disposition | DIS-1 … DIS-7 |
| RSK | itam-risk-controls-audit | RSK-1 … RSK-7 |
| FIN | itam-financial-management | FIN-1 … FIN-7 |
| SHT | itam-spreadsheet-models | SHT-1 … SHT-6 |
| PI | itam-process-improvement | PI-1 … PI-6 |
| VEN | itam-vendor-contract-management | VEN-1 … VEN-6 |
| ACQ | itam-acquisition-procurement | ACQ-1 … ACQ-6 |
| AUT | itam-automation-scripting | AUT-1 … AUT-7 |
| SN | servicenow-itam | SN-1 … SN-7 |
| SP | sharepoint-itam-records | SP-1 … SP-6 |
| CHG | itam-change-request | CHG-1 … CHG-6 |
| STS | itam-status-report | STS-1 … STS-6 |
| CAP | itam-capacity-planning | CAP-1 … CAP-7 |

## using-itam-plugin (RTR)

The router is injected by the session-start hook, so in practice it is always present. These rows check that it also loads on its own when the hook is absent.

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| RTR-1 | "I just installed the ITAM plugin. What can it do, and where should I start for a 6,000-seat company?" | using-itam-plugin | Orientation across the whole plugin |
| RTR-2 | "Which of your asset management skills should I use for a laptop that's lost, under lease, and has a Visio license on it?" | using-itam-plugin | Spans lifecycle, finance and licensing; needs the routing table and priority order |
| RTR-3 | "I have a mixed bag of ITAM questions for today: hardware, licenses and a CAB item. How do you want to handle them?" | using-itam-plugin | Multi-domain triage |
| RTR-4 | "Before we start: what rules do you follow when I ask you for asset numbers?" | using-itam-plugin | The core operating rules live in the router |
| RTR-5 NM | "Add a new skill to the ITAM plugin for BYOD phones." | maintaining-itam-skills | Authoring the plugin, not using it |

## maintaining-itam-skills (MNT)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| MNT-1 | "The licensing skill keeps loading when I ask about contract renewal notice periods. Fix the description." | maintaining-itam-skills | Mis-triggering description |
| MNT-2 | "Write pressure tests for the secure-disposition skill so we know it won't accept a vendor's word that drives were wiped." | maintaining-itam-skills | Scenario authoring for a discipline rule |
| MNT-3 | "I tweaked asset-data-model.md inside the servicenow-itam folder. Is that the right place?" | maintaining-itam-skills | Synced copy vs. canonical file |
| MNT-4 | "We need a skill for mobile device management. New skill, or extend the lifecycle one?" | maintaining-itam-skills | Add-vs-edit decision |
| MNT-5 | "Agents still say 'reconciled' at 97% even with the reconciliation skill loaded. Tighten the skill." | maintaining-itam-skills | REFACTOR after a GREEN failure |
| MNT-6 NM | "Review this disposal evidence memo before I send it to internal audit." | itam-operating-standard | QA of an ITAM deliverable, not a skill (the `itam-reviewer` agent also fits) |

## itam-operating-standard (OPS)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| OPS-1 | "How confident are you in that 4,312 laptop count? Where exactly did it come from?" | itam-operating-standard | Provenance and confidence |
| OPS-2 | "ServiceNow says we have 1,204 laptops, Intune says 1,187, and Finance says 1,250. Which one do I put in the board deck?" | itam-operating-standard | Conflicting sources; source hierarchy. Reconciliation follows if they want the record-level differences |
| OPS-3 | "QA this audit response memo before it goes to the audit committee tomorrow." | itam-operating-standard | Release gate on an audit-grade draft |
| OPS-4 | "Should this go to the CIO as an executive brief or a technical assessment?" | itam-operating-standard | Output mode choice |
| OPS-5 | "Is it OK to say we're 'ISO 19770 compliant' in the program summary?" | itam-operating-standard | Alignment vs. certification claim |
| OPS-6 NM | "ServiceNow and Intune laptop lists don't match. Give me the serial-level differences and why." | itam-inventory-reconciliation | Record matching, not a provenance question |

## itam-program-governance (GOV)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| GOV-1 | "We're starting an ITAM program from scratch. Build me a three-year roadmap." | itam-program-governance | Strategy and roadmap |
| GOV-2 | "Assess our ITAM maturity against the IAITAM KPAs. Here's what we have today…" | itam-program-governance | Maturity / KPA gap |
| GOV-3 | "Draft a RACI for asset management across IT, Procurement, Finance and HR." | itam-program-governance | Roles and decision rights |
| GOV-4 | "Which ITAM policies do we actually need, and who should approve them?" | itam-program-governance | Policy set and approval |
| GOV-5 | "I need a business case to get two more ITAM analysts funded next year." | itam-program-governance | Program business case. Financial follows for the numbers |
| GOV-6 NM | "Write the step-by-step procedure our receiving team follows when laptops arrive." | itam-sop-documentation | A procedure, not program design |

## itam-sop-documentation (SOP)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| SOP-1 | "Write an SOP for receiving and tagging new laptops at the Denver depot." | itam-sop-documentation | Procedure writing. Logistics follows for the content |
| SOP-2 | "Turn these notes into a runbook for the monthly reconciliation job." | itam-sop-documentation | Runbooks belong here |
| SOP-3 | "Revise our disposal work instruction so each step says what evidence is kept." | itam-sop-documentation | Revising a work instruction |
| SOP-4 | "Write the text of our BYOD acceptable-use policy for mobile devices." | itam-sop-documentation | Policy document text |
| SOP-5 | "Standardize these four regional leaver-device procedures into one." | itam-sop-documentation | Consolidating procedures |
| SOP-6 NM | "Our receiving process is a mess: 30% of laptops sit untagged for a week. Fix it." | itam-process-improvement | A broken process needs root cause before a document |

## itam-hardware-lifecycle (LIF)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| LIF-1 | "Design lifecycle states and substates for laptops, from order to disposal." | itam-hardware-lifecycle | State model design |
| LIF-2 | "A leaver hasn't returned their laptop after 30 days. What's our process?" | itam-hardware-lifecycle | Joiner-mover-leaver recovery |
| LIF-3 | "An employee's phone was stolen in Madrid. What happens to the asset record?" | itam-hardware-lifecycle | Lost/stolen handling |
| LIF-4 | "Should engineers move from a 4-year to a 3-year laptop refresh?" | itam-hardware-lifecycle | Refresh policy. Financial follows for cost |
| LIF-5 | "How should we track loaner laptops so they come back?" | itam-hardware-lifecycle | Loaner pool |
| LIF-6 NM | "Forecast next year's laptop refresh budget for 3,200 devices." | itam-financial-management | Cost forecast, not policy |
| LIF-7 NM | "Ship a laptop to a new hire in São Paulo by Monday." | itam-logistics-warehouse | Physical shipping |

## itam-inventory-reconciliation (REC)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| REC-1 | "Match these three exports (ServiceNow, Intune, SCCM) and tell me what's missing where." | itam-inventory-reconciliation | Multi-source matching |
| REC-2 | "Find ghost assets: in the CMDB but not seen by discovery in 90 days." | itam-inventory-reconciliation | Ghost/zombie classification |
| REC-3 | "We counted 412 laptops in the stockroom; ServiceNow says 437. Reconcile it." | itam-inventory-reconciliation | Count vs. records (cycle-count tie-break) |
| REC-4 | "There are duplicate serials between our asset register and the Intune export. Sort them out." | itam-inventory-reconciliation | Duplicate identifiers |
| REC-5 | "Compare the fixed asset register with the ITAM repository for the auditors." | itam-inventory-reconciliation | Finance-to-ITAM reconciliation |
| REC-6 NM | "Set up the physical count procedure for the Chicago stockroom shelves." | itam-logistics-warehouse | Counting shelves, not comparing records |
| REC-7 NM | "Chart inventory accuracy over the last 12 months for the dashboard." | itam-data-analysis-reporting | KPI trend, not matching |

## itam-data-analysis-reporting (DAT)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| DAT-1 | "Define the ten ITAM KPIs we should put on the executive dashboard, with formulas." | itam-data-analysis-reporting | Metric definitions |
| DAT-2 | "Why did inventory accuracy drop from 96% to 91% this month?" | itam-data-analysis-reporting | Explaining a KPI movement |
| DAT-3 | "Assess the data quality of this asset export: blanks, duplicates, bad dates." | itam-data-analysis-reporting | Data-quality assessment |
| DAT-4 | "Here's our asset spreadsheet. What trends or anomalies stand out?" | itam-data-analysis-reporting | Exploratory analysis |
| DAT-5 NM | "Write my weekly ITAM status update for the director." | itam-status-report | Periodic stakeholder update |
| DAT-6 NM | "Match the Intune export to ServiceNow by serial number." | itam-inventory-reconciliation | Record matching |

## endpoint-imaging-provisioning (IMG)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| IMG-1 | "Autopilot pre-provisioning fails at the ESP on the new Dell model. Where do we start?" | endpoint-imaging-provisioning | Provisioning failure at the bench |
| IMG-2 | "Write the build standard for Windows 11 laptops." | endpoint-imaging-provisioning | Build standard |
| IMG-3 | "We're onboarding the HP EliteBook 860 G11. What driver and BIOS baseline do we need to record?" | endpoint-imaging-provisioning | New model onboarding |
| IMG-4 | "Set up Apple Automated Device Enrollment with Jamf for new MacBooks." | endpoint-imaging-provisioning | Apple ADE |
| IMG-5 | "Do returned laptops need a full reimage before going to a new hire?" | endpoint-imaging-provisioning | Reimage-on-redeploy |
| IMG-6 NM | "Write a PowerShell script that pulls Autopilot hardware hashes from Graph." | itam-automation-scripting | Code, not build design |
| IMG-7 NM | "How many technicians do we need to image 2,000 laptops in six weeks?" | itam-capacity-planning | Staffing a throughput target (router tie-break: imaging bench) |

## itam-logistics-warehouse (LOG)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| LOG-1 | "Write the receiving check for pallets of laptops against the ASN." | itam-logistics-warehouse | Receiving |
| LOG-2 | "We're shipping laptops to remote staff in Canada and Mexico. What about customs and encryption?" | itam-logistics-warehouse | International shipping |
| LOG-3 | "Our leaver return kits keep arriving without chargers and with the wrong labels. How should we redo the kit?" | itam-logistics-warehouse | Return-kit mechanics (router tie-break: leaver devices) |
| LOG-4 | "The carrier lost a laptop in transit. How do we file the claim and update the record?" | itam-logistics-warehouse | Lost-in-transit |
| LOG-5 | "Barcode, QR or RFID for our asset tags?" | itam-logistics-warehouse | Tagging standard |
| LOG-6 NM | "Our ITAD vendor picked up 200 drives; the certificate lists 180. Where are the other 20?" | itam-secure-disposition | Disposal chain of custody, not transit to users |
| LOG-7 NM | "40% of leaver return kits never come back. Find out why and fix it." | itam-process-improvement | A failing recovery rate (router tie-break: leaver devices); lifecycle and logistics follow for content |

## itam-software-license-management (LIC)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| LIC-1 | "Are we compliant on Visio?" | itam-software-license-management | Compliance question, platform-neutral |
| LIC-2 | "Calculate our Acrobat license position from these entitlements and install counts." | itam-software-license-management | ELP |
| LIC-3 | "We got a license review letter from a publisher this morning. What do we do?" | itam-software-license-management | Publisher audit response |
| LIC-4 | "Reclaim Zoom licenses not used in the last 90 days." | itam-software-license-management | Reharvest |
| LIC-5 | "Help me prepare for the Microsoft EA true-up next month." | itam-software-license-management | True-up |
| LIC-6 NM | "Our SaaS contract auto-renews in 60 days. What notice do we have to give?" | itam-vendor-contract-management | Contract terms, not quantities (renewal tie-break) |
| LIC-7 NM | "Show me the cmdb_sam_sw_install records for Visio in our ServiceNow instance." | servicenow-itam | Named ServiceNow table |

## itam-secure-disposition (DIS)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| DIS-1 | "Prove these 40 laptops were wiped before they go for resale." | itam-secure-disposition | Wipe proof |
| DIS-2 | "We're retiring 60 servers. For the SSDs, should we purge or destroy?" | itam-secure-disposition | Sanitization outcome |
| DIS-3 | "What due diligence should we do before choosing an ITAD vendor?" | itam-secure-disposition | ITAD vendor selection |
| DIS-4 | "A laptop went missing between pickup and the recycler. What now?" | itam-secure-disposition | Disposal chain of custody |
| DIS-5 | "Put together the disposal evidence pack for last quarter's retirements for audit." | itam-secure-disposition | Disposal evidence |
| DIS-6 NM | "Returned laptops need wiping and reimaging before they go to new hires." | endpoint-imaging-provisioning | Redeploy, not disposal |
| DIS-7 NM | "How do we keep custody of laptops we ship to remote employees?" | itam-logistics-warehouse | Transit to users |

## itam-risk-controls-audit (RSK)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| RSK-1 | "Build an ITAM risk register for the leadership review." | itam-risk-controls-audit | Risk register |
| RSK-2 | "Test our quarterly asset recertification control: design and operating effectiveness." | itam-risk-controls-audit | Control testing |
| RSK-3 | "Internal audit found 12% of laptops with no assigned user. Draft our response and remediation." | itam-risk-controls-audit | Audit finding response |
| RSK-4 | "Map our asset inventory controls to CIS Controls 1 and 2 and NIST CSF ID.AM." | itam-risk-controls-audit | Framework mapping |
| RSK-5 | "Which IT asset controls are in scope for SOX ITGC?" | itam-risk-controls-audit | SOX/ITGC |
| RSK-6 NM | "A software publisher's auditor sent a license verification request." | itam-software-license-management | Publisher audit is licensing |
| RSK-7 NM | "Write the procedure the team follows for the quarterly recertification." | itam-sop-documentation | Procedure document |

## itam-financial-management (FIN)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| FIN-1 | "What's the four-year TCO of a MacBook Pro versus a Dell Latitude for us?" | itam-financial-management | TCO |
| FIN-2 | "Depreciation schedule and net book value at 30 June for this batch of 300 laptops." | itam-financial-management | Depreciation |
| FIN-3 | "Lease or buy for 1,500 laptops on a three-year cycle?" | itam-financial-management | Lease vs. buy |
| FIN-4 | "Set a monthly chargeback rate per laptop for the business units." | itam-financial-management | Chargeback |
| FIN-5 | "Finance doesn't believe ITAM saved anything. Help me prove it." | itam-financial-management | Savings tracking |
| FIN-6 NM | "Build the Excel workbook for the depreciation model: tabs, columns and Power Query." | itam-spreadsheet-models | Workbook construction (TCO tie-break); financial supplies the method |
| FIN-7 NM | "Did our repair vendor miss its SLA last quarter, and do they owe us credits?" | itam-vendor-contract-management | SLA credits |

## itam-spreadsheet-models (SHT)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| SHT-1 | "Build me a license position workbook in Excel." | itam-spreadsheet-models | ITAM workbook design. Licensing supplies the rules |
| SHT-2 | "My reconciliation spreadsheet's lookups return the wrong rows. Fix it." | itam-spreadsheet-models | Workbook repair |
| SHT-3 | "What tabs and columns should a refresh planning model have?" | itam-spreadsheet-models | Workbook architecture |
| SHT-4 | "Power Query steps to combine twelve monthly Intune exports into one table." | itam-spreadsheet-models | Power Query pipeline |
| SHT-5 NM | "What useful life should we use to depreciate laptops?" | itam-financial-management | Finance policy question |
| SHT-6 NM | "Write a Python script that merges the monthly Intune CSVs." | itam-automation-scripting | Code, not workbook |

## itam-process-improvement (PI)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| PI-1 | "Request-to-deploy takes 14 days on average. Find the bottlenecks." | itam-process-improvement | Slow process |
| PI-2 | "Give me an as-is and to-be map for leaver device recovery." | itam-process-improvement | Process mapping |
| PI-3 | "Why do 30% of receipts arrive without asset tags? Root cause, please." | itam-process-improvement | Root cause |
| PI-4 | "Draft a DMAIC charter to cut lost laptops in half." | itam-process-improvement | DMAIC |
| PI-5 NM | "Write the SOP for the new receiving process we designed last week." | itam-sop-documentation | Documenting, not fixing |
| PI-6 NM | "Assess our overall ITAM program maturity." | itam-program-governance | Program, not a process |

## itam-vendor-contract-management (VEN)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| VEN-1 | "Extract the obligations from this hardware services MSA into a register." | itam-vendor-contract-management | Clause-to-obligation |
| VEN-2 | "The vendor promised next-business-day repair at 98%. Did they hit it last quarter, and what credits are due?" | itam-vendor-contract-management | SLA credits |
| VEN-3 | "Build a quarterly scorecard for our repair and ITAD vendors." | itam-vendor-contract-management | Scorecard |
| VEN-4 | "Our reseller contract renews in 90 days. Help me prepare the negotiation." | itam-vendor-contract-management | Renewal and negotiation |
| VEN-5 NM | "Write an RFP for laptop supply and configuration services." | itam-acquisition-procurement | New sourcing |
| VEN-6 NM | "How many Microsoft 365 E3 licenses should we renew?" | itam-software-license-management | Quantities (renewal tie-break) |

## itam-acquisition-procurement (ACQ)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| ACQ-1 | "Write an RFP for a device-as-a-service provider." | itam-acquisition-procurement | RFx drafting |
| ACQ-2 | "Design a standard laptop catalog with three tiers." | itam-acquisition-procurement | Standard catalog |
| ACQ-3 | "What approval workflow should non-standard hardware requests follow?" | itam-acquisition-procurement | Request approval |
| ACQ-4 | "Score these three vendor responses against our requirements." | itam-acquisition-procurement | Evaluation scoring |
| ACQ-5 NM | "Review the payment and warranty terms in the contract we just signed with the winner." | itam-vendor-contract-management | Existing contract |
| ACQ-6 NM | "Should we lease or buy the new laptops?" | itam-financial-management | Lease vs. buy |

## itam-automation-scripting (AUT)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| AUT-1 | "Write PowerShell to export Intune devices with their primary user through Graph." | itam-automation-scripting | Graph/Intune script |
| AUT-2 | "Python script to normalize serial numbers in our asset CSV." | itam-automation-scripting | Data script. Reconciliation supplies the rules |
| AUT-3 | "Review this script that bulk-updates asset assignments before I run it." | itam-automation-scripting | Script review with write safety |
| AUT-4 | "Schedule a nightly job that pulls Autopilot devices into our asset database." | itam-automation-scripting | Scheduled pipeline |
| AUT-5 | "My Graph script dies with 429 errors halfway through." | itam-automation-scripting | Throttling failure |
| AUT-6 NM | "GlideRecord script to find alm_hardware records with no linked CI." | servicenow-itam | Named ServiceNow table and GlideRecord (router tie-break: ServiceNow leads for GlideRecord); automation follows for bulk writes |
| AUT-7 NM | "Which matching rules should we use to reconcile Intune and the CMDB?" | itam-inventory-reconciliation | Match rules, not code |

## servicenow-itam (SN)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| SN-1 | "What's the difference between alm_hardware and cmdb_ci_computer, and which one should hold the cost center?" | servicenow-itam | ServiceNow data model; asset vs. CI |
| SN-2 | "Encoded query for laptops in stock with no stockroom set." | servicenow-itam | Encoded query |
| SN-3 | "How do we set up hardware model normalization in HAM?" | servicenow-itam | HAM configuration |
| SN-4 | "SAM reconciliation in ServiceNow shows Visio over-deployed by 140. Why?" | servicenow-itam | SAM results in the platform. Licensing follows for the position |
| SN-5 | "Asset-CI sync isn't updating install status in our instance." | servicenow-itam | Asset-CI sync |
| SN-6 NM | "How should we define hardware lifecycle states?" (no platform named) | itam-hardware-lifecycle | Platform-neutral |
| SN-7 NM | "Do we have enough Visio licenses?" (no platform named) | itam-software-license-management | Platform-neutral |

## sharepoint-itam-records (SP)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| SP-1 | "Design a SharePoint library for certificates of destruction keyed to asset tag and serial." | sharepoint-itam-records | Library design |
| SP-2 | "Retention labels for contracts: keep 7 years after expiry. How do we set that up?" | sharepoint-itam-records | Event-based retention |
| SP-3 | "Power Automate flow that alerts us 60 days before warranty expiry." | sharepoint-itam-records | Flow pattern |
| SP-4 | "Can we use a SharePoint list as our loaner tracker?" | sharepoint-itam-records | List tracker |
| SP-5 NM | "Write the SOP that will be stored in the new SharePoint library." | itam-sop-documentation | Document content |
| SP-6 NM | "Analyze the termination clauses in the contracts we keep in SharePoint." | itam-vendor-contract-management | Contract analysis |

## itam-change-request (CHG)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| CHG-1 | "Draft the change request to bulk-retire 2,140 assets in ServiceNow next Tuesday." | itam-change-request | Bulk data change record. ServiceNow follows for platform detail |
| CHG-2 | "CAB pack for moving the stockroom from Building A to Building B." | itam-change-request | Stockroom move |
| CHG-3 | "We need a rollback plan for changing our asset state model." | itam-change-request | Rollback plan |
| CHG-4 | "Change record for the new Intune-to-ServiceNow integration going live." | itam-change-request | Integration change |
| CHG-5 NM | "Write the script that bulk-retires the 2,140 assets." | itam-automation-scripting | The code, not the record |
| CHG-6 NM | "Write the standing procedure for monthly stockroom transfers." | itam-sop-documentation | Standing procedure |

## itam-status-report (STS)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| STS-1 | "Write the weekly ITAM operations status for my director." | itam-status-report | Weekly status |
| STS-2 | "Monthly steering pack for the ITAM program with RAG ratings." | itam-status-report | Steering pack |
| STS-3 | "Quarterly update to the audit committee on asset control remediation." | itam-status-report | Committee update. Risk supplies the findings |
| STS-4 | "Turn these Jira updates into a refresh-wave status report." | itam-status-report | Tracker to narrative |
| STS-5 NM | "Define the leaver device recovery rate KPI with formula and target." | itam-data-analysis-reporting | Metric definition |
| STS-6 NM | "Design a Power BI dashboard for inventory accuracy." | itam-data-analysis-reporting | Dashboard design |

## itam-capacity-planning (CAP)

| ID | Prompt | Expected skill | Why |
|---|---|---|---|
| CAP-1 | "How many techs do we need to deploy 2,000 laptops in eight weeks?" | itam-capacity-planning | Throughput vs. staffing |
| CAP-2 | "How big should our spare laptop pool be for 5,000 users?" | itam-capacity-planning | Spares sizing |
| CAP-3 | "Is the asset team overallocated in Q3 with the refresh wave and the audit?" | itam-capacity-planning | Workload |
| CAP-4 | "How much stockroom space will the refresh wave need at peak?" | itam-capacity-planning | Space sizing |
| CAP-5 | "Can our two-person depot handle leaver returns if attrition doubles?" | itam-capacity-planning | Demand stress test |
| CAP-6 NM | "What will next year's hardware refresh cost?" | itam-financial-management | Cost, not capacity |
| CAP-7 NM | "Which laptops are due for refresh this year under our policy?" | itam-hardware-lifecycle | Refresh eligibility |
