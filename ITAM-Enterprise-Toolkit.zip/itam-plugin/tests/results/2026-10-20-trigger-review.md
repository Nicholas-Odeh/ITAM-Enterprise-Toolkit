# Trigger review — 2026-10-20

- **Plugin version:** 0.2.0 (`.claude-plugin/plugin.json`), skill set mid-rewrite
- **Skill state:** descriptions as on disk at review time (see "Snapshot" below)
- **Method:** offline, description-only judgment (`tests/README.md` → Run trigger tests). The menu was produced from the frontmatter of every `skills/*/SKILL.md` by a parsing script; the reviewer (Claude, as the plugin-infrastructure worker) read only the descriptions and judged which skill should load first for each prompt. One judge, one pass per prompt: this is a smoke test, not a subagent run with repetitions.
- **Sample:** 39 prompts from `tests/triggers.md`, weighted toward near-misses and known overlaps.
- **Audience:** the owners of each skill's description. This review edits no description; findings are recommendations.

## Snapshot

Taken 2026-10-20 at about 15:45 UTC, after all 24 descriptions had been rewritten. `python3 tests/print_descriptions.py --check` result: 24 skills, all `name` values match their folders, all descriptions start "Use when", all are 440–549 characters except `servicenow-itam` (564, over the 300–550 target, under the 1024 cap).

Earlier checks the same afternoon (15:20–15:35 UTC) found 15, then 3, then 2 descriptions still in the v1 "Plans…/Runs…/Works with…" style; the review waited until none remained.

## Results

Verdicts: **PASS** (expected skill clearly wins), **PASS-A** (expected skill wins, but a neighbor's description also matches strongly enough that a subagent could pick it), **MISS** (another skill wins on the descriptions as written).

39 prompts: 22 PASS, 16 PASS-A, 1 MISS.

| Prompt | Expected | Verdict | Note |
|---|---|---|---|
| RTR-2 | `using-itam-plugin` | PASS | Only description that offers to pick among skills. |
| MNT-6 NM | `itam-operating-standard` | PASS-A | "QA-reviewing a draft" wins, but `itam-risk-controls-audit` ("preparing for an internal … audit … evidence") and `itam-secure-disposition` ("closure evidence") also match. See F5. |
| OPS-2 | `itam-operating-standard` | PASS-A | "when sources conflict" wins; `itam-inventory-reconciliation` ("comparing … asset lists across systems") is a close second. Acceptable: reconciliation is the natural follow-on. |
| OPS-6 NM | `itam-inventory-reconciliation` | PASS | Serial-level differences match reconciliation, not provenance. |
| GOV-5 | `itam-program-governance` | PASS-A | "business case for tools or headcount" wins, but `itam-financial-management` also claims "builds a business case (ROI, NPV, payback)" with no Not-for clause. See F1. |
| GOV-6 NM | `itam-sop-documentation` | PASS | "write up the process"; logistics follows as the domain companion. |
| SOP-2 | `itam-sop-documentation` | PASS | "runbooks" is in the SOP description; reconciliation is the companion. |
| SOP-6 NM | `itam-process-improvement` | PASS-A | "this process is broken" and "receiving" match; `itam-logistics-warehouse` ("receiving … tag standards") also matches. |
| LIF-4 | `itam-hardware-lifecycle` | PASS | "refresh policy". |
| LIF-6 NM | `itam-financial-management` | PASS-A | "forecasts refresh spend or budget" wins, but lifecycle's "refresh policy or forecast" also matches the word *forecast*. See F2. |
| LIF-7 NM | `itam-logistics-warehouse` | PASS | "shipping abroad", "kits for new hires". |
| REC-3 | `itam-inventory-reconciliation` | PASS | "count-vs-record variance". |
| REC-6 NM | `itam-logistics-warehouse` | PASS-A | "running a physical cycle count" matches, and reconciliation's Not-for points here; `itam-sop-documentation` ("procedure … counts") could load first as the method companion. Acceptable under the companion rule. |
| REC-7 NM | `itam-data-analysis-reporting` | PASS | "trends", "dashboard"; reconciliation's Not-for points here. |
| DAT-2 | `itam-data-analysis-reporting` | PASS-A | "explaining why a number changed" wins; operating-standard's "where a number came from" is close. |
| DAT-5 NM | `itam-status-report` | PASS | "weekly operations report"; data-analysis's Not-for points here. |
| IMG-5 | `endpoint-imaging-provisioning` | PASS | "reimage on redeploy". |
| IMG-7 NM | `itam-capacity-planning` | PASS | "imaging bench throughput, technician staffing"; imaging's Not-for points here. (Imaging also lists "bench throughput metrics"; see F8.) |
| LOG-3 (original wording) | `itam-logistics-warehouse` | MISS | Prompt was "40% of leaver return kits never come back. What should we change?". Three descriptions match: logistics ("leaver return kits"), lifecycle ("unreturned leaver laptops") and process-improvement ("leaver device recovery … error-prone", "what should we change" reads as improvement). On the descriptions, process-improvement is at least as likely. Row reworded and a new near-miss added; see F3. |
| LOG-6 NM | `itam-secure-disposition` | PASS-A | "a certificate of destruction must be reconciled" wins; reconciliation ("comparing … lists") is close. |
| LIC-1 | `itam-software-license-management` | PASS | Quoted trigger "are we compliant on X". |
| LIC-6 NM | `itam-vendor-contract-management` | PASS-A | "renewal's … notice date" wins; licensing's "SaaS" pulls, but its Not-for ("renewal commercial … terms") points to vendor-contract. |
| LIC-7 NM | `servicenow-itam` | PASS-A | Wins on "SAM Pro" and licensing's Not-for ("ServiceNow SAM tables"). The servicenow description no longer names any SAM table (`cmdb_sam_sw_install`, `alm_license`), only `alm_hardware`/`alm_asset`. See F7. |
| DIS-6 NM | `endpoint-imaging-provisioning` | PASS-A | "reimage on redeploy" wins; disposition's "prove this was wiped" pulls on the word *wiping*. Disposition's "Use when retiring …" opening keeps it second. |
| DIS-7 NM | `itam-logistics-warehouse` | PASS | "in-transit chain of custody"; logistics' Not-for keeps ITAD custody separate. |
| RSK-6 NM | `itam-software-license-management` | PASS | Risk's Not-for names publisher license audits. |
| FIN-6 NM | `itam-spreadsheet-models` | PASS | "tabs, columns, formulas or Power Query"; financial's Not-for points here. |
| FIN-7 NM | `itam-vendor-contract-management` | PASS | "missed an SLA or owes credits". |
| SHT-5 NM | `itam-financial-management` | PASS | "depreciation schedule"; spreadsheet's Not-for ("finance method"). |
| VEN-6 NM | `itam-software-license-management` | PASS | "sizing a renewal quantity"; vendor-contract's Not-for ("true-up sizing"). |
| ACQ-5 NM | `itam-vendor-contract-management` | PASS | "reviewing an IT vendor contract"; acquisition's Not-for ("existing contracts"). |
| AUT-6 NM | `servicenow-itam` | PASS | "encoded queries, GlideRecord and Table API on asset tables"; automation's Not-for names GlideRecord. Consistent with the router tie-break. |
| SN-4 | `servicenow-itam` | PASS-A | "SAM Pro" wins; licensing ("over-deployed" reads as compliance) is the natural companion. |
| SP-1 | `sharepoint-itam-records` | PASS | "certificates of destruction" in a SharePoint library. |
| CHG-1 | `itam-change-request` | PASS-A | "change record … bulk asset … corrections" wins; servicenow ("disposal order", asset tables) and automation ("bulk update") also match. Acceptable: both are companions. |
| CHG-5 NM | `itam-automation-scripting` | PASS-A | "bulk update" wins and change-request's Not-for points here; if the user's context is ServiceNow, servicenow-itam may lead under the router's GlideRecord tie-break, which is also acceptable. |
| STS-3 | `itam-status-report` | PASS-A | "audit-committee summary … remediation progress" wins; risk-controls ("answering a … finding") is the companion. |
| CAP-1 | `itam-capacity-planning` | PASS | "absorb planned work … technician staffing". |
| CAP-3 | `itam-capacity-planning` | PASS-A | "absorb planned work" fits, but the user's word *overallocated* (or workload, utilization) isn't in the description; "overtime" is the nearest. See F9. |

## Findings for description owners

Each finding names the description that would change. None of these were edited by this review.

| # | Owner | Finding | Suggested fix |
|---|---|---|---|
| F1 | `itam-financial-management` | Claims "builds a business case (ROI, NPV, payback)" with no boundary against `itam-program-governance`, which claims "a business case for tools or headcount". GOV-5 could go either way. | Add "Not for … program funding cases (use itam-program-governance)" or say financial supplies the numbers for a governance business case. |
| F2 | `itam-hardware-lifecycle` | "refresh policy or forecast" overlaps financial's "forecasts refresh spend or budget" and capacity's "refresh waves". | Say "refresh policy, eligibility and volume forecast"; the cost Not-for is already there. |
| F3 | `itam-logistics-warehouse`, `itam-hardware-lifecycle`, `itam-process-improvement` | Leaver device recovery is claimed three ways ("leaver return kits", "unreturned leaver laptops", "leaver device recovery … error-prone"). The original LOG-3 prompt was a MISS. | Router tie-break added (JML process and records → lifecycle; return kits → logistics; failing recovery rate → process-improvement). Owners could mirror it: logistics "Not for a failing recovery rate (itam-process-improvement)"; lifecycle "Not for return-kit shipping (itam-logistics-warehouse)". |
| F4 | `itam-sop-documentation` | Lists "counts" among its procedure topics, so "set up the physical count procedure" (REC-6) may load SOP before logistics. | Acceptable as a method companion; no change needed unless live tests show logistics is skipped. |
| F5 | `itam-risk-controls-audit` | "preparing for an internal … audit … evidence" competes with operating-standard for "review this memo before internal audit" (MNT-6). | Add "Not for QA of a single draft before release (use itam-operating-standard)". |
| F6 | `sharepoint-itam-records` | Opens with general SharePoint how-to ("lists, items, libraries, views, sharing, site permissions, groups, version history, PowerShell, Graph updates"). It will fire for SharePoint questions with no ITAM content, and overlaps `itam-automation-scripting` (which claims "Graph … PowerShell") for SharePoint scripts. Not in the sample; found while reading descriptions. | Anchor the opening to ITAM records, or keep the breadth deliberately and add "Not for general Graph or Intune scripts (use itam-automation-scripting)"; add a matching clause to automation for SharePoint list scripts, or a router tie-break. |
| F7 | `servicenow-itam` | 564 characters (target 300–550). Names `alm_hardware`/`alm_asset` but no SAM tables, though SAM Pro is in scope; prompts naming `cmdb_sam_sw_install` or `alm_license` now rely on licensing's Not-for clause. | Trim elsewhere and add "SAM tables such as cmdb_sam_sw_install or alm_license" if room allows. |
| F8 | `endpoint-imaging-provisioning` | Still lists "bench throughput metrics", which overlaps capacity's "imaging bench throughput" and data-analysis's metrics ownership. Its Not-for (capacity sizing) mostly resolves it. | Optional: "bench KPIs" or drop the phrase. |
| F9 | `itam-capacity-planning` | User words *overallocated*, *workload*, *utilization*, *headcount* are absent from the description ("utilization targets" appears only in Covers). | Add "team workload or overallocation" to the Use-when list. |
| F10 | `itam-data-analysis-reporting`, `itam-vendor-contract-management` | Both say "scorecard" (data-analysis: "dashboard or scorecard"; vendor: "building a scorecard"). A vendor scorecard prompt (VEN-3, not sampled) could go to data-analysis. | Data-analysis: "Not for vendor scorecards (use itam-vendor-contract-management)". |
| F11 | `itam-risk-controls-audit`, `itam-vendor-contract-management` | Both say "obligations" (compliance obligations vs. contract obligation registers). Low risk; noted for completeness. | Optional: risk "regulatory obligations". |

No description summarizes a workflow; all use scope nouns in their "Covers" clause.

## Changes made in files this worker owns

- `skills/using-itam-plugin/SKILL.md`: added router tie-breaks for **Imaging bench**, **Bulk change**, **Leaver devices**, and "ServiceNow leads for GlideRecord and encoded queries".
- `tests/triggers.md`: reworded LOG-3 to a return-kit mechanics prompt; added LOG-7 NM (failing recovery rate → `itam-process-improvement`); updated the IMG-7 and AUT-6 notes to point at the new tie-breaks; stated the companion rule (a run passes if the named companion loads first and the expected skill second), which keeps trigger expectations consistent with the router's domain → method → platform order. The same rule is in `tests/README.md` and `testing-method.md` §2.

## Follow-up

- Re-run the sample with fresh subagents (three reps per prompt) once all descriptions are final, and record it as a new dated review.
- Run a live trigger test with the plugin installed before release.
