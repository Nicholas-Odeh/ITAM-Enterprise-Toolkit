#!/usr/bin/env python3
"""Print each ITAM skill's name and description from its SKILL.md frontmatter.

Use the output as the "skill menu" for offline trigger tests (see tests/README.md).
Standard library only. Run from the plugin root:

    python3 tests/print_descriptions.py            # markdown list
    python3 tests/print_descriptions.py --check    # also flag convention problems
"""
import argparse
import pathlib
import sys


def read_frontmatter(path):
    """Return a dict of top-level scalar keys from a SKILL.md YAML frontmatter block."""
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines or lines[0].strip() != "---":
        return {}
    fields, key = {}, None
    for line in lines[1:]:
        if line.strip() == "---":
            break
        if line[:1] not in (" ", "\t") and ":" in line:
            key, _, value = line.partition(":")
            key = key.strip()
            fields[key] = value.strip().strip('"').strip("'")
        elif key and line.strip():  # folded continuation line
            fields[key] += " " + line.strip()
    return fields


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", default=".", help="plugin root (default: current folder)")
    parser.add_argument("--check", action="store_true", help="flag name/description problems")
    args = parser.parse_args()

    skills_dir = pathlib.Path(args.root) / "skills"
    files = sorted(skills_dir.glob("*/SKILL.md"))
    if not files:
        sys.exit(f"No skills found under {skills_dir}")
    problems = 0
    for f in files:
        fm = read_frontmatter(f)
        name, desc = fm.get("name", ""), fm.get("description", "")
        print(f"- **{name or '(missing name)'}**: {desc or '(missing description)'}")
        if args.check:
            issues = []
            if name != f.parent.name:
                issues.append(f"name '{name}' != folder '{f.parent.name}'")
            if not desc.startswith("Use when"):
                issues.append("description does not start 'Use when'")
            if len(desc) > 1024:
                issues.append(f"description {len(desc)} chars > 1024")
            elif not 300 <= len(desc) <= 550:
                issues.append(f"description {len(desc)} chars (target 300-550)")
            for issue in issues:
                print(f"    CHECK: {issue}")
            problems += len(issues)
    if args.check:
        print(f"\n{len(files)} skills, {problems} check notes")


if __name__ == "__main__":
    main()
