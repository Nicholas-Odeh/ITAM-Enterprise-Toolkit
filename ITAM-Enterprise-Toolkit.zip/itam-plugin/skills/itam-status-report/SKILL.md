---
name: itam-status-report
description: Use when writing an ITAM program or project status update, such as a weekly operations report, monthly steering pack, quarterly executive or audit-committee summary, refresh-wave or remediation progress report, or any red-amber-green (RAG) status for asset management work. Covers KPI tables keyed to metrics-catalog IDs, RAG rules, accomplishments, risks and issues, decisions needed and next priorities. Not for defining metrics or building dashboards (use itam-data-analysis-reporting) or assessing program maturity (use itam-program-governance).
---

# ITAM Status Report

A status report is a decision tool: in three lines the reader knows what is on track, what is not, and what they must decide. Every RAG rating is earned with evidence; every KPI is a catalog metric with a source and as-of date. Adapted from the Operations status-report structure, for ITAM program owners and project leads reporting upward.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **No green without evidence.** Apply `references/rag-rules.md`. A KPI with stale data, no data or no approved target cannot be green.
7. **KPIs by catalog ID.** Each KPI row cites its ID from `itam-data-analysis-reporting/references/metrics-catalog.md`, with numerator, denominator, as-of date and source.
8. **Bad news goes in the headline.** Every red and amber item appears in the executive summary.

## When to use

- Weekly, monthly or quarterly ITAM program reports; audit- or risk-committee updates.
- Project status: refresh waves, implementations, audit remediation, stockroom moves.
- Turning tracker, ticket or chat activity into a readable report.

**When not to use:** defining metrics, targets or dashboards (`itam-data-analysis-reporting`); governance design (`itam-program-governance`); audit readiness (`itam-risk-controls-audit`); change records (`itam-change-request`).

## Workflow

### Step 1: Classify

| Report | Template in `references/report-templates.md` |
|---|---|
| Weekly or monthly operations, project status | Operational |
| Monthly steering, quarterly leadership | Executive |
| Audit or risk committee | Audit-committee |

Always load `references/rag-rules.md`.

### Step 2: Preflight

Establish audience, period, scope and the previous report (trend, last period's commitments). Pick five to eight KPIs by catalog ID; take targets from the catalog's target register, or write "no approved target". Gather extracts with as-of dates, the risk and issue log, and pending decisions. If the audience is unclear, ask that one question.

### Step 3: Build

1. **KPIs:** value, numerator and denominator, as-of date, source, prior value, target, trend.
2. **RAG:** KPI, then workstream, then overall, per `rag-rules.md`; give a reason for every change since last period.
3. **Accomplishments:** completed and evidenced only; the rest is in progress.
4. **Risks and issues:** a risk may happen, an issue has happened; each has impact, mitigation, owner, date.
5. **Decisions needed:** context, options, recommendation, deadline, consequence of no decision.
6. **Next priorities:** three to five, each owned and dated.
7. Write the headline and executive summary last.

### Step 4: Verify before release

- ★ Every green cites its evidence: a fresh KPI value against an approved target, or a completed deliverable.
- ★ No stale, missing or untargeted KPI is green; staleness shows the as-of date.
- ★ Every KPI row has catalog ID, numerator, denominator, as-of date and source.
- ★ No target or figure is invented.
- ★ Last period's commitments are each shown as done, slipped or dropped.
- Reds and ambers appear in the summary; each decision has a recommendation and deadline.
- Material reports: the `itam-reviewer` agent has checked the draft.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "It's basically on track, call it green" | Green needs evidence. Amber with a recovery date is more useful. |
| "The data is old but nothing changed" | Stale data can't be green. Show it as stale with its as-of date. |
| "Leadership doesn't want red" | Early red with a plan gets help; amber-washing hides their decision. |
| "The tool says 98% compliant" | Which metric, population and as-of date? A tool score is a claim. |
| "No target set, I'll use 95%" | That's an invented target. Report the trend and "no approved target". |

Stop if you are about to: mark green without evidence; drop last period's red without its resolution; change a metric definition silently; post or send the report without approval.

## Common mistakes

| Mistake | Fix |
|---|---|
| Watermelon status: green outside, red inside | Roll up per `rag-rules.md`. |
| Activity lists instead of outcomes | Report outcomes against plan and KPIs. |
| KPI definition changed between periods | State the change and restate the baseline. |
| Decisions buried in narrative | Use the decisions table. |
| Twenty metrics for executives | Five to eight per audience. |

## If connectors are available

- `~~ITSM`, `~~CMDB`: read KPI source data (record the read time) and the period's changes.
- `~~project tracker`: read milestones, completed and overdue items.
- `~~chat`: scan channels for blockers and decisions; draft a post, send only after approval.
- `~~document repository`, `~~office suite`: read the prior report; save the draft.
- `~~email`: draft the distribution.

## Output format

1. Header: scope, period, author, date, audience, data as-of.
2. Headline and overall RAG with a one-line reason; executive summary, reds and ambers first.
3. KPI table; workstream or milestone status.
4. Accomplishments, then in progress.
5. Risks and issues; decisions needed.
6. Next-period priorities.
7. Data notes: sources, stale items, definition changes.

## Reference files

- `references/rag-rules.md`: RAG definitions, freshness test, roll-up and override rules; read for every report.
- `references/report-templates.md`: executive, operational and audit-committee templates with suggested KPI sets; read after classifying.
- `itam-data-analysis-reporting/references/metrics-catalog.md`: metric IDs, definitions and target register; read when choosing KPIs (read-only here).
