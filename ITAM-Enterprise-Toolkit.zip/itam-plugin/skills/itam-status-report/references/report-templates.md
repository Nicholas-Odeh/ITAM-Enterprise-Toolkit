# ITAM status report templates

Three variants: **executive** (steering, leadership; one page), **operational** (weekly or monthly, for the ITAM team and partner teams) and **audit-committee** (controls, findings and exposure). Each uses the RAG rules in `rag-rules.md` and KPIs by ID from `itam-data-analysis-reporting/references/metrics-catalog.md`.

**Basis:** section structure adapts the Operations plugin's `status-report` skill (executive summary, key metrics, accomplishments, in progress, risks and issues, decisions needed, next priorities). The audit-committee variant and the KPI sets are `PRACTICE`. Targets are organizational; where none is approved, write "no approved target".

## Contents
1. Suggested KPI sets by audience
2. Executive template
3. Operational template
4. Audit-committee template
5. Writing rules

## 1. Suggested KPI sets by audience

Pick five to eight. These are starting points (`PRACTICE`); choose what supports the audience's decisions.

| Audience | Suggested metric IDs |
|---|---|
| Executive / steering | M-INV-01, M-INV-03, M-LC-06, M-LC-08, M-LIC-01, M-FIN-02, M-FIN-05, M-GOV-03 |
| ITAM operations (weekly) | M-OPS-03, M-OPS-04, M-OPS-06, M-OPS-09, M-LC-01, M-LC-09, M-LC-15, M-OPS-11 |
| ITAM operations (monthly) | M-INV-02, M-INV-04, M-DQ-01, M-DQ-09, M-LC-04, M-LC-05, M-DIS-07, M-CMDB-05 |
| Audit / risk committee | M-GOV-01, M-GOV-02, M-GOV-03, M-GOV-04, M-GOV-05, M-DIS-02, M-DIS-05, M-LIC-01 |
| Refresh-wave project | M-LC-07, M-LC-08, M-OPS-03, M-OPS-06, M-LC-04, M-FIN-06 |
| Software / SAM | M-LIC-01, M-LIC-02, M-LIC-03, M-LIC-05 |

Fill a definition card (metrics catalog, "Definition card") for each KPI before its first report.

## 2. Executive template

```markdown
## ITAM Status: [Program] — [Period]
**Author:** [Name/role] | **Date:** [Date] | **Audience:** [Steering group] | **Data as-of:** [Range]

**Overall: [Green On track / Amber At risk / Red Off track / Grey Not rated]** — [one-line reason with evidence]

### Headline
[Three or four sentences. Reds and ambers first, each with the decision or help needed. Then the main win, with evidence.]

### Key metrics
| ID | Metric | Target | Actual (num/den) | As-of | Trend | RAG | Source |
|---|---|---|---|---|---|---|---|
| M-… | [Name] | [Band or "no approved target"] | [Value (n/d)] | [Date] | [▲ better / ▼ worse / ► / n/c] | [Rating + label] | [System, extract] |

### Decisions needed
| Decision | Why it matters | Options | Recommendation | Needed by | If no decision |
|---|---|---|---|---|---|

### Top risks and issues
| Risk/Issue | Type | Impact | Mitigation | Owner | Date |
|---|---|---|---|---|---|

### Next period
1. [Priority, owner, date]
2. …

*Data notes:* [stale items, definition changes, exclusions]
```

## 3. Operational template

```markdown
## ITAM Operations Status: [Team/Project] — [Week/Month]
**Author:** [Name/role] | **Date:** [Date] | **Data as-of:** [Range]
**Overall:** [Rating + label] — [reason]

### Executive summary
[Three or four sentences.]

### Key metrics
| ID | Metric | Target | Actual (num/den) | Prior | As-of | Trend | RAG | Source |
|---|---|---|---|---|---|---|---|---|

### Workstreams / milestones
| Workstream or milestone | Due | Forecast | RAG | Evidence / reason | Owner |
|---|---|---|---|---|---|

### Last period's commitments
| Commitment | Status (Done / Slipped / Dropped) | Evidence or new date |
|---|---|---|

### Accomplishments this period (evidenced)
- [Outcome] — [evidence: record, document, sign-off]

### In progress
| Item | Owner | Status | ETA | Notes |
|---|---|---|---|---|

### Risks and issues
| Risk/Issue | Type | Likelihood | Impact | Mitigation | Owner | Due |
|---|---|---|---|---|---|---|

### Decisions needed
| Decision | Context | Deadline | Recommendation |
|---|---|---|---|

### Changes in the period
| Change ID | What | Status | KPI effect expected |
|---|---|---|---|

### Next period priorities
1. [Priority, owner, date]

### Data notes
- Sources and extract times; stale KPIs; definition or population changes; exclusions with counts.
```

## 4. Audit-committee template

Language: report control status and evidence, not compliance verdicts. Say "aligned with" for frameworks; never "compliant" or "certified" without a formal basis (see `itam-operating-standard`). A control that exists is not a control that works: show test evidence.

```markdown
## ITAM Controls and Exposure: [Period]
**Prepared by:** [Role] | **Date:** [Date] | **Data as-of:** [Range]
**Overall:** [Rating + label] — [reason]

### Summary for the committee
[Three or four sentences: open findings past due, material exposure, decisions requested.]

### Control execution and evidence
| Control | Objective | Executed on schedule (M-GOV-01) | Evidence sampled (M-GOV-05) | Result | RAG |
|---|---|---|---|---|---|

### Audit findings and remediation
| Finding ID | Source (audit, date) | Rating | Action | Owner | Due | Status | Closure evidence |
|---|---|---|---|---|---|---|---|

Summary metrics: M-GOV-02 (exception aging), M-GOV-03 (on-time closure), M-GOV-04 (recurrence).

### Exposure
| Area | Metric | Value | As-of | Basis | Comment |
|---|---|---|---|---|---|
| Software license | M-LIC-01 | | | [ELP source and date] | [Not a vendor-audit position unless stated] |
| Unrecovered assets | M-LC-06, M-FIN-05 | | | [Valuation basis] | |
| Disposal evidence | M-DIS-02, M-DIS-05 | | | [Certificates reconciled?] | |

### Decisions or acceptances requested
| Item | Options | Recommendation | Risk if accepted |
|---|---|---|---|
```

## 5. Writing rules

- Lead with the headline; busy readers stop after three lines.
- Give numbers with their denominators: "42 of 310 leaver devices", not "most".
- One owner per action; use a role where names are not appropriate.
- Write a recommendation for every decision.
- Mark planned items as planned, not done; done needs evidence.
- Keep the executive variant to one page; move detail to the operational report.
