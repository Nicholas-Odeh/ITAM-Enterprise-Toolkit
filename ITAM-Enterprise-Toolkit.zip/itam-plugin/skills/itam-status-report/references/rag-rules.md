# RAG rules for ITAM status reports

These rules decide what color a KPI, a workstream and the overall report may show. They exist to stop "watermelon" reporting (green outside, red inside) and to keep every green backed by evidence.

**Basis:** `PRACTICE`. The ratings, freshness test and roll-up are this plugin's defaults. If the organization has its own RAG policy, record it in `templates/company-profile.md` (Governance) and use it instead, keeping rules R1–R4 below, which follow from the plugin's evidence rules. Thresholds marked `[FILL]` are organizational.

## Contents
1. Ratings
2. Non-negotiable rules (R1–R4)
3. KPI rating
4. Freshness test
5. Workstream and milestone rating
6. Roll-up and overrides
7. Trend notation
8. Worked examples

## 1. Ratings

| Rating | Text label (always shown with the color) | Meaning |
|---|---|---|
| Green | On track | Evidence shows the item meets target or plan, and no unmitigated red risk sits under it. |
| Amber | At risk | Off target or plan but recoverable within the team's own authority and resources, with a dated recovery action. |
| Red | Off track | Off target or plan and not recoverable without a decision, resource or escalation from outside the team; or a critical control has failed. |
| Grey | Not rated | Evidence is missing, stale, or there is no approved target. Not a pass. |

Always print the text label next to the color; color alone fails for color-blind readers and in black-and-white print.

## 2. Non-negotiable rules

- **R1 No green without evidence.** A green KPI cites a value, its as-of date and source, and an approved target it meets. A green milestone cites the completed deliverable (document, record, sign-off).
- **R2 Stale data cannot be green.** A KPI that fails the freshness test (§4) is Grey, or Amber if the organization's policy doesn't allow Grey.
- **R3 No target, no green or red against target.** A KPI with no approved target is Grey with its trend shown and the words "no approved target". Never invent a target.
- **R4 No silent upgrades.** Every rating that changes since the last report gives a one-line reason with evidence. A red can't go straight to green without the evidence that closed it.

## 3. KPI rating

1. Find the KPI's approved bands in the metrics catalog's target register (`itam-data-analysis-reporting/references/metrics-catalog.md`, §11). Respect direction: for a KRI, lower is better.
2. Apply the freshness test (§4). Fail → Grey (R2).
3. No approved bands → Grey (R3).
4. Otherwise rate by band. If only a single target exists (no amber band), use the organization's tolerance `[FILL]`; if none, Green at or better than target, Amber within `[FILL]` of it, Red beyond; state that the tolerance is `ASSUMPTION` and needs approval.
5. A value computed on a different population or definition than last period is rated, but marked "definition changed" and not compared for trend.

## 4. Freshness test

A KPI value is **fresh** when its as-of date falls within one cadence period of the end of the reporting period:

```
fresh  ⇔  (report_period_end − as_of_date) ≤ cadence_length + grace
```

- `cadence_length`: from the catalog entry (weekly = 7 days, monthly = 1 calendar month, quarterly = 3 months).
- `grace`: organizational `[FILL]`; default 0 (`PRACTICE`).
- The as-of date is the extract time of the source data, not the date the report was written.
- A value with no recorded as-of date fails the test.

Example: monthly KPI, report period ends 30 Sep, as-of 12 Aug → 49 days > 1 month → stale → Grey.

## 5. Workstream and milestone rating

| Rating | Milestone or workstream condition (`PRACTICE`; set thresholds `[FILL]`) |
|---|---|
| Green | Milestones due this period completed with evidence; next milestone forecast on date; material KPIs green; no open red risk or issue. |
| Amber | A milestone slipped by ≤ `[FILL]` days or is forecast to; or a material KPI is amber; or a risk needs attention but has a dated mitigation within the team's authority. |
| Red | A milestone slipped by > `[FILL]` days, or a critical path date is lost; or a material KPI is red; or a decision, budget or resource outside the team is needed; or a ★ control or audit commitment is missed. |
| Grey | Not started, or no plan or evidence to rate against. |

"Material" KPIs are the ones the report names as the workstream's measures. A workstream with a Grey material KPI can't be Green.

## 6. Roll-up and overrides

- **Default roll-up:** overall rating = the worst rating among material workstreams (Grey counts as "not green": overall can be at best Amber while a material item is Grey).
- **Override:** the report owner may set overall better than the worst component only with a written reason and the name of who approved it, printed in the report. Overall can never be set to Green while any material workstream is Red.
- **Audit-committee reports:** any open high-rated audit finding past its agreed date makes the controls workstream Red.

## 7. Trend notation

| Symbol | Meaning |
|---|---|
| ▲ better | Moved in the favorable direction by more than the noise threshold `[FILL]` |
| ▼ worse | Moved in the unfavorable direction by more than the noise threshold |
| ► flat | Within the noise threshold |
| n/c | Not comparable (definition or population changed) |

Always label "better" or "worse"; an up arrow on a KRI is ambiguous. For noise and anomaly methods, see `itam-data-analysis-reporting/references/kpi-trend-anomaly-methods.md`.

## 8. Worked examples

| KPI | Value | As-of vs. period end | Target register | Rating | Why |
|---|---|---|---|---|---|
| M-INV-02 reconciliation match rate (monthly) | 96.1% (9,612/10,002) | 3 days | Green ≥ 95%, Amber 90–95% | Green | Fresh, meets approved band |
| M-DIS-02 sanitization evidence rate (monthly) | 100% | 49 days | Green = 100% | Grey (stale) | R2: fails freshness |
| M-LC-04 leaver recovery rate (monthly) | 81% | 5 days | none approved | Grey (no target), ▼ worse | R3; flag as watch item |
| M-LC-06 unrecovered leaver devices (KRI) | 42 | 5 days | Green ≤ 20, Amber 21–40, Red > 40 | Red | Lower is better; above red line |

The figures in this table are illustrative only, to show the rules working.
