---
name: servicenow-itam
description: Use when the work is in ServiceNow IT Asset Management - alm_hardware or alm_asset records, HAM or HAM Pro, SAM Pro, a stockroom, transfer order, reclamation, loaner, RMA or disposal order, the Hardware Asset Workspace, asset-CI sync with the CMDB, ServiceNow Otto (Now Assist), SAM tables such as cmdb_sam_sw_install, alm_license, alm_entitlement_asset or samp_reconciliation_result, or queries and scripts on asset tables. Covers configuration, procedures, data checks and doc citations. Not for platform-neutral method (use itam-hardware-lifecycle; use itam-software-license-management for platform-neutral licensing).
---

# ServiceNow ITAM

ServiceNow behavior depends on release, installed apps and instance configuration, so every product claim cites a ServiceNowDocs page or is marked for checking. For asset managers, ServiceNow administrators and ITAM analysts.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Release and entitlement first.** State release family, installed apps and tier before steps; brazil-only behavior is `VERIFY` on older releases.
7. **Platform write safety.** Never delete a linked asset or CI (the other goes too) or use `setWorkflow(false)` (it skips asset-CI sync). Prefer the documented flow to a script.
8. **Cite the doc path.** Product facts are `DOC (<ServiceNowDocs path>)`; anything else is `PRACTICE`, or `VERIFY` with the check that settles it.

## When to use

- Asset records, states, stockrooms, orders; HAM processes from receiving to disposal; asset-CI sync, duplicates, orphans.
- SAM, SaaS and Otto as configured in ServiceNow; queries, scripts, imports, APIs, reports on asset tables.

**When not to use:** platform-neutral method (`itam-hardware-lifecycle`, `itam-software-license-management`, `itam-risk-controls-audit`), cloud spend (`itam-financial-management`), the change record (`itam-change-request`), production scripts (`itam-automation-scripting`).

## Workflow

### Step 1: Classify

| Request | Load |
|---|---|
| Investigate an asset; fields, states, substates | `ham.md` §2–3, `procedures.md` §1 |
| Receive, issue, transfer, stock rules, inventory audit | `procedures.md` §2–4, `ham.md` §4–5, §10 |
| Refresh, reclaim, loaner, repair/RMA, disposal, lease end | `procedures.md` §5–10, `ham.md` §6–8 |
| Stale, unlinked or duplicate devices; IRE; CMDB Health | `asset-ci-cmdb.md` |
| POs, models, contracts, leases, warranty | `contracts-procurement.md` |
| Licenses, reconciliation, publisher-audit data; SaaS | `sam.md`, `saas-license-management.md` |
| Financial regulatory audit (FFIEC) | `asset-audit-response.md` + `itam-risk-controls-audit` |
| Cloud spend | `cloud-cost-management.md`, then `itam-financial-management` |
| ServiceNow Otto (Now Assist) | `now-assist-ham.md`, `now-assist-sam.md` |
| Enterprise, OT or medical assets | `enterprise-asset-management.md` |
| Queries, scripts, imports, APIs, reports | `query-script-patterns.md` |
| Find a doc page; another release | `doc-index.md`, `sources.md` |

### Step 2: Preflight

Read `instance-profile.md` (from `instance-profile-template.md`) and `templates/company-profile.md` if present. Establish release and patch, UI (Workspace or Core UI), apps and tier (`v_plugin`, order form), custom states or mappings, and read-only versus write.

### Step 3: Do

1. Read-only route first (`procedures.md` §1); count the problem with a copied encoded query.
2. Follow the documented flow: each step's state, substate, CI effect and DOC path.
3. Take field names and choice values from `sys_dictionary` and `sys_choice`.
4. SAM: walk the `sam.md` chain before trusting a result. Writes: `query-script-patterns.md` §5.

### Step 4: Verify before release

- ★ Every table, field, role, property and plugin has a DOC path or `VERIFY` plus its check.
- ★ Release, apps and tier stated.
- ★ Every write: dry run, numeric cap, snapshot, rollback, approval note.
- ★ No "fixed", "reconciled" or "disposed" without a re-query or certificate.
- Queries bounded; filters use state and substate together.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The CI will follow" | Only linked, mapped pairs sync. Re-query both. |
| "In use is state 1" | Values vary; read `sys_choice`. |
| "Delete the duplicate" | Its linked record goes too. Retire or unlink. |
| "Compliant, so no exposure" | ELA/ULA agreement types force Compliant; "No software model" is not no exposure. |
| "Reclamation asks the user" | Restricted and Unlicensed candidates proceed unasked; SaaS reclaim can delete accounts and data. |
| "The AI only suggests" | Otto agents allocate, raise POs and reclaim; SAM auto-approval defaults to USD 1,000. Gen-AI skills are on by default; data may leave the region. |
| "Just switch it on" | Content Service opt-in sends data, including instance and customer names for SAM custom products. The Cloud Cost Infra Stack can't be deactivated. |

Stop if you are about to write without a dry run, call an asset disposed without disposal-order and certificate evidence, or activate reclamation or agentic workflows unapproved.

## Common mistakes

| Mistake | Fix |
|---|---|
| Citing a forum post, old release or memory | Cite the path; check with `python3 scripts/extract_servicenow_docs.py <clone> --check-citations references`. |
| Assuming what "HAM Pro" includes | Tier boundaries are `VERIFY`. Check the order form. |
| Counting straight after an import | Check the Asset Creation Queue first. |
| Inserting CIs through the Table API | Use IRE. |

## If connectors are available

- `~~ITSM`: read lists, aggregates, `sys_choice`, `sys_dictionary`, `sys_properties`, `v_plugin`; draft, never submit, orders and changes.
- `~~CMDB`: read linked CIs, relationships, CMDB Health results.

## Output format

1. **Goal**. 2. **Applicability**: release, UI, apps, tier, roles, read-only or write, assumptions. 3. **Steps**: state, substate, CI effect, `DOC` path. 4. **Validation**: proving queries or counts. 5. **Risks and rollback**. 6. **Sources**: paths, release, open `VERIFY` items.

## Reference files

- `references/ham.md`: HAM data, states, flows, licensing, roles, properties, canonical-state mapping. Read for any HAM question.
- `references/procedures.md`: ten procedures with state effects. Read before giving steps.
- `references/asset-ci-cmdb.md`: asset-CI sync, IRE and CMDB Health.
- `references/query-script-patterns.md`: checks, queries, APIs, the safe-write pattern and imports.
- `references/contracts-procurement.md`: catalog, procurement, receiving, contracts and leases.
- `references/enterprise-asset-management.md`: EAM and OT assets.
- `references/now-assist-ham.md`: ServiceNow Otto for HAM.
- `references/sam.md`: SAM data chain, entitlements, reconciliation, remediation, publisher packs.
- `references/saas-license-management.md`: SaaS subscriptions, integrations, usage, reclamation.
- `references/cloud-cost-management.md`: Cloud Cost Management scope and links.
- `references/asset-audit-response.md`: financial regulatory audits.
- `references/now-assist-sam.md`: ServiceNow Otto for SAM.
- `references/asset-data-model.md`: shared canonical fields and states. Read when mapping states.
- `references/instance-profile-template.md`: what to record about an instance.
- `references/doc-index.md`: topic to doc page.
- `references/sources.md`: source commit, open `VERIFY` items, refresh steps. Read when the release changes.
- `scripts/extract_servicenow_docs.py`: offline index and citation check (`--help`).
