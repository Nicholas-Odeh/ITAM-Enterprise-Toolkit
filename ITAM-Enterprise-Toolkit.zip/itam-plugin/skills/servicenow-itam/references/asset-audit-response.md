# ServiceNow Asset Audit Response reference

**Labels.** `DOC` = official ServiceNow docs, summarized. `PRACTICE` = practitioner method. `VERIFY` = not confirmed; check in the instance.

**Source convention.** `DOC aar/<file>` = `markdown/it-asset-management/asset-audits/<file>`, `DOC sam/<file>` = `.../software-asset-management/<file>` in github.com/ServiceNow/ServiceNowDocs, branch `brazil`, as checked 2026-10-20 (all pages `last_updated` 2026-09-10).

## Read this first: what it is for

- **Asset Audit Response** is part of **ITAM for Financial Services**. It gives prescriptive workflows for **financial regulatory audits** (DOC aar/asset-audit-response.md). Its worked example starts with an audit letter from a financial regulator such as the **FFIEC** (DOC aar/exploring-asset-audit-response.md).
- The docs do **not** describe it as a tool for **publisher or vendor license audits** (Microsoft, Oracle, IBM and so on). They say nothing about audit clauses, scope negotiation, auditor scripts or settlements.
- What it offers is a general way to request evidence, collect it, find data gaps and fix them. You can borrow that structure for a publisher audit (section 5). Treat that use as `PRACTICE`, not product intent.
- For a publisher audit, use the `itam-software-license-management` playbook (`references/audit-response.md`). For regulatory and internal audits, use `itam-risk-controls-audit` (`references/audit-readiness.md`).

## Contents
1. Install and dependencies
2. Users, roles and tables
3. Documented workflow
4. Asset Response Guided Experience
5. Mapping to the publisher audit-response playbook
6. SAM features that serve a publisher audit
7. AI, data handling and domain separation
8. Cautions

## 1. Install and dependencies

- The application is `com.sn_audit_response`, installed by `admin` from All Available Applications. **SAM or HAM must already be installed** (DOC aar/install-asset-audit-response.md).
- It also installs these GRC store apps (DOC aar/installed-with-asset-audit-response.md):
  - GRC: Advanced Core (`com.sn_grc_advanced`)
  - GRC: Policy and Compliance Management (`com.sn_compliance`)
  - GRC: Audit Management Workspace (`com.sn_audit_workspace`)
  - IRM Feature Role (`com.sn_grc_ftr_role`)
  - GRC: Financial Services Controls Accelerator (`com.sn_finserv_cntrl`)
- Licensing impact: installing it pulls in GRC entitlements. Confirm with the account team before you install it in production (`VERIFY`).
- Regulatory content: requirements supported since before Australia ship in the base app. Requirements added from Australia onward need the **Unified Content Management** store app (DOC aar/audit-workspace.md).

## 2. Users, roles and tables

| Role | Who | Contains (DOC aar/installed-with-asset-audit-response.md) |
|---|---|---|
| `sn_audit_response.grc_asset_audit_manager` | Audit manager: creates engagements, activities, evidence requests, entity scopes | `sn_audit.shared_manager`, `sn_grc_advanced.evidence_requester` |
| `sn_audit_response.asset_governance` | Asset manager: fulfills evidence requests | `sn_grc_advanced.evidence_responder`; `sam_user` if SAM is installed; `sn_hamp.ham_user` and `asset` if HAM is installed |

Tables (same source):
- `amg_asset_evidence`: evidence records
- `amg_asset_evidence_task`: asset evidence tasks, one per evidence request assigned to the asset manager
- `amg_evidence_remediation_rule`: remediation rules
- `amg_evidence_remediation_task`: generated remediation tasks

Workspaces:
- **Audit Workspace**, for the audit manager (DOC aar/audit-workspace.md).
- **Asset Governance Workspace**, for the asset manager. Its **Asset governance overview** shows widgets for evidence tasks, evidence and remediation tasks (DOC aar/asset-governance-workspace.md, aar/asset-governance-overview.md).

## 3. Documented workflow

Paraphrased from DOC aar/exploring-asset-audit-response.md:

1. A regulator's audit letter arrives. The audit manager creates an **engagement** in the Audit Workspace.
2. The audit manager creates an **evidence request** and assigns it to the asset manager.
3. The asset manager accepts it in the Asset Governance Workspace. The asset manager then creates **evidence records** and assigns them to team members.
4. The asset manager defines **remediation rules** to catch data gaps.
5. Team members collect the evidence. The asset manager tracks progress.
6. Remediation tasks are **generated automatically** from the rules. The asset manager resolves or defers each one.
7. The asset manager approves the evidence and submits it to the audit manager.
8. The audit manager reviews it and then accepts it, cancels it, asks for a revision or asks for more information (DOC aar/fulfill-evidence-requests-guided-experience.md).
9. The audit manager reports findings to the regulator.

## 4. Asset Response Guided Experience

DOC aar/fulfill-evidence-requests-guided-experience.md. The role required is `sn_audit_response.asset_governance`. You must finish each step before you can move to the next one, and you can save at any point.

| Step | What happens |
|---|---|
| Audit scope | Verify the request and **Accept** it. Comments and the activity stream are in the side panel. |
| (side panel) Asset Evidence | Create evidence records. **Evidence type** is one of Attachment, Data Visualization, Report or URL. Each record has an assignment group and person. The assignee uploads the evidence and sets Status to Complete. |
| (side panel) Evidence Remediation Rules | Each rule has an **Evidence scope** (a table, e.g. Computer), a **Scope filter** and a **Scope condition** for creating tasks. It also has a Resolution and an assignment. |
| Readiness | Widgets: task analytics by priority, total assets evaluated by compliance status, evidence list, remediation tasks with the records each one affects. |
| Remediation | Task analytics, task **burndown**, and a resolve-or-defer decision for each task. |
| Review | Approve all evidence. All collection must be complete before approval. |
| Submit for review | Sends the evidence to the audit manager. |

## 5. Mapping to the publisher audit-response playbook

The playbook phases are in `itam-software-license-management/references/audit-response.md`. "None" means you must cover that phase outside this application.

| Playbook phase | Asset Audit Response element | Fit |
|---|---|---|
| 0 Receive | Audit engagement in the Audit Workspace | Partial. The engagement can be the case record. Letter metadata and deadlines are fields you add yourself (`PRACTICE`). |
| 1 Triage (audit clause, entities, notice limits) | None | Keep this in Legal and contract records (`itam-vendor-contract-management`). |
| 2 Preserve | None | Legal hold and any change freeze sit outside the app. |
| 3 Scope and terms | Engagement entity scope; evidence request description | Partial. The scoping is meant for GRC entities, not for agreeing the auditor's products, period or script. |
| 4 Internal position first | Evidence records of type Report or Data Visualization pointing at SAM reports (section 6). Remediation rules that flag data gaps, e.g. servers with no install data. | Good structural fit. The ELP itself comes from SAM reconciliation, not from this app. |
| 5 Data provision | Approve evidence, then Submit for review; activity stream | Partial. It records what was approved internally. It does **not** record what was sent to the auditor, so keep the playbook's data release log. |
| 6 Review findings | None | Reconcile the auditor's draft against the internal ELP outside the app. |
| 7 Settle | None | Procurement and Legal. |
| 8 Close | Remediation tasks: resolve or defer, burndown | Good fit for tracking root-cause fixes and data-quality fixes. |
| Audit response log | Activity stream, evidence records, approvals | Partial. Outbound communications to the publisher still need the playbook's log format. |

`PRACTICE`: If the organization already owns ITAM for Financial Services, reusing these records for a publisher audit gives traceable evidence and remediation. Do not buy or install the app only for publisher audits. Its scope, roles and GRC dependencies are built for regulatory audits.

## 6. SAM features that serve a publisher audit

These are documented SAM capabilities. They are separate from Asset Audit Response.

- **License position:** the SAM reconciliation results, the License Workbench and the license position reports (see `sam.md` sections 9 to 11).
- **Microsoft:** the **Microsoft Server Infrastructure and License Consumption** report shows clusters, hosts, VMs, cloud (BYOL or license-included), cross-licensed products and unlicensed installs with reasons. It can be exported to Excel and is refreshed weekly by the job *SAM - Generate Microsoft Infra Licensing Report* (DOC sam/device-license-consumption-report.md).
- **Oracle:**
  - Oracle asks for script-collected usage data during audits. Discovery uses **Oracle-verified patterns** to collect the same data (Oracle GLAS data collection), so you can track compliance before an audit (DOC sam/oracle-publisher-pack.md).
  - Partitioning, cloud and multitenant licensing rules are in the same pack.
  - The documented metrics are NUP (with edition minimums), Per Processor (with the core factor) and Employee (Java SE Universal).
- **VMware:** the VMware dashboard has an **Audit View** (DOC sam/dashboard-vmware.md). Its contents are `VERIFY`.
- **Engineering applications:** concurrent-usage data from OpenLM and Open iT is positioned as supporting audits and renewals (DOC sam/concurrent-licenses.md).

`PRACTICE`: Before releasing any of this data to an auditor, check it against the agreed scope (playbook phase 5). The reports hold more than an auditor is entitled to see.

## 7. AI, data handling and domain separation

- **Summarize evidence** is a generative AI skill available after you accept a request. It summarizes the request overview, evidence records, remediation rules and tasks, and activity. It is **on by default**. If you turn it off, it stays off until you turn it on again by hand (DOC aar/fulfill-evidence-requests-guided-experience.md).
- The AI page warns about the following (DOC aar/ai-in-asset-audit-response.md):
  - Outputs may be inaccurate.
  - Data is transferred to a central ServiceNow environment, possibly in another region and possibly to a third-party cloud such as Azure.
  - ServiceNow collects inputs, outputs and edits to improve its models, including legal request or legal matter information. An opt-out is available.
  - Some features are unavailable for in-country SKUs, FedRAMP, NSC DOD IL5, IRAP-Protected, self-hosted and Regulated Markets.
- **Domain separation:** Basic support (DOC aar/asset-audit-response-domain-separation.md).

## 8. Cautions

- Do not present Asset Audit Response as a publisher-audit product. The docs scope it to financial regulatory audits.
- Audit evidence can be legally privileged. Before running the AI summary on evidence for a contested audit, check with Legal on the data transfer and data collection terms. Turn the skill off for that work if needed (`PRACTICE`).
- Remediation rules create tasks automatically. Agree the scope filter with the asset team before you activate a rule, so you do not flood the queue (`PRACTICE`).
- During an active audit, fixing data creates the risk of altering records. Follow the playbook's preserve phase and record why each change was made (`PRACTICE`).
