# ServiceNow Software Asset Management (SAM) reference

**Labels.** `DOC` = official ServiceNow product documentation, summarized. `PRACTICE` = practitioner method, not product behavior. `VERIFY` = not confirmed in the docs read; check the user's instance before relying on it.

**Source convention.** `DOC sam/<file>` means `markdown/it-asset-management/software-asset-management/<file>` in github.com/ServiceNow/ServiceNowDocs, branch `brazil`, as checked 2026-10-20 (frontmatter `release: brazil`; most pages `last_updated` 2026-09-10). `saas/` = `.../saas-license-management/`. Behavior on earlier releases (Zurich, Yokohama, Xanadu) can differ: state the user's release and treat brazil-only behavior as `VERIFY` on older instances.

**UI note.** From Brazil, the SAM classic UI gets limited support; the Software Asset Workspace is the intended interface (DOC sam/c_SoftwareAssetMgmt.md).

Related references: `saas-license-management.md`, `now-assist-sam.md`, `asset-audit-response.md`, `cloud-cost-management.md`.

## Contents
1. Products, plugins and roles
2. The SAM data chain
3. Core tables
4. Software discovery sources
5. Normalization and the Content Service
6. Software models, entitlements and license types
7. License metrics
8. Allocations
9. Reconciliation: scheduling, results, properties
10. Remediation options
11. Software Asset Workspace, License Workbench and reports
12. Removal candidates and reclamation (installed software)
13. Software Spend Detection
14. Publisher packs
15. Other capabilities in brief
16. Troubleshooting a wrong license position
17. Documentation inconsistencies to verify

## 1. Products, plugins and roles

| Component | ID | What the docs say | Source |
|---|---|---|---|
| SAM Professional | `com.snc.samp` | Separate subscription; activated by ServiceNow personnel; not visible in the plugin list after activation; upgrading from `com.snc.software_asset_management` cannot be reverted | DOC sam/t_RequSoftwareAssetMgmt.md |
| SAM Pro + workspace bundle (Brazil) | `com.sn_samp_master_ws` | Loads `com.sn_samp_master` and the Software Asset Workspace store app `sn_sam_workspace` | DOC sam/sam-installed-components.md |
| Pre-Brazil bundle | `com.sn_samp_master` | Loads `com.snc.samp`, all publisher pack add-ons and `com.sn_samp_workbench` | same |
| SAM store application | `com.sn_itam_samp` | Holds reconciliation script includes from Yokohama; auto-activated with `com.sn_samp_master` or SAM Foundation `com.snc.sams` | DOC sam/c_SAMReconciliation.md |
| ITSM (basic) SAM | `com.snc.software_asset_management` | Migration to SAM Pro needs manual steps; table labels change (below) | DOC sam/c_SAMMigration.md |
| SaaS License Management | `sn_sam_saas_int` | Store app; requires `com.snc.samp` | DOC sam/sam-installed-components.md |
| Software Spend Detection | `com.sn_sam_spend` | Requires `com.snc.samp` | same |
| ML normalization | `com.sn_sam_ml_normalization` | Optional machine-learning normalization | DOC sam/sam-normalization.md |
| File Signature Normalization | `com.snc.file_signature_normalization` | Normalizes discovered file signatures | DOC sam/sam-installed-components.md |
| Client Software Distribution | `com.snc.orchestration.client_sf_distribution` | SAM Pro buyers are licensed for **uninstall (reclamation) only**; install needs more licensing | same |
| SCCM usage plugins | `com.snc.samp_usage_sccm`, `com.snc.samp.usage_sccm_2016` | Marked for deprecation; new SCCM integrations should use the Service Graph connector for Microsoft SCCM | same; sam/sam-software-discovery.md |
| Publisher packs | see §14 | Add-on plugins | DOC sam/sam-publisher-packs.md |
| ServiceNow Otto (Now Assist) for SAM | `sn_now_assist_sam` | See `now-assist-sam.md` | DOC sam/supporting-information-now-assist-sam.md |

- Install via Product Hub (guided) or the ServiceNow Store (DOC sam/installing-sam-app.md). After first install or upgrade from basic SAM, run **Revert Customizations** so all features work (DOC sam/t_RequSoftwareAssetMgmt.md).
- ServiceNow prices SAM itself in Subscription Units across five Managed IT Resource categories: Server, End User Computing Device, SaaS Subscription User, PaaS Resources, IaaS Storage (DOC sam/sam-subscription.md). This is the customer's ServiceNow license, not their publisher position.

**Roles** (DOC sam/sam-installed-components.md unless noted)

| Role | Purpose | Contains |
|---|---|---|
| `sam_admin` | Full SAM access; needed to import entitlements, manage reclamation rules, create custom products and pattern normalization rules, set up Content Service | `sam_user`, `sam_spend_import`, `asset`, `model_manager`, `contract_manager` |
| `sam_user` | All SAM features except administrative ones; views reconciliation results (DOC sam/c_SAMReconciliation.md); can run reconciliation in the workspace (DOC sam/run-recon-workspace.md) | `pa_viewer`, `cmdb_read`, `report_user`, `sn_remote_dir_sync.reader` |
| `sam_developer` | Script privileges comparable to a system administrator; creates custom license metric scripts (DOC sam/add-custom-license-metric.md); enables third-party discovery (DOC sam/configure-third-party-discovery.md) | `sam_admin` |
| `sam_integrator` | Creates and manages SaaS integration profiles | `sam_user`, `connection_admin`, `flow_operator` |
| `sam_spend_import` | Imports financial transactions for Spend Detection; cannot see SAM without more roles | `pa_viewer` |

Configuration Console access needs `sam_admin` plus `sn_ia_config.ia_user` (DOC sam/config-console-sam.md). Only `sam_admin` sees the Software Asset Job Result `[samp_job_log]` and Asset Job Log alerts (DOC sam/sam-workspace-landing.md).

## 2. The SAM data chain

```
Discovery source (ServiceNow Discovery patterns, SCCM / Service Graph connector,
  Agent Client Collector, third-party tools via IRE API)            → §4
  → Software Installation [cmdb_sam_sw_install]   key: Publisher + Display name + Version
  → Software Discovery Model [cmdb_sam_sw_discovery_model]   created automatically;
        normalized Publisher / Product / Version / Edition stored here   → §5
  → Software Model [cmdb_software_product_model]   set by "SAM – Discovery Model to
        Software Model matching"                                       → §6
  → Software Entitlement [alm_license]   rights, license metric, license type
  → Allocations [alm_entitlement_asset] / [alm_entitlement_user] / [alm_entitlement_group]
  → Reconciliation (scheduled, weekly by default, or on demand)       → §9
  → Reconciliation Result [samp_reconciliation_result]
       → Product Result [samp_product_result]
       → Software Model Result  (table name VERIFY)
       → License Metric Result [samp_license_metric_result]
  → Removal Candidate [samp_sw_reclamation_candidate]                 → §12
Subscriptions (SaaS/SSO) enter as Software Subscription [samp_sw_subscription] → saas-license-management.md
```

DOC: software models tie installations (software used) to entitlements (software owned); entitlements carry the license details (DOC sam/c_SAMOverview.md). Discovery-model and matching details: DOC sam/c_DiscoveryModels.md, sam/swmodel-swinstall-rel.md.

## 3. Core tables

| Table | Label / purpose | Source |
|---|---|---|
| `cmdb_sam_sw_install` | Software Installation; populated by discovery | DOC sam/sam-software-discovery.md |
| `cmdb_sam_sw_discovery_model` | Software Discovery Model; holds normalized columns and the matched software model | DOC sam/sam-normalization.md |
| `cmdb_software_product_model` | Software Model | DOC sam/deduplication-rule.md |
| `alm_license` | Software Entitlement (labelled Software License before SAM Pro) | DOC sam/c_SAMMigration.md |
| `alm_entitlement_asset` | Device Allocations (was Device Entitlement) | same |
| `alm_entitlement_user` | User Allocations (was User Entitlement) | same |
| `alm_entitlement_group` | Group Allocations | DOC sam/create-group-allocations.md |
| `samp_reconciliation_result` | Reconciliation Result (one per run) | DOC sam/sam-workspace-landing.md |
| `samp_product_result` | Product Results; source of true-up, over-licensed and compliance widgets | same |
| `samp_license_metric_result` | License Metric Results; source of the Software Spend widget | same |
| `samp_sw_reclamation_candidate` | Removal Candidate | same |
| `samp_sw_usage` | Software Usage; tracks usage to product level, not version or edition | DOC sam/view-sw-usage-workspace.md |
| `samp_sw_subscription` | Software Subscription (SaaS and SSO) | DOC saas/map-user-data.md |
| `samp_sw_resource_value` | Resource Value, used by consumption and custom metrics | DOC sam/c_SAMLicenseMetrics.md |
| `samp_entitlement_import` / `samp_bulk_import` | Entitlement import errors / entitlement import jobs | DOC sam/sam-workspace-landing.md |
| `samp_normalization_suggestions` | Normalization suggestions | same |
| `samp_install_unlicensed_reason`, `samp_entity_unlicensed_reason` | Reasons an entity is unlicensed | DOC sam/sam-workspace-workbench.md |
| `samp_job_log` | Software Asset Job Result | DOC sam/sam-workspace-landing.md |
| `sam_content_audit` | SAM Content Audit (content updates applied) | DOC sam/sam-content-updates.md |

The Software Model Results table and any `samp_*` table not listed here: `VERIFY` in `sys_db_object` before naming it.

## 4. Software discovery sources

- **ServiceNow Discovery** populates installs using patterns; base patterns used by SAM include Citrix XenApp and XenDesktop, VMware vCenter, Microsoft SQL Server, Microsoft Exchange Server and Oracle Database. A business rule links each install to an existing discovery model or creates one (DOC sam/sam-software-discovery.md).
- **Microsoft SCCM**: legacy 2012 v2 / 2016 integration and usage plugins are documented with deprecation notices; first-time integrations should use the Service Graph connector for Microsoft SCCM, and the Migration Readiness Tool prepares existing users (DOC sam/sam-software-discovery.md). The notice text still names Tokyo as the deprecation release: `VERIFY` current support status.
- **Agent Client Collector** collects inventory and usage from laptops and isolated networks without credentials or schedules (DOC sam/sam-agentclientcollector.md).
- **Third-party tools** send payloads through the IRE REST API. A `sam_developer` enables property `com.snc.samp.ire.datasource.integration`; include the CI `sys_class_name` so the CI is not reclassified. Generic payload for installs; Oracle, VMware and Citrix have their own payloads. Under domain separation, send the payload from the domain where the CIs live (DOC sam/configure-third-party-discovery.md, sam/third-party-discovery-sam.md).
- **Publisher-specific feeds** (each documented separately): IBM ILMT / BigFix Inventory, IBM Authorized SAM Provider (Anglepoint), SAP connections, OpenLM and Open iT for engineering licenses, CrowdStrike (titles in sam/).
- **Duplicates across sources**: if multiple sources report the same install with different values, separate records are created; the **SAM - Deduplicate Install Table** job keeps one record active and marks the rest inactive. For IBM, ServiceNow Discovery records win over authorized SAM provider records (DOC sam/third-party-discovery-sam.md, sam/deduplicating-software-installations-sam.md). Custom deduplication rules: DOC sam/deduplication-rule.md.
- **Exclusions and deletions that change counts**: discovery models are not created for installs whose name contains `Security Update` (DOC sam/c_DiscoveryModels.md). Property `com.snc.samp.exclude_device_flag` names a true/false field on `cmdb_ci_hardware` that excludes a device's software (DOC sam/sam-properties.md). If a CI's status becomes Retired or Stolen, its installations are deleted (DOC sam/view-sw-usage-workspace.md). Setting a software asset to Retired or Missing removes its installation without creating a removal candidate (DOC sam/c_SAMOptimization.md).

## 5. Normalization and the Content Service

- Normalization compares discovered publisher, product, version and edition against the SAM Content Library and writes matches to the **discovery model's** normalized columns (DOC sam/sam-normalization.md). It runs automatically when a new discovery model is created (DOC sam/c_DiscoveryModels.md) and daily through **SAM - Normalize discovery models using content library rules**; **SAM - Discovery Model Normalization job** updates trend charts (DOC sam/sam-normalization.md).
- **Statuses**: New, Normalized, Partially Normalized (publisher + product), Publisher Normalized, Match Not Found, Manually Normalized (DOC sam/normalization-status.md).
- **Rule types**: Product Map / Package Map (one rule per discovery model), pattern, enhanced pattern, wide-net (property `com.snc.samp.wide_net_normalization.enabled`, on by default) and machine learning (property `com.snc.samp.enable.ml_normalization`, on by default) (DOC sam/sam-normalization.md, sam/sam-properties.md).
- **Manual work**: manual normalization is allowed for Partially Normalized, Publisher Normalized and Match Not Found models; revert sets Match Not Found; Manually Normalized and pattern-rule results cannot be reverted; suggestions can be accepted or rejected (DOC sam/sam-normalization.md).
- **Content Service** (DOC sam/c_SAMContentService.md): opt-in, **off by default**. Sharing unnormalized data improves your content. Each data type can be toggled; records can be excluded with **Exclude from content service**. Custom software products also send the **instance name and customer name**. In NSC DOD IL5 deployments data flows only from ServiceNow to the customer, so missing products need a content request. You still receive updates after opting out.
- **Content updates** arrive twice a week; **SAM - Apply latest content changes** applies them and **SAM - Create suites for a software model** propagates suite and lifecycle changes. Clearing **Allow automated content updates** on a software model protects it. A publisher rename does not update existing software models. Custom products and custom discovery maps are untouched. Changes are logged in `sam_content_audit` (DOC sam/sam-content-updates.md).
- PRACTICE: record the Content Service opt-in decision with the data owner and privacy lead. Report the share of installs fully normalized, by publisher. The Software installs normalization status widget gives counts (DOC sam/sam-workspace-landing.md).

## 6. Software models, entitlements and license types

- **Software model** = profile of what was purchased; **discovery model** = what was found; many discovery models can map to one software model (DOC sam/c_DiscoveryModels.md, sam/software-models-and-entitlements.md).
- **Matching** (DOC sam/swmodel-swinstall-rel.md): the job matches the most specific model, falling back to the most generic. A model with an install condition is not a match, so a model without the condition is created automatically. Setting the model by hand clears **Automatically matched**, and the job then leaves it alone.
- **Automatic model creation**: `com.snc.samp.automaticsmrcreation` creates a non-compliant software model for unlicensed installs, subscriptions or options of licensable products without an entitlement, so they show in the License Position report. `com.snc.samp.automaticsmcreation` does the same for not-licensable products (default No) (DOC sam/sam-properties.md).
- **Entitlement import**: a publisher part number (PPN) is matched to the Content Library; without one, the system matches on publisher, product, version, edition, platform and language, then relaxes platform and language; failures create import-error records such as `PPN and SM not found`. Microsoft License Statement (MLS) imports do not search without a PPN. Step-up applies only to Microsoft. Contractual Microsoft durations need start and end dates (DOC sam/software-models-and-entitlements.md).
- **License types and reconciliation impact** (DOC sam/license-types-impact-reconciliation.md): Perpetual; Perpetual + Software Assurance (SA benefits applied automatically); Subscription; Perpetual + Maintenance; Upgrade and Step-up (link through **Upgraded Entitlements**); Subscription Step-up; **SA** and **Maintenance** entitlements are **not reconciled unless linked to a base perpetual entitlement**; Microsoft 365 **Add-on** and **From SA** must be linked to a perpetual Office license with active SA.
- **Agreement type**: when the agreement type is Enterprise License Agreement (ELA) or Unlimited Level Agreement (ULA), as the docs name them, the software model result shows **Compliant even with unlicensed installs or subscriptions** (DOC sam/t_ViewSWModelResults.md). Check agreement scope against the contract before reporting "compliant".
- Also documented: downgrade rights (sam/downgrade-rights.md), suites and suite inference (`com.snc.sam.auto_suite_inference`, default false), unlimited licenses (sam/unltd-allocations-rights.md), consumption rules and product install conditions (sam/operations-workspace.md).

## 7. License metrics

- License metrics belong to **metric groups**, are set on entitlements and drive reconciliation. Publisher metric groups appear only when that pack is installed. SaaS License Management adds the Subscription and Consumption groups (DOC sam/c_SAMLicenseMetrics.md).
- **Common group**: Per Core (CPU core count × CPU count), Per Device, Per Named Device and Per Named User (**allocations required**), Per Processor (CPU count), Per User, User CAL, Device CAL, User/Device CAL, Resource Consumption, Concurrent User. Resource Consumption and Concurrent User need a Resource Value record (DOC sam/c_SAMLicenseMetrics.md).
- **Definitions as documented**: Per Device "licenses a device for the number of installations"; Per User "licenses a user for the number of installations". How several installs for one user aggregate into rights: `VERIFY` using **Licenses Required By** for a known user (DOC sam/explanation-rights-post-recon.md shows the Per Device arithmetic: licensable installs ÷ maximum installs per right, minimum 1).
- Tier-based metrics sum per-tier factors and round up (worked example in DOC sam/explanation-rights-post-recon.md).
- **Custom license metrics**: `sam_developer` creates or modifies the script and `sam_admin` can read it; source table is installs or Resource Value; ranks set reconciliation order. They run unless `com.snc.samp.recon.enablecustommetrics` is set to No (default Yes) (DOC sam/add-custom-license-metric.md, sam/sam-properties.md).
- PRACTICE: the docs list each pack's metrics, but the user's contract decides how a metric applies. Never state publisher rules from memory. Cite the pack page and the contract, or label `VERIFY`.

## 8. Allocations

- Allocations reserve rights to a device, user or group, lock license assignment between runs, or override the default assignment, for example host-level instead of VM-level SQL Server (DOC sam/allocation-management-sam.md).
- Device allocation **Quantity defaults to 1** (DOC sam/create-device-allocation.md). Copying an allocation that already exists on the target increments its quantity (DOC sam/copy-allocations.md). During migration from basic SAM, duplicate allocations are aggregated into one record with a quantity (DOC sam/c_SAMMigration.md). PRACTICE: count rights as the sum of Quantity, not the number of allocation records.
- For core-based allocation, leaving Quantity blank or below the machine's core count uses the actual core count; a higher value is used and the surplus shows as **Allocated not in use** (DOC sam/allocation-management-sam.md).
- Allocation isn't required for subscription products. Allocate to hosts or VMs, never to the cluster object; cluster allocations, and SQL Server Standard at host level, show as Allocated not in use (same).
- Result columns: Allocated in use, Not allocated in use, Allocated not in use (wasted rights), Not allocated, Allocations needed (Per Named User / Per Named Device only) (DOC sam/t_ViewSWModelResults.md).

## 9. Reconciliation: scheduling, results, properties

- **Schedule**: a scheduled job, **weekly by default**; on demand for one, several or all publishers, with optional group and subgroup (None, Country, Department, Company, Region, Cost Center). Defaults for the weekly run are `com.snc.samp.recon.group` and `com.snc.samp.recon.subgroup`; apart from None they must differ (DOC sam/c_SAMReconciliation.md, sam/sam-properties.md).
- The reconciliation job's exact name is not given in the brazil pages read. List SAM jobs with the filter `Name starts with SAM` (DOC sam/sam-installed-components.md) and confirm the schedule (`VERIFY`).
- **Scope**: runs for products that have entitlements or installs. Narrow by publisher for speed. Roles: `sam_user` or `sam_admin` (DOC sam/run-recon-workspace.md). Parallel workers: `com.snc.samp.recon.max_workers`. Debug logging: `com.snc.samp.debug` (performance cost) (DOC sam/sam-properties.md).
- **Run status**: Completed, In Progress, Failed (DOC sam/run-recon-workspace.md). The workspace Reconciliation tab also shows **Partially Completed**, and a red icon on a publisher card marks a failed publisher (DOC sam/sam-workspace-workbench.md).
- **Result tiers** (DOC sam/software-reconciliation-results.md, sam/sam-workspace-workbench.md):
  - Product Results are created for licensable products **even without a software model**.
  - Software Model Results are created only when a model or entitlement exists, unless `com.snc.samp.unlicensed_smr_creation` = true (default false). Oracle Database option models without entitlements get none by default (DOC sam/t_ViewSWModelResults.md).
  - License Metric Results: one per metric on the model.
- **Which run**: each software model result has a **Latest** flag. History is under Reconciliation > Historical Results, and the License usage view shows the latest run (DOC sam/t_ViewSWModelResults.md, sam/sam-workspace-workbench.md). PRACTICE: always cite the run number, date and status.
- **Money fields**: Rights owned = active rights on entitlements sharing a metric. True-up cost = rights needed × **average price per right from entitlements** (lowest Purchase Rights option). Over-licensed amount = estimated cost of unused rights. Potential savings come from removal candidates (DOC sam/t_ViewSWModelResults.md). PRACTICE: true-up cost is an internal estimate, not a vendor quote.
- **Upgrade risk**: from Yokohama, reconciliation script includes moved to `com.sn_itam_samp`; customizations must be moved to the new script includes (DOC sam/c_SAMReconciliation.md).
- **Pack properties that change results**: `com.snc.samp.oracle.reconlevel` (ESX / ESX cluster default / vCenter), `com.snc.samp.oracle.hostaffinityenabled`, `com.snc.samp.citrix.app.license.period` (90 days), `com.snc.samp.windowserver.license.threshold` (4.59), `com.snc.samp.sqlserver.standard_sa.to.enterprise_sa.cost.ratio` (0.25), `com.snc.samp.ms.sa.to.nonsa.cost.ratio` (1.25), RHEL for Virtual Datacenters threshold (3.2) (DOC sam/sam-properties.md). Read their values before trusting a pack's position.

## 10. Remediation options

Created on software model results (DOC sam/t_ViewSWModelResults.md):

| Remediation action | Field shown | Effect when run |
|---|---|---|
| Purchase Rights | Rights needed | **Create Purchase Order** (Procurement `com.snc.procurement` active and rights needed > 0); voids other Purchase Rights options for that result |
| Create Allocations | Rights not allocated | Creates allocations; voids Remove Unallocated Installs for that metric |
| Remove Allocations | Rights not in use | Removes allocations that are not in use |
| Remove Unallocated Installs | Reclaimable rights | Creates removal candidates in **Ready** |
| Remove Unlicensed Installs (and "- Cloud") | Unlicensed rights | Creates removal candidates in **Awaiting Revocation** |

Create Allocations and Remove Unallocated Installs appear when Not allocated in use > 0, except for User CAL and Device CAL. Remove Allocations appears when Allocated not in use > 0. No button appears when actionable rights = 0. Wait for a purchase order to finish processing before re-running reconciliation, to avoid a duplicate order (same page). PRACTICE: every remediation that creates removal candidates or purchase orders is a write; it needs approval under the core operating rules.

## 11. Software Asset Workspace, License Workbench and reports

- **Views** (DOC sam/sam-workspace.md): Software asset overview, License usage, License operations, Software asset analytics, Success portal, Renewals calendar, Overlapping usage, Content lookup portal.
- **Software asset overview**: widgets for publishers or products out of compliance, over-licensed amount, total true-up cost, potential and actual savings, software spend (cost of non-retired entitlements), normalization status and end-of-life products. The **Activity center** raises alerts for last reconciliation failure, failed scheduled jobs, failed content download, entitlement import errors and new normalization suggestions (DOC sam/sam-workspace-landing.md).
- **License usage** (the workspace successor to the classic **License Workbench**, DOC sam/sam-license-workbench.md): publisher cards, publisher details with product, software model and license metric results, **unlicensed entity** categories (Unlicensed installs, Non-entitled product installs, Installs requiring action with reasons, unlicensed or non-entitled subscriptions, Unlicensed client access, Unlicensed options), progress indicators (ignored or inactive installs, removal candidates, health issues), and the Reconciliation, Reclamation, Reports and ELP Grouping tabs (DOC sam/sam-workspace-workbench.md).
- **License Position report**: one list of software models with rights owned, used, needed and available, unlicensed installs, true-up, potential savings and over-licensed amount, plus group and subgroup. A model with both SA and subscription entitlements produces two rows (active maintenance true and false) (DOC sam/sam-license-position-report.md).
- **ELP grouping report** (`sam_user`): regroups the latest results by group and subgroup without re-running reconciliation; only one grouping result exists per publisher and product (DOC sam/elp-grouping-byconsumption.md, sam/generate-elp-report-sam.md).
- **License operations**: entitlements, models, imports and errors, consumption rules, reclamation and deduplication rules, removal candidates, discovery models, installs, usage, SAP, SSO, client access, resource values, subscriptions, spend detection, content suggestions (DOC sam/operations-workspace.md).
- **Phase-wise implementation**: when `com.snc.samp.manage.published.products` is true, overview and License usage reports filter to **Published** products by default (DOC sam/sam-properties.md, sam/sam-workspace-landing.md). Clear the filter before calling a total complete.

## 12. Removal candidates and reclamation (installed software)

- **Sources of removal candidates** (DOC sam/c_SAMOptimization.md):
  - the **monthly** job **SAM – Identify new reclamation candidates**, which applies reclamation rules to usage and needs at least one successful reconciliation first;
  - remediation options for unlicensed or unallocated installs;
  - software models marked **restricted**;
  - manual creation by `sam_admin` or `sam_user` (DOC sam/add-sw-removal-workspace.md).
- **Reclamation rules** (`sam_admin`; DOC sam/t_AddAReclamationRule.md, sam/sw-reclamation-rules.md):
  - Applies to: Installed Software, Subscription Software, Engineering App License, SAP Named User.
  - Types: Total Usage Time (default), Last Used Date, Peak Concurrent Usage, Active Transaction Codes.
  - Look-back: Aggregate usage by Last 1, 2, 3 or 6 months; Last used before 1, 2, 3, 6 or 9 months or 1 year.
  - Options: **Include no activity**, **Notify user** with **Days before auto-reclamation**, **Create reclamation candidate**; the assignment group defaults to Software managers.
  - Adding a suite parent pulls in its components and product processes. After upgrading to Brazil, existing rules need suite parents removed and re-added for bulk reclamation.
  - Rules for SaaS and SSO apps are created automatically with each integration (see `saas-license-management.md`). The docs read show no out-of-box rules for installed software, which `sam_admin` creates: `VERIFY` in the user's instance.
- **Usage data**: `samp_sw_usage` is product-level only; records come from SCCM, third-party integrations or manual entry (DOC sam/view-sw-usage-workspace.md).
- **States**: Attention Required, Ready, Awaiting User, Awaiting Approval, Awaiting Revocation, Closed Complete, Closed Skipped, Closed Canceled (activity detected). Justifications: Low Usage, Unallocated, Unlicensed, Restricted Software (DOC sam/c_SAMOptimization.md, sam/add-sw-removal-workspace.md).
- **Approval behavior**: Unallocated and Low Usage prompt the user. **Restricted Software and Unlicensed run automatically: the user is notified, not asked** (DOC sam/c_SAMOptimization.md). With Notify user, no response within the set days means automatic reclamation (DOC sam/t_AddAReclamationRule.md).
- **Execution**: Workflow plus Client Software Distribution, manual tasks, or the **Software Reclamation Flow** in Flow Designer. The weekly **SAM — Updating Existing Reclamation Candidates** job closes Awaiting Revocation candidates whose install has gone. `sam_reclamation_flow_error_timeout` (30 days) cancels flows with unresolved errors (DOC sam/c_SAMOptimization.md, sam/reclaiming-software-sam.md, sam/sam-properties.md).
- **Savings**: Potential savings = unused rights × average price per right. Actual savings = potential savings of Closed Complete candidates in the month (DOC sam/add-sw-removal-workspace.md, sam/sam-workspace-landing.md).
- PRACTICE before enabling automated reclamation: a defined threshold, user notification, an exception list (privileged, seasonal, legal hold), a pilot, license-owner approval, and verification that the install is actually gone at the next discovery.

## 13. Software Spend Detection

- Plugin `com.sn_sam_spend`. From Brazil it is **Software Asset Workspace only** (License operations > Software spend detection); the Core UI modules and the Software Spend Detection Overview dashboard are removed (DOC sam/software-spend-detection.md, sam/spend-detection-sam-workspace.md).
- Import an Excel file of financial transactions or create transactions by hand. Tables: `sam_spend_transaction`, `sam_spend_transaction_import`, staging `imp_sam_spend_transaction` (DOC sam/installed-with-spend-detection.md).
- Labeling states: New, Labeled, Partially labeled, Manually labeled, Unlabeled. **Is software** = true and **Is managed** = false marks unmanaged software spend. **SAM - Label Spend Transactions** retries up to `samp.spend_prediction_service.max_label_attempts` (default 3) (DOC sam/spend-detection-sam-workspace.md, sam/sam-properties.md).
- Sharing spend data with the Content Service is a separate toggle, **off by default**. An admin can hide it with `glide.samp.spend_detection_opt_in.enabled` = false (DOC sam/opt-in-content-service.md).
- Do not confuse this with the overview's **Software spend** widget, which is entitlement cost (DOC sam/sam-workspace-landing.md).

## 14. Publisher packs

| Pack | Plugin | Scope per docs |
|---|---|---|
| Adobe | `com.sn_samp_adobe` | Adobe subscription software; Adobe Cloud integration |
| Citrix | `com.sn_samp_citrix` | Virtual Apps and Desktops; needs a Discovery schedule on the Delivery Controller |
| IBM (includes Red Hat) | `com.sn_samp_ibm` | PVU and RVU and other IBM metrics; RHEL Server and RHEL for Virtual Datacenters |
| Microsoft | `com.snc.samp.microsoft` | e.g. SQL Server; core, CAL, SA and cloud rules |
| Oracle | `com.snc.samp.oracle` | e.g. Oracle Database, options and packs, WebLogic |
| SAP | `com.sn_samp_sap` | Named users, engines, digital access, S/4HANA cloud |
| VMware | `com.sn_samp_vmware` | e.g. vCenter, vSphere |
| Engineering Applications | `com.sn_samp_eng_app` | e.g. AutoCAD; OpenLM and Open iT concurrent licenses |

Sources: DOC sam/sam-publisher-packs.md, sam/sam-installed-components.md, sam/c_SAMLicenseMetrics.md. Packs are requested from ServiceNow; confirm which the user owns (`v_plugin` or Application Manager). Publisher dashboards need the matching pack (DOC sam/sam-publisher-packs.md). Usage criteria per pack, used by Value builder: DOC sam/publisher-pack-criteria-usage.md. Publisher-specific licensing pages (Oracle partitioning, Microsoft clusters, IBM sub-capacity, BYOL rules) exist in sam/. Cite the specific page and the contract; never restate the rules from memory.

## 15. Other capabilities in brief

- **Health Check** (Store app): weekly **SAM - Trigger Full Scan**; checks SQL Server, Windows Server, Oracle, Java, WebLogic, Microsoft 365 and general configuration (DOC sam/sam-health-check.md).
- **Configuration Console**: AI-assisted setup and update-set packaging; AI suggestions must be reviewed (DOC sam/config-console-sam.md).
- **CMDB success advisor for SAM**: install data-quality dashboard (DOC sam/cmdb-sa-sam-use.md).
- **Domain separation** is supported (DOC sam/domain-separation-software-asset-management.md). Quick start ATF tests: DOC sam/quick-tests-sam.md.
- **SaaS** → `saas-license-management.md`. **AI** → `now-assist-sam.md`. **Regulatory audit evidence** → `asset-audit-response.md`. **Cloud spend** → `cloud-cost-management.md`.

## 16. Troubleshooting a wrong license position

Work in order and stop at the first break. Each check names what to look at.

1. **Which result?** Reconciliation number, date and status; **Latest** flag; group and subgroup; domain; Published-products filter (§9, §11).
2. **Installs present and active?** Count `cmdb_sam_sw_install` by source and last discovered; Active flag after deduplication; device exclusion property; CIs retired or stolen (§4).
3. **Normalized?** Discovery model normalization status; open suggestions; Content Service jobs and the last content download (§5).
4. **Matched?** Discovery model → software model; Automatically matched; install conditions; models auto-created by properties (§6).
5. **Entitled correctly?** Active entitlement; metric group and metric; SA or maintenance linked to a perpetual; agreement type ELA or ULA (forces Compliant); open `samp_entitlement_import` errors (§6).
6. **Allocated?** Needed for Per Named metrics; Allocated not in use; cluster-level allocations (§8).
7. **Reconciled cleanly?** Publisher failure icon; Scheduled jobs failed alert; custom metrics property; pack aggregation and cost-ratio properties (§9).
8. **Read the explanation.** Licenses Required By and Installs requiring action reasons before disputing the number (§7, §11).

Report: the break, the evidence query or screen, records affected, and the effect on the position (over- or under-stated). "No software model result" is not "no exposure": check Product Results and Non-entitled product installs.

## 17. Documentation inconsistencies to verify

- Software Reclamation Flow: "starting from Zurich" (sam/c_SAMOptimization.md) vs "starting from Brazil" (sam/reclaiming-software-sam.md).
- Spend import role: `sam_spend_import` (sam/sam-installed-components.md) vs `sam_user` (sam/installed-with-spend-detection.md).
- Running reconciliation: listed among `sam_admin` duties (sam/sam-installed-components.md), yet `sam_user` may run it in the workspace (sam/run-recon-workspace.md).
- Engineering pack ID: `com.sn_samp_eng_app` (sam/sam-installed-components.md) vs `sn_samp_eng_app` (sam/c_SAMLicenseMetrics.md).
- The earlier claim that SAM content needs a "Normalization Data Services" plugin does not appear in the brazil docs. Use the Content Service (§5) and check older releases separately.
