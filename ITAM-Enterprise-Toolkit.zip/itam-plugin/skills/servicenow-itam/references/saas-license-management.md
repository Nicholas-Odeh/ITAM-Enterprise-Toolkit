# ServiceNow SaaS License Management reference

**Labels.** `DOC` = official ServiceNow docs, summarized. `PRACTICE` = practitioner method. `VERIFY` = not confirmed; check in the instance.

**Source convention.** `DOC saas/<file>` = `markdown/it-asset-management/saas-license-management/<file>`, `DOC sam/<file>` = `.../software-asset-management/<file>` in github.com/ServiceNow/ServiceNowDocs, branch `brazil`, as checked 2026-10-20 (pages `last_updated` 2026-09-10 unless noted). Integration behavior changes with each store-app version; confirm the installed `sn_sam_saas_int` version.

Core SAM concepts (models, entitlements, reconciliation, removal-candidate states) are in `sam.md`. The vendor-neutral method for reharvest and SaaS sprawl is in the `itam-software-license-management` skill (`references/reharvest-saas.md`).

## Contents
1. What it is and how it is installed
2. Three ways to manage direct SaaS
3. Roles and tables
4. Direct integrations
5. SSO integrations (Microsoft Entra ID, Okta)
6. Microsoft 365 and Adobe (hybrid SaaS)
7. Subscriptions, users and identifiers
8. Reclamation rules and reclaiming subscriptions
9. License metrics, reconciliation and reporting
10. Write-safety checklist before enabling reclamation

## 1. What it is and how it is installed

- SaaS License Management tracks cloud subscriptions inside SAM, covering usage, cost and reclamation for **hybrid SaaS** (installed plus cloud, e.g. Microsoft 365, Adobe Cloud) and **direct SaaS** (browser-only) (DOC saas/sam-subscription-management.md).
- Plugin **Software Asset Management - SaaS License Management** (`sn_sam_saas_int`), requested from the ServiceNow Store. It requires SAM Professional (`com.snc.samp`). After installation, choose the SaaS applications under **Install optional features** in Application Manager; without them you get only base features. The installer role is `admin` (DOC saas/request-saas-license-management.md).
- Version coupling: with `sn_sam_saas_int` 16.0.6 or later on Zurich, the Software Asset Workspace app should be 9.0.4 (DOC saas/request-saas-license-management.md). Other version pairs: `VERIFY`.
- Large estates: when user subscriptions exceed 50,000 (direct SaaS, or Microsoft 365 plus Adobe combined), raise `com.snc.pa.dc.max_row_count_indicator_source` before creating profiles (DOC saas/saas-setup-large-companies.md).

## 2. Three ways to manage direct SaaS

| Option | Use when (per docs) | Reclamation |
|---|---|---|
| **Direct integration** | Supported vendor; you want user-level usage and automated license management | Automated only where the vendor API supports removal; otherwise candidates are created and removal is manual or custom |
| **SaaS License Connections** (custom) | Any SaaS with a public API; low-code build with Integration Hub and Flow Designer / Workflow Studio | Depends on the API and your flow |
| **SSO integration** | Apps behind Okta or Microsoft Entra ID; tackling SaaS sprawl | Direct user assignments can be reclaimed; **group-based access is not removed automatically**, because one group can grant several apps |

Source: DOC saas/sam-subscription-management.md.

**Custom connections**: need an Integration Hub subscription (Starter, Standard, Professional or Enterprise). Build on a non-production instance, which carries no Integration Hub charge, and promote with an update set. The license metric is User Subscription for subscription models or SaaS Consumption for consumption models. Reuse an existing spoke if one exists. ServiceNow provides a worksheet (KB0793266) (DOC saas/saas-license-connections.md). Build steps: data stream actions and subflows for users, activity, license consumption and user removal (titles in saas/).

## 3. Roles and tables

- `sam_integrator`: contains `sam_user`; creates and manages SaaS and SSO integration profiles (DOC saas/installed-with-saas.md). It also includes `connection_admin` and `flow_operator` (DOC sam/sam-installed-components.md).
- Reviewing reclamation rules and defining subscription exclusions need `sam_admin` (DOC saas/add-reclamation-rule-sub.md, saas/subscription-exclusions.md). User resolution rules need `sam_admin` or `sam_integrator`; `sam_user` can only view them (DOC saas/map-user-data.md). Reclaiming in the workspace needs `sam_user` (DOC saas/reclaim-user-subscription-saas-workspace.md).

| Table | Purpose (DOC saas/installed-with-saas.md unless noted) |
|---|---|
| `samp_sw_subscription` | Software Subscription: one record per user subscription (DOC saas/map-user-data.md) |
| `samp_sw_subscription_product_definition` | Drives automatic software-model creation when an app's External Catalog ID matches an Identifier |
| `samp_sw_custom_subscription_product_definition` / `samp_sw_custom_subscription_integration` | Custom models and providers |
| `samp_sw_subscription_integration` | Providers mapped to subscription products |
| `samp_sw_unrecognized_subscription_identifier` | Identifiers not tied to a software model |
| `samp_subscription_usage_summary` | Rights owned, assigned, stale, available, cost |
| `sam_saas_consumption_summary` | Consumption summaries (units, monthly use, contract dates) |
| `samp_sso_integration_profile`, `samp_sso_application`, `samp_sso_subscription`, `samp_sso_application_role`, `m2m_sso_user_application`, `m2m_sso_group_application` | SSO profiles, apps, subscriptions, and user and group mappings |
| `samp_sw_usage` | Usage records, including Microsoft 365 (DOC sam/o365-usage-activity.md) |
| `saas_sw_storage_usage` | Allocated versus used storage (DOC sam/operations-workspace.md) |

## 4. Direct integrations

- The docs list profiles for Adobe Cloud, Adobe Workfront, Aha!, Asana, Box, Calendly, Cisco Webex, Confluence Cloud, CrowdStrike, Docusign, Dropbox, Google Workspace, GitHub, GoTo, Jira Software, Looker, Microsoft 365, Microsoft Dynamics 365 and Power Apps, Miro, monday.com, PagerDuty, Rally, Roadmunk, Salesforce CRM and Marketing Cloud, SAP Ariba, SAP S/4HANA Public Cloud, Slack, SmartRecruiters, Smartsheet, SAP SuccessFactors, SurveyMonkey, Tableau Cloud, Trello, Workday, Workplace from Facebook, Zendesk and Zoom (DOC saas/create-integration-profile.md). Anything else needs a custom profile (DOC saas/create-integration-custom.md).
- **Each integration automatically creates a software model and a reclamation rule.** The documented sequence is: connect in the vendor admin account, create the profile, **review the reclamation rule**, then create an entitlement for purchased quantity and cost (DOC saas/create-integration-profile.md).
- Several profiles for one vendor (separate tenants or connections) use a child alias (DOC saas/create-child-alias-saas.md; Webex, Confluence and Jira variants).
- Profiles can also be created through the SAM Configuration Console (DOC saas/create-integration-profile.md).

## 5. SSO integrations (Microsoft Entra ID, Okta)

- An SSO profile downloads applications, users and groups and tracks logins. It reuses or creates a directory integration (DOC saas/saas-sso-integration.md, saas/integrate-with-azure-ad.md).
- **Entra ID permissions** (least privilege per the docs): read scopes `User.Read.All`, `GroupMember.Read.All`, `Application.Read.All`, plus `AuditLog.Read.All` for activity; **`User.ReadWrite.All` only if reclaiming**. The Microsoft Entra ID Spoke optional feature must be selected at install. Each Entra profile gets its own connection from SaaS LM 7.0.0 with spoke 3.1.0 (DOC saas/integrate-with-azure-ad.md).
- Profile options: **Exclude disabled accounts** (off by default), **Download Activity** (on), **Reclaim subscriptions** (on by default; when cleared, candidates are still created but the reclaim subflow does not run) (same page).
- **Connecting an app** (`sam_integrator`): the app needs a software model. Optionally use **Enable group based software model**, which requires an SSO group mapping first. **Analyze last activity from** goes back up to 60 days (default 30). In Entra, the **Assignment required** setting decides whether subscriptions are created for assigned users only or for all users. Connecting creates users, groups, subscriptions and **reclamation rules, refreshed daily** (same page).
- Disconnect an SSO app before creating a direct integration for it (DOC saas/disconnect-azure-ad-apps.md).

## 6. Microsoft 365 and Adobe (hybrid SaaS)

- **Microsoft 365 prerequisites** (DOC sam/integrate-with-microsoft.md): Microsoft publisher pack (`com.snc.samp.microsoft`), SaaS License Management, Microsoft Entra ID Spoke (Integration Hub subscription), Content Service updates, an Entra app registration, Power BI service-principal access for Power BI usage, and **turning off user-name anonymization** in the Microsoft 365 admin center. Use one profile per tenant. Government plans have their own endpoints.
- **Graph scopes by process** (same page): download subscriptions `User.Read.All` and `LicenseAssignment.Read.All`; usage `Reports.Read.All`; reclaim `GroupMember.ReadWrite.All` and `LicenseAssignment.ReadWrite.All`; assigning licenses adds `User.Read.All`.
- **Jobs**, run in sequence (DOC sam/m365-scheduled-jobs.md): SAM - Import M365 User Subscriptions (weekly); SAM - Collect Microsoft 365 Usage (daily); SAM - Create New Reclamation Candidates for Office 365 Integration (weekly); SAM - Microsoft 365 Daily Job (daily).
- **Usage sources**: Graph APIs; SCCM or ACC-V and Jamf for desktop apps; **manual upload** of admin-center reports for Microsoft 365 Copilot, Visio Online, Planner and Project, which have no usage API (DOC sam/o365-usage-activity.md).
- **Optimization types**: Overlapping, Low Usage, Downgrade (e.g. no Power BI use moves E5 to E3; no desktop use moves E3 to E1 or F3; shared mailbox moves to Exchange Online Plan 2; mailbox and OneDrive under 2 GB is a condition for E3 to F3) and Consolidate (DOC sam/o365-usage-activity.md, sam/m365-reclamation-rules.md).
- **Automated removal** in the Microsoft 365 admin center applies to low-usage and overlapping candidates. Suites notify the user and need SAM Manager approval by default, because Notify User is preselected. Group-assigned licenses: the user is removed from a group only when that group carries the single license in question; with multiple licenses through groups, the user is **not** removed (DOC sam/m365-license-auto-removal.md).
- Entitlement types (Add-on, From SA, Step-up, reserve entitlements) must be linked as documented (DOC sam/license-types-impact-reconciliation.md, sam/creating-0365-reserve-entitlements.md).
- **Adobe**: Adobe pack plus Adobe Cloud integration (OAuth server-to-server) with its own scheduled jobs and reclamation rules. Per the SaaS rules table, Adobe Cloud reclamation is **not automated** (DOC sam/adobe-cloud-integration.md, sam/reclamation-rules.md).

## 7. Subscriptions, users and identifiers

- **User resolution**: the subscription User field is matched by User principal name against `sys_user` Email and User ID. Fix misses with **User resolution rules**, then rerun **SAM - Refresh <profile name> Subscriptions**. Exclude `sys_user` child tables with `sn_itam_samp.user_resolution_exclude_table` when duplicates exist. Review "Subscriptions without user" in License operations (DOC saas/map-user-data.md). Non-human mailboxes may not need resolution (DOC sam/integrate-with-microsoft.md).
- **Subscription identifiers** link subscriptions to discovery maps and software models. Provider changes arrive with the twice-weekly content updates. Auto-generated models update automatically; **customized models need the suggestions accepted by hand**. Unrecognized identifiers are fixed by assigning a software model, and can be shared with the Content Service unless excluded (DOC saas/subscription-identifiers.md).
- **Exclusions** keep low-value, high-volume subscriptions out of license cost calculations: identifier-based (per profile type) and user-based (across all SaaS profiles), `sam_admin` (DOC saas/subscription-exclusions.md). PRACTICE: record every exclusion with an owner and reason, because exclusions change the reported position.

## 8. Reclamation rules and reclaiming subscriptions

- A rule is auto-created per direct integration and per connected SSO app; **review it** (`sam_admin`). The **Last activity threshold** defaults to **60 days for direct integrations and 30 days for SSO apps**. **Notify user** with **Days before auto-reclamation** gives the user a chance to keep the account. Microsoft 365 and Office 365 rules can include usage from SCCM or ACC-V (DOC saas/add-reclamation-rule-sub.md).
- **What counts as activity and what reclamation does differs by app** (DOC sam/reclamation-rules.md). Examples:
  - Box and Dropbox delete the account and move files to the admin account.
  - Google Workspace deletes the account and **deletes email** unless it is migrated first.
  - Zoom Basic removal deletes cloud recordings.
  - Asana deletes the user.
  - Slack deactivates the user.
  - Tableau Cloud sets the user to Unlicensed if they own content.
  - Not automated: Adobe Cloud, Dynamics 365, monday.com, SAP Ariba, SAP S/4HANA, SurveyMonkey and Docusign at organization level.
  The docs warn that users can't stop reclamation unless Notify user is selected, and that you must make sure users don't lose access to their files.
- **Doc conflict**: the rules table marks Roadmunk reclamation as automated ("Deactivates the user"), but the workspace reclaim page says Roadmunk, monday.com and SurveyMonkey **do not** support reclamation through the platform: deactivate in the vendor portal, then set the candidate to Closed Skipped (DOC saas/reclaim-user-subscription-saas-workspace.md). `VERIFY` for Roadmunk.
- **States** match installed-software candidates: Attention Required (also set on failure), Ready, Awaiting User, Awaiting Approval, Awaiting Revocation, Closed Complete, Closed Skipped, Closed Canceled (activity detected). A successful reclaim **deletes the subscription record** from `samp_sw_subscription`. **Reclaim All** asks for confirmation (DOC saas/reclaiming-user-subscriptions-saas.md, saas/reclaim-user-subscription-saas-workspace.md).

## 9. License metrics, reconciliation and reporting

- SaaS License Management adds the **Subscription** (User Subscription) and **Consumption** (SaaS Consumption) metric groups. For User Subscription, reconciliation consumes one right per active unique subscription assigned to a user (DOC sam/c_SAMLicenseMetrics.md). SaaS Consumption spend is calculated for the current subscription period only (DOC sam/license-metric-results-fields.md).
- Allocation isn't required for subscription products (DOC sam/allocation-management-sam.md). Reconciliation runs on subscriptions with the normal schedule; results show Unlicensed Subscriptions and Unlicensed Consumptions (DOC sam/software-reconciliation-results.md).
- **Reporting**: SaaS overview dashboard in the workspace (DOC sam/saas-dashboard-workspace.md); the **SaaS detection report** lists browser-accessed SaaS seen by Agent Client Collector for Visibility Content (ACC-VC 1.9.0+, 30-day default retention) and marks each as Managed or Unmanaged by whether a software model exists (DOC sam/shadow-saas-analytics.md); the Overlapping usage view shows feature-level usage (DOC sam/app-ration.md).

## 10. Write-safety checklist before enabling reclamation (PRACTICE)

Reclamation through an integration deletes, deactivates or downgrades accounts in the vendor system. Treat enabling it as a production change.

1. Read the app's row in the reclamation table (§8): what counts as activity, and what happens to the user's data.
2. Confirm the rule threshold, Notify user and days before auto-reclamation with the license owner. Record them in the company profile or SAM policy.
3. Confirm user resolution coverage (Subscriptions without user = 0, or explained) and exclusions (service accounts, executives, legal hold, seasonal staff).
4. For SSO, confirm whether access is direct or group-based. Group-based access needs manual removal by the identity team.
5. Pilot on a small group with **Reclaim subscriptions** cleared, or the Notify-user path, and compare candidates with the vendor admin view.
6. Get approval, a rollback route (re-invite or reassign in the vendor portal) and a data-retention plan (mail, files, recordings) before enabling it for everyone.
7. After the run, verify in the vendor portal and at the next subscription download, not from the candidate state alone.
