# Contracts, procurement and product catalog (ServiceNow)

How ServiceNow models what you buy (product catalog and models), how you buy and receive it (Procurement), and the agreements that cover it (Contract Management, leases, warranties). Sources: ServiceNowDocs `brazil`, paths relative to `markdown/`, checked 2026-10-20. Labels: `DOC (path)`, `PRACTICE`, `VERIFY`. For platform-neutral contract strategy, renewals and vendor negotiation, use `itam-vendor-contract-management` and `itam-acquisition-procurement`. This file covers the ServiceNow implementation only.

## Contents
1. Product catalog: models, model categories, catalog items
2. Procurement: plugin, roles, tables, workflows
3. Purchase orders and receiving
4. Contract Management: tables, roles, states
5. Contract renewal workflow
6. Leases, warranties and obligations (HAM)
7. Checks and common problems

## 1. Product catalog

- **Models** are specific versions or configurations of an asset. A model can belong to several **model categories**, and its definition says whether it creates an asset, a CI or both. Create them at Product Catalog > Product Model > All Models; role `model_manager` (contained by `sam`, `category_manager` and `asset`) (DOC `it-asset-management/product-catalog/c_Models.md`).
- Model types: hardware, consumable, bundled (one model made of component models; assigning it gives the user every component), software, application, work order, plus auto-created VMware/EC2 models (DOC same page; `it-asset-management/product-catalog/c_CreatingBundledModels.md`).
- A model can be deleted only if no asset or CI uses it (DOC `it-asset-management/product-catalog/t_DeletingModels.md`).
- **Model categories** associate the CI class, the asset class (base: Hardware, Software License, Consumable) and optionally the IBI class. This decides whether a CI creates an asset. The Contract model category can't be edited (DOC `it-asset-management/product-catalog/c_ModelCategories.md`, `it-asset-management/product-catalog/t_EditingModelCategories.md`).
- Tables: `pc_product_cat_item` (extends `sc_cat_item`), `pc_hardware_cat_item`, `pc_software_cat_item`, `pc_vendor_cat_item` (DOC `it-asset-management/product-catalog/r_TablesProductCatalog.md`).
- **Vendor catalog items** link a model to vendors and prices; several can sit under one product catalog item (DOC `it-asset-management/product-catalog/c_ManageVendorCatalogItems.md`). A stock rule with the Vendor option can raise a PO only for models published as vendor catalog items (DOC `it-asset-management/asset-management/c_StockRules.md`).
- Publish models to the hardware or software catalog to make them requestable (DOC `it-asset-management/product-catalog/t_PublishingModToHrdwreOrSftCat.md`). `glide.model.catalog_item_currency` sets catalog item currency from the model (DOC `it-asset-management/hardware-asset-management/ham-system-properties.md`).
- Hardware models in HAM also carry normalization and lifecycle data (see `ham.md` §9).

## 2. Procurement

- Plugin **Procurement** (`com.snc.procurement`). Activate it from System Applications > All Available Applications (DOC `it-asset-management/procurement/t_ActivateProcurement.md`). Functions: track catalog requests, create and manage purchase orders and transfer orders, receive assets (DOC `it-asset-management/procurement/c_Procurement.md`).
- Roles: `procurement_admin` (contains `procurement_user`; also manages Overview gauges) and `procurement_user` (contains `financial_mgmt_user`, `model_manager`). Both create POs with or without a request and source requests by PO or transfer order (DOC `it-asset-management/procurement/r_ProcurementRoles.md`).
- Tables: `proc_po`, `proc_po_item`, `proc_rec_slip`, `proc_rec_slip_item`. PO report access for `contract_manager` and `inventory_admin` needs HAM (`com.sn_hamp`) (DOC `it-asset-management/procurement/r_TablesProcurement.md`).
- Workflows: Service Catalog Request (items over 1,000 dollars need approval), Source Request (catalog tasks to source by TO or PO), Procurement Process Flow-Hardware. All are editable in Workflow Studio (DOC `it-asset-management/procurement/c_ProcurementWorkflows.md`). Check the approval threshold in the instance; it is a base default, not a policy (VERIFY).
- Sourcing: only items with a model can be sourced; bundles can't. Options are local stock (reserve and fulfil), transfer order (from one or several source stockrooms) or PO. Software is sourced by assigning license rights (DOC `it-asset-management/procurement/c_SourcingRequestItems.md`).
- External procurement: integration profiles, for example **Coupa**, with requisitions created from ServiceNow and reference-data sync. These pages are framed around SAM software requisitions (DOC `it-asset-management/procurement/integrate-ext-proc-ser.md`, `it-asset-management/procurement/integrate-with-coupa.md`).

## 3. Purchase orders and receiving

PO status lifecycle (read-only field) (DOC `it-asset-management/procurement/r_FollowAPurchaseOrderStatus.md`):

| Status | When |
|---|---|
| Requested | PO created. |
| Ordered | Lines added and **Order** selected. |
| Pending Delivery | Assets pre-created before receipt (`it-asset-management/procurement/t_CreateAssetReserveForRequester.md`). |
| Received | All lines received at the stockroom. |
| Canceled | Allowed from Requested, Ordered or Pending Delivery. |

Receiving (detail in `procedures.md` §2):
- Lines can be received at different times; each receipt makes a receiving slip; the PO is Received only when all lines are (DOC `it-asset-management/procurement/c_ReceiveAssets.md`).
- Over-receiving is allowed (received quantity above ordered) (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`). Treat it as a variance to explain (PRACTICE).
- Hardware: one asset per unit. Software: one license asset unless rights are split. Consumables merge into an existing consumable record (DOC same page; `it-asset-management/procurement/c_ReceiveAConsumableAsset.md`).
- The expected delivery date on POs is described in `it-asset-management/procurement/r_SetExpectDelDateOnPurchOrder.md`.
- Unit cost captured at receipt flows to the asset's cost (DOC receive page: "Edit the Unit Cost if the price changed"). Reconcile to the invoice, not the PO, for capitalization (PRACTICE; see `asset-data-model.md` §3).

## 4. Contract Management

- Active by default. With the Cost Management plugin it associates contracts with costs (expense lines) for TCO (DOC `it-asset-management/contract-management/c_ContractManagement.md`).
- Tables: `ast_contract` (contracts), `clm_m2m_contract_asset` (assets covered), `clm_m2m_contract_user` (users covered), `clm_m2m_rate_card_asset`, `clm_contract_history`, `clm_terms_and_conditions`, `clm_m2m_contract_and_terms`, `clm_condition_check`, `clm_condition_checker` (DOC `it-asset-management/contract-management/r_TablesInstalledWContractMgmt.md`).
- Role `contract_manager` (contains `financial_mgmt_user`) (DOC `it-asset-management/contract-management/r_UserRolesIWContractMgmt.md`). Creating contracts: `admin` or `contract_manager` (Core UI and Hardware Asset Workspace); `sam_admin` or `sam_user` (Software Asset Workspace); EAM roles for the Enterprise Asset Workspace (DOC `it-asset-management/contract-management/t_CreateAContract.md`).
- Contract models include Lease, Maintenance, Warranty, Service Contract, Software License, Subscription, Purchase Agreement and NDA. Agreement type (Enterprise, SaaS, Subscription) appears for Maintenance and Software License. Contracts with model Subscription are readable by all authenticated users (DOC `it-asset-management/contract-management/t_CreateAContract.md`, `it-asset-management/contract-management/t_MonitoringContracts.md`).
- States: Draft → Active (approved and start date reached) → Expired (end date reached); Canceled. Substates include Awaiting Review, Under Review, Approved, Rejected, Renewal Approved/Rejected, Renewal in process, Renewed, Extension Approved/Rejected. After Draft, date, renewal, extension and financial fields become read-only (DOC `it-asset-management/contract-management/c_ContractLifeCycle.md`).
- The nightly **Contract Compliance Checks** job activates, renews and expires contracts per condition checks; `contract_compliance_check_job.enable_override` lets child-table checks override parent ones. Expense lines generate only for Active or Expired contracts (DOC same page).
- Contract administrators get nightly expiry reminders (DOC `it-asset-management/contract-management/t_SendAContractNotification.md`). Changes to start date, end date or terms create a Contract History copy (DOC `it-asset-management/contract-management/t_MonitoringContracts.md`).
- Approval can run on a Workflow Studio flow when `com.sn_itam.enable_flow_designer.contract_approval` is on (DOC `it-asset-management/hardware-asset-management/ham-system-properties.md`).
- Domain separation is **not** supported in Contract Management (DOC `it-asset-management/contract-management/c_ContractManagement.md`).

## 5. Contract renewal workflow

(DOC `it-asset-management/contract-management/cont-renew-wf.md`)
- For Software license, Subscription, Maintenance and Warranty contract models. Tasks: renewal request → contract selection (child contracts) → build renewal → asset selection → software entitlement selection → terms and conditions → rate cards → confirmation → approval → renewal purchase order.
- Prerequisites: SAM Professional (`com.snc.samp`), or HAM / EAM for hardware or enterprise asset contracts, plus `sn_contract_enable_renewal_flow` on (default false for existing SAM/HAM users, true for new). Closed tasks can't be edited. Tables: `sn_contract_renewal_request`, `_line`, `_task` (DOC `it-asset-management/hardware-asset-management/installed-with-ham.md`).

## 6. Leases, warranties and obligations (HAM)

- **Lease expiration flow**: notices at 90, 60 and 30 days; **Begin Lease expiration process** on an active lease with covered assets; per-asset action Return, Buy out or Extend; Planning tasks capped at 1,000 per run by default. With HAM licensed, **Renew** is hidden for active leases with covered assets. An asset on several leases shows the latest in its Lease contract field (DOC `it-asset-management/hardware-asset-management/manage-your-leased-hw-asts-expiring-contract.md`). Steps: `procedures.md` §10.
- **Warranty**: an asset can hold several warranty records in `sn_itam_common_asset_warranty`. The Lenovo integration (Lenovo Spoke `sn_lenovo_spoke`, Client ID; weekly job in batches of 1,000 serials) fills them; excluded assets are skipped (DOC `it-asset-management/hardware-asset-management/integration-with-lenovo-asset-warranty.md`). For other manufacturers, warranty data comes from contracts (Warranty model), the `warranty_expiration` asset field (synced with the CI), or a custom integration (DOC for the field sync: `it-asset-management/asset-management/c_ManagingAssets.md`; integrations VERIFY).
- **Contract Management Pro integration** (HAM **Prime SKU** only): obligation management and AI extraction of metadata and obligations from signed lease, maintenance, warranty and purchase contracts. Needs Contract Management Pro Prime (`sc_cm_pro`), Obligation Management (`sn_cm_obligation`) and ServiceNow Otto for Contract Management Pro (`sn_cm_gen_ai`) (DOC `it-asset-management/hardware-asset-management/ham-cm-pro-integration.md`). Review every AI-extracted date and obligation before relying on it (PRACTICE; DOC `it-asset-management/hardware-asset-management/review-extracted-obligation-ham.md`).
- On disposal completion, maintenance-contract coverage for the asset is ended (Date removed) (DOC `it-asset-management/hardware-asset-management/create-disposal-order.md`).

## 7. Checks and common problems

| Symptom | Check |
|---|---|
| Stock rule with Vendor option makes no PO | Model not published as a vendor catalog item; Procurement inactive; HAM installed (it raises a catalog request instead) (DOC `it-asset-management/asset-management/c_StockRules.md`). |
| PO stuck in Ordered | Some lines not received; partial receipts are allowed (DOC `it-asset-management/procurement/c_ReceiveAssets.md`). |
| Can't receive: serial required | `glide.asset.create_ci_with_ire` or IRE identification on the CI class (`asset-ci-cmdb.md` §6). |
| Contract fields won't edit | Contract past Draft, or rate cards attached (DOC `it-asset-management/contract-management/c_ContractLifeCycle.md`, `it-asset-management/contract-management/t_CreateAContract.md`). |
| Expired assets still "covered" | Asset Covered rows lack Date removed; disposal or lease flows not run (PRACTICE check). |
| Lease Renew button missing | Expected with HAM licensed and covered assets; use the lease expiration flow (DOC). |
