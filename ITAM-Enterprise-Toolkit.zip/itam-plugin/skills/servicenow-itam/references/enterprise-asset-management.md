# Enterprise Asset Management (EAM) and OT assets: brief

Read this when the asset isn't IT hardware: medical devices, facilities equipment, industrial or operational technology (OT), linear assets, or when a stockroom or receiving page mentions "enterprise assets". Sources: ServiceNowDocs `brazil` (paths relative to `markdown/`, checked 2026-10-20). EAM has about 410 pages under `it-asset-management/enterprise-asset-management/`; this is a pointer, not a full reference. Labels: `DOC (path)`, `PRACTICE`, `VERIFY`.

## What it is

- **Enterprise Asset Management** (`com.sn_eam`) automates the lifecycle of physical business assets: request, sourcing, PO, deployment, work orders, contracts, TCO, refresh and disposal. Users include enterprise administrators, asset managers and technicians, with medical, facility and OT variants (DOC `it-asset-management/enterprise-asset-management/exploring-eam.md`, `it-asset-management/enterprise-asset-management/install-eam.md`).
- **OT Asset Management** (`com.sn_otam`) is a separate application, licensed per subscription unit for assets in the Industrial and Hardware model categories (DOC `it-asset-management/enterprise-asset-management/install-otam.md`, `it-asset-management/enterprise-asset-management/licensing-ot-asset-management.md`).
- Separate EAM variants exist for healthcare, providers and data center/network (DCNAM), each with its own install and licensing pages (DOC folder listing, for example `it-asset-management/enterprise-asset-management/eam-dcnam-licensing.md`).

## Data model

- Enterprise **model classes** (definitions) and enterprise **asset classes** (physical objects), mapped to CMDB CI classes through enterprise **model categories**. This mirrors the HAM model-category pattern (DOC `it-asset-management/enterprise-asset-management/eam-data-model.md`).
- Model types cover standalone, consumable (quantity-tracked) and multi-component assemblies. EAM also supports asset groups and linear assets (DOC same page; `it-asset-management/enterprise-asset-management/eam-model-types.md`, `it-asset-management/enterprise-asset-management/using-linear-assets.md`).

## Where it touches HAM

- **Shared tables and roles:** repair orders, asset orders, loaner orders and shipments live in `sn_itam_common_*` tables shared by HAM and EAM (DOC `it-asset-management/hardware-asset-management/installed-with-ham.md`).
- **Receiving across workspaces:** enterprise assets can be received in the Hardware Asset Workspace only if EAM is active, and hardware assets in the Enterprise Asset Workspace only if HAM is active (DOC `it-asset-management/hardware-asset-management/stockroom-receiving-ham.md`). PO receiving shows a MAC address column when EAM or OT is active (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`).
- **Audits:** a scanned enterprise asset counts as "Excluded from licensing" when the instance has no EAM license (DOC `it-asset-management/hardware-asset-management/audit-results.md`).
- **HAM licensing:** OT hardware assets are excluded from HAM licensing. With OT Asset Management active, models of opted-out HAM categories that have OT assets are still normalized (DOC `it-asset-management/hardware-asset-management/licensing-ham-solutions.md`, `it-asset-management/hardware-asset-management/hardware-normalization.md`).
- **Asset-CI sync for OT:** OT assets may have no serial number, so sync also uses the MAC address (`mac_addr` on `alm_asset`; Network Adapter `cmdb_ci_network_adapter` rows on the CI side). CI names become "Serial - Model", "MAC - Model" or the model name. MAC sync needs `sn_itam_common.mac_address_sync = true` (DOC `it-asset-management/enterprise-asset-management/asset-ci-sync-ot-assets.md`).
- **Contracts:** EAM uses the same Contract Management with its own roles (`sn_eam.enterprise_admin`, `sn_eam.enterprise_asset_manager`) and the Enterprise Asset Workspace "Contract and lease management" view (DOC `it-asset-management/contract-management/t_CreateAContract.md`, `it-asset-management/contract-management/t_MonitoringContracts.md`).

## How to use this skill for EAM questions

- Treat the HAM procedures as a pattern only. EAM has its own pages for onboarding, reclamation, work orders, repair, put-away, pick and drop-off tasks (DOC `it-asset-management/enterprise-asset-management/exploring-eam.md`). Search the doc index (`doc-index.md`, or run `python3 scripts/extract_servicenow_docs.py`) and cite the EAM page itself.
- State which application the user is licensed for (HAM, EAM, OTAM or several) before giving steps (PRACTICE).
- Medical-device regulation, maintenance strategy and OT security are outside this plugin's scope; say so rather than improvise (PRACTICE).
