# Operational procedures (ServiceNow HAM)

Ten procedures for day-to-day hardware asset work. Each gives prerequisites, steps, the state each step writes, validation, and risks with rollback. Sources: ServiceNowDocs `brazil` (paths relative to `markdown/`, checked 2026-10-20). Procedures 1–5 adapt the five standard procedures from the ServiceNow ITAM skill starter, each step checked against the docs.

Labels: `DOC (path)`, `PRACTICE`, `VERIFY`. Navigation paths are the documented defaults. Instances add or rename modules, so confirm the menu before giving click paths (VERIFY). Any step marked **WRITE** changes production data; it needs the dry run, scope cap, rollback and approval from the skill's operating rules.

## Contents
1. Investigate an asset (read-only)
2. Receive and stock assets
3. Issue, transfer and return within stock
4. Discrepancies and inventory audit
5. Refresh
6. Reclaim from a leaver or mover
7. Loaner
8. Repair and RMA
9. Disposal, resale and donation
10. Lease end

---

## 1. Investigate an asset (read-only)

**Prerequisites:** `asset` or `inventory_user` for read access. With `sn_itam_restrict_asset_read=true`, users with only `snc_internal` see just their own assets (DOC `it-asset-management/asset-management/c_ManagingAssets.md`).

1. Get one identifier: asset tag, serial number, assigned user, hostname, or PO number. Don't echo personal data beyond need (PRACTICE).
2. Find the record: Asset > Portfolios > All Assets (DOC `it-asset-management/asset-management/t_SettingAssetStatesAndSubstates.md`), or Hardware Asset Workspace > Asset estate / Inventory (DOC `it-asset-management/hardware-asset-management/using-ham-workspace.md`). Decide whether it is a hardware asset, consumable, bundle, CI, model or request.
3. Record identity and status: model, model category, State **and** Substate, Asset function, stockroom, location, Assigned to, Reserved for, Managed by, Owned by.
4. Open the linked CI. Check the asset ↔ CI back-link, compare serial, model and assignment, and compare the CI Install Status / Hardware Status with the mapping (`asset-ci-cmdb.md` §4).
5. Check related transactions: transfer order lines, PO and receiving slips, requested items, reclamation lines, refresh lines, loaner orders, RMA lines, disposal orders, contracts (Asset Covered), audit scans. HAM forms show these as related lists or tabs (DOC pages in `ham.md` §§4–8).
6. Write up the discrepancy: source of truth per attribute (see `asset-data-model.md` §3), affected records, proposed correction and owner. Change nothing without approval.

**Validation:** every attribute in the write-up has its source and read time.
**Risks:** reading the substate without the state (Pending disposal exists under three states).

## 2. Receive and stock assets

**Prerequisites:** Procurement (`com.snc.procurement`) for PO receiving; roles `procurement_admin` or `procurement_user`. For workspace stockroom receiving: HAM, and `inventory_user` or `asset` (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`, `it-asset-management/hardware-asset-management/receive-assets-stockroom-hws.md`).

1. Confirm the PO line and the **model**. The model category decides the asset class and CI class (DOC `it-asset-management/product-catalog/c_ModelCategories.md`). If HAM normalization is in use, check the model's normalization status (DOC `it-asset-management/hardware-asset-management/normalize-hardware-consumable-models.md`).
2. Check identifiers before receipt: serials are unique, and tags follow policy (PRACTICE). If `glide.asset.create_ci_with_ire` is true, the serial is mandatory for serial-identified classes and a serial already on a CI or asset blocks creation (DOC `it-asset-management/asset-management/c_ManagingAssets.md`).
3. **WRITE**, PO route: Procurement > Orders > Purchase Orders (or workspace Procurement > Purchase orders). Open a PO in Ordered or Pending Delivery, select **Receive**, tick lines, adjust stockroom, quantity or unit cost, then use **Capture asset tags** for tag, serial (and MAC with EAM/OT) and Reserved for. **Reserve** on → In stock / Reserved; off → In stock / Available. A receiving slip is created per receipt (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`).
4. **WRITE**, workspace route: Hardware Asset Workspace > Inventory > All stockrooms > stockroom > **Receive assets**. Search by tag, serial or MAC, pick from inbound shipments, or **Import assets** from the Excel template. In transit → In stock; the stockroom is set; source receive tasks close (DOC `it-asset-management/hardware-asset-management/receive-assets-stockroom-hws.md`, `it-asset-management/hardware-asset-management/stockroom-receiving-ham.md`).
5. If put-away tasks are enabled for the stockroom, close the put-away with the aisle and space (DOC `it-asset-management/hardware-asset-management/manage-asset-putaway-stockroom-hardware-asset-workspace.md`).
6. Check the CI side. With `glide.create_alm_asset.async` / CI creation from assets, confirm the CI exists and is linked; check the Asset Creation Queue for errors (DOC `it-asset-management/asset-management/c_ManagingAssets.md`).

**Validation:** received quantity = PO line quantity (or the over-receipt is explained); the PO status is Received only when all lines are; asset count by stockroom rose by the received count; no duplicate serials (GlideAggregate, `query-script-patterns.md` §3).
**Risks/rollback:** over-receiving is allowed by the platform, so flag the variance rather than absorbing it (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`; PRACTICE). Wrong-model receipts: fix the model on the asset before deployment. Delete only records created in error, and remember a linked CI is deleted with the asset (DOC `it-asset-management/asset-management/t_DeletingAssets.md`).

## 3. Issue, transfer and return within stock

**Prerequisites:** `inventory_user` for transfer orders (DOC `it-asset-management/asset-management/t_TransferAssetsUsingTransferOrders.md`); Procurement for sourcing from requests (DOC `it-asset-management/procurement/c_SourcingRequestItems.md`).

1. Check the request or approval, the eligible model, and availability. Only **In stock / Available** assets are sourceable stock (stock rule transfers count only Available; reserved and pending substates don't) (DOC `it-asset-management/hardware-asset-management/t_CreateAStockRule.md`).
2. **WRITE**, source the requested item from local stock (reserve and fulfil), by transfer order, or by PO (DOC `it-asset-management/procurement/c_SourcingRequestItems.md`, `it-asset-management/procurement/consume-local-asset-stock.md`).
3. **WRITE**, transfer order: Inventory > Transfer Orders > Create Transfer Order (From, To, Delivery by), then add lines. Close line tasks in order: Draft (In stock / Pending transfer), Requested, Shipment Preparation (carrier, tracking), In Transit (In transit / Reserved), Received (In stock / Available at the destination), Delivered (In stock / Reserved) (DOC `it-asset-management/asset-management/r_SummaryOfTransferOrderStages.md`).
4. Hand over to the user. On deployment the asset moves to In use with Assigned to set; through Reserved for, the **Transition reserved to assigned** rule fills Assigned to (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`). With HAM, change and incident asset actions (Deploy, Swap, Retire) update the CI and asset (DOC `it-asset-management/hardware-asset-management/asset-lifecycle-automation.md`).
5. Return to stock: inspect, clear the assignment, and choose the next state (Available, Pending repair, Defective, Pending disposal). Moving to In stock clears Assigned to automatically (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`). For leavers use procedure 6.

**Validation:** source and destination stockroom counts change by the moved quantity; no line stuck in a stage; the CI location and assignment follow the asset (sync).
**Risks/rollback:** **Closed Skipped** on a line task doesn't update the asset, so fix it manually (DOC `it-asset-management/asset-management/manage-transfer-orders.md`). Draft lines can be deleted; later stages need a return (DOC `it-asset-management/asset-management/t_ReturnItemsRecInXferOrder.md`).

## 4. Discrepancies and inventory audit

**Prerequisites:** HAM for asset audits. Role `asset`; with `sn_hamp.migrate_hamaudit=true`, also `sn_itam_common.asset_audit_admin` or `.asset_audit_user`. ServiceNow Agent app for scanning (DOC `it-asset-management/hardware-asset-management/audit-your-inventory.md`, `it-asset-management/hardware-asset-management/create-audit-using-mobile-app.md`).

1. Define scope: stockroom or location (with or without child locations), aisle/space, model category, consumables yes or no, single or multi scan (DOC `it-asset-management/hardware-asset-management/create-audit-using-mobile-app.md`).
2. Freeze or log moves during the count window (PRACTICE).
3. **WRITE**, create the audit: Hardware Asset Workspace > Inventory view > Asset audit > New (scheduled), or in the Agent app > Asset > Stockroom/Location audits > New (blind). With `migrate_hamaudit=true` you can't create audits from the Core UI (DOC `it-asset-management/hardware-asset-management/audit-your-inventory.md`).
4. Scan tag, serial or model barcode; submit scans; mark **Complete**. No more scans are possible after that (DOC `it-asset-management/hardware-asset-management/scan-assets-agent-app.md`).
5. Read results: Expected, Not expected and location corrected, Missing, New, Excluded from licensing, Found but not in audit scope (DOC `it-asset-management/hardware-asset-management/audit-results.md`).
6. Separately pull CMDB and discovery data with timestamps. Match on stable identifiers and sort exceptions into: exact match, missing physical, stale discovery, duplicate serial, orphan CI, orphan asset, wrong assignment (starter procedure; PRACTICE). Normalization won't merge duplicate models (DOC `it-asset-management/hardware-asset-management/hardware-normalization.md`).
7. Close remediation tasks for **New** assets created with Unknown model category and Unknown model, after setting the correct model category and model (DOC `it-asset-management/hardware-asset-management/close-an-asset-remediation-task.md`).
8. Build a correction sheet (record, field, from → to, evidence, owner, rollback) and apply only approved rows; then re-run the counts.

**Validation:** post-correction counts reconcile to the physical count, or the remaining variance is listed as open findings.
**Risks/rollback:** the result label "Not expected and location corrected" suggests the audit updates the location of unexpected scans, but the page only defines it as "scanned but weren't expected" (DOC `it-asset-management/hardware-asset-management/audit-results.md`; location update VERIFY in sub-production). Snapshot locations first if you need the before state (PRACTICE). Multi-scan **New** creates real asset records, so review them before they reach reports. Don't set records to Missing without an investigation note (PRACTICE).

## 5. Refresh

**Prerequisites:** HAM. Role `inventory_user` to request; `asset` and `itil` for refresh line tasks; a procurement role for sourcing (the page names `proc_user`, VERIFY) (DOC `it-asset-management/hardware-asset-management/hardware-asset-refresh.md`).

1. Confirm eligibility from policy **and** data. `eligible_for_refresh` is computed weekly from the model's `useful_life`. Don't infer eligibility from age alone (starter; DOC same page).
2. Check contracts (lease end, warranty), outstanding assignment, linked CI, and data obligations before choosing the replacement path (PRACTICE).
3. **WRITE**, Service Catalog > Asset Lifecycle > **Hardware Asset Refresh Order**: single or multi model; select assets (single model applies the eligibility filter by default).
4. After approval and sourcing, close the Refresh Line tasks: (Pick) → Prepare asset (replacement In stock / Reserved) → Schedule refresh (In stock / Pending install) → Deploy new asset (replacement In use; allocations move over) → Reclaim aged asset (aged In stock / Pending disposal).
5. Hand the aged asset to procedure 9.

**Validation:** each refresh line is closed; the aged asset is In stock / Pending disposal with the Refresh request line cleared; allocations sit on the replacement.
**Risks:** the refresh flow's **Update Sourcing set Variable** step and the catalog variables must not be removed during customization (DOC same page). Zero Touch Refresh is a different, provider-fulfilled flow (DOC `it-asset-management/hardware-asset-management/zero-touch-asset-refresh.md`).

## 6. Reclaim from a leaver or mover

**Prerequisites:** HAM (or SAM Professional for software-only) for the Reclaim Asset catalog item. Any employee can submit; `inventory_user` or `inventory_admin` closes tasks (DOC `it-asset-management/hardware-asset-management/reclaim-asset.md`, `it-asset-management/hardware-asset-management/submit-asset-reclamation-request.md`, `it-asset-management/hardware-asset-management/close-asset-reclamation-request.md`).

1. Find the leaver's assets: In use with Assigned to = the user. For leavers already inactive, use `assigned_to.active=false` (`query-script-patterns.md` §4).
2. For a lost or stolen asset, record it as Missing / Lost or Stolen and clear Assigned to so it leaves the reclaim form (DOC submit page). Raise the security incident per policy (PRACTICE).
3. **WRITE**, Service Catalog > Asset Lifecycle > **Reclaim Asset**: Requested by (HR, Manager, Employee), Requested for, Employee separation, Asset, Reclaim method (drop off, pickup, shipment), Legal hold method.
4. Inventory > Asset Reclamation > Asset Reclamation Request: close Schedule drop off / pickup / shipment (stockroom; carrier, tracking and ship date for shipment) → stage Pending receive.
5. Close **Receive asset** (Is asset reclaimed = yes; quantity for consumables) → Assigned to cleared; In stock / Pending repair.
6. Close **Evaluate** with Re-deployable (In stock / Available), Needs repair (In stock / Pending repair) or To be disposed (In stock / Pending disposal). Wipe or reimage evidence is your process; the platform doesn't record it (PRACTICE; see `itam-secure-disposition`).

**Validation:** every line Complete and the request Complete; no In use assets left assigned to the leaver; software reclamation handled in SAM (`sam.md`).
**Risks:** bundles and pallets aren't supported without customization (DOC). Legal hold must be respected before any wipe (PRACTICE).

## 7. Loaner

**Prerequisites:** HAM. Asset function = Loaner on pool assets; `inventory_user` for tasks (DOC `it-asset-management/hardware-asset-management/prepare-deploy-reclaim-loaner-assets.md`).

1. The user requests via Service Catalog > Asset Lifecycle > **Loaner Asset Request**: start within 3 months, return within 6 months of the start. Waitlisted if there is no stock (DOC `it-asset-management/hardware-asset-management/loaner-asset-request.md`).
2. Inventory > Loaner > Loaner Asset Orders: close **Prepare** (In stock / Pending install, Reserved for set) → **Deploy** (In use, Assigned to set; consumables Consumed).
3. Reclaim: close **Reclaim** with Stockroom, Returned on, Asset returned, Asset functional → In stock / Available (or Reserved for the next order); not functional → In stock / Pending repair. Early return: **Reclaim** button.

**Validation:** the Hardware Asset dashboard shows loaner orders New, Deployed, Return Overdue (DOC same page); no loaner In use past its return date without a task.
**Risks:** excluded assets can't be loaners (DOC `it-asset-management/hardware-asset-management/ham-license-exclusion.md`); reclaiming to a different stockroom can affect queued orders (DOC).

## 8. Repair and RMA

**Prerequisites:** HAM. `asset` and `inventory_user` to submit an RMA; `asset`, `inventory_user` or `itil` for tasks (DOC `it-asset-management/hardware-asset-management/submit-rma-request.md`, `it-asset-management/hardware-asset-management/closing-rma-request.md`).

1. Decide internal repair (repair order; DOC `it-asset-management/hardware-asset-management/requesting-hardware-asset-repair.md`) or vendor RMA (in warranty or under contract; check warranty first, for example `sn_itam_common_asset_warranty`) (PRACTICE).
2. **WRITE**, RMA: Service Catalog > Asset Lifecycle > **Asset RMA Order**; add rows per asset (quantity for consumables).
3. Inventory > Return Merchandise Authorization > All RMA Requests > line > **Assessment** task: choose on-site or off-site → In stock / Pending repair.
4. Off-site: **Shipment** (carrier, tracking) → In transit; **Vendor RMA decision** (repair or replace); **Receive**. Repaired → In stock / Available. Replaced → select the replacement asset: new In stock / Available (Acquisition method RMA Replacement), old Retired / Vendor credit.
5. Record the serial swap on both records and follow the drive-retention or sanitization policy for the returned unit (PRACTICE; see `asset-data-model.md` T15).

**Validation:** every RMA line closed; the replacement asset has a unique serial and is linked to its CI; the old asset is Retired / Vendor credit.
**Risks:** cancelling is possible only before any Assessment task closes; a new RMA on the same asset cancels the old lines (DOC `it-asset-management/hardware-asset-management/return-merchandise-authorization.md`).

## 9. Disposal, resale and donation

**Prerequisites:** HAM; role `asset`; ITAD vendor agreed (DOC `it-asset-management/hardware-asset-management/create-disposal-order.md`).

1. Confirm the approved retirement pathway; check contracts, assignment, linked CI, legal hold, and data-sanitization obligations (starter; PRACTICE).
2. **WRITE**, create the disposal order: Core UI Inventory > Create Disposal Order, or Hardware Asset Workspace > Inventory view > Disposal orders > New (Stockroom, Vendor, Assigned to; pickup details).
3. **Planned Assets > Add**. **Verify Asset** → Retired / Pending disposal. Excluded assets can't be selected.
4. **Schedule Pickup** (vendor, vendor order ID, date, contact) → **Asset Departure** (shipped to, carrier, tracking; **Depart** selected assets → In transit / Pending disposal; the rest are cancelled).
5. **Vendor Confirmation** → **Disposal Documentation**: attach the certificate and documents, set Certificate of disposal = Yes, choose **Dispose** or **Sell** (Sell → Retired / Sold with resold value and a negative expense line) (DOC `it-asset-management/hardware-asset-management/create-resale-order.md`).
6. On completion: Disposal date set; maintenance-contract coverage ended (Date removed); entitlements removed (DOC create-disposal-order page).
7. Reconcile the certificate to each serial and file the sanitization evidence (PRACTICE; `itam-secure-disposition`). Donation instead: Asset Donation Order (DOC `it-asset-management/hardware-asset-management/asset-donation.md`).

**Validation:** count of Retired / Disposed (or Sold, Donated) assets = serials on the certificate; no disposed asset still on an active contract; linked CIs Retired.
**Risks:** no cancellation after the Transit stage. Never say "disposed" or "wiped" without the certificate and sanitization record in hand (core rule 2).

## 10. Lease end

**Prerequisites:** HAM; role `contract_manager`; lease contract with assets covered (DOC `it-asset-management/hardware-asset-management/manage-your-leased-hw-asts-expiring-contract.md`).

1. Notifications go out at 90, 60 and 30 days before expiry (notification "Lease contract threshold breached").
2. **WRITE**, Contract > Contracts > Leases > active lease > **Begin Lease expiration process**. A Planning task is created per covered asset (first 1,000 by default; `com.sn_hamp.flow.lease_contract_expiration.max_results` in `asset_property`).
3. Choose a Lease action per asset: **Return**, **Buy out** or **Extend**, and work the generated Contract Asset tasks (DOC `it-asset-management/hardware-asset-management/return-your-leased-hardware-asset.md`, `it-asset-management/hardware-asset-management/purchase-your-leased-hw-asset.md`, `it-asset-management/hardware-asset-management/extend-your-lease-contract.md`).
4. Returned assets end as Retired / Lease return; bought-out assets carry Buy out (substates per `ham.md` §3).

**Validation:** every covered asset has an action and closed tasks before the end date; the lessor's return receipt lists each serial (PRACTICE).
**Risks:** with HAM licensed, the **Renew** button doesn't appear for active leases that have covered assets; an asset on several leases shows only the most recent in its Lease contract field (DOC same page).
