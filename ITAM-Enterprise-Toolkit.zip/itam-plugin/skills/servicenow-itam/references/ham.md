# Hardware Asset Management (HAM) reference

Grounded in the official ServiceNowDocs repository, branch `brazil`, checked 2026-10-20. Doc paths are relative to `markdown/` in https://github.com/ServiceNow/ServiceNowDocs. Most cited pages show `last_updated` 2026-09-10; the repo README dates Brazil Early Availability to 24 Sept 2026.

Labels: `DOC (path)` = stated on that page; `PRACTICE` = ITAM practice, not product behavior; `VERIFY` = not found in the brazil docs, or release- or instance-dependent. Confirm in the instance (`sys_dictionary`, `sys_choice`, `sys_properties`, `v_plugin`) before relying on it.

Step-by-step procedures (navigation, roles, state effects) are in `procedures.md`. Asset-CI sync is in `asset-ci-cmdb.md`. Contracts, purchase orders and models are in `contracts-procurement.md`.

## Contents
1. Products and plugins: Base Asset Management vs Hardware Asset Management
2. Tables and fields
3. States and substates
4. Stockrooms, stock rules and transfer orders
5. Receiving
6. Reclamation, loaners and refresh
7. Repair and RMA
8. Retirement, disposal, resale and donation
9. Hardware model normalization and lifecycle
10. Inventory audits and asset attestation
11. Asset tasks from incident, change and FSM
12. HAM licensing, resource categories, exclusion and tiers
13. Roles
14. Hardware Asset Workspace
15. HAM system properties
16. Common questions and where to look
17. Canonical state model → ServiceNow state / substate

## 1. Products and plugins

| Item | What the docs say | Label |
|---|---|---|
| Base Asset Management | Core application for the financial tracking of company property. Owns `alm_asset` and its child tables, stockrooms, stock rules and transfer orders. Plugin `com.snc.asset_management` is the stated prerequisite for transfer order flows. | DOC (`it-asset-management/asset-management/am-landing-page.md`, `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`, `it-asset-management/asset-management/transfer-order-flows.md`) |
| Hardware Asset Management (HAM) | A *licensable* application (`sn_hamp`; also written `com.sn_hamp` and "Hardware Asset Management Professional plugin" on some pages). Adds workflow, automation and mobile capabilities: disposal orders, reclamation, loaners, refresh, RMA, normalization content, asset audits, attestation and more. Installed from the ServiceNow Store or Product Hub. | DOC (`it-asset-management/hardware-asset-management/ham-landing-page.md`, `it-asset-management/hardware-asset-management/install-ham.md`, `it-asset-management/hardware-asset-management/installing-ham-app.md`, `it-asset-management/hardware-asset-management/pallet-assets.md`) |
| Hardware Asset Workspace | Needs Asset Management Workspace (`sn_itam_workspace`) together with HAM (`sn_hamp`). | DOC (`it-asset-management/hardware-asset-management/using-ham-workspace.md`) |
| HAM Core UI | Limited support since the Washington DC release; ServiceNow directs users to the workspace (KB1584544). | DOC (`it-asset-management/hardware-asset-management/ham-landing-page.md`) |
| Hardware Model Normalization | Plugin `com.sn_hwnorm`, activated with `sn_hamp`. | DOC (`it-asset-management/hardware-asset-management/hardware-normalization.md`) |
| Procurement | Plugin `com.snc.procurement` (purchase orders, receiving slips). | DOC (`it-asset-management/procurement/t_ActivateProcurement.md`) |
| "HAM Pro" | Community shorthand. The docs name the subscription tiers "Hardware Asset Management Pro", "Hardware Asset Management Advanced" and a "Hardware Asset Management Prime SKU", plus "AI Native" vs "Non-AI Native" SKUs. No page maps every feature to a tier. | DOC for the names (`it-asset-management/hardware-asset-management/install-additional-ham-apps.md`, `it-asset-management/hardware-asset-management/install-ham-from-product-hub.md`, `it-asset-management/hardware-asset-management/ham-cm-pro-integration.md`, `it-asset-management/hardware-asset-management/product-hub-for-ham.md`). Tier-to-feature mapping: `VERIFY` against the order form |

Rule for answers (PRACTICE): when the entitlement is unknown, give the Base Asset Management answer first. Mark anything in sections 5–12 that depends on `sn_hamp` as conditional.

## 2. Tables and fields

Base Asset Management (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`):

| Table | Holds |
|---|---|
| `alm_asset` | General, financial and contractual data for all assets (root). |
| `alm_hardware` | Hardware assets. |
| `alm_consumable` | Consumables, tracked as quantities of one model. |
| `alm_license` | Software license assets. |
| `alm_entitlement`, `alm_entitlement_asset`, `alm_entitlement_user` | License entitlements (SAM side; see `sam.md`). |
| `alm_fixed_assets`, `m2m_fixed_asset_to_asset` | Fixed assets (containers of assets) and their members. |
| `alm_stockroom`, `alm_stockroom_type`, `alm_m2m_stockroom_model`, `alm_user_stockroom` | Stockrooms, types, models ever stocked, a user's default stockroom. |
| `alm_stock_rule` | Stock rules. |
| `alm_transfer_order`, `alm_transfer_order_line` | Transfer orders and lines. Tasks are in `alm_transfer_order_line_task`; templates in `alm_template_task`, `alm_custom_template_task` and `alm_template_subtask`. |
| `asset_job_log`, `asset_job_log_detail`, `alm_asset_creation_queue` | Asset job logging and queued asset creation (see `asset-ci-cmdb.md`). |

The default asset classes are Hardware, Software License, Consumable, Bundle, Software Entitlement and Facility. Create a custom class only after checking that the general classes don't fit (DOC `it-asset-management/asset-management/c_AssetClasses.md`).

The HAM application (`sn_hamp`) adds, among others (DOC `it-asset-management/hardware-asset-management/installed-with-ham.md`):
- `alm_bundle` and `sn_hamp_asset_audit` (legacy audits).
- Reclamation: `sn_hamp_asset_reclaim_line`, `sn_hamp_asset_reclaim_task`.
- RMA: `sn_hamp_rma_request`, `sn_hamp_rma_request_line`, `sn_hamp_asset_rma_task`.
- Disposal: `sn_hamp_hardware_disposal`, `sn_hamp_hw_asset_disposal_task`, `sn_hamp_m2m_hw_asset_disposal` (planned assets).
- Refresh: `sn_hamp_hw_refresh_line`, `sn_hamp_hw_refresh_line_task`.
- Loaners: `sn_hamp_loaner_asset_order`, `sn_hamp_loaner_asset_task`.
- Normalization and lifecycle: `sn_hamp_lifecycle_definition`, `sn_hamp_hw_product_model` and the other library tables.
- Licensing: `sn_hamp_resource_category`.
- Zero Touch Refresh: `sn_hamp_ztr_request` and related tables.
- Contract renewal: `sn_contract_renewal_request`, `_line`, `_task`.
- `rfid_asset`.
- Common HAM/EAM tables: `sn_itam_common_repair_order`, `sn_itam_common_asset_order`, `sn_itam_common_loaner_asset_order` and `sn_itam_common_shipment`.

Other tables used in HAM work:

| Table | Use | Label |
|---|---|---|
| `cmdb_model_category` | Links the asset class, CI class (and IBI class). Decides whether an asset is created from a CI, and of what class. | DOC (`it-asset-management/product-catalog/c_ModelCategories.md`) |
| `cmdb_model`, `cmdb_hardware_product_model` | Product models; hardware models. | DOC (`it-asset-management/product-catalog/r_TablesProductCatalog.md`, `it-asset-management/hardware-asset-management/hardware-asset-content-pack.md`) |
| `cmdb_hardware_model_lifecycle`, `cmdb_consumable_model_lifecycle` | Model lifecycle phases and dates loaded from content. | DOC (`it-asset-management/hardware-asset-management/approximated-lifecycles-hardware-products.md`) |
| `ast_contract`, `clm_m2m_contract_asset` | Contracts; assets covered. | DOC (`it-asset-management/contract-management/r_TablesInstalledWContractMgmt.md`) |
| `proc_po`, `proc_po_item`, `proc_rec_slip`, `proc_rec_slip_item` | Purchase orders, lines, receiving slips. | DOC (`it-asset-management/procurement/r_TablesProcurement.md`) |
| `sn_itam_common_asset_audit` | Common asset audits (HAM 15.0.0+, when enabled). | DOC (`it-asset-management/hardware-asset-management/ham-inventory-audit.md`) |
| `sn_itam_common_asset_attestation`, `sn_itam_common_attestation_schedule` | Asset attestation. | DOC (`it-asset-management/hardware-asset-management/asset-attestation-ham.md`) |
| `sn_itam_common_asset_warranty` | Asset warranty records (for example from Lenovo). | DOC (`it-asset-management/hardware-asset-management/integration-with-lenovo-asset-warranty.md`) |

**Field names.** The docs mostly give field *labels*. Names such as `install_status` (State), `substatus` (Substate), `asset_tag`, `serial_number`, `assigned_to`, `reserved_for`, `stockroom`, `ci`, `model_category` and `warranty_expiration` are platform conventions; confirm each in `sys_dictionary` (`name=alm_hardware^ORname=alm_asset`) before a script or import (VERIFY). Documented field names include `eligible_for_refresh`, `planned_for_disposal`, `pre_allocated`, `mac_address`, `excluded_from_ham` and `product_instance_id` (DOC `it-asset-management/hardware-asset-management/asset-record-fields.md`, `it-asset-management/hardware-asset-management/hardware-asset-refresh.md`, `it-asset-management/hardware-asset-management/installed-with-ham.md`). The **Asset function** field takes Primary, Secondary, Shared, Loaner or Asset Bundle (DOC `it-asset-management/hardware-asset-management/asset-record-fields.md`).

## 3. States and substates

Rules (DOC `it-asset-management/asset-management/t_SettingAssetStatesAndSubstates.md`; role `asset`):
- Don't modify **state** values. Substates may be modified where the process defines them.
- Some substates belong to several states. Pending disposal appears under In stock, In transit and Retired. The state + substate pair is the status.
- Read numeric values from `sys_choice`; never hard-code them (PRACTICE).

Documented pairs (brazil):

| State | Substates | Notes |
|---|---|---|
| On order | none | Ordered, not received. |
| In stock | Available; Reserved (for a sourcing-request requester); Defective; Pending repair (marked for vendor repair); Pending install; Pending disposal; Pending transfer (planned on a transfer order); Pre-allocated (ready to allocate; not a financial liability until allocated); On hold; Legal hold; Quarantine; Pending fulfillment; Pending certificate (awaiting disposal certificate); Pending return (leased, not yet returned); Test; End of support; Pending Retirement; Pending resale; Pending evaluation | Stored in a stockroom; the substate says whether it can be used. |
| In transit | Available; Reserved; Defective; Pending install; Pending disposal; Pending donation; Pre-allocated; Pending resale | Being transported. |
| In use | Pending fulfillment; End of support; Pending retirement; None | Non-consumables only. |
| In maintenance | none | Being repaired or maintained. |
| Retired | Disposed; Pending disposal; Sold; Donated; Vendor credit (returned through RMA for a replacement); Lease return; Obsolete; RMA; Buy out; Pending resale | Delete records only if they were created in error. |
| Missing | Lost; Stolen | |
| Build | none | Used while creating an asset bundle. Hardware and consumables don't have a Build state. |

Also documented: **Consumed** is a consumable lifecycle stage. The consumable stages are On order, In stock, In transit, Consumed, In maintenance, Retired and Missing (DOC `it-asset-management/asset-management/c_FollowLifeCycleConsumbl.md`). A **Design** state is not in the brazil docs; `VERIFY` in `sys_choice` (the earlier skill cited a KB for it).

**Release differences.** Compare before quoting a list. The zurich branch lists Pending donation under In stock and doesn't list Pending fulfillment, End of support or Pending Retirement under In stock (zurich `it-asset-management/asset-management/t_SettingAssetStatesAndSubstates.md`, last_updated 2025-07-31). Always read the user's `sys_choice`.

Platform behaviors tied to state (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`):
- The **Asset Retirement** business rule clears Assigned to, Stockroom and Reserved for, and sets the retirement date.
- **Clear Assigned To on update** clears Assigned to when the state becomes On order, In stock or In transit.
- **Transition reserved to assigned** fills Assigned to from Reserved for when the state allows it.
- The UI policy **Make substatus read-only when not required** makes Substate read-only for On order, In use, Consumed and In maintenance. This conflicts with the In use substates listed above. `VERIFY` which applies in the user's release (check the UI policy and `sys_choice`).
- Retiring an asset also sets related CIs to Retired. Moving it back out of Retired reactivates it (DOC `it-asset-management/asset-management/t_RetiringAssets.md`).

## 4. Stockrooms, stock rules and transfer orders

**Stockrooms** are standalone entities in Base Asset Management (DOC `it-asset-management/asset-management/c_Stockrooms.md`). Each stockroom type carries a sourcing **priority** and a **shipment required** flag (DOC `it-asset-management/hardware-asset-management/r_StockroomTypes.md`):

| Type | Priority | Shipment required |
|---|---|---|
| On Site | 1 | No |
| Field Agent | 2 | No |
| FSL | 4 | Yes |
| PUDO | 5 | Yes |
| Warehouse | 6 | Yes |
| Central Warehouse | 7 | Yes |

HAM adds service locations, distribution channels, aisles and spaces, put-away and pick tasks, pallets, RFID and indoor maps (DOC `it-asset-management/hardware-asset-management/manage-your-stockrooms.md`, `it-asset-management/hardware-asset-management/associate-stockroom-with-service-locations.md`, `it-asset-management/hardware-asset-management/add-aisle-space-stockroom-ham-ws.md`).

**Stock rules belong to Base Asset Management**, not to HAM only. This corrects the earlier community claim. The table is `alm_stock_rule`, and creating one needs `inventory_admin` (DOC `it-asset-management/asset-management/c_StockRules.md`, `it-asset-management/hardware-asset-management/t_CreateAStockRule.md`):
- The **Stock Rule Runner** job runs daily.
- Restocking option **Stockroom** creates a transfer order from the parent stockroom.
- Restocking option **Vendor** emails the stockroom manager. With Procurement active it also creates a PO and PO line, but only for models published as vendor catalog items.
- With HAM installed and the rule set to Vendor or Service Catalog, the job submits a Service Catalog request (Hardware Inventory Stock Order) instead of a PO.
- Without Procurement and HAM, the job creates a task for the stockroom manager.
- A transfer is created only if the parent stockroom has enough **Available** stock (Reserved, Pending install and similar don't count) for the full restocking quantity. That quantity is the shortfall rounded up to a multiple of the order size.
- The `pending_delivery` flag prevents duplicates while restocking is in progress; set it back to false once processed. Setting `glide.sc.checkout.twostep=true` interrupts automatic request submission.
- Loaner assets aren't counted in stockroom counts when stock rules run (DOC `it-asset-management/hardware-asset-management/loaner-asset.md`).

**Transfer orders** belong to Base Asset Management; role `inventory_user` (DOC `it-asset-management/asset-management/manage-transfer-orders.md`, `it-asset-management/asset-management/t_TransferAssetsUsingTransferOrders.md`, `it-asset-management/asset-management/r_TrsferOrderLneAssetTrackNonConsum.md`):
- A transfer order has one From stockroom, one To stockroom and one or more lines. Non-consumables move as quantity 1; consumables by quantity; pre-allocated assets only in full quantity.
- Line stages and the effect on a non-consumable asset:

| Line stage | Asset state / substate |
|---|---|
| Draft | In stock / Pending transfer (the asset shows as reserved and can't be requested) |
| Requested | In stock / Pending transfer |
| Shipment Preparation | In stock / Pending transfer (carrier, tracking and ship date recorded) |
| In Transit | In transit / Reserved |
| Received | In stock / Available, Stockroom = destination |
| Delivered | In stock / Reserved |

- Closing a task opens the next one. **Closed Skipped** doesn't update the asset, so update it manually (DOC `it-asset-management/asset-management/manage-transfer-orders.md`).
- If From and To are the same stockroom, the order jumps from Draft to Received when a line is added (DOC `it-asset-management/asset-management/t_TransferAssetsUsingTransferOrders.md`).
- With Field Service Management active, FSM workflows process transfer order lines (DOC `it-asset-management/asset-management/manage-transfer-orders.md`).
- Transfer order and line processing runs on Workflow Studio flows when `com.sn_itam.enable_flow_designer.transfer_order` and `..._line` are on (DOC `it-asset-management/hardware-asset-management/ham-system-properties.md`).

**Pre-allocated assets** are vendor-owned stock held in your stockroom for just-in-time procurement. They become a liability only when allocated, so they aren't the same as Reserved (DOC `it-asset-management/asset-management/manage-preallocated-asset.md`, `it-asset-management/asset-management/t_SettingAssetStatesAndSubstates.md`).

## 5. Receiving

**PO receiving** (Procurement; roles `procurement_admin` or `procurement_user`) (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`, `it-asset-management/procurement/c_ReceiveAssets.md`):
- Receiving with **Reserve** on sets In stock / Reserved and fills Reserved for. Without it, the asset is In stock / Available.
- Capture asset tag, serial number and (with EAM/OT) MAC address. If the model category maps to a CI class whose identification rules use those fields, at least one of them is required.
- Each receipt creates a receiving slip. The PO becomes Received only when every line is received.

With `glide.asset.create_ci_with_ire` on, a serial number is required to receive PO lines whose model category maps to a CI class that identifies on serial (DOC `it-asset-management/asset-management/c_ManagingAssets.md`).

**Standardized stockroom receiving** (HAM workspace) (DOC `it-asset-management/hardware-asset-management/stockroom-receiving-ham.md`):
- Receive single assets by tag, serial or MAC, from inbound shipments, or in bulk from an Excel template (rows land in `sn_itam_cmn_import_asset_row`).
- Receipt moves the asset from In transit to In stock, sets the stockroom and closes receive tasks in the source workflow.
- Consumables can be received only in complete quantities.
- Receiving PO lines here needs Zurich, Yokohama Patch 11 or Xanadu Patch 10, or later.

Advanced Shipment Notification imports, carrier integrations and stale-shipment tracking are HAM features (DOC `it-asset-management/hardware-asset-management/asn-for-ham.md`, `it-asset-management/hardware-asset-management/stale-shipments.md`).

## 6. Reclamation, loaners and refresh

**Reclamation** (HAM) (DOC `it-asset-management/hardware-asset-management/reclaim-asset.md`, `it-asset-management/hardware-asset-management/close-asset-reclamation-request.md`):
- The **Reclaim Asset** catalog item (Service Catalog > Asset Lifecycle) creates an Asset Reclamation Request with one Hardware Asset Reclamation Line per asset.
- Each line has up to three tasks: Schedule drop off, pickup or shipment (by method); Receive asset; Evaluate. Line stages run Ready → Pending receive → Pending evaluation → Complete.
- HR professionals can submit for anyone, managers for their reports, and employees for themselves. The feature links Asset Management with the HR module.
- Service Catalog submission needs SAM Professional or HAM Professional. With SAM only, just the software reclamation flow runs.
- Hardware and consumables only; bundles and pallets need customization.
- On **Receive asset**, Assigned to is cleared and the asset becomes In stock / Pending repair.
- **Evaluate** sets the outcome: Re-deployable → In stock / Available; Needs repair → In stock / Pending repair; To be disposed → In stock / Pending disposal.
- To keep a lost or stolen asset off the form, clear its Assigned to first (DOC `it-asset-management/hardware-asset-management/submit-asset-reclamation-request.md`).
- Offboarding triggered automatically from an HR case isn't described on these pages. `VERIFY` by looking for an HRSD integration in the instance.

**Loaners** (HAM) (DOC `it-asset-management/hardware-asset-management/loaner-asset.md`, `it-asset-management/hardware-asset-management/loaner-asset-request.md`, `it-asset-management/hardware-asset-management/prepare-deploy-reclaim-loaner-assets.md`):
- Mark the asset with **Asset function = Loaner**. Only hardware, bundles and consumables can be loaners.
- A Loaner Asset Request must start within three months of submission and end within six months of the start. Requests without stock go on a waitlist. A daily job assigns loaners on the preparation start day.
- **Prepare** is created two days before the start by default. The catalog variable "Number of days required for preparing the loaner asset" changes this, and only `catalog_admin` can edit it. This corrects the earlier `lead_time` claim.
- **Deploy** follows Prepare. **Reclaim** is created one day before the return date, after a reminder email two days before.
- State effects:
  - Prepare closed: In stock / Pending install, Reserved for set.
  - Deploy closed: In use, stockroom cleared, Assigned to set (Managed by for a third-party vendor). A consumable becomes Consumed.
  - Reclaim: In stock / Available, or Reserved if a future loaner order is waiting. An asset that isn't functional goes to In stock / Pending repair.
- Role `inventory_user`. Navigation: Inventory > Loaner > Loaner Asset Orders.

**Refresh** (HAM) (DOC `it-asset-management/hardware-asset-management/hardware-asset-refresh.md`):
- The **Hardware Asset Refresh Order** catalog item takes a single model or multiple models (up to 50 rows).
- Approval triggers the Source Request flow. On receipt, the Hardware Asset Refresh Line flow runs:
  1. Asset pick task (only for local stock with pick tasks enabled).
  2. Prepare asset: the replacement becomes In stock / Reserved.
  3. Schedule refresh: the replacement becomes In stock / Pending install.
  4. Deploy new asset: the replacement becomes In use, and allocations move from the aged asset to the replacement.
  5. Reclaim aged asset: the aged asset becomes In stock / Pending disposal.
- The weekly job **SAM - Calculate Asset Refresh Eligibility** sets `eligible_for_refresh` on `alm_hardware` from the model's `useful_life` (months). The single-model form filters on it; the multi-model form doesn't.
- Roles: `inventory_user` to request; `asset` and `itil` for refresh line tasks. The page names `proc_user` for sourcing, but the Procurement role pages list `procurement_user`, so `VERIFY` the role name.
- **Zero Touch Refresh** sends refresh fulfillment to an external provider, with no local stock (DOC `it-asset-management/hardware-asset-management/zero-touch-asset-refresh.md`).
- A refresh policy such as "laptops every N years" is an organizational input, not a platform default (PRACTICE).

## 7. Repair and RMA

- The **Repair flow** handles internal repair of stockroom assets. Repair orders (`sn_itam_common_repair_order`) move through Troubleshoot → Repair → Evaluate (DOC `it-asset-management/hardware-asset-management/requesting-hardware-asset-repair.md`, `it-asset-management/hardware-asset-management/fulfilling-repair-orders-ham.md`).
- **RMA** handles vendor repair or replacement. The Asset RMA Order catalog item creates one RMA request line per asset, and an Assessment task decides on-site or off-site repair (DOC `it-asset-management/hardware-asset-management/return-merchandise-authorization.md`, `it-asset-management/hardware-asset-management/submit-rma-request.md`, `it-asset-management/hardware-asset-management/closing-rma-request.md`):
  - Assessment closed: the faulty asset becomes In stock / Pending repair.
  - Off-site Shipment closed: In transit. Then a Vendor RMA decision task (repair or replace) and a Receive task.
  - Repaired: In stock / Available.
  - Replaced: the new asset is In stock / Available with Acquisition method "RMA Replacement"; the old asset becomes Retired / Vendor credit.
  - An RMA can be cancelled only while no Assessment task is closed. Roles: `asset` and `inventory_user` to submit; `asset`, `inventory_user` or `itil` for the tasks.
- These flows keep assets in **In stock** substates and don't set **In maintenance** (DOC, same pages). Use In maintenance only if the organization's process says so (PRACTICE).
- The DaaS RMA pages (`it-asset-management/hardware-asset-management/assess-rma.md`, `it-asset-management/hardware-asset-management/evaluate-rma-asset.md`) describe the provider side (Hardware Asset Management for DaaS, `com.sn_daas_ham`), not customer RMA.

## 8. Retirement, disposal, resale and donation

- **Retire** (Base; role `asset`): State Retired with substate Disposed, Sold, Donated or Vendor credit (DOC `it-asset-management/asset-management/t_RetiringAssets.md`).
- **Delete** only to clean up errors. Deleting a linked asset or CI deletes the other. An asset in a bundle can't be deleted (DOC `it-asset-management/asset-management/t_DeletingAssets.md`).
- **Disposal order** (HAM; role `asset`; Core UI Inventory > Create Disposal Order, or the workspace Inventory view > Disposal orders) (DOC `it-asset-management/hardware-asset-management/create-disposal-order.md`, `it-asset-management/hardware-asset-management/hardware-disposal-stages.md`):

| Stage | Task | Effect |
|---|---|---|
| Draft | Verify Assets | Verified assets become Retired / Pending disposal. |
| Scheduling | Schedule Pickup | Records vendor, vendor order ID, date and contact. |
| Transit | Asset Departure | Departed assets become In transit / Pending disposal. Planned assets that don't depart are cancelled. |
| Confirmation | Vendor Confirmation | No cancellation after this point. |
| Documentation | Disposal Documentation | Attach documentation **and** set Certificate of disposal = Yes to close. Choose Dispose or Sell (HAM 15.0.0+). |
| Completed | — | Disposal date set; maintenance-contract coverage gets a Date removed; entitlements on the asset are removed. |

  A disposal order can be cancelled only until the Transit stage. Consumables join through **Mark for disposal** (`planned_for_disposal`).
- **Resale**: in the Documentation stage, Sell sets Retired / Sold, records the resold value and creates a negative expense line (DOC `it-asset-management/hardware-asset-management/create-resale-order.md`).
- **Donation**: an Asset Donation Order for in-stock hardware and consumables, approved by the asset manager and completed when the charity acknowledges delivery (DOC `it-asset-management/hardware-asset-management/asset-donation.md`).
- **Evidence** (PRACTICE; see `itam-secure-disposition`): a per-serial sanitization record, a certificate matched to each serial, and a chain-of-custody manifest. The platform requires a document and the Yes flag; it doesn't check that the certificate lists each serial. Check that yourself.

## 9. Hardware model normalization and lifecycle

Sources: DOC `it-asset-management/hardware-asset-management/hardware-normalization.md`, `it-asset-management/hardware-asset-management/Work-with-hardware-normalization.md`, `it-asset-management/hardware-asset-management/normalize-hardware-consumable-models.md`, `it-asset-management/hardware-asset-management/approximated-lifecycles-hardware-products.md`, `it-asset-management/hardware-asset-management/revert-norm-ham.md`, `it-asset-management/hardware-asset-management/calculate-active-lifecycle-phase-ham.md`.

- Normalization compares manufacturer, product, model and device type against the Hardware Model Normalization Content Service. It fills normalized fields plus end-of-life and end-of-support dates.
- The **HAM - Hardware Normalization** job runs daily. It doesn't add, remove or merge models, and doesn't change the original Model name, Manufacturer or Model number; it updates only the normalization fields. Duplicate models stay duplicates.
- Normalization runs only for models in the TOP/Default domain, unless **Run asset process** is set for a domain in `alm_domain_asset_process_setting`.
- Models in opted-out HAM resource categories are excluded (section 12).
- Statuses include Fully, Partially, Manufacturer, Publisher and Manually Normalized, and Match not Found. Full normalization needs the manufacturer and model number.
- **Revert Normalization** deactivates the rule permanently and reverts every model that rule normalized.
- Lifecycle dates: the **HAM - Hardware Lifecycles** job loads phases into `cmdb_hardware_model_lifecycle` and `cmdb_consumable_model_lifecycle`. A **Lifecycle code** marks approximated dates (codes in `sn_itam_common_lifecycle_code` and `sn_hamp_lifecycle_code`; see KB2726382).
- The property for approximated dates appears as `sn_hamp.approximate_dates_in_hw_lifecycle` on one page and `approximate_dates_in_hw_lifecycle` on another (default true). `VERIFY` the name in `sys_properties`.
- Opt in to the Content Service at Asset > Administration > Hardware Model Normalization > Content Service Setup. Role `ham_admin`, plus `domain_admin` if the instance is domain-separated (DOC `it-asset-management/hardware-asset-management/opt-in-hardware-normalization.md`). Request missing content through the ITAM content request process (DOC `it-asset-management/asset-management/content-request-itam.md`).
- To find gaps (PRACTICE), list normalized models with no lifecycle rows, or with rows that carry only a lifecycle code.

## 10. Inventory audits and asset attestation

**Inventory audits** (HAM) (DOC `it-asset-management/hardware-asset-management/ham-inventory-audit.md`, `it-asset-management/hardware-asset-management/audit-your-inventory.md`, `it-asset-management/hardware-asset-management/create-audit-using-mobile-app.md`, `it-asset-management/hardware-asset-management/scan-assets-agent-app.md`):
- Create scheduled audits in the app or workspace (role `asset`). Create blind or unscheduled audits from the **ServiceNow Agent** mobile app.
- Scan the asset tag, serial number or model barcode, by single scan or multi scan. Include consumables forces single scan.

Setting `sn_hamp.migrate_hamaudit = true` (HAM 15.0.0+) changes the audit model (DOC `it-asset-management/hardware-asset-management/ham-system-properties.md`, `it-asset-management/hardware-asset-management/view-deprecated-audit-records.md`):
- Audits are stored in `sn_itam_common_asset_audit`, and users need `asset` plus `sn_itam_common.asset_audit_admin` or `.asset_audit_user`.
- Close all New and In progress audits first. Afterwards, old audits are read-only under Audits [Deprecated].
- `inventory_user` and `inventory_admin` lose access unless ACLs are configured.

**Results** in the common table: Expected, Not expected and location corrected, Missing, New, Excluded from licensing, and Found but not in audit scope. A scan of an unknown asset creates an asset with Unknown model category and Unknown model; multi scan also creates a remediation task (DOC `it-asset-management/hardware-asset-management/audit-results.md`).

**Asset Attestation** (DOC `it-asset-management/hardware-asset-management/asset-attestation-ham.md`):
- Employees confirm their assigned serialized assets through Now Mobile or Employee Center (needs `sn_ex_sp` and `sn_employee`).
- One-time or scheduled; schedules run through the "ITAM Common- Asset attestation" job.
- Only opted-in resource categories; no consumables, bundles or pallets.

PRACTICE: an audit variance is a finding. Don't edit records to match a count without an investigation note (see `procedures.md` §4).

## 11. Asset tasks from incident, change and FSM

With HAM installed, these processes can update the CI and asset, software allocations and maintenance contracts (DOC `it-asset-management/hardware-asset-management/asset-lifecycle-automation.md`):
- Incident: Update/Repair, Swap, Retire.
- Change: Deploy, Retire.
- Field Service: Deploy.

By default, an **asset action is required to close incidents and change requests**. Turn this off with `sn_hamp.enable_asset_action_validation_incident` or `..._change_request` (KB1695540). Automated workflows skip excluded assets.

## 12. HAM licensing, resource categories, exclusion and tiers

Sources: DOC `it-asset-management/hardware-asset-management/ham-licensing.md`, `it-asset-management/hardware-asset-management/licensing-ham-solutions.md`, `it-asset-management/hardware-asset-management/ham-license-exclusion.md`.

- HAM is licensed by **resource category**, and only opted-in categories count toward subscription units.
- An asset in `alm_asset` counts if its category is opted in and it is in an active state (not Disposed or Retired), whether or not it's assigned. Licensing doesn't depend on CMDB CIs.
- Ratios (assets per subscription unit):

| Resource category | Ratio |
|---|---|
| End User Computers | 4:1 |
| Servers | 1:1 |
| Network Gear | 5:1 |
| Mobile Device | 10:1 |
| Telecom Network Inventory | 1:1 |
| Unclassified hardware | 1:1 |
| Monitors | 15:1 |
| Storage | 3:1 |
| Printers | 10:1 |

  The last four need HAM 10.1.0+ and HAM license version 5.0.
- Normalization and asset actions don't work for a category until it is opted in.
- Custom model categories inherit from an opted-in parent. `sn_hamp.enable_custom_category_licensing` governs pre-v4 SKUs. On-premise instances store entitlements in `sn_hamp.sn_ham_active_entitlements`.
- With several HAM solutions active (Zero Touch Mobility, Telecom Network Inventory, HAM), each category is licensed under one solution, by priority (HAM 10.1.0+).
- **Excluded** assets can't be used in loaner, disposal, refresh, lease, bundle, RMA, audit, RFID, lifecycle automation, pallet or donation flows. An asset is excluded if its category is opted out or its `excluded_from_ham` flag is set (by `sn_hamp.ham_system_admin`). A flow already running on the asset finishes.
- Check usage under ITAM licensing > ITAM License Report or Subscription Summary (role `asset_licensing_admin`) (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`, `it-asset-management/hardware-asset-management/view-license-report-ham.md`).
- **Tier boundaries** (Pro / Advanced / Prime): the docs tie only a few features to a tier. Contract Management Pro obligation extraction needs the Prime SKU (DOC `it-asset-management/hardware-asset-management/ham-cm-pro-integration.md`). ServiceNow Otto agentic features follow the Foundation / Advanced / Prime AI tiers (see `now-assist-ham.md`). For everything else, `VERIFY` against the order form and the Product Hub Not installed tab.

## 13. Roles

| Role | Contains / grants | Source |
|---|---|---|
| `asset` | category_manager, contract_manager, financial_mgmt_user, inventory_user, procurement_user. Manages hardware and consumables; can read and delete, but not edit, automatically created asset records. | DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md` |
| `inventory_admin` | inventory_user; stock information; stock rules, stockrooms and types. | same |
| `inventory_user` | Stock information; create and manage transfer orders. | same |
| `sam` | contract_manager, model_manager, financial_mgmt_user (software licenses). | same |
| `asset_system_admin`, `asset_task_admin`, `asset_licensing_admin`, `asset_recommendation_admin`, `procurement_system_admin`, `contract_system_admin` | Granular admin roles: job logs, system properties, transfer order templates, licensing reports, important actions, contract properties. | same |
| `ham_admin` | inventory_admin, catalog_manager, report_user, sn_hamp.ham_user, asset, procurement_admin. Full HAM access, including Content Service opt-in. | DOC `it-asset-management/hardware-asset-management/installed-with-ham.md` |
| `sn_hamp.ham_user` | asset. Day-to-day hardware asset CRUD and reports. | same |
| `sn_hamp.ham_system_admin` | HAM licensing exclusion flag, resource categories, guided setup, HAM properties. | same |
| `sn_hamp.ham_asn_admin`, `asset_integration_admin`, `asset_aia_admin` | ASN import; provider and carrier integration profiles; ITAM AI agent logs. | same |
| `sn_itam_common.asset_audit_admin`, `.asset_audit_user` | Audits when `sn_hamp.migrate_hamaudit` is true. | DOC `it-asset-management/hardware-asset-management/audit-your-inventory.md` |
| `procurement_admin`, `procurement_user` | POs, sourcing, receiving. procurement_user contains financial_mgmt_user and model_manager. | DOC `it-asset-management/procurement/r_ProcurementRoles.md` |
| `contract_manager` | financial_mgmt_user; the contract lifecycle. | DOC `it-asset-management/contract-management/r_UserRolesIWContractMgmt.md` |
| `model_manager`, `category_manager` | Create models; category_manager also administers model categories. | DOC `it-asset-management/product-catalog/r_RolesProductCatalog.md` |
| `ia_admin`, `ia_user` | Product Hub install / view. | DOC `it-asset-management/hardware-asset-management/product-hub-for-ham.md` |

Workspace access list: inventory_admin, procurement_user, inventory_user, model_manager (printed "model_manger" on the page), contract_manager, itil, sam_admin, asset, catalog_manager, ham_admin, sam_user, catalog_admin and sam (DOC `it-asset-management/hardware-asset-management/ham-workspace-roles.md`). Before advising on access, read the role's contents from `sys_user_role_contains` in the instance (VERIFY).

## 14. Hardware Asset Workspace

Views (DOC `it-asset-management/hardware-asset-management/using-ham-workspace.md`, `it-asset-management/hardware-asset-management/hardware-asset-overview.md`):
- **Hardware asset overview**: important actions; dashboards for normalization, requests, transfer orders, stock orders, reservations, RMA, refresh and disposal; filters by location, stockroom and model category.
- **Asset analytics**: TCO and KPIs.
- **DaaS provider**: needs `com.sn_daas_ham`.
- **Inventory**: audits, disposal orders, stockrooms, attestation.
- **Asset estate**: expiring assets and leases.
- **Model management** and the **Content lookup portal**.
- **Procurement** and **Contract management**.
- **Success portal**.
- **Asset operations**: stock rules, stock orders, sourcing requests, contract renewals, custom products and models, warranties.

Configure HAM from the **Configuration Console**, with modules HAM Foundations, Team management, Otto and Operations (DOC `it-asset-management/hardware-asset-management/config-console-ham.md`).

## 15. HAM system properties

Read the current value in `sys_properties` (or in `asset_property` where stated) before explaining behavior. Documented in `it-asset-management/hardware-asset-management/ham-system-properties.md` unless noted:

| Property | Effect |
|---|---|
| `glide.asset.create_ci_with_ire` | Create CIs from assets through IRE (see `asset-ci-cmdb.md`). |
| `glide.create_alm_asset.async` | Defer asset creation from CIs to a scheduled job. |
| `sn_itam_enable_cache_for_asset_ci_mapping` | Cache asset-CI field and status mappings. |
| `sn_hamp.update_assets_norm_model_name` | Update asset records with the normalized model name. |
| `sn_hamp.enable_asset_action_validation_incident`, `..._change_request` | Require an asset action to close incidents or changes. |
| `sn_hamp.migrate_hamaudit` | Move audits to the common audit table (section 10). |
| `glide.asset.procurement.sourcing.local_stock_transfer` | Offer local stock transfer as a sourcing option. |
| `glide.itam_update_ci_status_from_ritm` | Which CIs a requested item updates (true on upgraded instances, false on new ones). |
| `sn_itam_tol_bulk_update_max_count`, `sn_itam_stockrulejob_batch_size` | Cap on bulk transfer order line updates; stock rule batch size. |
| `com.sn_itam.enable_flow_designer.transfer_order`, `..._line`, `.source_request`, `.contract_approval` | Run those processes on Workflow Studio flows. |
| `sn_itam_common.sn_contract_enable_renewal_flow` | Contract renewal flow (see `contracts-procurement.md`). |
| `sn_hamp.enable_custom_category_licensing`, `sn_hamp.sn_ham_active_entitlements` | Licensing (section 12). |
| `com.sn_hamp.flow.lease_contract_expiration.max_results` (in `asset_property`) | Planning tasks per lease expiration run; default 1000 (DOC `it-asset-management/hardware-asset-management/manage-your-leased-hw-asts-expiring-contract.md`). |

## 16. Common questions and where to look

| Question | Approach |
|---|---|
| Laptops in use or in stock by location | GlideAggregate on `alm_hardware` grouped by state, substate and stockroom, filtered by model category (`query-script-patterns.md`). The workspace overview shows the same by lifecycle state. |
| Assets assigned to inactive users | `alm_hardware` In use with `assigned_to.active=false`; start reclamation (`procedures.md` §6). |
| Stockroom says 40, shelf says 35 | Inventory audit (section 10) and a variance investigation (`procedures.md` §4). |
| Models going end of support | `cmdb_hardware_model_lifecycle` phases and the Model management view. Check lifecycle codes for approximated dates. |
| Assets not counted in HAM licensing | Resource category opt-in and `excluded_from_ham` (section 12). |
| Disposal order won't close | The Documentation task needs an attachment and Certificate of disposal = Yes (section 8). |
| Incident won't resolve after HAM install | Asset action validation property (section 11). |
| Asset missing from the refresh form | `eligible_for_refresh` and the single-model default filter (section 6). |
| Stock rule fired but no transfer | The parent stockroom lacks Available stock for the full rounded quantity, or `pending_delivery` is still true (section 4). |

## 17. Canonical state model → ServiceNow state / substate

The plugin's canonical states are in `asset-data-model.md` §4. This table is the starting map against the **brazil documented** pairs in section 3. Confirm every row in `sys_choice` and against the user's custom substates. "Custom" means there is no documented equivalent, so the organization decides. Where a HAM flow writes a specific pair, the flow is cited, so the mapping matches what automation writes.

| Canonical | ServiceNow state / substate | Basis |
|---|---|---|
| `ON_ORDER` | On order / none | DOC (states page) |
| `CANCELLED` | No documented state. Cancel the PO (`it-asset-management/procurement/t_CancelAPurchaseOrder.md`). For a pre-created On order asset, follow policy: deletion is documented only for records created in error, while retiring with a custom substate keeps history. | custom, PRACTICE |
| `IN_TRANSIT/TO_STOCKROOM` | In transit / Reserved | DOC (transfer order In Transit stage) |
| `IN_TRANSIT/TO_USER` | In transit / Reserved or Pending install | VERIFY (no flow page sets it for user shipments) |
| `IN_TRANSIT/RETURN_TO_STOCK` | Reclamation goes from In use straight to In stock / Pending repair on receipt. Use In transit / Defective or Available only if the organization tracks the return leg. | DOC (reclamation) + custom |
| `IN_TRANSIT/TO_VENDOR` | In transit for an RMA off-site shipment (substate not stated). For a lease return, Retired / Lease return after the return. | DOC + VERIFY substate |
| `IN_TRANSIT/TO_ITAD` | In transit / Pending disposal | DOC (disposal Asset Departure) |
| `IN_STOCK/RECEIVING` | No receiving substate. Receipt sets In stock / Available, or Reserved if reserved. | DOC (PO receiving) + custom if tagging is a separate step |
| `IN_STOCK/AVAILABLE` | In stock / Available | DOC |
| `IN_STOCK/RESERVED` | In stock / Reserved. **Not** Pre-allocated, which means vendor-owned stock. | DOC |
| `IN_STOCK/IN_BUILD` | custom (closest documented: Test or Pending install) | custom |
| `IN_STOCK/READY_TO_DEPLOY` | In stock / Pending install (written by the loaner Prepare and refresh Schedule tasks) | DOC |
| `IN_STOCK/PENDING_INSPECTION` | In stock / Pending evaluation (brazil). Reclamation writes Pending repair on receipt, so decide which one counts. | DOC + PRACTICE |
| `IN_STOCK/PENDING_REPAIR` | In stock / Pending repair | DOC |
| `IN_STOCK/DEFECTIVE` | In stock / Defective | DOC |
| `IN_STOCK/LOANER_POOL` | In stock / Available with Asset function = Loaner | DOC (loaner page) |
| `IN_STOCK/PENDING_RETIREMENT` | In stock / Pending Retirement (brazil), or In stock / Pending disposal (written by refresh and reclamation) | DOC |
| `IN_USE/INDIVIDUAL` | In use / None; Asset function Primary or Secondary; Assigned to set | DOC + PRACTICE |
| `IN_USE/SHARED`, `IN_USE/LOCATION` | In use / None; Asset function Shared; Location or Managed by instead of a single user | DOC + PRACTICE |
| `IN_USE/ON_LOAN` | In use, Asset function = Loaner, with an open loaner asset order | DOC |
| `IN_MAINTENANCE/ONSITE_REPAIR` | In maintenance / none (set manually) | DOC |
| `IN_MAINTENANCE/DEPOT_OR_RMA` | HAM RMA keeps the asset In stock / Pending repair, then In transit when shipped. | DOC (RMA) |
| `MISSING/LOST`, `MISSING/STOLEN` | Missing / Lost, Stolen | DOC |
| `MISSING/UNDER_SEARCH`, `MISSING/NOT_RETURNED` | custom | custom |
| `RETIRED/AWAITING_SANITIZATION`, `SANITIZED`, `AWAITING_PICKUP` | Retired / Pending disposal (disposal Verify task). In stock / Pending certificate covers waiting for the certificate. | DOC |
| `DISPOSED/RECYCLED`, `DISPOSED/DESTROYED` | Retired / Disposed | DOC |
| `DISPOSED/RESOLD` | Retired / Sold | DOC (resale) |
| `DISPOSED/DONATED` | Retired / Donated | DOC |
| `DISPOSED/RETURNED_TO_LESSOR` | Retired / Lease return | DOC |
| `DISPOSED/RMA_REPLACED` | Retired / Vendor credit (written by the RMA replace path). Retired / RMA also exists. | DOC |
| `DISPOSED/VENDOR_TRADE_IN` | custom (closest: Vendor credit or Sold; agree with finance) | custom |
| `DISPOSED/WRITTEN_OFF` | custom, or keep Missing / Lost or Stolen with a write-off record | custom |
| (no canonical state) | Retired / Obsolete, Buy out, Pending resale; In stock / On hold, Legal hold, Quarantine, Pending return, Pending fulfillment, End of support | Map in the organization worksheet (`asset-data-model.md` §5) |
