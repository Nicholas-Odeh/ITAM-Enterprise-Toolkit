# ServiceNow Otto (Now Assist) for SAM reference (short)

**Labels.** `DOC` = official ServiceNow docs, summarized. `PRACTICE` = practitioner method. `VERIFY` = not confirmed; check in the instance.

**Source.** `DOC sam/<file>` = `markdown/it-asset-management/software-asset-management/<file>`. `DOC na/now-assist-sam.md` = `.../now-assist-for-software-asset-management-sam/now-assist-sam.md`. Both are in github.com/ServiceNow/ServiceNowDocs, branch `brazil`, as checked 2026-10-20 (pages `last_updated` 2026-09-10).

**Naming.** Brazil-era docs call the product **ServiceNow Otto for Software Asset Management (SAM)**. Older pages and the plugin names still say "Now Assist". Treat the two names as the same product.

## What it is and how it is installed

- Store app `sn_now_assist_sam`, supported **from Yokohama**. Its dependencies are (DOC sam/supporting-information-now-assist-sam.md):
  - `com.snc.samp`
  - `sn_sam_workspace`
  - `sn_genai_platform` (Now Assist for Platform)
  - `sn_aia` (AI Agents)
  - `sn_itam_aia` (AI Agents for ITAM)
- Activation order: SAM Professional, then Software Asset Workspace, then Now Assist for Platform, then Otto for SAM (same source).
- The installer role is `admin`. After installing (DOC sam/install-now-assist-sam.md):
  - Enable the Otto (Now Assist) panel.
  - Request **AI Search** under AI Search Status. Activation can take up to 24 hours.
- Licensing tiers are Foundation, Advanced and Prime. Which skills and agents you get depends on your license (DOC na/now-assist-sam.md).

## Generative AI skills

Source: DOC sam/explore-generative-ai-skills-now-assist-sam.md.

- **Publisher compliance summarization** and **Product compliance summarization**: summaries of deployment, compliance, configuration health and optimization.
- **Recommended actions**: recommendations for compliance and spend.
- **Error log summarization** and **Error resolution recommendation**: for SaaS integration job failures.
- **SaaS user resolution**: generates rules that map incoming SaaS users to SAM users.
- **Contract entitlement data extraction**: creates entitlements from software-license contracts uploaded in the workspace (DOC sam/extract-entitlements-from-contracts-now-assist-sam.md).
  - It is **on by default**.
  - Files must be PDF, JPG/JPEG or PNG, at most 4 MB each, and at most 10 image pages or 25 PDF pages.
  - You review the extracted data before entitlements are created.
- **Resolve entitlement import errors**.
- **Spend transaction software classification** and **normalization**: these match transactions against the SAM Content Library.
- Access: the skills are available to `sam_user` and `sam_admin`. `sam_user` includes `sn_nowassist_admin.user`, which gives read-only access to Otto Admin. Custom role mappings are kept on upgrade.

## Agentic workflows

Source: DOC sam/explore-agentic-workflows-now-assist-sam.md.

- All workflow and agent records are **read-only** by default. To use one, you can:
  - Activate it as shipped.
  - Or duplicate it, customize the copy and activate the copy.
  - In either case, activate every agent in the workflow. Activate the **trigger** only if you want it to run automatically.
- **Help manage software request**: allocates entitlements if rights exist, otherwise creates a purchase order. It also includes a Microsoft license assignment agent. It needs Procurement (`com.snc.procurement`). The docs describe a default auto-approval for carts up to **USD 1,000** (DOC sam/now-assist-sam-fulfill-sw-asset-requests-workflow.md).
- **Create software reclamation rule**: proposes a rule when a product has none.
- **Evaluate software removal candidate**: checks usage over a period. It asks the user to confirm before reclamation starts and **excludes VIP users** (DOC sam/now-assist-sam-evaluate-removal-candidate-workflow.md).
- **Manage contract repository**: needs `sn_cm_gen_ai` (DOC sam/configure-manage-contract-repository-agentic-workflow.md).
- The **Config Console** can suggest configuration with AI. Review every suggestion before you apply it (DOC sam/config-console-sam.md).

## Model providers

Source: DOC sam/exploring-now-assist-sam.md.

- Supported providers: Now LLM Service, Azure OpenAI, Google Gemini and Anthropic Claude on AWS. You choose them in **AI Control Tower** configuration controls.
- A **third-party LLM is now the default** for new or inactive AI assets. Existing Now LLM Service configurations stay as they are.
- From Australia Patch 4, **Azure OpenAI** is the default for SaaS user resolution.

## Governance cautions

- **On by default** (DOC). Some skills are already active after install or upgrade, e.g. contract extraction. Inventory the active skills in Otto Admin and AI Control Tower, and approve each one through the AI governance process (`PRACTICE`).
- **Data leaves the instance** (DOC na/now-assist-sam.md). Prompts and records go to a central ServiceNow environment, possibly in another region and possibly to a third-party cloud. Contracts and spend lines can contain commercially sensitive terms and personal data. Check the data-processing terms and the provider choice with Legal and Privacy.
- **ServiceNow collects data** (DOC). Inputs, outputs and edits are used to improve ServiceNow models. An opt-out exists; record whether the organization has used it.
- **Accuracy** (DOC). Outputs may be wrong or incomplete.
  - Treat compliance summaries and recommended actions as drafts, not license positions.
  - Check every extracted entitlement against the signed contract (`PRACTICE`).
- **Agentic writes.** Allocations, purchase orders, Microsoft license assignment and reclamation all change records or spend.
  - Set auto-approval thresholds to the organization's delegation of authority, not the USD 1,000 default.
  - Keep automatic triggers off until the workflow has been tested on sub-production (`PRACTICE`).
- **Availability** (DOC). Some features are unavailable for in-country SKUs, FedRAMP, NSC DOD IL5, IRAP-Protected, self-hosted and Regulated Markets instances. Some are region-limited. Confirm before you plan to rely on them.
- **Audit trail** (`PRACTICE`). Record which records an AI skill or agent created or changed. Reviewers in a publisher audit will ask how each entitlement was created.
