# Asset ↔ CI and CMDB reference

Grounded in ServiceNowDocs, branch `brazil`, checked 2026-10-20. Paths are relative to `markdown/`. Labels: `DOC (path)`, `PRACTICE`, `VERIFY`. The `servicenow-platform/...` pages sit outside `it-asset-management`, so include `markdown/servicenow-platform/configuration-management-database-cmdb` in the sparse checkout when you refresh (see `sources.md`).

## Contents
1. Principle
2. How the link and sync work
3. Fields that sync
4. State ↔ status mapping (install status, hardware status)
5. CSDM life cycle and Install Base Items
6. Creation behavior and properties
7. Business rules that create and sync records
8. IRE, identification and reconciliation
9. CMDB Health and CMDB success advisor for HAM
10. Asset-CI exception checks

## 1. Principle

An asset record (`alm_asset` family) answers *who owns it, what it cost, what contract covers it and where it is in its lifecycle*. Asset Management focuses on the financial side of owning property. A CI (`cmdb_ci` family) answers *what it runs, what depends on it and which service it affects*; the CMDB tracks items and makes them available to users (DOC `it-asset-management/asset-management/c_ManagingAssets.md`). An object can need an asset only, a CI only, both or neither. Decide which before designing sync, imports or reports (PRACTICE).

## 2. How the link and sync work

- Two business rules keep a linked pair in sync: **Update CI fields on change** (on `alm_asset`) and **Update Asset fields on change** (on `cmdb_ci`). Sync happens only when the asset and CI **point to each other** and are logically mapped (DOC `it-asset-management/asset-management/c_ManagingAssets.md`). The reference fields are conventionally `alm_asset.ci` and `cmdb_ci.asset` (VERIFY in `sys_dictionary`).
- The **model category** (`cmdb_model_category`) links the asset class with the CI class (and the IBI class). It decides whether the platform creates an asset from a CI, and of what class (DOC `it-asset-management/product-catalog/c_ModelCategories.md`).
- Drive changes from the **asset** form. The docs say to update statuses on the Asset form (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`, "Update Asset fields on change").
- **Deleting** a linked asset or CI deletes the other (DOC `it-asset-management/asset-management/t_DeletingAssets.md`).
- Code lives in the `AssetandCI` and `AssetAndCISynchronizer` script includes. If `AssetAndCISynchronizer` was customized before an upgrade, overwrite the customization and recreate the mappings (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`, `it-asset-management/asset-management/t_CreateAssetandCIFieldsMapping.md`).

## 3. Fields that sync

Out of the box these sync both ways; **Cost** syncs asset → CI only and is informational on the CI (DOC `it-asset-management/asset-management/c_ManagingAssets.md`):

Asset tag, Assigned, Assigned to, Checked in, Checked out, Company, Cost (one way), Cost center, Delivery date, Department, Due in, Due, GL account, Install date, Invoice number, Justification, Lease id, Location, Managed by, Model (`model_id` on the CI), Order date, Order received, Ordered, Owned by, PO number, Purchase date, Purchased, Serial number, Support group, Supported by, Vendor, Warranty expiration.

Custom field mappings: **Asset > Administration > Asset-CI Field Mapping** (role `admin` or `asset`). They can be conditional (an Asset mapping condition and a CI mapping condition under Advanced view). A field that exists only on `alm_hardware` and not on `alm_asset` can't be mapped (DOC `it-asset-management/asset-management/t_CreateAssetandCIFieldsMapping.md`).

## 4. State ↔ status mapping

Rules (DOC `it-asset-management/asset-management/c_ManagingAssets.md`):
- The asset State (with Substate) syncs with the CI's **Install Status** (no substatus; use it for non-hardware CIs) and with **Hardware Status** plus its sub status (shown only on hardware CIs).
- The mapping is not one-to-one; each value maps to the most logical counterpart. Example: an asset In stock / Pending disposal sets the CI to **In Disposition** with no substate.
- If both Hardware Status and Install Status change on a hardware CI, the Hardware Status change drives the asset state.
- Install Status and Hardware Status are independent; changing one doesn't change the other. ServiceNow advises against maintaining both on hardware CIs.

Where the mappings live:

| Mapping | Module (DOC) | Notes | Table name |
|---|---|---|---|
| Asset state/substate ↔ CI Install Status | Asset > Administration > **Asset-CI Install Status Mapping** (`it-asset-management/asset-management/t_CreateAssetandCIInstallStatusMapping.md`) | For hardware CIs, sync is asset → CI only; non-hardware CI classes can sync both ways. Don't use the CI Substatus with Install Status on hardware CIs. | `alm_asset_ci_state_mapping`: VERIFY (not named in the brazil docs) |
| Asset state/substate ↔ CI Hardware Status / sub status | Asset > Administration > **Asset-CI Hardware Status Mapping** (`it-asset-management/asset-management/t_CreateAssetandCIHardwareStatusMapping.md`) | Sync direction can be asset, CI or both. Don't use the separate CI Substatus field; sync doesn't update it. | `alm_hardware_state_mapping`: VERIFY |
| Asset field ↔ CI field | Asset > Administration > **Asset-CI Field Mapping** | See section 3. | `alm_asset_ci_field_mapping`: VERIFY |

- Both status lists open filtered to **[Out of the box] [is] [False]**, so only custom mappings show by default. Remove the filter to see the OOB rows before reasoning about behavior (DOC, same pages).
- `sn_itam_enable_cache_for_asset_ci_mapping` caches these mappings for performance. After changing a mapping, check that the cache picks it up (DOC `it-asset-management/asset-management/c_ManagingAssets.md`; refresh behavior VERIFY).
- Earlier community claims that the OOB mapping rows are ACL-protected, that Build/Design states are absent from the mappings, and that custom states on CI subclasses can't be mapped are **not in the brazil docs**. Treat them as `VERIFY` and check the mapping lists in the instance.
- CI **Operational status** isn't in the documented sync; the docs name Install Status and Hardware Status (DOC `it-asset-management/asset-management/c_ManagingAssets.md`). Don't promise that asset changes move Operational status (PRACTICE).

## 5. CSDM life cycle and Install Base Items

(DOC `it-asset-management/asset-management/c_ManagingAssets.md`)
- With the CSDM life cycle plugin (`csdm.lifecycle.migration.activated`), the property **`csdm.lifecycle.sync.between.ci.and.asset.activated`** decides how the life cycle syncs. When false (the default on upgrade to Xanadu), it syncs through the legacy State/Substate. When true, the CSDM Life Cycle Stage and Status fields sync directly.
- Example: asset In use → asset Life Cycle Stage Operational / In use, and CI Installed / In use.
- If you have custom states or substates, map them to the CSDM fields before activating the plugin.
- **Install Base Items (IBI)** sync with the asset only through the CSDM life cycle fields. The model category associates the asset, CI and IBI classes.

## 6. Creation behavior and properties

| Property | Documented behavior | Source |
|---|---|---|
| `glide.create_alm_asset.async` | true: the **Asset - Create asset delayed sync** job creates assets from CIs every 15 minutes. Status in `asset_job_log`; queue and errors at Asset > Administration > **Asset Creation Queue** (set Error → Ready to retry). false: assets are created immediately. Default false if upgraded to Brazil from Orlando or earlier. Review processes that need the asset to exist right away. | DOC `it-asset-management/asset-management/c_ManagingAssets.md` |
| `glide.asset.create_ci_with_ire` | Creates CIs from assets through IRE for CI classes extending `cmdb_ci_hardware` that identify on serial number and have no dependent relationships. CI name format "Serial number - Model name", source `SNAssetManagement`. Serial number becomes required on those model categories and to receive their PO lines; asset creation fails if the serial already exists on a CI or asset. Pre-allocated assets need the serial only when allocated. Default false if upgraded from Orlando or earlier. | DOC, same page; also `it-asset-management/hardware-asset-management/ham-system-properties.md` |
| `sn_itam_common.mac_address_sync` | Syncs asset and CI by MAC address. Default false; set it in the **Asset Property** (`asset_property`) table. Replaces the earlier unverified name `snitamcommon.macaddresssync`. The OT sync page names the asset field `mac_addr` and matches CI-side Network Adapter rows (`cmdb_ci_network_adapter`). | DOC `it-asset-management/asset-management/c_ManagingAssets.md`, `it-asset-management/enterprise-asset-management/asset-ci-sync-ot-assets.md` |
| `sn_itam_enable_cache_for_asset_ci_mapping` | Caches field, install status and hardware status mappings. | same |
| `sn_itam_restrict_asset_read` | When true, users with only `snc_internal` read only assets assigned to them or where they're Reserved for, Managed by or Owned by. Default false. | same |
| `glide.itam_update_ci_status_from_ritm` | Which CIs a requested item updates. | DOC `it-asset-management/hardware-asset-management/ham-system-properties.md` |

Always read current values in `sys_properties` (or `asset_property`) before explaining behavior (PRACTICE).

## 7. Business rules that create and sync records

(DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`)

| Rule | Table | Effect |
|---|---|---|
| Create Asset on insert | `cmdb_ci` | New CI with no asset → creates an asset. |
| Create asset on model change | `cmdb_ci` | Model ID changes → new associated asset. |
| Create CI on insert | `alm_asset` | New asset with no CI → creates a CI. |
| GenerateAssets | `cmdb_model_category` | Scheduled job creates assets for CIs. |
| Sync model category | `cmdb_model` | Model category change → creates missing assets for CIs of that model. |
| Null out asset on insert and stay / Null out Ci on insert and stay | `cmdb_ci` / `alm_asset` | "Insert and stay" doesn't copy the link, so a new partner is created. |
| Update CI fields on change / Update Asset fields on change | `alm_asset` / `cmdb_ci` | Field and status sync. |

CMDB success advisor for HAM checks that the four create/update rules are active (DOC `it-asset-management/hardware-asset-management/cmdb-sa-ham-analyze-settings.md`).

## 8. IRE, identification and reconciliation

- IRE is the central framework for identifying and reconciling CI data from several sources. It applies to Import Sets and prevents duplicates they might otherwise create (DOC `servicenow-platform/configuration-management-database-cmdb/c_CMDBIdentifyandReconcile.md`).
- **Identification rules** (per class, in CI Class Manager) decide whether incoming data matches an existing CI. Prefer independent rules, use at most one level of dependency (two is the maximum supported), and avoid lookup identifier entries (DOC `servicenow-platform/configuration-management-database-cmdb/best-practices-id-reconcile.md`, `servicenow-platform/configuration-management-database-cmdb/c_IdentificationRules.md`).
- **Reconciliation rules** decide which discovery sources may update which attributes, and in what precedence. Static rules are stored in `cmdb_reconciliation_definition`; dynamic rules use CMDB 360. Without them, sources overwrite each other (DOC `servicenow-platform/configuration-management-database-cmdb/r_ReconciliationRulesPrinciples.md`).
- APIs: the Identification and Reconciliation REST API (`api-reference/rest-apis/c_IdentifyReconcileAPI.md`) and the server-side IdentificationEngine API (`api-reference/server-api-reference/IdentificationEngineScopedAPI.md`).
- PRACTICE: list every CMDB writer, give authoritative sources precedence, route CI inserts through IRE (Service Graph Connectors, the IRE API or IRE-enabled import sets) rather than direct GlideRecord inserts, and treat a duplicate CI as a likely duplicate or orphan asset.
- PO receiving honors IRE identification fields. If the model category's CI class identifies on asset tag, serial or MAC, supply at least one at receipt (DOC `it-asset-management/procurement/t_ReceiveAnAsset.md`).

## 9. CMDB Health and CMDB success advisor for HAM

- **CMDB Health** KPIs (DOC `servicenow-platform/configuration-management-database-cmdb/r_CMDBHealthMetrics.md`, `servicenow-platform/configuration-management-database-cmdb/overview-cmdb-health.md`):
  - **Correctness**: orphan (per-class orphan rules), staleness (default rule on `cmdb_ci`: 60 days effective duration) and duplicates (from identification rules; independent CIs only).
  - **Completeness**: required (mandatory) and recommended fields. Out of the box, no recommended fields are set.
  - **Compliance**: audits must be activated; relationship duplicates, orphans and staleness.
- **Orphan rules** are one per class, created in CI Class Manager > Health > Correctness. Example from the docs: a computer CI with no owner or asset (DOC `servicenow-platform/configuration-management-database-cmdb/t_CreateCMDBHealthOrphanRule.md`). The docs don't state that any orphan rule ships by default; check the instance (VERIFY).
- **CMDB success advisor for HAM** (role `sn_cmdb_admin`) rates HAM-relevant settings Ideal or Requires attention. It checks the create/update business rules, custom model categories, asset-CI field mappings, install status mappings and CMDB Data Manager policy coverage, and recommends data integrations (DOC `it-asset-management/hardware-asset-management/cmdb-sa-ham-analyze-settings.md`, `it-asset-management/hardware-asset-management/cmdb-sa-ham-use.md`).
- Health scores measure the CI side only. Pair them with the asset-side checks below (PRACTICE).

## 10. Asset-CI exception checks

Read-only queries. Build and copy the encoded query from the list view; field names are VERIFY (section 2).

| Check | Query idea |
|---|---|
| Asset without CI where one is expected | `alm_hardware`: `ciISEMPTY` and the model category has a CI class. |
| CI without asset | `cmdb_ci_hardware`: `assetISEMPTY` and the model category has an asset class. If `glide.create_alm_asset.async` is true, check the Asset Creation Queue for errors first. |
| Broken back-link | `alm_hardware.ci.asset != alm_hardware.sys_id` (script; can't be a simple filter). |
| State mismatch | Asset Retired while the CI is Installed (or the reverse). Compare with the install status and hardware status mapping lists, including OOB rows. |
| Duplicate serials | GlideAggregate on `alm_hardware.serial_number`, count > 1, blanks excluded. With `create_ci_with_ire` on, duplicates block asset creation. |
| Missing serials | `alm_hardware`: `serial_numberISEMPTY` by model category (blocks IRE creation and PO receiving for serial-identified classes). |
| Discovered vs undiscovered | Hardware asset overview "Discovered and undiscovered asset count" (not discovered at all, or not within one month) (DOC `it-asset-management/hardware-asset-management/hardware-asset-overview.md`). |
