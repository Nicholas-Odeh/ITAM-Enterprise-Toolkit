# ServiceNow Otto (formerly Now Assist) for HAM: brief

In the brazil docs, ServiceNow's generative and agentic AI brand appears as **ServiceNow Otto**. Pages that earlier releases titled "Now Assist for Hardware Asset Management" are now "ServiceNow Otto for Hardware Asset Management (HAM)". Some links and roles still say "Now Assist" (for example the `now_assist_panel_user` role). Users may use either name. Sources: ServiceNowDocs `brazil` (paths relative to `markdown/`, checked 2026-10-20). For the SAM side, see `now-assist-sam.md`. Labels: `DOC (path)`, `PRACTICE`, `VERIFY`.

## Licensing tiers and availability

- AI capabilities come in three tiers: **Foundation** (insights), **Advanced** (productivity) and **Prime** (autonomous agents, build your own) (DOC `it-asset-management/now-assist-for-hardware-asset-management/now-assist-ham.md`, `it-asset-management/hardware-asset-management/ai-in-ham.md`).
- Some features are unavailable for in-country SKUs, FedRAMP, NSC DOD IL5, Australia IRAP-Protected, self-hosted and Regulated Markets customers, or in some regions (KB1584492, KB0743854, KB2593939) (DOC `it-asset-management/now-assist-for-hardware-asset-management/now-assist-ham.md`).
- **Data leaves the instance.** Processing may happen in a central ServiceNow environment in another data-center region and at a third-party cloud provider such as Microsoft Azure. ServiceNow collects inputs, outputs and edits to improve its models unless the customer opts out (DOC same page). Flag this for privacy review before enabling it (PRACTICE).

## Application and install

- Store application `sn_now_assist_ham`, supported from Yokohama Patch 4. Install in order: HAM (`com.sn_hamp`), ServiceNow Otto for Platform (`com.sn_genai_platform`), AI Agents for IT Asset Management (`com.sn_itam_aia`), then `sn_now_assist_ham`. Role `admin`. Then enable the Otto panel and request AI Search, which can take up to 24 hours (DOC `it-asset-management/hardware-asset-management/supporting-info-now-assist-ham.md`, `it-asset-management/hardware-asset-management/install-now-assist-ham.md`).
- Access is through the ServiceNow Otto panel in the Hardware Asset Workspace (DOC `it-asset-management/hardware-asset-management/supporting-info-now-assist-ham.md`).

## Capabilities (brazil)

| Capability | What it does | Source |
|---|---|---|
| **Help manage hardware asset requests** (agentic workflow, v1.0) | Fulfills hardware requests from local stock, by transfer order or by purchase order. Agents: HAM sourcing, transfer order creation, purchase order creation. | DOC `it-asset-management/hardware-asset-management/now-assist-ham-agentic-workflow.md`, `it-asset-management/hardware-asset-management/now-assist-ham-fulfill-req-agent-workflow.md` |
| **Help repair hardware assets** (agentic workflow, v2.0) | Validates repair tasks, guides troubleshooting, suggests actions, closes tasks after user confirmation. Agents: next best action, evaluate asset, repair asset. | DOC `it-asset-management/hardware-asset-management/now-assist-ham-repair-agent-workflow.md` |
| **Generate hardware asset insights** (generative skill, v4.0) | Asset summary and recommendations in the workspace. | DOC `it-asset-management/hardware-asset-management/now-assist-ham-agent-ai.md`, `it-asset-management/hardware-asset-management/generate-asset-analysis-now-assist-ham.md` |
| Stockroom auto-sourcing by AI agents | Configure a stockroom for automated sourcing. | DOC `it-asset-management/hardware-asset-management/configure-stockroom-auto-sourcing.md` |
| Manage contract repository (agentic) | Extracts contract metadata and obligations and sets reminders. Needs the HAM Prime SKU and Contract Management Pro apps. | DOC `it-asset-management/hardware-asset-management/ham-cm-pro-integration.md`, `it-asset-management/hardware-asset-management/manage-contract-repo-agent-flow-ham.md` |
| AI-assisted configuration | The Configuration Console suggests assignment groups, users and roles; ServiceNow says to review them before applying. | DOC `it-asset-management/hardware-asset-management/config-console-ham.md`, `it-asset-management/hardware-asset-management/configure-team-using-ai.md` |

## Controls (what to check before relying on it)

- Agentic workflows and AI agent records are **read-only and may be inactive** by default. To customize, duplicate the workflow, then activate the workflow, its agents and (for automatic runs) its trigger (DOC `it-asset-management/hardware-asset-management/now-assist-ham-agentic-workflow.md`).
- Agents create real transfer orders and purchase orders. Treat activation as a write-capable change: who can invoke it (ACLs on agents), approval thresholds, and an audit trail in `itam_aia_log` (role `asset_aia_admin`) (DOC same page; `it-asset-management/hardware-asset-management/installed-with-ham.md`). The thresholds themselves aren't documented on the HAM pages, so check the flow (VERIFY).
- Outputs may be inaccurate or incomplete, and the customer is responsible for testing them (DOC `it-asset-management/now-assist-for-hardware-asset-management/now-assist-ham.md`). Never cite an AI summary as evidence of an asset's state; re-query the record (PRACTICE).
- Tier entitlement: confirm the AI tier on the order form before recommending a capability (VERIFY).
