# ServiceNowDocs index for this skill

Topic → page → what it covers. Paths are relative to `markdown/` in the ServiceNowDocs repository, branch `brazil`, checked 2026-10-20. Every path below resolved with `scripts/extract_servicenow_docs.py --check-citations`. The `servicenow-platform/...` pages are outside the `it-asset-management` folder; add that folder to a sparse checkout to check them (see `sources.md`). Pages move between releases, so re-run the check before citing a path for another release.

To find a page not listed here, build a full index: `python3 scripts/extract_servicenow_docs.py <clone> --branch <release> --out <dir>`, then search `<dir>/INDEX.md`.

## Folder map (`it-asset-management/`, brazil)

| Folder | Pages | Covered in |
|---|---|---|
| `asset-management/` (Base Asset Management) | 66 | `ham.md`, `asset-ci-cmdb.md` |
| `hardware-asset-management/` | 358 | `ham.md`, `procedures.md`, `now-assist-ham.md` |
| `procurement/` | 44 | `contracts-procurement.md` |
| `contract-management/` | 54 | `contracts-procurement.md` |
| `product-catalog/` | 44 | `contracts-procurement.md` |
| `asset-audits/` (Asset Audit Response, regulatory audits) | 15 | `asset-audit-response.md` |
| `software-asset-management/` | 479 | `sam.md` |
| `saas-license-management/` | 92 | `saas-license-management.md` |
| `cloud-cost-management/` | 143 | `cloud-cost-management.md` |
| `enterprise-asset-management/` | 410 | `enterprise-asset-management.md` (pointer only) |
| `now-assist-for-hardware-asset-management/`, `now-assist-for-software-asset-management-sam/` | 1 each | `now-assist-ham.md`, `now-assist-sam.md` |

## Base Asset Management (`it-asset-management/asset-management/`)

| Page | What it covers |
|---|---|
| `am-landing-page.md` | Landing page for Base Asset Management. |
| `r_InstalledWithAssetManagement.md` | Plugins, tables, roles and business rules installed with Base Asset Management. |
| `c_ManagingAssets.md` | Asset-CI link and sync, synced fields, creation properties, `asset_property` keys. |
| `c_AssetClasses.md` | Asset classes and how they relate to model categories. |
| `t_SettingAssetStatesAndSubstates.md` | Full state and substate list; which substates belong to which state. |
| `t_CreateAssetandCIInstallStatusMapping.md`, `t_CreateAssetandCIHardwareStatusMapping.md`, `t_CreateAssetandCIFieldsMapping.md` | Asset state ↔ CI install status / hardware status mapping and field mapping modules. |
| `t_RetiringAssets.md`, `t_DeletingAssets.md` | Retiring (fields cleared, CI retired) and deleting (the linked record is deleted too). |
| `c_Stockrooms.md`, `c_StockRules.md` | Stockrooms and stock rules (restock by transfer or vendor). |
| `manage-transfer-orders.md`, `t_TransferAssetsUsingTransferOrders.md`, `transfer-order-flows.md`, `r_SummaryOfTransferOrderStages.md`, `r_TrsferOrderLneAssetTrackNonConsum.md`, `t_ReturnItemsRecInXferOrder.md` | Transfer orders: creation, flows, line stages and their effect on asset state, returns. |
| `manage-preallocated-asset.md` | Pre-allocated assets. |
| `c_FollowLifeCycleConsumbl.md` | Consumables life cycle. |
| `content-request-itam.md` | How to request ITAM content (models, products) from ServiceNow. |

## Hardware Asset Management (`it-asset-management/hardware-asset-management/`)

| Topic | Pages | What they cover |
|---|---|---|
| Product and install | `ham-landing-page.md`, `installing-ham-app.md`, `install-ham.md`, `install-ham-from-product-hub.md`, `install-additional-ham-apps.md`, `product-hub-for-ham.md`, `installed-with-ham.md` | Install paths, plugins, tables and roles installed with HAM. |
| Licensing | `ham-licensing.md`, `licensing-ham-solutions.md`, `ham-license-exclusion.md`, `view-license-report-ham.md` | Resource categories, ratios, exclusions, license report. |
| Configuration | `config-console-ham.md`, `ham-system-properties.md`, `ham-workspace-roles.md`, `asset-lifecycle-automation.md` | Configuration Console, properties, workspace roles, lifecycle automation. |
| Workspace and reporting | `using-ham-workspace.md`, `hardware-asset-overview.md`, `hardware-asset-content-pack.md`, `asset-record-fields.md` | Hardware Asset Workspace views, overview, analytics, asset record fields. |
| CMDB success advisor | `cmdb-sa-ham-use.md`, `cmdb-sa-ham-analyze-settings.md` | Checking CMDB settings that affect HAM. |
| Stockrooms | `manage-your-stockrooms.md`, `r_StockroomTypes.md`, `t_CreateAStockRule.md`, `add-aisle-space-stockroom-ham-ws.md`, `associate-stockroom-with-service-locations.md`, `manage-asset-putaway-stockroom-hardware-asset-workspace.md` | Stockroom types, stock rules, aisles and spaces, service locations, put-away. |
| Receiving and shipping | `stockroom-receiving-ham.md`, `receive-assets-stockroom-hws.md`, `asn-for-ham.md`, `pallet-assets.md`, `stale-shipments.md` | Receiving (including Excel import), ASN, pallets, stale shipments. |
| Reclamation | `reclaim-asset.md`, `submit-asset-reclamation-request.md`, `close-asset-reclamation-request.md`, `close-an-asset-remediation-task.md` | Reclamation requests, tasks, closure. |
| Loaners | `loaner-asset.md`, `loaner-asset-request.md`, `prepare-deploy-reclaim-loaner-assets.md` | Loaner requests, preparation, deployment, return. |
| Refresh | `hardware-asset-refresh.md`, `zero-touch-asset-refresh.md` | Refresh requests and Zero Touch Refresh. |
| Repair and RMA | `requesting-hardware-asset-repair.md`, `fulfilling-repair-orders-ham.md`, `return-merchandise-authorization.md`, `submit-rma-request.md`, `assess-rma.md`, `evaluate-rma-asset.md`, `closing-rma-request.md` | Repair orders and the RMA flow. |
| Disposal and end of life | `create-disposal-order.md`, `hardware-disposal-stages.md`, `create-resale-order.md`, `asset-donation.md` | Disposal order stages, resale, donation. |
| Leases and warranty | `manage-your-leased-hw-asts-expiring-contract.md`, `return-your-leased-hardware-asset.md`, `purchase-your-leased-hw-asset.md`, `extend-your-lease-contract.md`, `integration-with-lenovo-asset-warranty.md` | Lease expiration (return, buy out, extend); Lenovo warranty integration. |
| Contract Management Pro | `ham-cm-pro-integration.md`, `review-extracted-obligation-ham.md`, `manage-contract-repo-agent-flow-ham.md` | Prime SKU integration, AI-extracted obligations. |
| Normalization and lifecycle | `hardware-normalization.md`, `Work-with-hardware-normalization.md`, `opt-in-hardware-normalization.md`, `normalize-hardware-consumable-models.md`, `revert-norm-ham.md`, `approximated-lifecycles-hardware-products.md`, `calculate-active-lifecycle-phase-ham.md` | Hardware Model Normalization, Content Service opt-in, lifecycle data. |
| Audits and attestation | `ham-inventory-audit.md`, `audit-your-inventory.md`, `audit-results.md`, `create-audit-using-mobile-app.md`, `scan-assets-agent-app.md`, `view-deprecated-audit-records.md`, `asset-attestation-ham.md` | Inventory audits, scan results, mobile scanning, attestation. |
| ServiceNow Otto (AI) | `ai-in-ham.md`, `supporting-info-now-assist-ham.md`, `install-now-assist-ham.md`, `now-assist-ham-agent-ai.md`, `generate-asset-analysis-now-assist-ham.md`, `now-assist-ham-agentic-workflow.md`, `now-assist-ham-fulfill-req-agent-workflow.md`, `now-assist-ham-repair-agent-workflow.md`, `configure-stockroom-auto-sourcing.md`, `configure-team-using-ai.md` | AI tiers, install, generative skill, agentic workflows. Overview page: `it-asset-management/now-assist-for-hardware-asset-management/now-assist-ham.md`. |

## Procurement, contracts, product catalog

| Page | What it covers |
|---|---|
| `procurement/c_Procurement.md`, `procurement/t_ActivateProcurement.md` | Procurement plugin and activation. |
| `procurement/r_ProcurementRoles.md`, `procurement/r_TablesProcurement.md` | Roles and tables. |
| `procurement/c_ProcurementWorkflows.md` | Base workflows, including the catalog approval threshold. |
| `procurement/c_SourcingRequestItems.md`, `procurement/consume-local-asset-stock.md` | Sourcing by local stock, transfer order or PO. |
| `procurement/r_FollowAPurchaseOrderStatus.md`, `procurement/t_CancelAPurchaseOrder.md`, `procurement/r_SetExpectDelDateOnPurchOrder.md`, `procurement/t_CreateAssetReserveForRequester.md` | PO status, cancellation, delivery date, pre-created assets. |
| `procurement/c_ReceiveAssets.md`, `procurement/t_ReceiveAnAsset.md`, `procurement/c_ReceiveAConsumableAsset.md` | Receiving against POs. |
| `procurement/integrate-ext-proc-ser.md`, `procurement/integrate-with-coupa.md` | External procurement integrations (Coupa). |
| `contract-management/c_ContractManagement.md`, `contract-management/c_ContractLifeCycle.md` | Contract Management overview, states, substates, compliance job. |
| `contract-management/r_TablesInstalledWContractMgmt.md`, `contract-management/r_UserRolesIWContractMgmt.md` | Tables and roles. |
| `contract-management/t_CreateAContract.md`, `contract-management/t_MonitoringContracts.md`, `contract-management/t_SendAContractNotification.md` | Creating and monitoring contracts; expiry notifications. |
| `contract-management/cont-renew-wf.md` | Contract renewal workflow. |
| `product-catalog/c_Models.md`, `product-catalog/c_CreatingBundledModels.md`, `product-catalog/t_DeletingModels.md` | Models, bundles, deletion rules. |
| `product-catalog/c_ModelCategories.md`, `product-catalog/t_EditingModelCategories.md` | Model categories (CI class, asset class). |
| `product-catalog/r_TablesProductCatalog.md`, `product-catalog/r_RolesProductCatalog.md` | Product catalog tables and roles. |
| `product-catalog/c_ManageVendorCatalogItems.md`, `product-catalog/t_PublishingModToHrdwreOrSftCat.md` | Vendor catalog items; publishing models to catalogs. |

All paths in this table start with `it-asset-management/`.

## Enterprise and OT assets (`it-asset-management/enterprise-asset-management/`)

`exploring-eam.md`, `install-eam.md`, `eam-data-model.md`, `eam-model-types.md`, `using-linear-assets.md`, `eam-dcnam-licensing.md`, `install-otam.md`, `licensing-ot-asset-management.md`, `asset-ci-sync-ot-assets.md` (MAC-based asset-CI sync for OT). Summary in `enterprise-asset-management.md`.

## CMDB and IRE (`servicenow-platform/configuration-management-database-cmdb/`)

| Page | What it covers |
|---|---|
| `c_CMDBIdentifyandReconcile.md` | IRE overview, including use with import sets. |
| `c_IdentificationRules.md`, `best-practices-id-reconcile.md` | Identification rules and guidelines. |
| `r_ReconciliationRulesPrinciples.md` | Reconciliation rules (which source may update which attribute). |
| `overview-cmdb-health.md`, `r_CMDBHealthMetrics.md`, `t_CreateCMDBHealthOrphanRule.md` | CMDB Health dashboard, KPIs, orphan rules. |

## APIs and platform administration

| Page | What it covers |
|---|---|
| `api-reference/rest-apis/c_TableAPI.md` | Table API (`/api/now/table`). |
| `api-reference/rest-apis/c_AggregateAPI.md` | Aggregate API (`/api/now/stats`). |
| `api-reference/rest-apis/c_ImportSetAPI.md` | Import Set API. |
| `api-reference/rest-apis/c_IdentifyReconcileAPI.md` | Identification and Reconciliation REST API. |
| `api-reference/server-api-reference/c_GlideRecordScopedAPI.md`, `api-reference/server-api-reference/c_GlideAggregateScopedAPI.md`, `api-reference/server-api-reference/IdentificationEngineScopedAPI.md` | Server-side GlideRecord, GlideAggregate, IdentificationEngine. |
| `platform-administration/t_ViewChoiceListDefinitions.md` | Viewing choice list definitions. |
| `platform-administration/t_CoalesceNormalValues.md` | Field Normalization "coalesce each normal" (destructive). |
| `platform-administration/table-administration-and-data-management/data-hierarchies.md` | Hierarchical queries ("is in hierarchy"). |
| `platform-administration/table-administration-and-data-management/r_DictionaryEntryForm.md` | Dictionary entry form. |
