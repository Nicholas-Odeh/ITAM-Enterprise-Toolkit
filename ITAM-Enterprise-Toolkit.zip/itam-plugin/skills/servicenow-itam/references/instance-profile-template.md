# Instance profile template

Fill this in once per ServiceNow instance and keep it beside the skill (for example as `instance-profile.md`, outside the plugin folder if it holds internal details). The skill reads it before answering, so answers match the actual instance rather than OOB defaults. Write `[FILL]` for anything unknown and the date each section was last checked. Record where each value came from (list view, `sys_properties`, order form) so it counts as evidence.

## Platform
- Instance names (prod / sub-prod / dev):
- Release family and patch (for example brazil, zurich, yokohama P4). This decides which ServiceNowDocs branch to cite:
- UI in use: Hardware Asset Workspace / Software Asset Workspace / Core UI (classic) / mixed:
- Domain separation in use (Contract Management doesn't support it):

## Applications and plugins (check `v_plugin.list` or Product Hub)
| App | ID | Installed (Y/N) | Version |
|---|---|---|---|
| Base Asset Management | `com.snc.asset_management` | | |
| Hardware Asset Management | `sn_hamp` (`com.sn_hamp`) | | |
| Hardware Asset Workspace | `sn_itam_workspace` | | |
| Hardware Model Normalization | `com.sn_hwnorm` | | |
| Procurement | `com.snc.procurement` | | |
| Contract Management Pro / Obligation Management | `sc_cm_pro` / `sn_cm_obligation` | | |
| Enterprise Asset Management / OT Asset Management | `com.sn_eam` / `com.sn_otam` | | |
| ServiceNow Otto (Now Assist) for HAM | `sn_now_assist_ham` (plus `com.sn_itam_aia`) | | |
| SAM Professional and SAM-side apps | see `sam.md` | | |
| Lenovo warranty spoke | `sn_lenovo_spoke` | | |

## Entitlements (from the order form, not the plugin list)
- HAM tier: Pro / Advanced / Prime SKU; AI Native or Non-AI Native:
- ServiceNow Otto (AI) tier: Foundation / Advanced / Prime, or none:
- HAM resource categories opted in or out, and the current license-report count:
- SAM, SaaS License Management, Cloud Cost Management and EAM subscriptions:
- HAM Content Service opted in (shares hardware model data with ServiceNow weekly), and which data types: yes / no:
- SAM Content Service opted in (custom products send instance and customer names; see `sam.md`): yes / no:

## Key properties (check `sys_properties`, and `asset_property` for ITAM common keys)
| Property | Value | Why it matters |
|---|---|---|
| `glide.asset.create_ci_with_ire` | | CI creation from assets goes through IRE; serial may be required. |
| `glide.create_alm_asset.async` | | Assets for new CIs appear only after the delayed job. |
| `sn_itam_common.mac_address_sync` (`asset_property`) | | Asset-CI sync by MAC address. |
| `csdm.lifecycle.sync.between.ci.and.asset.activated` | | CSDM life cycle sync between asset and CI. |
| `sn_itam_restrict_asset_read` | | Users with only `snc_internal` see only their own assets. |
| `sn_hamp.migrate_hamaudit` | | Which audit table is in use. |
| `sn_hamp.enable_asset_action_validation_incident` | | Asset action validation on incidents. |
| `sn_contract_enable_renewal_flow` | | Contract renewal workflow on or off. |

## Data sources
- Discovery (agentless / agent client collector), Service Graph Connectors (MECM, Intune, Jamf, others):
- Imports: source, frequency, transform map, coalesce field:
- Receiving method: PO receipt / stockroom Excel import / ASN / manual:
- Manual entry points:

## Customizations
- Custom states or substates (value, label, meaning), and any changes to the OOB choice lists:
- Changes to the Asset-CI Install Status / Hardware Status / Field Mapping rows:
- Custom fields on `alm_asset` / `alm_hardware` used in reporting:
- Custom asset classes, model categories or tables:
- Customized flows (transfer order, reclamation, disposal, loaner, RMA) and business rules that change asset state:
- Activated or duplicated agentic workflows, with their approval thresholds:

## Organization rules
- Asset tag format and who applies tags:
- Stockrooms (type, owner, service locations) and stock rules:
- Refresh policy by device type:
- Leaver reclamation SLA, and whether HR events start reclamation:
- Capitalization threshold and depreciation method (if tracked in ServiceNow):
- ITAD and disposal vendor, and where certificates are stored:
- Change approval needed for bulk updates (change request type and approvers):

## Roles
- Holders of `asset`, `ham_admin`, `sn_hamp.ham_user`, `inventory_admin`, `inventory_user`, `procurement_admin` / `procurement_user`, `contract_manager`, `model_manager`, `sn_itam_common.asset_audit_admin` (or local equivalents):
- Integration users and their roles (least privilege):
