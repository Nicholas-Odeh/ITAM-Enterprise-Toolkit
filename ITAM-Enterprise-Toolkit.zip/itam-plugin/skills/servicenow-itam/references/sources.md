# Sources, confidence and refresh

## Primary source

- **ServiceNowDocs** is the official ServiceNow product documentation in Markdown, at github.com/ServiceNow/ServiceNowDocs (Apache-2.0).
  - Branch `brazil`, commit `461e11d` (16 Oct 2026). The repository README dates the Brazil early-access docs to 24 Sept 2026.
  - Most cited pages carry the front matter `release: brazil` and `last_updated: 2026-09-10`.
- **Checked 2026-10-20.** All 287 doc paths cited across `references/` resolved on that commit with `scripts/extract_servicenow_docs.py --check-citations references` (0 missing).
- **Citation forms.**
  - Full paths, relative to `markdown/` (for example `DOC it-asset-management/.../<file>.md`), in `ham.md`, `asset-ci-cmdb.md`, `query-script-patterns.md`, `procedures.md`, `contracts-procurement.md`, `enterprise-asset-management.md`, `now-assist-ham.md` and `doc-index.md`.
  - Shorthand prefixes in the SAM-side files (`sam.md`, `saas-license-management.md`, `cloud-cost-management.md`, `asset-audit-response.md`, `now-assist-sam.md`), which the extractor expands:

    | Prefix | Folder |
    |---|---|
    | `sam/` | `software-asset-management` |
    | `saas/` | `saas-license-management` |
    | `ccm/` | `cloud-cost-management` |
    | `aar/` | `asset-audits` |
    | `na/` | `now-assist-for-software-asset-management-sam` |
- **Labels used in every file.**
  - `DOC (path)`: stated on that page and summarized in our own words.
  - `PRACTICE`: ITAM practice, not product behavior.
  - `VERIFY`: not found in the brazil docs, or it depends on the release or the instance.

  The old labels `INSTANCE FACT`, `PLATFORM DOC` and `COMMUNITY` are retired. When the user shows a fact from their instance, cite it as their evidence (for example "your `sys_choice` export").
- **Naming.** The brazil docs rename Now Assist to **ServiceNow Otto**, for example "ServiceNow Otto for Hardware Asset Management (HAM)". Some roles, plugin IDs and older pages still say Now Assist. Treat the two names as the same product.

For a topic-to-page map, see `doc-index.md`.

## Doc areas used (paths relative to `markdown/`)

| Area | Folder | Used in |
|---|---|---|
| Base Asset Management | `it-asset-management/asset-management/` | `ham.md`, `asset-ci-cmdb.md`, `procedures.md` |
| Hardware Asset Management and ServiceNow Otto for HAM | `it-asset-management/hardware-asset-management/`, `it-asset-management/now-assist-for-hardware-asset-management/` | `ham.md`, `procedures.md`, `now-assist-ham.md` |
| Procurement, Contract Management, Product Catalog | `it-asset-management/procurement/`, `.../contract-management/`, `.../product-catalog/` | `contracts-procurement.md` |
| Enterprise and OT Asset Management | `it-asset-management/enterprise-asset-management/` | `enterprise-asset-management.md` |
| SAM, SaaS, Cloud Cost, Asset Audit Response, ServiceNow Otto for SAM | `software-asset-management/`, `saas-license-management/`, `cloud-cost-management/`, `asset-audits/`, `now-assist-for-software-asset-management-sam/` (all under `it-asset-management/`) | The SAM-side files; each has its own source header. |
| CMDB, IRE, CMDB Health | `servicenow-platform/configuration-management-database-cmdb/` | `asset-ci-cmdb.md`, `query-script-patterns.md` |
| REST and server APIs | `api-reference/rest-apis/`, `api-reference/server-api-reference/` | `query-script-patterns.md` |
| Choice lists, dictionary, hierarchies, field normalization | `platform-administration/` | `query-script-patterns.md` |

ServiceNow KB articles appear only where a doc page cites them, for example KB1584544 on limited support for the HAM Core UI. The doc page is the citation.

## What changed from the previous version

The previous version relied on search-result extracts of servicenow.com pages and on community posts. Each community-based claim was checked against the docs:

| Earlier claim (source) | Now |
|---|---|
| State/substate list (community thread) | DOC `it-asset-management/asset-management/t_SettingAssetStatesAndSubstates.md`. The list includes **Build** (bundles only). **Consumed** is a consumable stage. |
| Mapping tables lack Build/Design (KB2701442) | The Build state is DOC. A **Design** state isn't in the brazil docs. Whether the mappings include Build is VERIFY. |
| Core Asset Management vs HAM Pro (community blog) | DOC landing, licensing and install pages. The feature-to-tier mapping is VERIFY because the docs have no matrix. |
| Transferable stock rules (forum) | DOC `it-asset-management/asset-management/c_StockRules.md`. Stock rules belong to Base Asset Management. With HAM, the Vendor option raises a catalog request, and transfers count only Available stock. |
| Asset/CI install status mapping (forum) | DOC mapping pages under `it-asset-management/asset-management/`. The table names behind them are VERIFY. |
| MAC sync property `snitamcommon.macaddresssync` | Corrected to `sn_itam_common.mac_address_sync`, set in `asset_property` (DOC `it-asset-management/asset-management/c_ManagingAssets.md`). |
| Hardware normalization and lifecycle (community guides) | DOC pages on normalization, Content Service opt-in and lifecycle under `it-asset-management/hardware-asset-management/`. |
| Loaner `lead_time` variable (forum) | Corrected: the documented variable is "Number of days required for preparing the loaner asset" (DOC `it-asset-management/hardware-asset-management/loaner-asset-request.md`). |
| CMDB Health (community article) | DOC `servicenow-platform/configuration-management-database-cmdb/overview-cmdb-health.md` and related pages. |
| CI operational vs install status (blog) | The docs name Install Status and Hardware Status as the synced fields. Operational status sync isn't documented, so the skill doesn't promise it. |
| SAM tables, normalization data flow (KB0859817), allocations, reclamation rules (community) | Replaced in `sam.md` by DOC citations. Normalized fields live on `cmdb_sam_sw_discovery_model`. The Content Service replaces the earlier "Normalization Data Services plugin" wording. |
| Asset Audit Response as a publisher-audit tool | Corrected: it serves **financial regulatory audits** (ITAM for Financial Services, for example FFIEC). See `asset-audit-response.md`. |

## Still VERIFY (check in the instance)

- Table names behind the Asset-CI mapping modules (`alm_asset_ci_state_mapping`, `alm_hardware_state_mapping`, `alm_asset_ci_field_mapping`), and whether the OOB rows are ACL-protected.
- A **Design** asset state, and whether Build appears in the mappings.
- Internal field names where the docs give only labels (for example `install_status`, `substatus`). Check `sys_dictionary`, and never use numeric choice values from memory.
- Which features belong to which HAM tier (Pro / Advanced / Prime), and the AI tier entitlements.
- The `proc_user` role named on the refresh page, versus `procurement_user` on the Procurement role pages.
- The name of the approximated-lifecycle-dates property (the docs spell it two ways).
- The In use substates, versus the UI policy that makes Substate read-only for In use.
- Whether audits update the asset location for "Not expected and location corrected" results.
- Offboarding started from an HR case (no HAM page describes it).
- Approval thresholds for HAM agentic workflows, and whether the base catalog approval threshold (1,000 dollars) is still active in the instance.
- The default CMDB Health orphan rules in the instance.
- Items marked VERIFY in the SAM-side files.

## How to refresh (another release, or a newer brazil commit)

1. Make a sparse clone outside the skill folder:
   ```
   git clone --depth 1 --branch <release> --filter=blob:none --sparse \
       https://github.com/ServiceNow/ServiceNowDocs.git sndocs
   git -C sndocs sparse-checkout set markdown/it-asset-management \
       markdown/platform-administration/table-administration-and-data-management \
       markdown/api-reference \
       markdown/servicenow-platform/configuration-management-database-cmdb
   ```
   Cone mode also checks out the top-level files of parent folders, which covers `platform-administration/t_*.md`.
2. Check every cited path:
   ```
   python3 -I scripts/extract_servicenow_docs.py sndocs --branch <release> --check-citations references
   ```
   The command exits with code 1 if any path is missing. For each missing path it lists files with the same name elsewhere, because pages move between folders across releases.
3. Expect some paths to be missing on older releases. For example, against `zurich`, 54 of the 287 paths were missing:
   - Some topics sit in other folders on zurich. `c_ManagingAssets.md` is under `hardware-asset-management/`, and the ServiceNow Otto for HAM pages are under `now-assist-for-hardware-asset-management/`.
   - Others are brazil-only, such as the Contract Management Pro integration and the repair-order fulfillment pages.
   - Zurich also lists different In stock substates. State the user's release, and treat brazil-only behavior as VERIFY on older instances.
4. To find new or changed topics, build an index:
   ```
   python3 -I scripts/extract_servicenow_docs.py sndocs --branch <release> --out <scratch>/sn-index
   ```
   Then read `INDEX.md` and `SOURCE_MANIFEST.jsonl`, which gives the title, release, last_updated and canonical URL of each page.
5. Update the affected reference files and `doc-index.md`. Change the branch, commit and check date at the top of this file. Remove any `__pycache__` the run left in the skill folder.
