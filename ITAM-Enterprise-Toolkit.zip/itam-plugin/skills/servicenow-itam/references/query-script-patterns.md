# Query, script and integration patterns

All patterns are read-only unless marked **WRITE**. Test every pattern in sub-production first. Field names and choice values are placeholders until resolved from the user's instance (see "Verify, don't guess" below). API facts are from ServiceNowDocs `brazil` (paths relative to `markdown/`, checked 2026-10-20); script style is `PRACTICE`.

## Contents
1. Verify, don't guess
2. Encoded queries and hierarchy filters
3. Counting first (GlideAggregate)
4. Reading records (GlideRecord)
5. Safe-write pattern (WRITE)
6. Table, Aggregate, Import Set and IRE REST APIs
7. Imports
8. Reports and dashboards

## 1. Verify, don't guess

When a table, field, choice value, role or property is uncertain, give the user the check instead of a guess:

| What | Check |
|---|---|
| Table exists, hierarchy | `sys_db_object.list` filtered on name, or Tables & Columns |
| Field and type | `sys_dictionary.list` with `name=<table>^element=<field>` (also check the parent, for example `alm_asset`). The dictionary entry form is described in `platform-administration/table-administration-and-data-management/r_DictionaryEntryForm.md`. |
| Choice values (state, substate, install status) | `sys_choice.list` with `name=<table>^element=<field>^language=en^inactive=false`. Choice sets are in `sys_choice_set` (DOC `platform-administration/t_ViewChoiceListDefinitions.md`). Never hard-code numeric state values from memory. |
| System property | `sys_properties.list` with `name=<property>`. Some ITAM keys live in `asset_property` (DOC `it-asset-management/asset-management/c_ManagingAssets.md`). |
| Plugin or app installed | `v_plugin.list`, System Applications > All Available Applications, or Product Hub for HAM (DOC `it-asset-management/hardware-asset-management/product-hub-for-ham.md`) |
| Role and what it contains | `sys_user_role.list` with `name=<role>`; `sys_user_role_contains` |
| Asset-CI mapping rows | Asset > Administration > Asset-CI Install Status / Hardware Status / Field Mapping; remove the default `Out of the box = false` filter (DOC `it-asset-management/asset-management/t_CreateAssetandCIInstallStatusMapping.md`) |

## 2. Encoded queries and hierarchy filters

- Build the filter in the list view, then right-click the breadcrumb and choose **Copy query**. That gives an exact encoded query for the user's instance and release, which is safer than writing one from memory (PRACTICE).
- Syntax reminders: `^` = AND, `^OR` = OR, `^NQ` = new OR group, `ISEMPTY` / `ISNOTEMPTY`, `IN` for lists, dot-walking such as `assigned_to.active=false`, `ORDERBY` / `ORDERBYDESC` (PRACTICE; confirm by copying from the list view).
- **Hierarchy queries**: the condition builder's "is in hierarchy" operator can filter assets by Department, Location or Manager hierarchy, and you can define a record hierarchy on `alm_asset` using the Parent field (DOC `platform-administration/table-administration-and-data-management/data-hierarchies.md`).

## 3. Counting first (GlideAggregate)

Server API reference: `api-reference/server-api-reference/c_GlideAggregateScopedAPI.md`.

```javascript
// Read-only: count hardware assets by state and substate
var ga = new GlideAggregate('alm_hardware');
ga.addEncodedQuery('model_category.name=Computer'); // copy from the list view
ga.addAggregate('COUNT');
ga.groupBy('install_status');   // VERIFY field names in sys_dictionary
ga.groupBy('substatus');
ga.query();
while (ga.next()) {
  gs.info(ga.install_status.getDisplayValue() + ' / ' +
          ga.substatus.getDisplayValue() + ': ' + ga.getAggregate('COUNT'));
}
```

## 4. Reading records (GlideRecord)

Server API reference: `api-reference/server-api-reference/c_GlideRecordScopedAPI.md`.

```javascript
// Read-only: in-use assets assigned to inactive users (leaver recovery)
var gr = new GlideRecord('alm_hardware');
gr.addQuery('install_status', getChoiceValue('alm_hardware', 'install_status', 'In use'));
gr.addQuery('assigned_to.active', false);
gr.setLimit(500);
gr.query();
while (gr.next()) {
  gs.info([gr.asset_tag, gr.serial_number, gr.assigned_to.getDisplayValue(),
           gr.location.getDisplayValue()].join(' | '));
}

// Resolve a choice value by label instead of hard-coding numbers
function getChoiceValue(table, element, label) {
  var c = new GlideRecord('sys_choice');
  c.addQuery('name', 'IN', [table, 'alm_asset'].join(','));
  c.addQuery('element', element);
  c.addQuery('label', label);
  c.addQuery('language', 'en');
  c.addQuery('inactive', false);
  c.setLimit(1);
  c.query();
  return c.next() ? c.getValue('value') : null;
}
```

Rules (PRACTICE):
- Always `setLimit` on exploratory queries.
- Use `getValue()` / `getDisplayValue()` explicitly; don't compare GlideElement objects with `==`.
- Don't hard-code `sys_id`s. Look records up by name or number, or use a property.
- Remember substates repeat across states (Pending disposal is under In stock, In transit and Retired); always filter on **both** fields (DOC `it-asset-management/asset-management/t_SettingAssetStatesAndSubstates.md`).

## 5. Safe-write pattern (WRITE)

Use only after the user approves, and in sub-production first.

```javascript
// WRITE: set substate on matched assets. DRY_RUN must be flipped manually.
var DRY_RUN = true;
var MAX = 200;                       // hard cap per run
var q = '<encoded query copied from list view>';
var gr = new GlideRecord('alm_hardware');
gr.addEncodedQuery(q);
gr.setLimit(MAX + 1);
gr.query();
var n = 0, ids = [];
while (gr.next()) {
  n++;
  if (n > MAX) { gs.warn('More than ' + MAX + ' matches; narrow the query. Aborting.'); break; }
  ids.push(gr.getUniqueValue());
  if (!DRY_RUN) {
    gr.setValue('substatus', '<value from sys_choice>');
    gr.work_notes = 'Bulk update: <ticket/approval reference>';  // if the field exists
    gr.update();                     // business rules and asset-CI sync run normally
  }
}
gs.info((DRY_RUN ? '[DRY RUN] ' : '') + 'Matched ' + Math.min(n, MAX) + ': ' + ids.join(','));
```

Rules:
- Keep business rules on. The asset-CI sync runs through business rules (**Update CI fields on change**, **Update Asset fields on change**), so `setWorkflow(false)` skips that sync and leaves the pair inconsistent. Propose it only with a stated reason and approval (DOC for the rules: `it-asset-management/asset-management/c_ManagingAssets.md`; consequence PRACTICE).
- A state change can trigger other rules: retiring clears Assigned to, Stockroom and Reserved for and retires the CI; moving to In stock clears Assigned to (DOC `it-asset-management/asset-management/r_InstalledWithAssetManagement.md`, `it-asset-management/asset-management/t_RetiringAssets.md`). Include those fields in the before-snapshot.
- **Never script deletes of linked assets or CIs as "cleanup"**: deleting one deletes the other (DOC `it-asset-management/asset-management/t_DeletingAssets.md`). Retire instead.
- Prefer the documented flow over a script when one exists (disposal order, transfer order, reclamation, RMA), because flows also update tasks, contracts and entitlements (DOC `it-asset-management/hardware-asset-management/create-disposal-order.md`).
- Save the affected `sys_id`s and prior values first (export or staging table) so the change can be reversed.
- For large changes use an import set and transform map, or a batched scheduled job, not one background script.
- HAM bulk operations have their own caps, for example `sn_itam_tol_bulk_update_max_count` for transfer order lines (DOC `it-asset-management/hardware-asset-management/ham-system-properties.md`).

## 6. REST APIs

**Table API** (DOC `api-reference/rest-apis/c_TableAPI.md`): `GET /api/now/table/{tableName}`.

```
GET /api/now/table/alm_hardware
    ?sysparm_query=<encoded query>
    &sysparm_fields=asset_tag,serial_number,install_status,substatus,assigned_to,location,model,ci
    &sysparm_display_value=true
    &sysparm_exclude_reference_link=true
    &sysparm_limit=1000
    &sysparm_offset=0
```

- Page with `sysparm_limit` and `sysparm_offset` until a page returns fewer rows than the limit (PRACTICE).
- `sysparm_display_value` returns actual values, display values, or both (`all`). Choice fields return a number as the actual value and a label as the display value (DOC, same page). Use `all` when reconciling.

**Aggregate API** (DOC `api-reference/rest-apis/c_AggregateAPI.md`): `GET /api/now/stats/{tableName}` with `sysparm_count=true`, `sysparm_group_by=install_status`, `sysparm_query=...`. Pass `sysparm_count` or a field aggregate parameter, or no aggregate runs.

**Import Set API** (DOC `api-reference/rest-apis/c_ImportSetAPI.md`) loads rows into a staging table so transform maps and coalesce rules apply.

**Identification and Reconciliation API** (DOC `api-reference/rest-apis/c_IdentifyReconcileAPI.md`) creates or updates CIs through IRE. Use it, not the Table API, for CI inserts (PRACTICE; see `asset-ci-cmdb.md` §8).

Access (PRACTICE): an integration user with least-privilege roles (read-only for reporting); never put credentials in prompts, scripts or files. Note `sn_itam_restrict_asset_read`: if true, users with only `snc_internal` see just their own assets (DOC `it-asset-management/asset-management/c_ManagingAssets.md`).

## 7. Imports

- Load with **import sets + transform maps**, or Service Graph Connectors for supported sources, so coalesce rules, field mapping and errors are visible. Route CIs through IRE: IRE can be applied to import sets and prevents the duplicates they might otherwise create (DOC `servicenow-platform/configuration-management-database-cmdb/c_CMDBIdentifyandReconcile.md`).
- Coalesce hardware on a stable unique key, usually `serial_number` (plus manufacturer if serials collide). Never coalesce on display name (PRACTICE).
- Don't confuse transform coalescing with **Field Normalization "Coalesce each normal"**: that permanently repoints references to one record and deletes duplicates, and a rollback doesn't restore the variants (DOC `platform-administration/t_CoalesceNormalValues.md`).
- For HAM receiving in bulk, use the stockroom **Import assets** Excel template; rows land in `sn_itam_cmn_import_asset_row` with a validation status (DOC `it-asset-management/hardware-asset-management/stockroom-receiving-ham.md`). The Import Staging table `sn_hamp_import_template` holds templates for asset and model import (DOC `it-asset-management/hardware-asset-management/installed-with-ham.md`).
- With `glide.create_alm_asset.async=true`, assets for imported CIs appear only after the delayed-sync job; check the Asset Creation Queue before counting (DOC `it-asset-management/asset-management/c_ManagingAssets.md`).
- Run a test load, review the transform history (inserted / updated / ignored / errors), then load production (PRACTICE).

## 8. Reports and dashboards

- Prefer OOB views before building reports: Hardware asset overview and Asset analytics in the Hardware Asset Workspace (DOC `it-asset-management/hardware-asset-management/using-ham-workspace.md`), the HAM content pack dashboards (DOC `it-asset-management/hardware-asset-management/hardware-asset-content-pack.md`), CMDB success advisor for HAM (DOC `it-asset-management/hardware-asset-management/cmdb-sa-ham-use.md`), and CMDB Health.
- Large overview reports can be lazy-loaded with `sn_itam_workspace.asset_overview_enable_lazy_loading` (DOC `it-asset-management/hardware-asset-management/hardware-asset-overview.md`).
- For custom reports, state the table, filter (encoded query), grouping and the date the data was pulled (PRACTICE).
