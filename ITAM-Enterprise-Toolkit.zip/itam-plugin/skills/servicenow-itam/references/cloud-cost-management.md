# ServiceNow Cloud Cost Management reference (short)

**Labels.** `DOC` = official ServiceNow docs, summarized. `PRACTICE` = practitioner method. `VERIFY` = not confirmed; check in the instance.

**Source.** `DOC ccm/<file>` = `markdown/it-asset-management/cloud-cost-management/<file>` in github.com/ServiceNow/ServiceNowDocs, branch `brazil`, as checked 2026-10-20 (pages `last_updated` 2026-09-10). Cloud Cost Management (CCM) is a store app that ships often. Confirm the installed version before you rely on any feature listed here.

**Scope of this file.** It covers orientation only. This plugin has no FinOps skill. For cloud cost governance method, use `itam-financial-management` (cost allocation, showback) and `itam-software-license-management` (BYOL, cloud licensing) where they apply.

## What it is

- CCM was formerly **Cloud Insights**. Its application scope is `sn_clin` (DOC ccm/cloud-insights-landing-page.md, ccm/install-ci.md).
- It discovers public-cloud resources and their billing. It analyzes cost by cost center, business service or a custom entity, makes optimization recommendations, and automates follow-up actions (DOC ccm/exploring-cloud-insights.md).
- Providers covered: AWS, Microsoft Azure and Google Cloud. Billing and price-sheet data comes in through scheduled download jobs that run over MID Servers (DOC ccm/configuring-cloud-insights.md).

## Key features

Source: DOC ccm/exploring-cloud-insights.md and ccm/ri-cloudin.md.

- **Workspace** with spend analytics, tags and cost allocation rules.
- **Rightsizing** recommendations.
- **Commitments**: reservation and savings-plan recommendations, worked from New, Accepted and Declined tabs.
- **Unused resources** and **Unassigned resources**: resources with no owner or allocation.
- **Business hours** schedules that power resources off when they are not needed.
- **Cloud budgets**.
- **Change Management integration** for actions that change resources.
- **Infra Stack**: optional from version 8.1. Once activated it **cannot be deactivated**.
- **AI:** the Otto for CCM skill *Cloud cost summarizer* (DOC ccm/ai-ccm.md). The governance cautions in `now-assist-sam.md` apply here too.

## Install and setup notes

Source: DOC ccm/install-ci.md and ccm/configuring-cloud-insights.md.

- Prerequisites: Discovery (`com.snc.discovery`) and `sn_itom_pattern`.
- **Demo data:** it can break features and cannot be loaded later. Load it only on a sub-production instance.
- Setup order: MID Servers, cloud accounts and credentials, then the billing and price-sheet download jobs for each provider.
- Versions **8.0.0 and earlier** are in Planned Deprecation.

## Roles

Source: DOC ccm/cloud-insights-roles.md.

| Role | Purpose (summary) |
|---|---|
| `sn_clin_core.insights_admin` | Administer CCM |
| `sn_clin_core.insights_owner` / `insights_user` | Own or use insights and recommendations |
| `sn_clin_core.spend_owner` | Spend administration. The roles table labels it "Spend Admin" while the name is `spend_owner`; `VERIFY` in the instance. |
| `sn_clin_core.budget_viewer` | View budgets |
| `sn_cld_intg_core.cloud_integrations_admin` | Cloud account integrations |
| `sn_cld_spend_core.spend_user` | Spend views |

From version 10.1.0, `discovery_admin` is no longer included in the admin roles (same source).

## Licensing

Source: DOC ccm/managing-ccm-subscriptions.md.

- CCM is licensed in **Subscription Units** across resource categories: Server, PaaS Resources and IaaS Storage.
- From Australia, the resources that count are those discovered in billing data in the **past 30 days**.

## Links to SAM and ITAM

- SAM covers **BYOL** for cloud (e.g. Oracle Database and WebLogic, and Microsoft server products) and has a cloud cost simulator. CCM supplies the cost side (see `sam.md`; DOC `software-asset-management/byol-concepts.md`, `cloud-cost-simulator.md`).
- The Asset Management Executive dashboard can show CCM KPIs next to HAM and SAM KPIs (`VERIFY` which KPIs on the instance).
- `PRACTICE`: Check with Procurement before acting on reservation or savings-plan recommendations. They are financial commitments and are hard to undo.

## Where the docs are

- Landing page: ccm/cloud-insights-landing-page.md
- Overview: ccm/exploring-cloud-insights.md
- Roles: ccm/cloud-insights-roles.md
- Install: ccm/install-ci.md
- Configuration: ccm/configuring-cloud-insights.md
- Commitments: ccm/ri-cloudin.md
- Subscriptions and licensing: ccm/managing-ccm-subscriptions.md
- AI: ccm/ai-ccm.md
