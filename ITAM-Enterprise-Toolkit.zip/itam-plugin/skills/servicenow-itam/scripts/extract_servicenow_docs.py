#!/usr/bin/env python3
"""Index ServiceNowDocs Markdown for the servicenow-itam skill, offline.

Works on a local clone of https://github.com/ServiceNow/ServiceNowDocs (any
release-family branch; a sparse clone of markdown/it-asset-management is
enough). Python 3 standard library only. No network access.

Two modes:

1. Index (default). Reads every Markdown file in the selected publications,
   parses the YAML front matter (title, description, release, last_updated,
   canonical_url, product, topic_type), scores cross-publication topics for
   ITAM relevance, and writes:
     <out>/INDEX.md               human-readable index, ITAM publication first
     <out>/SOURCE_MANIFEST.jsonl  one JSON object per selected document
     <out>/raw/<repo path>        verbatim copies (skip with --no-copy)

2. Citation check (--check-citations DIR). Finds every doc path the skill's
   reference files cite (for example `it-asset-management/asset-management/
   c_ManagingAssets.md`) and reports, for the given clone, whether each path
   exists, its release and last_updated, and, for a missing path, files with
   the same name elsewhere (topics move between folders across releases).
   Shorthand citations used by the SAM files (sam/, saas/, ccm/, aar/, na/)
   are expanded to their full paths (see SHORTHAND).

Examples:
  git clone --depth 1 --branch brazil --filter=blob:none --sparse \
      https://github.com/ServiceNow/ServiceNowDocs.git sndocs
  git -C sndocs sparse-checkout set markdown/it-asset-management \
      markdown/platform-administration/table-administration-and-data-management \
      markdown/api-reference \
      markdown/servicenow-platform/configuration-management-database-cmdb
  python3 scripts/extract_servicenow_docs.py sndocs --branch brazil --out /tmp/sn-index
  python3 scripts/extract_servicenow_docs.py sndocs --branch zurich \
      --check-citations references
"""
import argparse
import json
import re
import shutil
import sys
from pathlib import Path

CORE = {"it-asset-management"}
RELATED = {
    "it-operations-management", "it-service-management", "platform-administration",
    "platform-user-interface", "api-reference", "integrate-applications",
    "build-workflows", "now-intelligence", "intelligent-experiences",
    "platform-security", "mobile", "servicenow-platform", "field-service-management",
    "employee-service-management",
}
# Terms that mark a cross-publication topic as ITAM-relevant. Heavy terms score 3.
HEAVY = {
    "asset management", "hardware asset", "software asset", "stockroom", "cmdb",
    "asset lifecycle", "disposal", "asset audit", "transfer order", "alm_asset",
    "alm_hardware", "model category", "identification and reconciliation",
}
LIGHT = {
    "configuration item", "discovery", "inventory", "model normalization",
    "asset reservation", "receiving", "procurement", "purchase order", "retirement",
    "refresh", "repair", "rma", "warranty", "contract management", "asset workspace",
    "asset request", "barcode", "scanning", "import set", "transform map",
    "reconciliation", "table api", "aggregate api", "flow designer", "workflow studio",
    "condition builder", "access control", "asset tag", "serial number", "consumable",
    "entitlement", "reclamation", "agent app", "glideaggregate", "gliderecord",
}
FRONT_KEYS = ("title", "description", "release", "product", "classification",
              "topic_type", "last_updated", "canonical_url")
# A cited doc path: <publication>/<folders>/<file>.md, optionally prefixed by markdown/.
CITE_RE = re.compile(r"(?:markdown/)?((?:%s)/[A-Za-z0-9_./-]+?\.md)" % "|".join(
    sorted(CORE | RELATED, key=len, reverse=True)))
# Shorthand prefixes used by the SAM-side reference files ("DOC sam/<file>.md").
SHORTHAND = {
    "sam": "it-asset-management/software-asset-management",
    "saas": "it-asset-management/saas-license-management",
    "ccm": "it-asset-management/cloud-cost-management",
    "aar": "it-asset-management/asset-audits",
    "na": "it-asset-management/now-assist-for-software-asset-management-sam",
}
SHORT_RE = re.compile(r"(?<![A-Za-z0-9_./-])(%s)/([A-Za-z0-9_.-]+?\.md)" % "|".join(SHORTHAND))


def front_matter(text):
    """Return a dict of simple key: value pairs from the YAML front matter."""
    m = re.match(r"\A---\s*\n(.*?)\n---\s*\n", text, re.S)
    meta = {}
    if not m:
        return meta
    for line in m.group(1).splitlines():
        if ":" not in line or line.startswith((" ", "-")):
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        if key in FRONT_KEYS:
            meta[key] = value.strip().strip("\"'").replace("\\_", "_")
    return meta


def markdown_root(repo):
    """Accept the clone root or its markdown/ directory."""
    repo = Path(repo)
    if (repo / "markdown").is_dir():
        return repo / "markdown"
    if repo.name == "markdown" and repo.is_dir():
        return repo
    return None


def score(rel, meta, content):
    hay = " ".join([rel, meta.get("title", ""), meta.get("description", ""),
                    content[:12000]]).lower().replace("\\_", "_")
    matched = sorted(t for t in HEAVY | LIGHT if t in hay)
    return sum(3 if t in HEAVY else 1 for t in matched), matched


def build_index(md_root, out, branch, min_score, copy, publications):
    out.mkdir(parents=True, exist_ok=True)
    entries = []
    for src in sorted(md_root.rglob("*.md")):
        rel = src.relative_to(md_root).as_posix()
        pub = rel.split("/", 1)[0]
        if pub not in publications:
            continue
        text = src.read_text(encoding="utf-8", errors="replace")
        meta = front_matter(text)
        sc, matched = score(rel, meta, text)
        if pub not in CORE and sc < min_score:
            continue
        if copy:
            dest = out / "raw" / "markdown" / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
        entries.append({
            "path": rel,
            "title": meta.get("title", src.stem),
            "publication": pub,
            "folder": rel.rsplit("/", 1)[0],
            "release": meta.get("release", branch),
            "last_updated": meta.get("last_updated", ""),
            "topic_type": meta.get("topic_type", ""),
            "description": meta.get("description", ""),
            "github_url": "https://github.com/ServiceNow/ServiceNowDocs/blob/%s/markdown/%s"
                          % (branch, rel),
            "score": sc,
            "matched_terms": matched,
        })
    entries.sort(key=lambda e: (e["publication"] not in CORE, e["folder"], -e["score"], e["path"]))
    with open(out / "SOURCE_MANIFEST.jsonl", "w", encoding="utf-8") as fh:
        for e in entries:
            fh.write(json.dumps(e, ensure_ascii=False) + "\n")
    lines = ["# ServiceNow ITAM source index", "",
             "Release family: `%s`. Selected documents: **%d**." % (branch, len(entries)), "",
             "Paths are relative to `markdown/` in the ServiceNowDocs repository.", ""]
    folder = None
    for e in entries:
        if e["folder"] != folder:
            folder = e["folder"]
            lines += ["", "## " + folder, "", "| Topic | Path | Type | Updated |",
                      "|---|---|---|---|"]
        lines.append("| %s | `%s` | %s | %s |" % (
            e["title"].replace("|", "/").replace("\\", ""), e["path"],
            e["topic_type"], e["last_updated"]))
    (out / "INDEX.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("Indexed %d documents (branch %s) into %s%s" % (
        len(entries), branch, out, "" if copy else " (index only, --no-copy)"))
    return 0


def check_citations(md_root, ref_dir, branch, as_json):
    ref_dir = Path(ref_dir)
    files = [ref_dir] if ref_dir.is_file() else sorted(ref_dir.rglob("*.md"))
    cited = {}
    for f in files:
        for m in CITE_RE.finditer(f.read_text(encoding="utf-8", errors="replace")):
            cited.setdefault(m.group(1).rstrip("."), set()).add(f.name)
        for m in SHORT_RE.finditer(f.read_text(encoding="utf-8", errors="replace")):
            full = "%s/%s" % (SHORTHAND[m.group(1)], m.group(2).rstrip("."))
            cited.setdefault(full, set()).add(f.name)
    by_name = {}
    for p in md_root.rglob("*.md"):
        by_name.setdefault(p.name, []).append(p.relative_to(md_root).as_posix())
    rows, missing = [], 0
    for path in sorted(cited):
        target = md_root / path
        row = {"path": path, "cited_in": sorted(cited[path])}
        if target.is_file():
            meta = front_matter(target.read_text(encoding="utf-8", errors="replace"))
            row.update(status="found", release=meta.get("release", ""),
                       last_updated=meta.get("last_updated", ""), title=meta.get("title", ""))
        else:
            missing += 1
            row.update(status="missing", same_name_elsewhere=by_name.get(Path(path).name, []))
        rows.append(row)
    if as_json:
        print(json.dumps({"branch": branch, "cited": len(rows), "missing": missing,
                          "rows": rows}, ensure_ascii=False, indent=1))
    else:
        print("Citation check against branch %s: %d cited paths, %d missing" % (
            branch, len(rows), missing))
        for r in rows:
            if r["status"] == "found":
                print("  ok       %s  [%s, %s]" % (r["path"], r["release"], r["last_updated"]))
            else:
                alt = ", ".join(r["same_name_elsewhere"]) or "no file with this name"
                print("  MISSING  %s  (cited in %s; candidates: %s)" % (
                    r["path"], ", ".join(r["cited_in"]), alt))
        if any(r["status"] == "found" and r["release"] and r["release"] != branch for r in rows):
            print("Note: some files report a release that differs from --branch; "
                  "check that the clone is on the branch you named.")
    return 1 if missing else 0


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("repo", help="local ServiceNowDocs clone (or its markdown/ folder)")
    p.add_argument("--branch", default="brazil",
                   help="release family the clone is on, used for labels and URLs (default brazil)")
    p.add_argument("--out", type=Path, default=Path("sn-docs-index"),
                   help="output folder for INDEX.md, SOURCE_MANIFEST.jsonl and raw/ "
                        "(default ./sn-docs-index; keep it outside the skill folder)")
    p.add_argument("--min-score", type=int, default=4,
                   help="minimum relevance score for topics outside it-asset-management (default 4)")
    p.add_argument("--publications", default="",
                   help="comma-separated publication folders to scan (default: ITAM plus related)")
    p.add_argument("--no-copy", action="store_true", help="write the index only; do not copy files")
    p.add_argument("--check-citations", metavar="PATH",
                   help="verify doc paths cited in this reference folder or file, then exit")
    p.add_argument("--json", action="store_true", help="JSON output for --check-citations")
    a = p.parse_args(argv)
    md_root = markdown_root(a.repo)
    if md_root is None:
        p.error("no markdown/ folder under %s; clone ServiceNowDocs first" % a.repo)
    if a.check_citations:
        return check_citations(md_root, a.check_citations, a.branch, a.json)
    pubs = set(x.strip() for x in a.publications.split(",") if x.strip()) or (CORE | RELATED)
    return build_index(md_root, a.out, a.branch, a.min_score, not a.no_copy, pubs)


if __name__ == "__main__":
    sys.exit(main())
