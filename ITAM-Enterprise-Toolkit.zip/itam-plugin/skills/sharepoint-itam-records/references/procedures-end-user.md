# End-user procedures: lists, libraries, files, views, sharing

How-to answers for people working inside a SharePoint Online site (modern experience). Labels follow `source-index.md` §1: `DOC` = read in the cited source; `PRACTICE` = adapted pattern; `VENDOR — VERIFY` = UI path or behavior from a cited Support/Learn page not re-read for this skill, or not documented; `[FILL]` = the tenant's own value. These are adaptations in our own words, not copies of Microsoft text.

## Contents
1. Answer template
2. Create a list
3. Add a column
4. Edit a list item
5. Change an asset's assignee in a tracker list (ITAM)
6. Create a document library
7. Upload or edit a file in a library
8. Views and filters
9. Format a column, view or the list form
10. Share a file or folder
11. Check version history

## 1. Answer template

Use this shape for every how-to answer. Put a label on each step or block.

```markdown
**Goal:** one sentence.
**Applies to:** SharePoint Online modern | SharePoint Server | Microsoft Lists | admin center | Teams-connected site.
**Permissions/prerequisites:** role needed, what must already exist, what to check first.
**Steps:** numbered; start from an exact location; one action per step.
**Verify:** how the user confirms it worked (reopen, view, version history, test account).
**If it does not work:** the two or three likeliest causes and the safe next action for each.
**Source:** the Microsoft URL or GitHub path used, with as-checked date; "custom to your tenant" for organization fields.
```

Before giving steps, confirm the experience. SharePoint Server, the classic experience, Microsoft Lists and a list opened inside Teams can show different commands (`VENDOR — VERIFY`). If the user can't see a command, see `troubleshooting.md` §4.

## 2. Create a list

**Applies to:** SharePoint Online, modern team or communication site. **Prerequisites:** permission to create lists on the site (typically site Member or Owner; `VENDOR — VERIFY` for customized permission levels).

1. Open the modern SharePoint site.
2. On the command bar, select **New > List**.
3. In "How would you like to start?", under **Create from blank**, select **List**.
4. Enter a name and select **Create**. SharePoint opens the new list.
5. Add columns (§3).

**Verify:** the list appears in Site contents and opens with a Title column. **Source:** `DOC` `spdev:docs/business-apps/get-started/set-up-sharepoint-site-lists-libraries.md` (ms.date 2025-11-17). Templates offered next to "Create from blank" vary by tenant (`VENDOR — VERIFY`).

By API: `POST /sites/{site-id}/lists`; with no template the list defaults to `genericList`, which includes a Title column (`DOC` `graph:api-reference/v1.0/api/list-create.md`). That call needs Sites.Manage.All as its least-privileged scope. Treat it as an admin or developer task (`advanced-operations.md`).

## 3. Add a column

1. In the list, select **+ Add column** and choose the type (for example **Person** for an owner or assignee).
2. In **Create a column**, enter the name and description; select **Save**.

**Source:** `DOC` same file as §2. Settings such as required, unique values, default value and indexing sit under the column's settings (`VENDOR — VERIFY` exact location). In the Graph model a column has an API-facing `name` and a user-facing `displayName`, plus `required`, `enforceUniqueValues` and `indexed` properties (`DOC` `graph:api-reference/v1.0/resources/columndefinition.md`). Columns like Asset Tag, Serial Number and Assigned To are organization columns, not SharePoint defaults. Design them from `metadata-schema.md`.

**ITAM tip (PRACTICE):** if the column will filter a large list (Asset Tag, Asset Status, Assigned To), make it indexed when you create the list, before the list grows (`metadata-schema.md` §8).

## 4. Edit a list item

**Prerequisites:** edit permission on the list and item.
1. Open the site and the list.
2. Find the item by search, filter or a view.
3. Select the item and choose **Edit**, or open it and choose **Edit** in the item pane.
4. Change the value. For a Person column, pick the account from the people picker.
5. Select **Save**.

**Verify:** reopen the item; if versioning is on, open **Version history** and confirm the new version. **If it does not work:** no Edit command (permissions, a custom Power Apps form, an approval or check-out rule); field missing (hidden in the form, a different content type, form configuration). See `troubleshooting.md` §1. **Source:** `VENDOR — VERIFY` https://support.microsoft.com/en-us/sharepoint/lists/get-started-with-sharepoint/introduction-to-lists.

## 5. Change an asset's assignee in a tracker list (ITAM)

**Classification:** `PRACTICE` (an adapted custom-list pattern, not a Microsoft ITAM feature). SharePoint mechanics as §4 (`VENDOR — VERIFY`). **Prerequisites:** edit rights on the tracker; the change is authorized (ticket or request ID) [FILL — your process]; you know which system is authoritative for assignment (`metadata-schema.md` §7).

1. Open the site that hosts the asset tracker list [FILL — site/list name].
2. Search for the exact Asset Tag, then confirm the Serial Number matches the physical device or the request.
3. Open the item and choose **Edit**.
4. In the organization's Assigned To Person column, select the new person. If your process requires it, also update the custody reason, the assigned date and the request ID.
5. **Save**; reopen the item and confirm the Person value.
6. Make or confirm the same change in the authoritative system (`~~ITSM` asset record). SharePoint doesn't update ServiceNow or another ITAM tool by itself unless an integration exists and is confirmed running.

**Verify:** the tracker and the authoritative record show the same assignee and date. **If it does not work:** the tracker is overwritten nightly by a sync (edit the source instead); the people picker can't find the user (account not yet provisioned or the column restricted to a group; `VENDOR — VERIFY`); the item is locked by an approval flow.

## 6. Create a document library

**Prerequisites:** permission to create libraries on the site.
1. Open the site.
2. Select **New > Document library**.
3. Choose blank, a template, or copy from an existing library, if offered.
4. Name it, set any offered options, and create it.
5. Upload a test file; check permissions and versioning before real content goes in.

**Source:** `VENDOR — VERIFY` https://support.microsoft.com/en-us/sharepoint/documents-and-library/create-a-document-library-in-sharepoint. For an ITAM evidence library, take the name, content types, columns, permissions and retention label from `library-taxonomy.md` §3 before step 4.

## 7. Upload or edit a file in a library

1. Open the library and select the file; choose **Open** (browser or desktop app, as offered).
2. Edit. In Microsoft 365 web apps, wait until the save completes before you close.
3. If you edited a downloaded copy offline, upload it back as a new version of the same file, not as a second file.
4. **Verify** the content and, when versioning is on, the new entry in version history.

**Source:** `VENDOR — VERIFY` https://support.microsoft.com/en-us/sharepoint/libraries/edit-a-document-in-a-document-library. **ITAM rule (PRACTICE):** final evidence such as signed contracts and certificates of destruction is uploaded as PDF and not edited afterward. Correct the metadata, not the document.

## 8. Views and filters

1. Open the list or library and use the view menu, filter pane or column header.
2. Filter or sort by the columns you need.
3. Save as a new view if offered; decide whether it is personal or public.
4. Test it with sample items. Filtering changes nothing in the data.

**Source:** `VENDOR — VERIFY` Lists overview URL in §4. **A view is not security.** Anyone with access to the list can switch views or search. Restrict access with permissions (`procedures-admin.md`). For lists near or above the list view threshold, filter first on an indexed column (`metadata-schema.md` §8). ITAM operational views: `metadata-schema.md` §9.

## 9. Format a column, view or the list form

- **Column and view formatting** change only how values are displayed, not the data. Anyone who can create and manage views can apply them (`DOC` `spdev:docs/declarative-customization/column-formatting.md`, `spdev:docs/declarative-customization/view-formatting.md`). Use them for status colors (Asset Status, overdue Last Audit Date). They never enforce a rule.
- **List form configuration** adds a header, footer and sections to the item form; it doesn't change data either. The layout is stored on the list content type, so a content type from the content type hub is read-only until it's set to allow edits (`DOC` `spdev:docs/declarative-customization/list-form-configuration.md`, ms.date 2026-03-03).
- Formatting JSON is written by the user; check samples before applying them (`PRACTICE`).

## 10. Share a file or folder

1. Select the file or folder; choose **Share** or **Manage access**.
2. Choose the least-permissive link that meets the need. Prefer specific people over organization-wide or anyone links.
3. Check edit vs. view and the expiration (if offered) before you send.
4. Confirm the recipient can open it; remove the link when it is no longer needed.

**Source:** `VENDOR — VERIFY` https://learn.microsoft.com/en-us/sharepoint/modern-experience-sharing-permissions. **ITAM rule:** never share contracts, pricing or personal data with an anyone link. External auditors get time-limited access through the pattern in `flow-patterns.md` §6. Site and tenant sharing settings can block an option you expect to see (`procedures-admin.md` §4).

## 11. Check version history

1. Select the item or file; open **Version history** from its menu or details pane (`VENDOR — VERIFY` location).
2. Compare versions; note who changed what and when.

List-item versioning and library versioning are separate settings. If versioning was off when a change happened, there is no earlier version to restore; say so plainly (`troubleshooting.md` §3). Previous versions can also be trimmed by admin settings, and Graph exposes item versions at `GET /sites/{site-id}/lists/{list-id}/items/{item-id}/versions` (`DOC` `graph:api-reference/v1.0/api/listitem-list-versions.md`).
