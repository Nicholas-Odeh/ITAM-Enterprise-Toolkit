# Metadata schema and list trackers

Design content is `PRACTICE`. Column type behavior, validation syntax, indexing and list limits are `VENDOR — VERIFY` against current Microsoft documentation unless a `DOC` path is given (paths explained in `source-index.md`). Key formats are `[FILL]` from the organization's ITAM and procurement systems. Asset field names follow the canonical data model in `itam-hardware-lifecycle` (`skills/itam-hardware-lifecycle/references/asset-data-model.md`; not copied into this skill).

## Contents
1. Principles
2. Site columns
3. Keys to ServiceNow and other systems
4. Managed metadata vs. choice vs. lookup
5. Batch documents
6. Audit evidence completeness
7. List tracker designs (incl. the interim asset tracker)
8. List scale and performance
9. Operational views for an asset tracker
10. Audit a tracker against the authoritative system

## 1. Principles

- **Keys, not copies.** Store the identifiers that join to the system of record (asset tag, contract ID, PO) and a link. Don't copy cost, state, assigned user or vendor terms from ServiceNow into SharePoint columns unless a named sync owns them (SKILL rule 6).
- **Validate at entry.** Format validation on key columns stops typos that break joins.
- **Required means required.** Make the minimum key columns required in the content type; everything else optional.
- **Site columns, not library columns,** so the same column means the same thing everywhere and search can refine by it.

## 2. Site columns

| Internal name | Display name | Type | Required for | Validation / source | Notes |
|---|---|---|---|---|---|
| AssetTag | Asset tag | Single line of text | WAR, ACK (and any per-asset document) | Format [FILL — e.g., regex-like rule via column validation, VERIFY syntax] | The physical tag identifier (see `itam-logistics-warehouse`) |
| SerialNumber | Serial number | Single line of text | Optional | Uppercase, no spaces [FILL] | Secondary key; tags can be replaced |
| ContractID | Contract ID | Single line of text | CON, LIC | Format [FILL] | Key to the contract record |
| ParentContractID | Parent contract ID | Single line of text | Amendments | Same format | — |
| EntitlementID | Entitlement ID | Single line of text | LIC (where used) | [FILL] | Key to SAM entitlement record |
| PONumber | PO number | Single line of text | FIN | Format [FILL] | — |
| InvoiceNumber | Invoice number | Single line of text | FIN | — | — |
| VendorName | Vendor | Managed metadata or lookup (section 4) | CON, FIN, LIC, DIS | Vendor master [FILL] | Use the normalized vendor name |
| Publisher | Software publisher | Managed metadata | LIC | Publisher term set | — |
| ContractType | Contract type | Choice | CON | [FILL list — e.g., MSA, order form, SOW, SLA, renewal, NDA] | — |
| EffectiveDate | Effective date | Date | CON | — | — |
| ExpiryDate | Expiry date | Date | CON | — | Drives renewal reminders (`flow-patterns.md`) and possibly event-based retention |
| NoticeDate | Notice deadline | Date | CON (optional) | From the contract, never computed by assumption | Feeds reminders; confirm with `itam-vendor-contract-management` |
| WarrantyEnd | Warranty end | Date | WAR | — | — |
| DisposalBatchID | Disposal batch / order ID | Single line of text | DIS | Format [FILL] | Joins to disposal order in ServiceNow |
| ITADVendor | ITAD vendor | Managed metadata or lookup | DIS | Vendor master | — |
| CertificateDate | Certificate date | Date | DIS | — | — |
| DeviceCount | Devices on certificate | Number | DIS | Integer ≥ 1 | Compare with manifest row count in the intake flow |
| ManifestAttached | Serial manifest attached | Yes/No | DIS | — | Section 5 |
| CountID / AuditID | Count or audit ID | Single line of text | INV | [FILL] | — |
| Site | Site / location | Managed metadata | INV, optional elsewhere | Location term set aligned to ITAM locations | — |
| ServiceNowLink | ServiceNow record | Hyperlink | CON, DIS, optional elsewhere | URL to the record | Section 3 |
| ServiceNowNumber | ServiceNow record number | Single line of text | Optional | — | Human-readable reference |
| DocumentDate | Document date | Date | All | — | The date on the document, not the upload date |
| EvidenceStatus | Evidence status | Choice | DIS, INV | Received · Validated · Rejected · Superseded | Set by intake flow or reviewer |
| ReviewedBy | Reviewed by | Person | DIS, INV, CON | — | CAMP measures documents reviewed before committing to the repository (CAMP S:100) |
| DocumentID, Version, Status, DocumentOwner, NextReviewDate | Governance fields | Text / choice / person / date | GOV | — | Align with `itam-sop-documentation` document control |

## 3. Keys to ServiceNow and other systems

Options for linking a document to a ServiceNow asset or contract record (choose one primary pattern per class; `servicenow-itam` for the ServiceNow side):

| Pattern | How | Pros | Cons |
|---|---|---|---|
| A. Key + link in SharePoint | Columns hold AssetTag/ContractID and a hyperlink to the record | Simple; no integration | One direction; ServiceNow users don't see the document |
| B. Link field on the ServiceNow record | A URL field or related link on the asset/contract points to the SharePoint document or a filtered view | ServiceNow users can open the evidence | Needs a field/config change in ServiceNow (approval, `servicenow-itam`) |
| C. Both, maintained by a flow | Intake flow writes the link to ServiceNow after validation | Two-way discoverability | Integration account, connector licensing (`VENDOR — VERIFY` premium), error handling |
| D. Attachment in ServiceNow | Document stored as a ServiceNow attachment | One place for ServiceNow users | Duplicates storage; retention and permissions then live in ServiceNow; avoid for large evidence volumes |

Link to a filtered library view by key (for example all documents where ContractID = X) rather than to each file when a record has many documents.

## 4. Managed metadata vs. choice vs. lookup

| Need | Use | Why |
|---|---|---|
| Vendor, publisher, location used across sites | Managed metadata term set | Central, consistent, supports synonyms; needs a term store owner |
| Short, stable list used in one library | Choice | Simple |
| Value maintained in a SharePoint list on the same site (e.g., a vendor master list) | Lookup | Easy to maintain; same-site only (`VENDOR — VERIFY`) |
| Value mastered in ServiceNow | Text key + link | Don't re-master it in SharePoint |

## 5. Batch documents

A certificate of destruction or an ITAD manifest usually covers many devices. Don't type hundreds of serials into a multi-value column.
- Key the certificate by DisposalBatchID.
- Attach the serial manifest as a CSV or spreadsheet in the same library with the same DisposalBatchID (or as a second file in a document set if used).
- The intake flow (`flow-patterns.md`) compares manifest row count with DeviceCount and, where integrated, with the disposal order in ServiceNow; mismatches set EvidenceStatus = Rejected and notify the ITAM team. Detailed serial matching belongs to `itam-inventory-reconciliation`; the disposal evidence rules to `itam-secure-disposition`.

## 6. Audit evidence completeness

CAMP indicators for Documentation Management include the percentage of documents that can be linked to their asset and the percentage reviewed before being committed (CAMP S:100). Measure:
- Documents with a valid key ÷ documents in the class.
- Assets (or contracts, or disposal orders) with at least one required document ÷ assets in scope. This needs a join with the ServiceNow export; see `itam-data-analysis-reporting`.

## 7. List tracker designs

Use a list when the item is a task or event, not a document. Keep asset master data in the ITAM system.

**Contract renewal calendar** — ContractID (text, required), VendorName, ContractOwner (person), ExpiryDate, NoticeDate, RenewalDecision (choice: Renew · Renegotiate · Terminate · Undecided), DecisionDate, ServiceNowLink, Status. Feeds the reminder flow.

**Evidence request log** (audits) — RequestID, AuditID, Requester, RequestText, DueDate, Owner (person), Status, EvidenceLink (link to library view), DateProvided, Notes.

**Certificate intake queue** — DisposalBatchID, ITADVendor, ExpectedDate, ReceivedDate, EvidenceStatus, Reviewer, Discrepancy (text).

**Interim asset tracker** (where no ITAM system exists yet, or as a stockroom or project working list): a SharePoint list is a custom tracker, not a Microsoft ITAM feature and not a system of record (SKILL rule 6). Label it interim, name the migration target, and use the canonical field names from the asset data model above so migration is mechanical. Recommended columns, merged from the procedural package's schema (`PRACTICE`):

| Display name | Internal name (set at creation) | Type | Settings | Canonical field |
|---|---|---|---|---|
| Asset Tag | AssetTag | Single line of text | Required; enforce unique values; indexed | `asset_tag` |
| Serial Number | SerialNumber | Single line of text | Indexed; normalize to uppercase | `serial_number` |
| Device Model | DeviceModel | Single line of text or lookup to a model list | — | `model` |
| Asset Status | AssetStatus | Choice | Values = the organization's lifecycle states [FILL]; indexed | `state` / `substate` |
| Assigned To | AssignedTo | Person | People only; single value; indexed | `assigned_to` |
| Stockroom | Stockroom | Choice or lookup | — | `stockroom` |
| Location | Location | Text, lookup or managed metadata | — | `location` |
| Last Audit Date | LastAuditDate | Date | — | `last_verified_date` |
| Source System ID | SourceSystemID | Single line of text | The record ID in the authoritative system, when one exists | `asset_id` |
| Comments | Comments | Multiple lines of text | Plain text; no passwords, recovery keys or unneeded personal data | — |

Column facts: a column has an API `name` and a user-facing `displayName`, and `required`, `enforceUniqueValues` and `indexed` are column properties (`DOC` `graph:api-reference/v1.0/resources/columndefinition.md`). The internal name is fixed when the column is first created, so create it without spaces and rename the display name afterward (`VENDOR — VERIFY`). Turn on list versioning so assignment changes leave a history (`procedures-end-user.md` §11).

**Data ownership (required for any asset tracker):** write down, per column, which system is authoritative and how changes flow: for example "AssignedTo: `~~ITSM` is authoritative, nightly one-way sync to SharePoint, owner [FILL]" or "SharePoint is authoritative until migration on [FILL date]". Without this, tracker and ITAM records drift (`troubleshooting.md` §8). Changing an assignee step by step: `procedures-end-user.md` §5.

## 8. List scale and performance

Large lists and libraries need indexed columns on the fields used to filter, and views that filter on an indexed column first, because of the list view threshold (`VENDOR — VERIFY` current value and behavior). Plan indexes when creating the list, before volume grows. Related documented limits:
- Graph `$filter` on list items works best on indexed columns and can use one indexed field at a time (`DOC` `graph:api-reference/v1.0/api/listitem-list.md`).
- Power Automate **Get items** returns 100 items by default, up to 5,000 with Top Count; turn on pagination for larger lists (`DOC` `spdev:docs/business-apps/power-automate/guidance/working-with-get-items-and-get-files.md`).
- Get items / Get files fail when a list has more than 12 lookup columns. Person columns are returned like lookups in Graph's fieldValueSet; whether they count toward this limit is `VENDOR — VERIFY`. Keep trackers lean (`DOC` `spdev:docs/business-apps/power-automate/sharepoint-connector-actions-triggers.md`; `graph:api-reference/v1.0/resources/fieldvalueset.md`).

## 9. Operational views for an asset tracker

Create these as public views when the columns exist (`PRACTICE`; how to save a view: `procedures-end-user.md` §8):

| View | Filter | Sort / group | Purpose |
|---|---|---|---|
| My assets | AssignedTo = [Me] | AssetTag | Self-service check |
| In stock by stockroom | AssetStatus = [in-stock value, FILL] | Group by Stockroom | Stock counts and allocation |
| Audit overdue | LastAuditDate < [Today] − [FILL days], or empty | LastAuditDate ascending | Cycle-count worklist |
| Unassigned in use | AssetStatus = [in-use value] and AssignedTo is empty | — | Data-quality exception |
| Duplicates check | Group by SerialNumber | Count > 1 | Data-quality exception |

Views filter what people see; they are not security (`procedures-end-user.md` §8). Put the first filter on an indexed column. Column formatting can highlight overdue audits, but it doesn't enforce anything.

## 10. Audit a tracker against the authoritative system

`PRACTICE` (a recommended operating pattern, not a Microsoft workflow). For full count-to-record reconciliation use `itam-inventory-reconciliation`; this is the SharePoint side.
1. Export the in-scope records from the authoritative system (`~~ITSM` or ITAM tool) and the tracker (list export or Graph read). Note the time of each read.
2. Normalize the keys (Asset Tag, Serial Number: trim, uppercase); list duplicates and blanks before comparing.
3. Compare per key: present in both, tracker only, source only, field mismatches (assignee, status, location).
4. Log each discrepancy in an evidence request or discrepancy list with checker, date, location and category; file count sheets in the Inventory and audit evidence library with the CountID/AuditID key (`library-taxonomy.md`).
5. Fix exceptions in the authoritative system through its change process, then re-sync or update the tracker. Bulk corrections in SharePoint need the dry-run, cap and rollback steps in `advanced-operations.md` §7 and approval.
6. Report counts per category from the comparison output, not estimates.
