# Retention schedule (template) and Purview design

**Retention periods, legal holds and disposal decisions are organizational and legal decisions.** This file never supplies a period. Every period cell stays `[FILL — Records/Legal]` until an approved schedule or counsel provides it. CAMP places the requirement-setting for document retention with compliance and legislation functions, including financial records such as proofs of purchase and invoices (CAMP M:41), and lists a document retention policy among ITAM policies (CAMP M:71). DocuForge's rule applies: never infer a retention period.

Microsoft Purview features (retention labels, label policies, auto-apply, event-based retention, disposition review, records and regulatory records, adaptive scopes) and their licensing are `VENDOR — VERIFY` against current Microsoft documentation and the tenant's licenses.

## Contents
1. Who decides
2. Schedule template
3. Retention triggers
4. Purview label design
5. Event-based retention
6. Disposition review
7. Legal hold
8. Change control

## 1. Who decides

| Decision | Owner [FILL] | Evidence of decision |
|---|---|---|
| Retention period per record class | Records management / Legal | Approved retention schedule ID and version |
| Jurisdiction-specific requirements | Legal / Compliance | Legal advice record |
| Disposition approvers | Records management + class owner | Schedule |
| Legal hold placement and release | Legal | Hold notice |
| Purview configuration | M365 compliance administrator | Change record |

If the organization already has an enterprise retention schedule, map ITAM classes to its codes rather than creating new ones.

## 2. Schedule template

| Class ID | Record class | Enterprise schedule code | Retention trigger | Retention period | Action at end | Disposition review? | Reviewer | Record label? | Legal/regulatory basis | Approved by / date |
|---|---|---|---|---|---|---|---|---|---|---|
| CON | Contracts and agreements | [FILL] | Contract end/termination | [FILL — Records/Legal] | [FILL — delete / review] | [FILL] | [FILL] | [FILL] | [FILL — Legal] | [FILL] |
| FIN | Purchase and financial records | [FILL] | [FILL — e.g., fiscal year end, or asset disposal] | [FILL — Records/Legal] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL — Legal/Finance] | [FILL] |
| LIC | License and entitlement records | [FILL] | [FILL — e.g., entitlement end or product fully retired] | [FILL — Records/Legal] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| WAR | Warranty and support | [FILL] | [FILL — warranty end or asset disposal] | [FILL — Records/Legal] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| DIS | Disposition evidence | [FILL] | Disposal date | [FILL — Records/Legal] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL — Legal; data protection and environmental rules may apply] | [FILL] |
| INV | Inventory and audit evidence | [FILL] | Audit or count closure | [FILL — Records/Legal] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| ACK | User acknowledgments | [FILL] | [FILL — asset return or employment end] | [FILL — Records/Legal/Privacy] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL — privacy law] | [FILL] |
| GOV | Governance documents | [FILL] | Superseded | [FILL — Records/Legal] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |

Notes for the people filling it in (PRACTICE, not legal advice):
- Software license records can matter long after purchase: an audit can ask for proof of an old purchase or upgrade path (CAMP S:103 gives the example of proving a competitive upgrade from years earlier). Consider a trigger tied to the end of use of the entitlement rather than the purchase date.
- Disposition evidence is what proves a device was sanitized; its trigger is the disposal date, and its period should be set with security and legal.
- User acknowledgments contain personal data; privacy law may limit as well as require retention.

## 3. Retention triggers

| Trigger type | Use for | Note |
|---|---|---|
| Created / modified date | GOV drafts, low-value working files | Simple; often wrong for ITAM records whose relevance starts later |
| Labeled date | Records declared final at a known point | — |
| Event-based | CON (contract end), DIS (disposal), WAR (warranty end), ACK (employment end), LIC (entitlement end) | Section 5; `VENDOR — VERIFY` availability and licensing |

## 4. Purview label design

| Label name | Class | Retain/delete behavior | Mark as record? | How applied | Notes |
|---|---|---|---|---|---|
| ITAM-CON-[code] | CON | Per schedule | [FILL] | Default library label or by content type [VERIFY] | — |
| ITAM-DIS-[code] | DIS | Per schedule | [FILL — commonly yes for final evidence] | Applied by intake flow or default library label | — |
| … | … | … | … | … | — |

Design points (PRACTICE; mechanics `VENDOR — VERIFY`):
- **Retention policy vs. retention label:** a policy applies broadly to a location; a label applies to items and can carry record status and event triggers. ITAM classes usually need labels.
- **Default library label** is the simplest reliable application method when one library = one class.
- **Auto-apply** (by content, keywords or metadata) may require additional licensing; verify before designing around it.
- **By code:** retention labels can also be set on many items through the CSOM method `SetComplianceTagOnBulkItems`, which Microsoft's page says works without the label being published to the location (`DOC` `spdev:docs/apis/csom-methods-for-applying-retention-labels.md`; `advanced-operations.md` §11). It is still a records change under section 8.
- **Record and regulatory record labels** restrict editing and deletion. Regulatory records in particular can be impossible to unlabel or delete before the period ends; use them only with explicit Legal approval and a pilot (SKILL rule 7).
- **Retention preserves content** (including deleted items and versions in a hidden preservation location) for the period; storage planning should allow for this (`VENDOR — VERIFY` behavior).

## 5. Event-based retention

Pattern: a label is configured with an event type (for example "Contract expired" or "Asset disposed"); documents carry an asset ID value (for example ContractID or DisposalBatchID); when the event is created for that ID, the retention period starts. `VENDOR — VERIFY` the current configuration steps, how asset ID values are matched, and whether events can be raised by API or flow.

| Event type | Raised when | Raised by | ID matched |
|---|---|---|---|
| Contract ended | Contract record closed in [FILL — ServiceNow / contract system] | [FILL — manual / flow] | ContractID |
| Asset batch disposed | Disposal order closed with validated certificate | [FILL] | DisposalBatchID |
| Employment ended | HR leaver event | [FILL] | [FILL — employee ID; privacy review] |

Control: reconcile events raised against closures in the system of record [FILL frequency]; a missed event means retention never starts.

## 6. Disposition review

- Reviewers per class from the schedule; at least one reviewer outside the ITAM team for DIS and FIN [RECOMMENDATION].
- Reviewers can approve deletion, extend, or relabel; their decision is the evidence of defensible disposal.
- Keep proof of disposition (what, when, approved by) as long as the schedule requires [FILL].
- `VENDOR — VERIFY` licensing and permissions needed for disposition review.

## 7. Legal hold

- Holds are placed and released by Legal through the organization's eDiscovery process; retention labels don't replace them.
- An item on hold is not deleted when its retention period ends.
- ITAM's job: tell Legal which libraries, keys (vendor, contract ID, asset tags) and date ranges are relevant, and stop any manual cleanup in scope.

## 8. Change control

Changes to labels, label policies or the schedule are changes to records controls: change record, Legal/Records approval, pilot on a test library, and a note in the schedule's version history. Never shorten a period on existing content without Legal approval.
