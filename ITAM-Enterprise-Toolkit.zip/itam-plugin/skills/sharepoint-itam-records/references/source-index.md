# Official source index

Where every SharePoint, Graph and Power Automate claim in this skill comes from, and how sure we are of it. Read this when you need a link to cite, when a step looks out of date, or when refreshing the skill.

## Contents
1. Evidence classes and labels
2. Sources read for this skill (DOC)
3. Sources cited but not re-read (VENDOR — VERIFY)
4. Source hierarchy
5. Refreshing the sources

## 1. Evidence classes and labels

The SharePoint procedural package grouped guidance into three evidence classes. This plugin uses its own labels; map them like this:

| Package class | Plugin label | Meaning here | Example |
|---|---|---|---|
| Verified Microsoft procedure | `DOC` + path or URL + as-checked date | The source was read and the statement summarizes it | "PATCH …/fields with If-Match returns 412 on an ETag mismatch" (graph: listitem-update.md) |
| Adapted example | `PRACTICE` | A pattern built on SharePoint features, not something Microsoft prescribes | Asset tracker list schema, change-assignee steps, audit-vs-authoritative workflow |
| Tenant-specific / not verified | `VENDOR — VERIFY` for product behavior; `[FILL]` for organization values | UI labels, menu paths, limits and licensing not confirmed against a source read for this skill; column, group and site names belong to the tenant | "Settings > Site permissions" path; an `AssignedTo` column |

A UI path taken from a Microsoft Support or Learn page listed in section 3 stays `VENDOR — VERIFY` with that URL as its source until someone reads the page and confirms it.

## 2. Sources read for this skill (DOC)

Repositories, read from shallow sparse clones on 2026-10-20 (both CC BY 4.0; summarized in our own words, not copied):
- `spdev:` = https://github.com/SharePoint/sp-dev-docs, branch `main`, commit `c411a84`. Publishes to learn.microsoft.com/sharepoint/dev.
- `graph:` = https://github.com/microsoftgraph/microsoft-graph-docs-contrib, branch `main`, commit `a7edbd4`. Publishes to learn.microsoft.com/graph.

The ms.date shown is the page's own date stamp.

| Topic | Path | ms.date | Used for |
|---|---|---|---|
| Create a list, add a Person column (modern UI walk-through) | `spdev:docs/business-apps/get-started/set-up-sharepoint-site-lists-libraries.md` | 2025-11-17 | End-user list creation steps |
| SharePoint connector triggers, actions, known limitations | `spdev:docs/business-apps/power-automate/sharepoint-connector-actions-triggers.md` | 2020-03-10 | Trigger polling, supported templates, 12-lookup limit, moved files don't trigger |
| Get items / Get files limits and filter queries | `spdev:docs/business-apps/power-automate/guidance/working-with-get-items-and-get-files.md` | 2022-06-28 | Default 100 items, Top Count up to 5,000, pagination |
| Manage item/file permissions from a flow | `spdev:docs/business-apps/power-automate/guidance/manage-list-item-file-permissions.md` | 2022-12-01 | Grant access action has no external-user support |
| Column formatting | `spdev:docs/declarative-customization/column-formatting.md` | 2022-09-08 | Display-only; needs view-management rights |
| View formatting | `spdev:docs/declarative-customization/view-formatting.md` | 2022-06-28 | Display-only views |
| List form configuration | `spdev:docs/declarative-customization/list-form-configuration.md` | 2026-03-03 | Form layout stored on the list content type; hub content types are read-only by default |
| Site templates and site scripts | `spdev:docs/declarative-customization/site-design-overview.md` | 2025-01-22 | Repeatable site provisioning |
| Hub sites overview | `spdev:docs/features/hub-site/hub-site-overview.md` | 2022-06-28 | Hub association doesn't change permissions |
| Retention label CSOM methods | `spdev:docs/apis/csom-methods-for-applying-retention-labels.md` | 2024-09-30 | Bulk label application by code |
| Graph vs SharePoint REST v2 | `spdev:docs/apis/sharepoint-rest-graph.md` | 2020-12-05 | Prefer Graph endpoints |
| SharePoint REST lists and items | `spdev:docs/sp-add-ins/working-with-lists-and-list-items-with-rest.md` | 2022-06-13 | If-Match ETag on MERGE/DELETE |
| Throttling | `spdev:docs/general-development/how-to-avoid-getting-throttled-or-blocked-in-sharepoint-online.md` | 2025-10-02 | 429/503, Retry-After, User-Agent decoration |
| List webhooks | `spdev:docs/apis/webhooks/lists/overview-sharepoint-list-webhooks.md` | 2022-09-23 | Change notifications without polling |
| SharePoint Framework overview | `spdev:docs/spfx/sharepoint-framework-overview.md` | 2025-12-10 | SPFx as the supported extension model |
| Add-in retirement | `spdev:docs/sp-add-ins/retirement-announcement-for-add-ins.md` | 2023-07-30 | Add-ins stop working in all tenants 2 April 2026 |
| Azure ACS retirement | `spdev:docs/sp-add-ins/retirement-announcement-for-azure-acs.md` | 2023-11-13 | ACS app-only auth retired 2 April 2026 |
| Update listItem | `graph:api-reference/v1.0/api/listitem-update.md` | 2024-03-06 | PATCH …/fields, If-Match → 412, 200 + fieldValueSet |
| Get listItem | `graph:api-reference/v1.0/api/listitem-get.md` | 2024-03-06 | `?expand=fields(select=…)`; approval-status note |
| List items | `graph:api-reference/v1.0/api/listitem-list.md` | 2024-04-04 | `$filter` operators; one indexed field at a time |
| Create list | `graph:api-reference/v1.0/api/list-create.md` | 2024-04-04 | `genericList` default with Title column |
| List item versions | `graph:api-reference/v1.0/api/listitem-list-versions.md` | 2024-03-06 | Version history by API |
| Get site by path | `graph:api-reference/v1.0/api/site-getbypath.md` | 2024-03-14 | Resolve site ID from URL |
| listItem resource | `graph:api-reference/v1.0/resources/listitem.md` | 2024-10-09 | `eTag` property |
| fieldValueSet resource | `graph:api-reference/v1.0/resources/fieldvalueset.md` | 2017-09-11 | `<Field>LookupId` for lookup and person fields; 12 lookups per query |
| columnDefinition resource | `graph:api-reference/v1.0/resources/columndefinition.md` | 2024-08-01 | `name` vs `displayName`; `indexed`; `enforceUniqueValues` |
| personOrGroupColumn resource | `graph:api-reference/v1.0/resources/personorgroupcolumn.md` | 2017-09-11 | Person column settings |
| Permission tables | `graph:api-reference/v1.0/includes/permissions/listitem-update-permissions.md` (and `listitem-get-`, `listitem-list-`, `list-create-`) | (include) | Least-privileged scopes |
| Selected scopes | `graph:concepts/permissions-selected-overview.md` | 2024-11-07 | Sites.Selected, Lists.SelectedOperations.Selected, ListItems.SelectedOperations.Selected |

## 3. Sources cited but not re-read (VENDOR — VERIFY)

From the user's SharePoint procedural package, which records them as checked by its author on 2026-10-20. learn.microsoft.com and support.microsoft.com could not be reached from the environment that built this skill, so the steps drawn from them are labelled `VENDOR — VERIFY`.

| Priority | Subject | Publisher | URL |
|---|---|---|---|
| 1 | Lists overview, editing, views, item versioning | Microsoft Support | https://support.microsoft.com/en-us/sharepoint/lists/get-started-with-sharepoint/introduction-to-lists |
| 1 | Create a document library | Microsoft Support | https://support.microsoft.com/en-us/sharepoint/documents-and-library/create-a-document-library-in-sharepoint |
| 1 | Edit a document in a library | Microsoft Support | https://support.microsoft.com/en-us/sharepoint/libraries/edit-a-document-in-a-document-library |
| 1 | Modern site permissions and Microsoft 365 groups | Microsoft Learn | https://learn.microsoft.com/en-us/sharepoint/modern-experience-sharing-permissions |
| 1 | Customize site permissions, create SharePoint groups | Microsoft Learn | https://learn.microsoft.com/en-us/sharepoint/customize-sharepoint-site-permissions |
| 1 | Organization-level external sharing | Microsoft Learn | https://learn.microsoft.com/en-us/sharepoint/turn-external-sharing-on-or-off |
| 1 | Site-level external sharing | Microsoft Learn | https://learn.microsoft.com/en-us/sharepoint/change-external-sharing-site |
| 1 | Permission scopes and unique permissions | Microsoft Learn | https://learn.microsoft.com/en-us/sharepoint/manage-permission-scope |
| 2 | Connect to SharePoint Online PowerShell | Microsoft Learn | https://learn.microsoft.com/en-us/powershell/sharepoint/sharepoint-online/connect-sharepoint-online |
| 2 | SharePoint Online PowerShell reference | Microsoft Learn | https://learn.microsoft.com/en-us/powershell/sharepoint/sharepoint-online/ |
| 2 | Graph v1.0 listItem update (rendered page of the `graph:` file above) | Microsoft Learn | https://learn.microsoft.com/en-us/graph/api/listitem-update?view=graph-rest-1.0 |

Purview retention, event-based retention and disposition review pages are not in either list. Treat every Purview statement in `retention-schedule.md` as `VENDOR — VERIFY` until checked on Microsoft Learn.

## 4. Source hierarchy

For SharePoint questions, in order: the tenant's own configuration and policy (what the user shows you) > Microsoft Support for end-user UI > Microsoft Learn for administration, PowerShell and Purview > the GitHub doc repositories for developer and API detail > this skill's `PRACTICE` patterns > inference. When the tenant shows something different from the docs (a renamed button, a customized form), the tenant wins for "how do I do it here". Record the difference.

## 5. Refreshing the sources

**Git (works wherever github.com is reachable).** Shallow, sparse clones keep the download small:

```bash
git clone --depth 1 --filter=blob:none --sparse https://github.com/SharePoint/sp-dev-docs.git
git -C sp-dev-docs sparse-checkout set --no-cone /docs/business-apps/ /docs/declarative-customization/ /docs/apis/sharepoint-rest-graph.md /docs/general-development/how-to-avoid-getting-throttled-or-blocked-in-sharepoint-online.md
git clone --depth 1 --filter=blob:none --sparse https://github.com/microsoftgraph/microsoft-graph-docs-contrib.git
git -C microsoft-graph-docs-contrib sparse-checkout set --no-cone '/api-reference/v1.0/api/listitem-*' '/api-reference/v1.0/resources/listitem.md' '/api-reference/v1.0/includes/permissions/listitem-*' /concepts/permissions-selected-overview.md
```

Compare each file's `ms.date` with the table in section 2. If it changed, re-read the page and update the statements that cite it.

**Script (needs network access to the listed hosts).** `python3 scripts/collect_official_docs.py --list` shows the source allowlist; `python3 scripts/collect_official_docs.py --out <folder>` fetches each source, extracts text (HTML via `html.parser`, Markdown as-is), and writes `manifest.jsonl` with the HTTP status, the `ms.date` found, a SHA-256 and the fetch time. Run it where learn.microsoft.com and support.microsoft.com are allowed, to turn the section 3 rows into `DOC`. The snapshots are for your own checking and retrieval; don't republish them.
