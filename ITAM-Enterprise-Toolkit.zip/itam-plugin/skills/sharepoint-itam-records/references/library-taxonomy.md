# Site and library taxonomy

Design content is `PRACTICE` unless cited. SharePoint Online behavior is `VENDOR — VERIFY` against current Microsoft documentation and the tenant's settings. Organization values are `[FILL]`.

## Contents
1. Record classes
2. Site structure options
3. Library design
4. Content types
5. Folders: when and when not
6. File naming convention
7. Versioning and check-out
8. Permissions matrix
9. Migration from file shares or Teams

## 1. Record classes

CAMP's Documentation Management KPA covers purchase contracts, proofs of purchase, software licenses and certificates of authenticity, warranties, support and maintenance agreements, insurance documents, and disposal documentation, plus process documentation, discovery and physical inventory reports, and IMAC reports (CAMP M:43–44; CAMP S:97, S:101). Group them by class, because each class has its own retention trigger and audience.

| Class ID | Record class | Typical documents | Primary key | Retention trigger (event) | Audience |
|---|---|---|---|---|---|
| CON | Contracts and agreements | MSAs, order forms, SOWs, amendments, SLAs, NDAs with IT vendors | Contract ID | Contract end/termination [VERIFY with Legal] | Procurement, ITAM, Legal |
| FIN | Purchase and financial records | POs, invoices, proofs of purchase, payment confirmations, lease schedules | PO / invoice number | Fiscal year end or asset disposal [FILL] | Finance, ITAM |
| LIC | License and entitlement records | License certificates, entitlement statements, COAs, subscription confirmations, true-up records | Contract ID / entitlement ID | Entitlement end or product retirement [FILL] | SAM team |
| WAR | Warranty and support | Warranty certificates, support contracts, RMA records | Asset tag / contract ID | Warranty end or asset disposal [FILL] | ITAM, service desk |
| DIS | Disposition evidence | Certificates of data destruction/erasure, recycling certificates, transfer of ownership, ITAD manifests | Disposal order / batch ID (+ manifest of serials) | Disposal date [FILL] | ITAM, Security, Audit |
| INV | Inventory and audit evidence | Count sheets, reconciliation reports, audit responses, control test evidence | Count / audit ID | Audit closure [FILL] | ITAM, Audit |
| ACK | User acknowledgments | Device acceptance, acceptable use acknowledgments, return receipts | Asset tag + user | Asset return or employment end [VERIFY with HR/privacy] | ITAM (restricted) |
| GOV | ITAM governance | Policies, SOPs, standards, RACI, program reports | Document ID | Superseded date [FILL] | ITAM, broad read |

Adjust to the organization's records classification if one exists (it outranks this list).

## 2. Site structure options

| Option | When it fits | Watch-outs |
|---|---|---|
| One ITAM site, libraries per class | Most organizations; one team owns ITAM records | Restricted classes need library-level permissions |
| ITAM hub + a few associated sites (e.g., Contracts, Disposition evidence, SAM) | Distinct audiences or very large volumes; separate owners | More admin; navigation and search must be configured at the hub (`VENDOR — VERIFY` hub features). Joining a hub doesn't change any site's permissions (`DOC` `spdev:docs/features/hub-site/hub-site-overview.md`) |
| Records in an existing enterprise contract or records system, ITAM site links to them | The organization already has a contract or records management platform | Don't duplicate; link (SKILL rule 6) |

Communication site vs. team site: a team site (often Teams-connected) suits collaborative drafting; a communication or standalone site suits controlled records with narrow contributor groups. On a group-connected team site, membership also opens the group's other services, so auditors and read-only audiences are better served by SharePoint groups (`procedures-admin.md` §2). `VENDOR — VERIFY` current site template options. To build the same structure on several sites, use a site template and site script (`advanced-operations.md` §11).

## 3. Library design

One library per record class (section 1). Creation steps: `procedures-end-user.md` §6. For each library define:

| Setting | Value |
|---|---|
| Library name | [FILL — e.g., "Contracts", "Disposition Evidence"] |
| Content types allowed | From section 4 |
| Required columns | From `metadata-schema.md` |
| Default view | Grouped or filtered by a key column; never an unfiltered "all items" for large libraries |
| Versioning | Section 7 |
| Retention label (default or applied by rule) | From `retention-schedule.md` |
| Permissions | Section 8 |
| Sensitivity label (if used) | [FILL] |

**Disposition evidence library (DIS), extra rules (`PRACTICE`, from the procedural package):** metadata carries the request or disposal order ID, asset tag or batch ID, ITAD vendor, approval status and retention classification; edit rights are limited to the intake role (contribute without delete); versioning and the DIS retention label are on before the first upload. Never upload passwords, BitLocker or other recovery keys, or personal data the evidence doesn't need. Evidence rules for the certificates themselves belong to `itam-secure-disposition`.

## 4. Content types

Create content types centrally (content type gallery or hub; `VENDOR — VERIFY` current mechanism) so every site uses the same definitions. Content types from the content type hub are read-only in the consuming list by default, and custom list-form layouts are stored on the list content type, so plan form customization before publishing (`DOC` `spdev:docs/declarative-customization/list-form-configuration.md`).

| Content type | Parent | Class | Required columns (see `metadata-schema.md`) |
|---|---|---|---|
| ITAM Contract | Document | CON | ContractID, VendorName, ContractType, EffectiveDate, ExpiryDate, ContractOwner, ServiceNowLink |
| ITAM Contract Amendment | ITAM Contract | CON | + AmendmentNumber, ParentContractID |
| ITAM Purchase Record | Document | FIN | PONumber, VendorName, InvoiceNumber, DocumentDate |
| ITAM License Record | Document | LIC | ContractID or EntitlementID, Publisher, Product, Quantity [as stated on document], DocumentDate |
| ITAM Warranty Record | Document | WAR | AssetTag or ContractID, WarrantyEnd |
| ITAM Disposition Certificate | Document | DIS | DisposalBatchID, ITADVendor, CertificateDate, DeviceCount, ManifestAttached (Yes/No) |
| ITAM Inventory Evidence | Document | INV | CountID or AuditID, Site, CountDate |
| ITAM User Acknowledgment | Document | ACK | AssetTag, UserPrincipal (person column), AckType, AckDate |
| ITAM Governance Document | Document | GOV | DocumentID, DocumentOwner, Version, Status, NextReviewDate |

## 5. Folders: when and when not

- Default: no folders; use metadata and views.
- Acceptable: one level of folders for a natural, stable grouping that also carries different permissions or retention (avoid if possible), or for very large libraries where a flow files by year.
- Avoid: folders per vendor or per asset (they duplicate metadata and break when the vendor name changes).

## 6. File naming convention

Names help people; metadata drives the system. Recommended (RECOMMENDATION):
`<Class>_<PrimaryKey>_<ShortDescription>_<YYYY-MM-DD>.<ext>`
Examples: `CON_C-2026-0142_Dell-MSA-Amendment2_2026-03-01.pdf`, `DIS_DO-2026-0031_CoD-ITADVendor_2026-09-15.pdf`.
Avoid personal names, "final", "v2-new" and characters SharePoint or sync clients reject (`VENDOR — VERIFY` current list).

## 7. Versioning and check-out

- Major versions on for all libraries; minor (draft) versions for GOV where drafts are reviewed.
- Version count limits and automatic version trimming settings are `VENDOR — VERIFY`; set them knowing that retention can also preserve versions.
- Check-out required only for GOV documents under formal review, if at all.
- Signed or final evidence (CoDs, signed contracts) is uploaded as PDF and then protected by a record label if policy requires (see `retention-schedule.md`).

## 8. Permissions matrix

Use groups (Microsoft 365 or Entra security groups) mapped to SharePoint permission levels; avoid named users and item-level permissions. How-to and the Microsoft 365 group vs. SharePoint group distinction: `procedures-admin.md`. Breaking inheritance at library level is a change: inspect first, warn, and get approval (SKILL rule 7).

| Library | ITAM team | Procurement | Finance | Legal | Security | Service desk | Auditors (internal) | External (vendors, external auditors) |
|---|---|---|---|---|---|---|---|---|
| Contracts | Edit | Edit | Read | Edit | — | — | Read | None, or time-limited guest read [FILL] |
| Purchase records | Edit | Edit | Edit | — | — | — | Read | None |
| License records | Edit | Read | Read | Read | — | — | Read | Time-limited during a publisher audit [FILL] |
| Warranty and support | Edit | Read | — | — | — | Read | Read | None |
| Disposition evidence | Contribute (no delete) | — | Read | — | Read | — | Read | None |
| Inventory and audit evidence | Edit | — | Read | — | Read | — | Read | Time-limited [FILL] |
| User acknowledgments | Edit (restricted members) | — | — | Read | — | — | Read on request | None |
| Governance | Edit (owners) | Read | Read | Read | Read | Read | Read | None |

Permission levels and whether "contribute without delete" needs a custom level are `VENDOR — VERIFY`. Review membership [FILL frequency].

## 9. Migration from file shares or Teams

1. Inventory the source: locations, volumes, owners, file types, duplicates.
2. Classify each source folder to a record class; mark files with no class for owner review (don't migrate junk).
3. Map source folder names or file names to metadata where possible (vendor, contract ID); capture the rest at upload or in a review queue.
4. Preserve original created/modified dates and authors (`VENDOR — VERIFY` which migration tools preserve them).
5. Pilot one library; validate metadata, permissions and labels; then migrate in batches.
6. Set the source to read-only, then retire it on a date [FILL]; record the decision.
