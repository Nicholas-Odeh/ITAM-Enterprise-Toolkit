# Troubleshooting decision guide

Work top-down: identify the experience, then check the cheapest, read-only causes first. Make one minimal change at a time, then test it. Labels as in `source-index.md` §1. For a fault in a script or integration, also use the systematic method in `itam-automation-scripting`.

## Contents
1. Cannot edit a list item
2. User cannot open a site, library or document
3. No version history, or the old version is gone
4. A command or button is missing
5. Large lists: errors, slow views, empty results
6. A flow didn't run, or ran twice
7. Graph or REST call fails
8. Tracker and ITAM system disagree

## 1. Cannot edit a list item

1. Does the user have edit rights on this list or item? Check whether the item inherits permissions or has unique ones (`procedures-admin.md` §6).
2. Is the item constrained by required check-out, content approval, a retention or record label, or a flow that locks it? A record label can block edits (`retention-schedule.md` §4; `VENDOR — VERIFY` behavior).
3. Is the field missing from a customized form (Power Apps form or list form configuration) or from this content type? (`procedures-end-user.md` §9)
4. Right list? Trackers are often copied; confirm the site URL and list name.

Fix at the narrowest level. Don't ask for a site-owner or admin role when list-level edit rights are enough.

## 2. User cannot open a site, library or document

1. Site type: group-connected team site or communication site (`procedures-admin.md` §2).
2. Membership: Microsoft 365 group, SharePoint groups, direct grants.
3. Unique permissions on the library, folder or file; active sharing links and whether they expired.
4. Guests: organization and site external-sharing settings (`procedures-admin.md` §4), and whether the guest account is fully redeemed (`VENDOR — VERIFY`).
5. Test after each minimal correction with the user's own sign-in.

## 3. No version history, or the old version is gone

- List-item versioning and library versioning are separate settings. Check whether each is on and whether versions exist.
- If versioning was off when the change happened, the earlier value cannot be reconstructed from SharePoint. Say so; don't imply it can be restored. Look for the value elsewhere: an export, the authoritative ITAM record, or flow run history.
- Versions can be limited or trimmed by settings (`VENDOR — VERIFY`; Graph notes retention of versions depends on admin settings, `DOC` `graph:api-reference/v1.0/api/listitem-list-versions.md`).
- Never suggest turning versioning off to save space on an evidence library.

## 4. A command or button is missing

- Confirm the experience: SharePoint Online modern, classic, SharePoint Server, Microsoft Lists app, or a list opened in Teams. Commands differ (`VENDOR — VERIFY`).
- Permissions hide commands (no Edit, no New, no Share).
- Narrow windows collapse the command bar into a "…" menu.
- Tenant policy can remove an option, such as "anyone" links.
- Give the user the official page for the current path (`source-index.md`) instead of guessing a menu.

## 5. Large lists: errors, slow views, empty results

- Views and queries on big lists should filter first on an **indexed** column (`metadata-schema.md` §8). Graph filtering works best on indexed columns and filters only one indexed field at a time (`DOC` `graph:api-reference/v1.0/api/listitem-list.md`).
- Power Automate **Get items** returns 100 items by default; Top Count can go to 5,000. A filter query on a list over 5,000 items can return nothing if no match is in the first 5,000 unless **Pagination** is on (`DOC` `spdev:docs/business-apps/power-automate/guidance/working-with-get-items-and-get-files.md`).
- Get items / Get files fail on lists with more than 12 lookup columns (`DOC` `spdev:docs/business-apps/power-automate/sharepoint-connector-actions-triggers.md`).
- Don't promise that a filter removes the list view threshold. Redesign the view or the list.

## 6. A flow didn't run, or ran twice

- SharePoint triggers poll for changes. A run usually starts within minutes, and one run may batch several changes (`DOC` connector page, "Flow runs").
- Moving or syncing files between libraries keeps their metadata and **doesn't** fire created/modified triggers in the destination (`DOC` same page).
- Flows for lists are supported on generic lists and document libraries only. Custom list templates aren't supported (`DOC` same page).
- "When an item is created or modified" fires on every edit, including the flow's own updates. Guard with a status column so the flow doesn't loop or run twice (`flow-patterns.md` §1, idempotency).
- Check the run history, the connection owner (left the company?), and DLP policy changes (`VENDOR — VERIFY`).

## 7. Graph or REST call fails

| Symptom | Likely cause | Safe next step |
|---|---|---|
| 401 / 403 | Token lacks the scope, or a Selected scope has no grant on this site/list/item | Check the scopes in the token and the Selected grant (`advanced-operations.md` §3); don't jump to a broader scope |
| 404 on site or list | Wrong site path or ID | Resolve by path, then list ID (`advanced-operations.md` §4) |
| 400 on PATCH | Body uses a display name instead of the column's internal `name`, or a wrong type for a Person/lookup field | Read `/columns`; for Person use the LookupId pattern (`advanced-operations.md` §6, `VENDOR — VERIFY`) |
| 412 Precondition Failed | ETag changed since you read the item | Re-read and show the difference; ask before retrying (`DOC` listitem-update) |
| 429 / 503 with Retry-After | Throttled | Wait at least Retry-After; slow down; decorate User-Agent (`advanced-operations.md` §8) |
| Items missing from results | Content approval is on and the app lacks Sites.Manage.All; or paging not followed | `DOC` listitem-get note; follow `@odata.nextLink` |
| App stopped working in April 2026 | Built on SharePoint Add-ins or Azure ACS, which were retired on 2 April 2026 | Re-platform to an Entra ID app and Graph (`advanced-operations.md` §11) |

## 8. Tracker and ITAM system disagree

1. Name the authoritative system for the disputed field (assignment, status, location) from the data ownership agreed in `metadata-schema.md` §7. If none is agreed, say so; that gap is the finding.
2. Check whether an integration or sync actually exists and when it last ran successfully. Don't assume one does.
3. Compare on unique keys (Asset Tag, then Serial Number). Check for duplicates and blanks first.
4. Correct the authoritative system through its own change process. Then update or re-sync the tracker. Never silently edit both by hand.
5. Record the discrepancy and the fix. For a full count-vs-record reconciliation, use `itam-inventory-reconciliation`.
