# Power Automate flow patterns

Patterns are `PRACTICE`. Connector tiers (standard vs. premium), throttling and licensing are `VENDOR — VERIFY` against current Microsoft documentation and the tenant's Power Platform licensing and DLP policies. SharePoint trigger and action behavior that was checked against Microsoft's developer docs is in section 10 (`DOC`). For production integration code (Graph API, ServiceNow REST scripts), hand off to `itam-automation-scripting`; for ServiceNow-side configuration, `servicenow-itam`.

## Contents
1. Controls every flow needs
2. Pattern A: certificate-of-destruction intake
3. Pattern B: contract renewal and notice reminders
4. Pattern C: warranty expiry alerts
5. Pattern D: audit evidence request
6. Pattern E: evidence pack assembly
7. Pattern F: ServiceNow link-back
8. Pattern G: metadata quality sweep
9. Design template
10. SharePoint connector facts (DOC)

## 1. Controls every flow needs

| Control | Standard |
|---|---|
| Owner | A service account or shared ownership by the ITAM team, not one person's account [FILL — owner group]; co-owners named |
| Connections | Least privilege; the account reaches only the sites/tables the flow needs |
| Connector classification | Confirm the connectors are allowed together under the tenant's DLP policy; flag premium connectors (`VENDOR — VERIFY`) |
| Idempotency | Re-running on the same item must not duplicate records, emails or ServiceNow updates (check a status column first). A "created or modified" trigger also fires when the flow updates the item itself, so guard against loops |
| Error handling | A failure branch (configure run-after on failure/timeout) that notifies the owner group and writes the error to a log list |
| Monitoring | Weekly review of run history or failure alerts [FILL]; owner named |
| Change control | Export/solution-based deployment from test to production where available [VERIFY]; changes logged |
| Data minimization | Emails carry links, not attachments of contracts or personal data |
| Writes to ServiceNow | Dry run on a test instance; scoped; approval before go-live (`servicenow-itam` read-only default) |

## 2. Pattern A: certificate-of-destruction intake

Goal: every certificate arrives in one place, is validated against the disposal batch, and is linked to the records.

| Step | Action |
|---|---|
| Trigger | File created in the Disposition Evidence library (or arrives at a monitored mailbox [FILL]) |
| 1 | Check required columns: DisposalBatchID, ITADVendor, CertificateDate, DeviceCount; if missing, set EvidenceStatus = Received, ask the uploader to complete, stop |
| 2 | Find the serial manifest with the same DisposalBatchID; if none, notify and stop |
| 3 | Compare manifest row count with DeviceCount; where integrated, compare with the disposal order line count in ServiceNow |
| 4 | Mismatch → EvidenceStatus = Rejected; log the discrepancy; notify ITAM and the ITAD vendor manager |
| 5 | Match → EvidenceStatus = Validated pending review; assign a reviewer |
| 6 | Reviewer approves → apply the DIS label if not default; optionally write the link to the disposal order (Pattern F) |
| Evidence | Intake log entry; reviewer; date |

Serial-by-serial matching and certificate content rules belong to `itam-inventory-reconciliation` and `itam-secure-disposition`; the flow only gates and routes.

## 3. Pattern B: contract renewal and notice reminders

| Step | Action |
|---|---|
| Trigger | Scheduled (recurrence), daily or weekly [FILL] |
| 1 | Query the renewal calendar list (or the Contracts library) for NoticeDate or ExpiryDate within the reminder windows [FILL — e.g., three windows set by Procurement] |
| 2 | For each, skip if a reminder for this window was already sent (status column) |
| 3 | Notify ContractOwner (and backup) with a link to the contract record and the decision field; never compute a notice date from assumptions; the date comes from the contract (`itam-vendor-contract-management`) |
| 4 | If RenewalDecision is still Undecided at the final window, escalate to [FILL role] |
| Evidence | Reminder log per contract and window |

## 4. Pattern C: warranty expiry alerts

Prefer reporting from the ITAM system of record where warranty dates live. Use a flow only if warranty documents in SharePoint carry WarrantyEnd and no other alert exists.
Trigger: scheduled → filter WarrantyEnd within [FILL] days → summary to the hardware lifecycle owner (one digest, not one email per device) → link to filtered view. Refresh decisions belong to `itam-hardware-lifecycle`.

## 5. Pattern D: audit evidence request

| Step | Action |
|---|---|
| Trigger | Item created in the Evidence request log list |
| 1 | Assign Owner by request type [FILL mapping]; set DueDate per audit plan |
| 2 | Notify owner with the request text and upload location (library + required key, e.g., AuditID) |
| 3 | When a document with that AuditID is uploaded, set Status = Provided, record DateProvided |
| 4 | Reminders before DueDate; escalation after |
| Evidence | Request log (who asked, what, when provided); `itam-risk-controls-audit` uses this for audit readiness |

## 6. Pattern E: evidence pack assembly

Goal: "give me everything for contract C-123" or "for disposal batch DO-31" in minutes.
Trigger: manual (button/instant flow) with the key as input → search libraries for the key column value → build an index (file name, class, date, link) in a list item or a generated summary file → share the index link with the requester's existing permissions (don't widen access to assemble a pack). For external auditors, copy into a time-limited audit library with its own permissions [FILL], and log what was shared.

## 7. Pattern F: ServiceNow link-back

Goal: ServiceNow users can open the SharePoint evidence from the asset, contract or disposal record (pattern C in `metadata-schema.md` §3).

| Step | Action |
|---|---|
| Trigger | EvidenceStatus changes to Validated (or document created with a key) |
| 1 | Look up the ServiceNow record by key (asset tag, contract number, disposal order) through the ServiceNow connector or REST (`VENDOR — VERIFY` connector tier and authentication options) |
| 2 | Exactly one match → write the document or view URL to the agreed field or related list; zero or many → log and notify, don't guess |
| 3 | Record the ServiceNowNumber/link back on the SharePoint item |
| Controls | Integration account with write access only to the agreed field; tested on sub-production; approval before go-live; failure branch |

## 8. Pattern G: metadata quality sweep

Scheduled → find items in each library missing required keys or with invalid formats → digest to library owners → track count over time as a documentation completeness metric (CAMP S:100: percentage of documents linkable to their asset).

## 9. Design template

| Field | Value |
|---|---|
| Flow name | ITAM-<Pattern>-<Scope> |
| Purpose | — |
| Trigger | — |
| Inputs / keys | — |
| Steps | — |
| Writes to | Lists, libraries, ServiceNow fields |
| Owner / co-owners | — |
| Connectors and tier | — (`VENDOR — VERIFY`) |
| Error handling and alerting | — |
| Evidence produced | — |
| Test cases | Happy path, missing key, duplicate run, ServiceNow no-match, connector failure |
| Approval and go-live date | — |

## 10. SharePoint connector facts (DOC)

From `spdev:docs/business-apps/power-automate/sharepoint-connector-actions-triggers.md` and `…/guidance/working-with-get-items-and-get-files.md` (read 2026-10-20; see `source-index.md`):

| Fact | Design consequence |
|---|---|
| Item and file triggers poll the list or library; a run usually starts within minutes and may batch several changes | Don't promise real-time; for near-real-time integration consider list webhooks (`advanced-operations.md` §10) |
| Moving or syncing files into a library keeps their metadata and doesn't fire created/modified triggers there | Pattern A must not rely on a move into Disposition Evidence; upload or set a status column instead |
| List flows are supported on generic lists and document libraries only, not custom list templates | Build trackers from blank lists |
| **Get items** returns 100 items by default, up to 5,000 with Top Count; with a filter on a list over 5,000 items, turn on pagination or the result can be empty | Reminder and sweep patterns (B, C, G) set Top Count, pagination and an indexed filter |
| Get items / Get files fail on lists with more than 12 lookup columns | Keep tracker lists lean |
| "When an item is deleted" needs a site collection admin connection to read the deleted item's properties | Avoid delete-triggered evidence logic; prefer a status column |
| **Send an HTTP request to SharePoint** can run any SharePoint REST call the connection can reach | Treat it as a privileged write path: approval, least-privilege connection |
| Grant access, sharing-link and stop-sharing actions change item permissions; stop sharing removes all permissions except site owners | Avoid in ITAM flows unless approved (`procedures-admin.md` §8) |
