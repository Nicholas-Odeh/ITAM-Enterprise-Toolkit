# Advanced operations: PowerShell, Microsoft Graph, REST, SPFx

For administrators and developers who need more than the UI. Labels as in `source-index.md` §1. Production scripts and integrations go to `itam-automation-scripting` for code standards and tests; this file gives the SharePoint-specific facts and the safe sequence. Never put tokens, secrets or passwords in chat, files or examples (CONNECTORS.md rule 3).

## Contents
1. Escalation order
2. SharePoint Online Management Shell
3. Microsoft Graph: permissions
4. Graph: read before you write
5. Graph: update a list item safely (If-Match / ETag)
6. Person and lookup columns
7. Bulk changes: dry run, cap, rollback
8. Throttling and traffic decoration
9. SharePoint REST (_api) and Power Automate HTTP
10. Change notifications: webhooks
11. Customization: formatting, SPFx, site templates; retired add-ins

## 1. Escalation order

Use the lowest rung that does the job (`PRACTICE`, adapted from the procedural package):
1. Supported SharePoint UI (`procedures-end-user.md`).
2. Approved admin-center configuration (`procedures-admin.md`).
3. Power Automate, where approved and the connectors are allowed by DLP (`flow-patterns.md`).
4. Read-only PowerShell or Graph inspection.
5. Reviewed, approved writes through Graph v1.0 or supported PowerShell (§5, §7).
6. Developer extensions (SPFx, webhooks) with lifecycle and security review (§10, §11).

Prefer Graph **v1.0** over beta for anything in production.

## 2. SharePoint Online Management Shell

For tenant and site administration (sites, sharing settings, storage), not as a substitute for editing list items. Cmdlet names and parameters below come from the package and are `VENDOR — VERIFY` against https://learn.microsoft.com/en-us/powershell/sharepoint/sharepoint-online/connect-sharepoint-online.

```powershell
# Install for the current user only if your organization allows it
Install-Module -Name Microsoft.Online.SharePoint.PowerShell -Scope CurrentUser
# Connect interactively as an administrator; replace TENANT
Connect-SPOService -Url https://TENANT-admin.sharepoint.com
# Read-only first
Get-SPOSite -Limit 10
```

Run `Get-` cmdlets and save the output before any `Set-` cmdlet; that output is your rollback reference. Any `Set-SPOSite` or tenant setting change follows `procedures-admin.md` §1.

## 3. Microsoft Graph: permissions

Least-privileged scopes from the Graph permission tables (`DOC` `graph:api-reference/v1.0/includes/permissions/*.md`, read 2026-10-20):

| Operation | Endpoint | Least privileged (delegated and application) |
|---|---|---|
| Get item / list items | `GET /sites/{site-id}/lists/{list-id}/items[/{item-id}]` | Sites.Read.All |
| Create item | `POST …/items` | Sites.ReadWrite.All |
| Update item fields | `PATCH …/items/{item-id}/fields` | Sites.ReadWrite.All |
| Create list | `POST /sites/{site-id}/lists` | Sites.Manage.All |

Narrower alternative: `Sites.Selected`, `Lists.SelectedOperations.Selected` or `ListItems.SelectedOperations.Selected`. A consented Selected scope grants nothing until a permission is also assigned on the specific site, list or item, and the token must carry the scope. All three steps are needed (`DOC` `graph:concepts/permissions-selected-overview.md`, ms.date 2024-11-07). For an ITAM integration that touches one tracker list, ask whether the list-level Selected scope fits before requesting Sites.ReadWrite.All (`PRACTICE`).

When content approval is on, application callers need Sites.Manage.All to read items whose approval status isn't Approved; otherwise those items aren't returned (`DOC` `graph:api-reference/v1.0/api/listitem-get.md`).

## 4. Graph: read before you write

1. **Site ID from URL:** `GET /sites/{hostname}:/{server-relative-path}` (`DOC` `graph:…/api/site-getbypath.md`).
2. **List ID:** list the site's lists and match on display name, then store the ID; display names can change.
3. **Internal column names:** `GET /sites/{site-id}/lists/{list-id}/columns`. Use each column's `name` (API-facing) in `fields`, not its `displayName` (`DOC` `graph:…/resources/columndefinition.md`). "Assigned To" in the UI might be `AssignedTo`, `Assigned_x0020_To` or something else. Read it; never guess.
4. **Find the item by key:** `GET …/items?expand=fields(select=Title,AssetTag,AssignedTo)&$filter=fields/AssetTag eq 'TAG-123'`. Filtering supports `eq, ne, lt, gt, le, ge, startswith`, works best on indexed columns, and can use only one indexed field at a time; results may be paged (`DOC` `graph:…/api/listitem-list.md`). Column names here are examples [FILL].
5. **Capture the item's `eTag`** from the item (not the fields); it is a read-only property of the listItem (`DOC` `graph:…/resources/listitem.md`).

## 5. Graph: update a list item safely (If-Match / ETag)

```http
PATCH https://graph.microsoft.com/v1.0/sites/{site-id}/lists/{list-id}/items/{item-id}/fields
Authorization: Bearer {token}
Content-Type: application/json
If-Match: {etag from step 4.5}

{ "AssetStatus": "In stock" }
```

Per `DOC` `graph:api-reference/v1.0/api/listitem-update.md` (ms.date 2024-03-06): only the fields in the body change; on success the response is `200` with the item's fieldValueSet; if the ETag no longer matches, the call returns **`412 Precondition Failed`** and nothing is updated. `AssetStatus` is an example name [FILL].

- On **412**: re-read the item, show the user what changed since the plan was made, and ask before retrying. Don't drop If-Match to force the write (`PRACTICE`).
- After **200**: compare the returned values with what you intended, then re-read the item. Only then report the change, and only as "SharePoint item updated". The authoritative ITAM record is a separate change (SKILL rule 6).

## 6. Person and lookup columns

- **Reading:** lookup-type fields (Person columns included) come back as `<FieldName>LookupId` by default. To get the display value, name the field in `expand=fields(select=…)`. At most 12 lookup fields per query (`DOC` `graph:…/resources/fieldvalueset.md`).
- **Writing a Person column:** commonly done by setting `<FieldName>LookupId` to the person's ID in that site's user list, not their email or Entra object ID. Multi-value fields need a typed collection. This is not stated in the pages read for this skill: `VENDOR — VERIFY` before use, and test on one item in a test list first.
- Never send a display name and assume it resolves.

## 7. Bulk changes: dry run, cap, rollback

A bulk update of tracker items is a write under core rule 4 (`PRACTICE`):
1. **Before-image:** export every in-scope item with `id`, `eTag` and the fields to change.
2. **Plan file:** one row per item with old value → new value, and the reason or request ID. Show counts and a sample; get approval.
3. **Cap and pilot:** run the first N items [FILL, for example 10], verify, then continue in batches.
4. **Per item:** PATCH with If-Match; log status (200, 412, other). Skip and report 412s; don't retry blindly.
5. **Rollback:** re-PATCH from the before-image using each item's current eTag.
6. **Report:** counts updated, skipped and failed, with the log location. Report counts only from the log.

## 8. Throttling and traffic decoration

From `DOC` `spdev:docs/general-development/how-to-avoid-getting-throttled-or-blocked-in-sharepoint-online.md` (ms.date 2025-10-02):
- Throttled calls (Graph, CSOM or REST) get **429** (too many requests) or **503** (server too busy), with a **`Retry-After`** header. Wait at least that long. Throttled calls still count against limits, so aggressive retries make it worse. Persistent abuse can lead to the app being blocked.
- SharePoint Online doesn't support IETF `RateLimit` headers; rely on `Retry-After`.
- Decorate traffic: register the app (AppID/AppTitle) and send a User-Agent such as `NONISV|CompanyName|AppName/Version` for enterprise apps. Decorated traffic is prioritized.

## 9. SharePoint REST (_api) and Power Automate HTTP

- For SharePoint Online, Microsoft directs new REST work to Graph; `/_api/v2.0/...` mirrors the Graph sites, lists and drives endpoints (`DOC` `spdev:docs/apis/sharepoint-rest-graph.md`).
- The legacy REST API also uses ETags: MERGE or DELETE with `If-Match: "{etag or *}"` (`DOC` `spdev:docs/sp-add-ins/working-with-lists-and-list-items-with-rest.md`). `*` skips the concurrency check. Don't use it for ITAM records (`PRACTICE`).
- Power Automate's **Send an HTTP request to SharePoint** action runs any SharePoint REST call the connection has access to, and Microsoft's page itself warns to use it with caution. It covers SharePoint REST only, not other services (`DOC` `spdev:docs/business-apps/power-automate/sharepoint-connector-actions-triggers.md`; `…/guidance/working-with-send-sp-http-request.md`, ms.date 2023-01-27). The same ETag discipline applies, and it counts as a write path for approval purposes.

## 10. Change notifications: webhooks

List webhooks notify an application of item changes in a list or library without polling. Subscriptions are managed at `/_api/web/lists('{list-guid}')/subscriptions` (`DOC` `spdev:docs/apis/webhooks/lists/overview-sharepoint-list-webhooks.md`). Use them when a downstream system (for example `~~ITSM`) must react to tracker changes faster than a scheduled sync. They need an always-on endpoint and an owner.

## 11. Customization: formatting, SPFx, site templates; retired add-ins

- **Column, view and form formatting** (JSON, display only): `procedures-end-user.md` §9.
- **Site templates and site scripts** apply a repeatable set of lists, columns and settings to new sites. Use them to stamp out an ITAM records site consistently (`DOC` `spdev:docs/declarative-customization/site-design-overview.md`; actions and limits `VENDOR — VERIFY`).
- **SharePoint Framework (SPFx)** is the supported model for custom web parts and extensions (`DOC` `spdev:docs/spfx/sharepoint-framework-overview.md`). It needs a developer, a tenant app catalog, and a lifecycle owner.
- **SharePoint Add-ins and Azure ACS** stopped working for all SharePoint Online tenants on **2 April 2026** (`DOC` `spdev:docs/sp-add-ins/retirement-announcement-for-add-ins.md`; `…/retirement-announcement-for-azure-acs.md`). Don't recommend them. Replace with SPFx, or with an Entra ID-registered app calling Graph.
- **Retention labels by code:** the CSOM method `SetComplianceTagOnBulkItems` applies a retention label to many items, and the page says labels applied this way needn't be published to the location by a label policy (`DOC` `spdev:docs/apis/csom-methods-for-applying-retention-labels.md`, ms.date 2024-09-30). Labelling is a records change: `retention-schedule.md` §8 change control applies.
