# Administrative procedures: membership, groups, sharing, permission scopes

For site owners and SharePoint administrators. Labels as in `source-index.md` §1. Every access change here follows SKILL rule 7 and core rule 4: inspect read-only first, state the scope, have a rollback, and get approval. Answer in the template in `procedures-end-user.md` §1.

## Contents
1. Before any permission change
2. Microsoft 365 group vs. SharePoint group
3. Add or remove site members
4. External sharing: organization vs. site
5. Create a SharePoint group
6. Breaking inheritance and permission scopes
7. Hub sites and permissions
8. Permissions set by flows or apps
9. ITAM permission design

## 1. Before any permission change

Read-only inspection, in order (`PRACTICE`):
1. **Site type:** Microsoft 365 group-connected team site, team site without a group, or communication site. The site's settings or the admin center show this (`VENDOR — VERIFY` where).
2. **Who has access now:** group memberships, SharePoint groups, direct grants, and active sharing links on the item, folder or library.
3. **Inheritance:** is the target inheriting from its parent, or does it already have unique permissions?
4. **Policy:** organization and site external-sharing settings; sensitivity labels on the site [FILL].
5. **Change record:** what changes, for whom, how to roll it back, and who approved it.

## 2. Microsoft 365 group vs. SharePoint group

| Question | Microsoft 365 group (group-connected team site) | SharePoint group (any site) |
|---|---|---|
| What membership grants | Owners and members of the group get the matching site access and also the group's other services, such as the shared mailbox, calendar, Planner and Teams if connected (`VENDOR — VERIFY` per tenant) | Only the SharePoint permission level the group holds on that site |
| Where you manage it | Group membership (site membership panel, Teams, or Entra/admin centers) | Site permissions > advanced permissions settings |
| Typical use | Collaborating team that owns the site | Read-only audiences, contributors without team access, auditors |
| ITAM caution | Adding an auditor as a group member also gives them the team's conversations and files | Prefer this for narrow, read-only ITAM audiences |

Owners, Members and Visitors don't mean exactly the same thing on every site type (`VENDOR — VERIFY` https://learn.microsoft.com/en-us/sharepoint/modern-experience-sharing-permissions). Ask which site type it is before you answer.

## 3. Add or remove site members

**Applies to:** SharePoint Online. **Prerequisites:** site owner (or SharePoint admin).
1. Open the site; select **Settings > Site permissions** (`VENDOR — VERIFY`).
2. Confirm whether the site is group-connected (§1).
3. Group-connected team site: add the person to the Microsoft 365 group as a member or owner. Communication site: add them to the right SharePoint group (Visitors, Members, Owners).
4. Grant the least access that does the job; prefer a security group over named individuals for standing audiences.
5. **Verify** with the user's own sign-in or the site's check-permissions feature (`VENDOR — VERIFY`); record the change.

**If it does not work:** the user still sees "access denied" (unique permissions lower down, §6; a cached session; a sharing policy for guests, §4). **Sources:** `VENDOR — VERIFY` https://learn.microsoft.com/en-us/sharepoint/modern-experience-sharing-permissions ; https://learn.microsoft.com/en-us/sharepoint/customize-sharepoint-site-permissions.

## 4. External sharing: organization vs. site

**Prerequisites:** SharePoint Administrator. Site owners can't change the admin-center site sharing setting (`VENDOR — VERIFY`).
1. Find the organization's external-sharing policy and the data classification of the site [FILL].
2. In the SharePoint admin center, check the organization-level setting first. A site can be as restrictive as you like but never more permissive than the organization allows (`VENDOR — VERIFY`).
3. Open the site's sharing setting and pick the most restrictive option that meets the need.
4. Save; test with a guest account if one exists; record the change and its approval.

**Warn before:** turning on "anyone" links, or widening a site that holds contracts, pricing, certificates or personal data. **Sources:** `VENDOR — VERIFY` https://learn.microsoft.com/en-us/sharepoint/turn-external-sharing-on-or-off ; https://learn.microsoft.com/en-us/sharepoint/change-external-sharing-site.

## 5. Create a SharePoint group

Use an existing Microsoft 365 group or the built-in SharePoint groups first. Create a new group only for a standing audience the built-in groups don't fit (for example "ITAM Evidence Readers").
1. **Settings > Site permissions > Advanced permissions settings** (`VENDOR — VERIFY`).
2. **Create Group**; set name, description, owner, membership visibility and the permission level.
3. Add members (a security group where possible); **verify** with a test account.

**Source:** `VENDOR — VERIFY` https://learn.microsoft.com/en-us/sharepoint/customize-sharepoint-site-permissions.

## 6. Breaking inheritance and permission scopes

Decision support, not a default procedure. Every list, folder, file or item with unique permissions creates a separate permission scope. Many scopes are hard to audit and can slow the list (`VENDOR — VERIFY` limits at https://learn.microsoft.com/en-us/sharepoint/manage-permission-scope).

Before breaking inheritance, answer:
- Can a separate library (or site) with its own groups do this instead? For ITAM record classes it usually can (`library-taxonomy.md` §8).
- How many unique scopes will this create now and over time? Item-level grants added by a flow grow with every item.
- Who reviews them, and how often [FILL]?
- What is the rollback? Restoring inheritance discards the unique permissions on that object (`VENDOR — VERIFY`).

If the answer is still yes, warn the user, get approval, and check the current Microsoft article for the clicks before you act.

## 7. Hub sites and permissions

Associating a site with a hub doesn't change the permissions of the hub or the associated site. People who may associate sites to the hub need permission to the hub site (`DOC` `spdev:docs/features/hub-site/hub-site-overview.md`). Hub navigation and search can surface titles of content users can already open. They don't grant access.

## 8. Permissions set by flows or apps

- The Power Automate SharePoint actions **Grant access to an item or a folder**, **Create sharing link for a file or folder** and **Stop sharing an item or a file** change item-level permissions. Per `DOC` `spdev:docs/business-apps/power-automate/guidance/manage-list-item-file-permissions.md` (ms.date 2022-12-01): the grant action maps roles to the standard Members and Visitors groups (custom roles by `role:<id>`) and doesn't support external users; the sharing-link action works only on library files and folders and can create "anyone" links; **Stop sharing removes all permissions on the item except site owners**. Assume each grant gives the item unique permissions (§6; `VENDOR — VERIFY`), and warn before any flow uses these actions.
- Apps that read or write lists through Microsoft Graph should use the narrowest scope. `Sites.Selected`, `Lists.SelectedOperations.Selected` and `ListItems.SelectedOperations.Selected` give no access until a permission is also granted on the specific site, list or item (`DOC` `graph:concepts/permissions-selected-overview.md`). Details: `advanced-operations.md` §3.
- SharePoint Add-ins and Azure ACS app-only access stopped working in all SharePoint Online tenants on 2 April 2026 (`DOC` `spdev:docs/sp-add-ins/retirement-announcement-for-add-ins.md`, `spdev:docs/sp-add-ins/retirement-announcement-for-azure-acs.md`). An old ITAM integration that still uses them needs migration to Entra ID app registration.

## 9. ITAM permission design

The library-by-class permissions matrix is in `library-taxonomy.md` §8. In short (`PRACTICE`): inherit at site level, break inheritance at library level only, grant to groups, keep contracts, pricing and acknowledgments restricted, and give auditors time-limited, read-only access. Review membership on a set cycle [FILL].
