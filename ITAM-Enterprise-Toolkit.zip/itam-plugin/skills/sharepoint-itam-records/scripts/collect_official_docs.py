#!/usr/bin/env python3
"""Snapshot the official SharePoint / Microsoft Graph sources this skill cites.

NEEDS NETWORK ACCESS to the hosts in SOURCES (learn.microsoft.com,
support.microsoft.com, raw.githubusercontent.com). Python 3 standard library
only (urllib + html.parser); no packages to install. Honors HTTPS_PROXY and
SSL_CERT_FILE through the standard library.

Purpose: check whether a cited page changed since the skill's "as checked"
date (see references/source-index.md), and keep local text extracts for your
own reading. It is a fixed allowlist, not a crawler. Snapshots are Microsoft
content: don't republish them; the skill summarizes sources in its own words.

Usage:
  python3 scripts/collect_official_docs.py --list
  python3 scripts/collect_official_docs.py --out ./sp-doc-snapshots
  python3 scripts/collect_official_docs.py --out ./snap --only graph-listitem-update,spo-throttling

Output: one <id>.txt per source and manifest.jsonl with id, url, status,
http_status, ms_date (page date stamp if found), sha256, characters,
fetched_at (UTC) and error. Compare ms_date and sha256 between runs.
Write the output outside the plugin folder.
"""
import argparse
import hashlib
import json
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path

RAW_SP = "https://raw.githubusercontent.com/SharePoint/sp-dev-docs/main/"
RAW_GRAPH = "https://raw.githubusercontent.com/microsoftgraph/microsoft-graph-docs-contrib/main/"

# (id, url, kind) -- kind "html" for rendered pages, "md" for raw Markdown.
SOURCES = [
    ("lists-overview", "https://support.microsoft.com/en-us/sharepoint/lists/get-started-with-sharepoint/introduction-to-lists", "html"),
    ("create-library", "https://support.microsoft.com/en-us/sharepoint/documents-and-library/create-a-document-library-in-sharepoint", "html"),
    ("edit-library-file", "https://support.microsoft.com/en-us/sharepoint/libraries/edit-a-document-in-a-document-library", "html"),
    ("modern-permissions", "https://learn.microsoft.com/en-us/sharepoint/modern-experience-sharing-permissions", "html"),
    ("customize-permissions", "https://learn.microsoft.com/en-us/sharepoint/customize-sharepoint-site-permissions", "html"),
    ("external-sharing-org", "https://learn.microsoft.com/en-us/sharepoint/turn-external-sharing-on-or-off", "html"),
    ("external-sharing-site", "https://learn.microsoft.com/en-us/sharepoint/change-external-sharing-site", "html"),
    ("permission-scopes", "https://learn.microsoft.com/en-us/sharepoint/manage-permission-scope", "html"),
    ("spo-powershell-connect", "https://learn.microsoft.com/en-us/powershell/sharepoint/sharepoint-online/connect-sharepoint-online", "html"),
    ("spdev-create-list", RAW_SP + "docs/business-apps/get-started/set-up-sharepoint-site-lists-libraries.md", "md"),
    ("spdev-connector", RAW_SP + "docs/business-apps/power-automate/sharepoint-connector-actions-triggers.md", "md"),
    ("spdev-get-items", RAW_SP + "docs/business-apps/power-automate/guidance/working-with-get-items-and-get-files.md", "md"),
    ("spdev-flow-permissions", RAW_SP + "docs/business-apps/power-automate/guidance/manage-list-item-file-permissions.md", "md"),
    ("spdev-column-formatting", RAW_SP + "docs/declarative-customization/column-formatting.md", "md"),
    ("spdev-list-form", RAW_SP + "docs/declarative-customization/list-form-configuration.md", "md"),
    ("spdev-hub-sites", RAW_SP + "docs/features/hub-site/hub-site-overview.md", "md"),
    ("spdev-retention-csom", RAW_SP + "docs/apis/csom-methods-for-applying-retention-labels.md", "md"),
    ("spo-throttling", RAW_SP + "docs/general-development/how-to-avoid-getting-throttled-or-blocked-in-sharepoint-online.md", "md"),
    ("spdev-addin-retirement", RAW_SP + "docs/sp-add-ins/retirement-announcement-for-add-ins.md", "md"),
    ("graph-listitem-update", RAW_GRAPH + "api-reference/v1.0/api/listitem-update.md", "md"),
    ("graph-listitem-get", RAW_GRAPH + "api-reference/v1.0/api/listitem-get.md", "md"),
    ("graph-listitem-list", RAW_GRAPH + "api-reference/v1.0/api/listitem-list.md", "md"),
    ("graph-fieldvalueset", RAW_GRAPH + "api-reference/v1.0/resources/fieldvalueset.md", "md"),
    ("graph-columndefinition", RAW_GRAPH + "api-reference/v1.0/resources/columndefinition.md", "md"),
    ("graph-selected-scopes", RAW_GRAPH + "concepts/permissions-selected-overview.md", "md"),
]

SKIP_TAGS = {"script", "style", "nav", "header", "footer", "aside", "noscript", "svg"}
VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "source", "track", "wbr"}
BLOCK_TAGS = {"p", "div", "li", "tr", "br", "h1", "h2", "h3", "h4", "h5", "h6", "pre", "section", "article", "table"}


class TextExtractor(HTMLParser):
    """Collect visible text, preferring the <main> element; read meta ms.date."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.main_depth = 0
        self.main_parts, self.all_parts = [], []
        self.ms_date = None

    def handle_starttag(self, tag, attrs):
        if tag == "meta":
            a = dict(attrs)
            if (a.get("name") or "").lower() == "ms.date" and a.get("content"):
                self.ms_date = a["content"]
            return
        if tag in BLOCK_TAGS:
            self._add("\n")
        if tag in VOID_TAGS:
            return
        if tag in SKIP_TAGS:
            self.skip += 1
        if tag == "main" or self.main_depth:
            self.main_depth += 1

    def handle_endtag(self, tag):
        if tag in VOID_TAGS or tag == "meta":
            return  # no matching start was counted (also covers <br/> etc.)
        if tag in SKIP_TAGS and self.skip:
            self.skip -= 1
        if self.main_depth:
            self.main_depth -= 1
        if tag in BLOCK_TAGS:
            self._add("\n")

    def handle_data(self, data):
        if not self.skip and data.strip():
            self._add(data.strip() + " ")

    def _add(self, text):
        self.all_parts.append(text)
        if self.main_depth:
            self.main_parts.append(text)

    def text(self):
        raw = "".join(self.main_parts) or "".join(self.all_parts)
        lines = [ln.strip() for ln in raw.splitlines()]
        return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()


def md_date(text):
    m = re.search(r"^ms\.date:\s*['\"]?([^'\"\n]+)", text[:3000], re.MULTILINE)
    return m.group(1).strip() if m else None


def fetch(url, timeout):
    req = urllib.request.Request(url, headers={
        "User-Agent": "NONISV|ITAM-plugin|sharepoint-itam-records-doc-snapshot/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.status, resp.read().decode(charset, errors="replace")


def main():
    p = argparse.ArgumentParser(
        description="Snapshot official SharePoint/Graph sources (NEEDS NETWORK ACCESS).")
    p.add_argument("--out", help="output folder (create outside the plugin)")
    p.add_argument("--list", action="store_true", help="print the source allowlist and exit")
    p.add_argument("--only", help="comma-separated source ids to fetch")
    p.add_argument("--timeout", type=float, default=25.0)
    p.add_argument("--delay", type=float, default=0.5, help="seconds between requests")
    a = p.parse_args()

    if a.list:
        for sid, url, kind in SOURCES:
            print(f"{sid}\t{kind}\t{url}")
        return 0
    if not a.out:
        p.error("--out is required unless --list is given")

    wanted = set(a.only.split(",")) if a.only else None
    unknown = (wanted or set()) - {s[0] for s in SOURCES}
    if unknown:
        p.error("unknown source id(s): " + ", ".join(sorted(unknown)))

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    ok = 0
    with (out / "manifest.jsonl").open("w", encoding="utf-8") as manifest:
        for sid, url, kind in SOURCES:
            if wanted and sid not in wanted:
                continue
            row = {"id": sid, "url": url, "kind": kind, "status": "error",
                   "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
            try:
                status, body = fetch(url, a.timeout)
                if kind == "html":
                    ex = TextExtractor()
                    ex.feed(body)
                    text, date = ex.text(), ex.ms_date
                else:
                    text, date = body, md_date(body)
                (out / f"{sid}.txt").write_text(f"SOURCE: {url}\n\n{text}\n", encoding="utf-8")
                row.update(status="ok", http_status=status, ms_date=date, filename=f"{sid}.txt",
                           characters=len(text),
                           sha256=hashlib.sha256(text.encode("utf-8")).hexdigest())
                ok += 1
            except (urllib.error.URLError, OSError, ValueError) as e:
                row["error"] = f"{type(e).__name__}: {e}"
            manifest.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(f"{sid}\t{row['status']}\t{row.get('ms_date') or row.get('error', '')}")
            time.sleep(a.delay)
    print(f"{ok} fetched; manifest: {out / 'manifest.jsonl'}", file=sys.stderr)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
