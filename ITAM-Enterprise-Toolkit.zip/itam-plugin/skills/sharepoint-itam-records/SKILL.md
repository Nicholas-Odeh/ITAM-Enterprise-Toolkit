---
name: sharepoint-itam-records
description: Use when someone asks how to do something in SharePoint Online (lists, items, libraries, views, sharing, site permissions, groups, version history, PowerShell, Graph updates) or is setting up SharePoint to hold ITAM evidence and trackers such as contracts, certificates of destruction, audit evidence, or asset and contract lists. Covers library taxonomy, metadata, retention templates, Power Automate flows, troubleshooting. Not for SOP text (itam-sop-documentation), ServiceNow config (servicenow-itam), or general Graph, Intune or PowerShell scripts outside SharePoint (itam-automation-scripting).
---

# SharePoint ITAM Records

SharePoint holds ITAM evidence and small trackers; the system of record lives elsewhere. This skill designs the evidence repository and answers SharePoint how-to questions with sourced steps, for ITAM staff, site owners and Microsoft 365 admins.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.

6. **SharePoint lists are custom trackers, not the ITAM system of record.** Store keys and links; every copied field names its authoritative system and sync owner. Asset Tag, Serial Number and Assigned To are organization columns, not SharePoint defaults.
7. **Start read-only; warn before breaking inheritance, broadening sharing, or disabling versioning or audit** (and before publishing record labels or content types). State scope, reversibility and approver; pilot first.
8. **Never invent retention periods or product facts.** Periods, holds and disposal decisions are `[FILL — Records/Legal]`. Buttons, menu paths, cmdlets, API scopes and limits carry a `DOC` source or `VENDOR — VERIFY`.

## When to use

- "How do I…" in a list, library, view or sharing dialog; missing button; access denied; lost version.
- Changing or auditing a SharePoint asset tracker.
- Designing the evidence site, retention labels or flows; Graph or PowerShell list updates.

**When not to use:** SOP text → `itam-sop-documentation`; contract terms → `itam-vendor-contract-management`; ServiceNow config → `servicenow-itam`; production code → `itam-automation-scripting`; count reconciliation → `itam-inventory-reconciliation`.

## Workflow

### Step 1: classify

| Request | Load |
|---|---|
| End-user how-to: lists, items, libraries, views, formatting, sharing, versions | `references/procedures-end-user.md` |
| Membership, groups, external sharing, inheritance, hubs | `references/procedures-admin.md` |
| PowerShell, Graph, REST, throttling, SPFx | `references/advanced-operations.md` |
| Something doesn't work | `references/troubleshooting.md` |
| Site structure, content types, permissions matrix | `references/library-taxonomy.md` |
| Columns, keys, asset tracker, views, tracker audit | `references/metadata-schema.md` |
| Retention, disposition, legal hold | `references/retention-schedule.md` |
| Flows | `references/flow-patterns.md` |

### Step 2: preflight

Read `templates/company-profile.md` if present. Confirm or label: experience (Online modern, classic, Server, Lists, Teams); site type; the user's role; system of record and sync. Design work also needs Purview licensing, the retention schedule and key formats.

### Step 3: do

- **How-to:** adapt the closest procedure; label every step `DOC`, `PRACTICE`, `VENDOR — VERIFY` or `[FILL]` (`references/source-index.md` §1); warn before access-changing or destructive steps.
- **Design:** library per record class, metadata over folders, groups over users, event-based retention, owned flows with error paths.
- **Writes:** read first, capture eTags, take a before-image, cap the run, get approval (`advanced-operations.md` §5–7).

### Step 4: verify before release

- ★ Every UI path, column name, scope, cmdlet and limit is `DOC` or `VENDOR — VERIFY`.
- ★ No retention period, hold or disposal decision without a supplied schedule.
- ★ Access-changing or destructive steps carry a warning, scope, rollback and approver.
- ★ Tracker answers name the authoritative system and the matching change there.
- Every how-to has Verify and If-it-does-not-work sections.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Just break inheritance on this one item" | Unique scopes multiply. Warn and get approval. |
| "An anyone link is quickest for the auditor" | Specific people, view only, expiry, logged. |
| "Turn off versioning to save space" | Evidence history is lost for good. |
| "The tracker says it's assigned" | Check the authoritative record. |
| "The PATCH returned 200, done" | Read back; update the ITAM record separately. |

Stop if you are about to: grant broad or external access, disable versioning or audit, publish a record label, retry a 412 without re-reading, or bulk-edit without a before-image.

## Common mistakes

| Mistake | Fix |
|---|---|
| Adding an auditor to the Microsoft 365 group | Use a read-only SharePoint group |
| Sending column display names to Graph | Read `/columns`; use `name` |
| Treating a view filter as security | Restrict with permissions |
| Steps for the wrong experience | Confirm modern, classic, Server, Lists or Teams first |

## If connectors are available

- **`~~document repository`:** read columns, views, permissions, sharing links and versions, noting when. Draft changes as dry runs; apply only after approval.
- **`~~ITSM`:** read the authoritative record to compare with the tracker; draft link-back updates for approval.

## Output format

**How-to:** **Goal** · **Applies to** · **Permissions/prerequisites** · **Steps** (numbered, labelled) · **Verify** · **If it does not work** (2–3 causes) · **Source** (URL or repo path, as-checked date; custom fields marked custom).

**Design:** **Answer** (2–5 sentences) · **Design** tables · **Assumptions and VERIFY list** with owners · **Risks**.

## Reference files

- `references/procedures-end-user.md`: answer template and end-user steps, including change-assignee.
- `references/procedures-admin.md`: before changing access; groups, sharing, inheritance.
- `references/advanced-operations.md`: before any script, API call or bulk change.
- `references/troubleshooting.md`: when something fails.
- `references/library-taxonomy.md`: for site and library structure.
- `references/metadata-schema.md`: for columns, keys and trackers.
- `references/retention-schedule.md`: for any retention question.
- `references/flow-patterns.md`: for any flow.
- `references/source-index.md`: to cite or check a source.
- `scripts/collect_official_docs.py`: needs network access. Run `python3 scripts/collect_official_docs.py --list`, then `--out <folder>`, to see whether cited pages changed.
