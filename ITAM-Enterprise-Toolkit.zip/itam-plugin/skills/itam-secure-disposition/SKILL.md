---
name: itam-secure-disposition
description: Use when retiring laptops, servers, drives, SSDs, phones, printers or network gear; someone asks "can we resell these", "prove this was wiped" or "where is the certificate"; a certificate of destruction must be reconciled; an ITAD vendor or recycler is chosen or audited; or a device went missing in disposal. Covers sanitization outcomes, chain of custody, certificates, ITAD vendors, value recovery, closure evidence. Not for lifecycle state design or refresh planning (use itam-hardware-lifecycle).
---

# Secure IT Asset Disposition (ITAD)

Retire assets so that data is provably gone, custody is unbroken, legal and environmental duties are met, value is recovered and every record is closed. For disposal managers, ITAM analysts, security and ITAD vendor owners.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **No closure without serial-level evidence.** An asset is not "Disposed" until its sanitization or destruction record, custody trail and final-disposition certificate match its serial number (AssetForge §25).
7. **Data risk outranks value recovery.** If data classification or the sanitization result is unknown, treat the media as holding the most sensitive data in scope.
8. **Law, contract and policy decide the method.** `references/standards.md` names what to check, with current editions to verify; it is not legal advice.

## When to use

- Wipe vs. destroy; resale, donation or lease return.
- Proving a device was sanitized; reconciling certificates to manifests.
- ITAD or recycler selection or audit; a device missing in disposal; audit evidence.

**When not to use:** lifecycle states, refresh cycles, lost or stolen devices in service → `itam-hardware-lifecycle`; disposal controls and audit programs → `itam-risk-controls-audit`; write-off values → `itam-financial-management`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| Wipe vs. destroy | `references/sanitization-decision.md` |
| Custody, manifests, certificates, missing device | `references/chain-of-custody.md` |
| ITAD vendor | `references/itad-vendor.md` |
| Redeploy, resell, donate, lease return | `references/value-recovery.md` |
| Closure, evidence pack, KPIs | `references/evidence-pack.md` |
| Which standard or law applies | `references/standards.md` |
| End-to-end batch | `references/retirement-workflow.md` first |

### Step 2 — Preflight

Checklist in `retirement-workflow.md` §1: serials, media (including embedded), data class, ownership, holds, destination, jurisdictions. If class, hold status or destination is unknown and the device holds data, ask first.

### Step 3 — Do the work

Authorize → prepare → sanitize → hand over under custody → final disposition → reconcile certificates by serial → close records (`retirement-workflow.md` §2). A failed or unverifiable sanitization escalates to destruction. Every certificate variance becomes an owned exception.

### Step 4 — Verify before release

- ★ Every serial in scope has a sanitization or destruction record, or is an open exception.
- ★ Manifest, vendor receipt and certificates reconcile by serial with zero unexplained variances.
- ★ Legal-hold status was checked before any sanitization.
- ★ No standard clause, certification or legal requirement appears without a source or `VERIFY`.
- ★ Media the method doesn't cover (for example flash with an overwrite-only tool) is not recorded as sanitized.
- Non-blocking checks in `retirement-workflow.md` §3 are done.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Certified vendor, the counts are close enough" | Only serials named on the certificate are covered. Match by serial. |
| "It was encrypted, skip the wipe" | Encryption is not a sanitization record. |
| "We overwrote the SSD" | Overwrite may not reach all flash. Purge with a device command or destroy. |
| "Mark it disposed; the certificate will come" | No certificate, no closure. Keep an open exception. |

Stop if you are about to: close an asset without a certificate line for its serial; sanitize before the legal-hold check; trigger a remote wipe or retire action without named approval.

## Common mistakes

| Mistake | Fix |
|---|---|
| Ignoring printer or appliance storage | Inventory embedded media in preflight. |
| Device serial only for removed drives | Record media serials too. |
| Trusting a vendor's certification claim | Check the certifying body's registry; date it. |
| Missing device treated as paperwork | Escalate as a potential security incident. |

## If connectors are available

- **~~ITSM / ~~CMDB:** read asset and CI state; draft state changes for approval.
- **~~endpoint management:** confirm management release; any wipe or retire action needs named approval per run.
- **~~document repository:** read manifests and certificates; draft the evidence-pack filing.
- **~~finance:** draft the fixed-asset retirement notice; Finance posts it.

## Output format

1. **Answer:** recommended outcome or batch status.
2. **Batch table:** asset tag | serial | media | data class | destination | required outcome | method | verified | certificate ref | status.
3. **Exceptions** with owner, risk, next step.
4. **Assumptions to verify; evidence pack contents and location.**

Executive variant: data-exposure status first, then compliance flags, value vs. cost, decisions.

## Reference files

- `references/retirement-workflow.md`: preflight, the seven steps, non-blocking checks.
- `references/sanitization-decision.md`: any wipe-vs-destroy decision.
- `references/chain-of-custody.md`: custody, certificates, reconciliation.
- `references/itad-vendor.md`: choosing or auditing an ITAD vendor.
- `references/value-recovery.md`: choosing the disposition route.
- `references/evidence-pack.md`: closure criteria, KPIs, audit questions.
- `references/standards.md`: before naming any standard, certification or law.
- `references/asset-data-model.md`: shared copy of the canonical data model (source `itam-hardware-lifecycle`); don't edit.
