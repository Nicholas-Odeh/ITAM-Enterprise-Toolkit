# Standards, certifications and legal obligations for disposition

**Read this first.** Every entry is described by **purpose only** and marked `VERIFY`: confirm the current edition or version, the jurisdiction, and whether it applies to the organization before relying on it. Do not quote clause numbers, particle sizes, retention periods or legal duties from memory. Applicability of laws is a question for Legal; this file is not legal advice.

The CAMP material treats legislation as country- and industry-specific: copyright, security, disposal, financial, privacy and industry-specific laws all shape ITAM, and disposal methods may be constrained by regulation, licensing agreements and policy (CAMP S:113; M:42). Its named examples are illustrative and dated; re-verify any of them before use (CAMP S:116–118).

## 1. Media sanitization

| Name | Purpose | Applies when | Verify |
|---|---|---|---|
| NIST SP 800-88, *Guidelines for Media Sanitization* | US federal guidance defining sanitization outcomes (clear, purge, destroy) and a decision process by media type and confidentiality; widely adopted outside government as the reference for wipe policy | Any organization that cites it in policy or contracts, or needs a recognized baseline | `VERIFY current edition`: Rev. 1 (2014) was the long-standing edition and NIST has since revised it; check which revision the policy and vendor contracts cite and what moved between documents |
| IEEE 2883, *Standard for Sanitizing Storage* | Technique-level guidance for sanitizing current storage interfaces and media | When choosing or validating sanitize commands for SSD, NVMe and other modern media | `VERIFY` edition and whether the organization's policy references it |
| ISO/IEC 27040 (storage security) | Storage security guidance that includes sanitization | Organizations aligning to the ISO/IEC 27000 family | `VERIFY` edition and scope |
| Manufacturer guidance | Device-specific secure-erase and factory-reset behavior | Phones, tablets, self-encrypting drives, printers, network devices | `VERIFY` per model and firmware or OS version |

## 2. ITAD and recycling certifications

Confirm certificates in the certifying body's public registry, including facility scope and expiry.

| Name | Purpose | Verify |
|---|---|---|
| R2v3 (Responsible Recycling, maintained by SERI) | Certification for electronics reuse and recycling facilities covering environmental, health and safety, data security and downstream management | `VERIFY` current version, facility scope and expiry |
| e-Stewards (Basel Action Network) | Certification for electronics recyclers with strict limits on exporting hazardous e-waste, plus data security requirements | `VERIFY` current standard version, scope and expiry |
| NAID AAA (i-SIGMA) | Certification for data destruction service providers, covering destruction processes, security and personnel | `VERIFY` which services and media types the certification covers, and expiry |
| ISO 14001 / ISO 45001 / ISO/IEC 27001 | Environmental, occupational health and safety, and information security management systems at the vendor | `VERIFY` certificate scope includes the facility and services used |

## 3. Environmental and e-waste rules

| Name | Purpose | Verify |
|---|---|---|
| WEEE (EU Directive on waste electrical and electronic equipment, and national transpositions; separate UK regulations) | Separate collection, treatment and producer responsibility for electrical and electronic waste | `VERIFY jurisdiction`: national rules and the obligations of business end users vary by country |
| Basel Convention (transboundary movement of hazardous wastes) and its e-waste amendments | Controls cross-border shipment of hazardous and other wastes, including electronic waste | `VERIFY` current amendments, and whether the vendor's downstream exports comply |
| US federal and state rules (for example hazardous-waste rules for batteries, CRTs and other components; state electronics recycling and disposal-ban laws) | No single US federal e-waste law; obligations come from federal hazardous-waste rules and state laws | `VERIFY jurisdiction` for every state where assets are processed |
| Battery rules (transport as dangerous goods; battery-specific regulations in some jurisdictions) | Safe transport and end-of-life handling of lithium and other batteries | `VERIFY` carrier requirements and jurisdiction |
| Other national e-waste laws | Equivalent regimes outside the EU, UK and US | `VERIFY jurisdiction` |

## 4. Data protection and records obligations

These drive *why* sanitization and custody evidence are needed. The CAMP material lists patient confidentiality, financial responsibility and privacy among the drivers of diligence at end of life (CAMP M:77) and privacy-protected disposition as a compliance function (CAMP S:90).

| Name | Purpose relevant to disposition | Verify |
|---|---|---|
| GDPR (EU) and UK GDPR / Data Protection Act | Security of personal data through its whole lifecycle, and contracts with processors such as ITAD vendors | `VERIFY jurisdiction` and the processor terms in the ITAD contract |
| HIPAA (US health sector) | Safeguards for electronic protected health information, including disposal and re-use of media | `VERIFY` whether the organization is a covered entity or business associate |
| Gramm-Leach-Bliley Act Safeguards Rule (US financial institutions) | Safeguarding customer information, including its disposal | `VERIFY` applicability and current rule text |
| FACTA disposal rule (US) | Proper disposal of consumer report information | `VERIFY` applicability |
| PCI DSS | Secure destruction of media holding cardholder data | `VERIFY` current version and the organization's scope |
| State, provincial and national data-disposal and breach-notification laws (for example Canada's PIPEDA, named in CAMP S:117) | Duties to destroy personal data securely and to notify if a device with personal data is lost | `VERIFY jurisdiction` |
| Records retention schedules and legal hold | Some data must be kept for a period, or preserved for litigation, before media can be sanitized | Legal and records management confirm before sanitization |

## 5. Cross-border shipment of devices

Encrypted devices and their components can be subject to export-control and sanctions rules when shipped across borders for resale or processing, and customs rules apply to used equipment. `VERIFY` with trade compliance before any cross-border disposition. Logistics detail belongs to the `itam-logistics-warehouse` skill.

## 6. Recording verification

When a standard or law is relied on, record it in the disposal policy or evidence pack as:

`name | edition / version | jurisdiction | applies to (asset classes, data classes) | verified by | verified on | source (URL or document)`
