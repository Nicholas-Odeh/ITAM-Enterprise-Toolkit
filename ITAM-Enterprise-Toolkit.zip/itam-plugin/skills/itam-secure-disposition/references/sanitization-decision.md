# Sanitization decision flow

Labels: `FACT`, `STANDARD`, `PRACTICE`, `INFERENCE`, `ASSUMPTION`, `RECOMMENDATION`, `VERIFY`. The organization's approved media sanitization policy overrides this file. Standards named here are described by purpose only; see `standards.md` and verify the current edition.

## Contents
1. Outcome categories
2. Decision flow
3. Minimum-outcome matrix (fill-in)
4. Media-specific notes
5. Verification
6. Per-item record

## 1. Outcome categories

NIST SP 800-88 (Guidelines for Media Sanitization) groups sanitization into three outcomes. Paraphrased by purpose (`STANDARD`, `VERIFY` current revision and its exact definitions):

| Outcome | Purpose | Media reusable? |
|---|---|---|
| Clear | Logical techniques that protect against simple, non-invasive recovery (for example overwriting user-addressable storage) | Yes |
| Purge | Physical or logical techniques that make recovery infeasible even with laboratory techniques (for example device-supported sanitize commands, cryptographic erase where valid) | Usually yes |
| Destroy | Makes recovery infeasible and the media unusable (for example shredding, disintegration, pulverizing, incineration) | No |

Physical destruction is not the only valid method; choose the outcome the data and destination require (AssetForge §25).

## 2. Decision flow

Work top to bottom and stop at the first rule that decides.

1. **Hold?** Device or user under legal, investigation or incident hold → **stop**; do not sanitize until the hold owner releases it.
2. **Data still needed?** Records the business must retain → copy under the records policy first.
3. **Classification known?** No → treat as the highest classification in scope (SKILL.md operating rule 7).
4. **Destination.**
   - Leaves organizational control (resale, donation, lease return, recycler) → needs at least the outcome the matrix in §3 sets for that classification and destination.
   - Stays inside (internal redeploy) → the policy's internal-reuse outcome.
5. **Is the technique valid for this media?** Check §4. If the only available technique is not valid for the media (for example a software overwrite on flash storage), escalate to purge with a device-supported command or to destroy.
6. **Verified?** Sanitization verified per §5 → record and continue. Failed, partial or unverifiable → destroy, and record the failure.
7. **Damaged or non-functional media** that cannot run a logical technique → destroy.

## 3. Minimum-outcome matrix (fill-in)

Rows use the organization's data classification scheme; values are set by Security and the policy owner. Do not fill this from memory. Until approved, label any recommendation built on it `ASSUMPTION`.

| Data classification | Internal redeploy | Leaves control, reusable (resale, donation, lease return) | Leaves control, recycling | Damaged / failed sanitization |
|---|---|---|---|---|
| [Public] | [org] | [org] | [org] | Destroy |
| [Internal] | [org] | [org] | [org] | Destroy |
| [Confidential] | [org] | [org] | [org] | Destroy |
| [Restricted / regulated] | [org] | [org] | [org] | Destroy |

`PRACTICE`: many organizations require at least purge for any media leaving their control, and destroy for the most sensitive classes regardless of destination. Confirm before adopting.

## 4. Media-specific notes (`PRACTICE`, verify against manufacturer and current standards)

| Media | Notes |
|---|---|
| Magnetic hard drives (HDD) | Overwrite is a recognized clear technique. Degaussing can purge but renders modern drives unusable; it needs a degausser rated for the media's coercivity. |
| SATA / SAS SSD, NVMe, eMMC, other flash | Wear-leveling and over-provisioned areas mean a host overwrite may not reach all cells. Prefer device-supported sanitize commands, or cryptographic erase where the encryption implementation and key handling are verified. Otherwise destroy. Destruction particle size for flash must meet the policy's or standard's requirement (`VERIFY`; do not quote a size from memory). |
| Self-encrypting drives | Cryptographic erase is only as good as the drive's implementation; confirm the model's support and any validation the policy requires. |
| Phones and tablets | Modern devices with hardware encryption are typically sanitized by a factory reset that discards keys (`VERIFY` per manufacturer guidance and OS version). Remove from device management and activation lock first, or the device cannot be reused. Remove SIM and memory cards. |
| Laptops and desktops | Check for more than one drive, and soldered storage. |
| Servers and storage arrays | Every drive, including spares and hot spares; controller cache; array-level cryptographic erase where supported. Pulled drives are tracked by drive serial. |
| Printers and multifunction devices | Internal storage holds scanned and printed documents; use the manufacturer's secure-erase function or remove and destroy the storage. |
| Network and security devices | Configurations, credentials, keys and logs; reset to factory and verify, or destroy storage. |
| Removable media, backup tapes | Inventory separately; tapes are typically degaussed or destroyed. |
| IoT, conference-room and other embedded devices | Assume storage exists until the manufacturer says otherwise. |

## 5. Verification

- Use a tool that reports per media serial: method, start and end time, result, and errors.
- Verify the result: a tool report for each item plus sample-based independent verification (for example reading back sampled areas) at a rate set in policy ([org: sample rate]).
- Treat any error, partial completion or missing report as a failure (decision flow step 6).
- For destruction, record the witness or video evidence, the destruction method and the media serials.

## 6. Per-item record

`asset_tag | device_serial | media_serial | media_type | data_classification | destination | required_outcome | technique | tool_and_version | operator | location | start | end | result | verification_method | verified_by | exception_id`

The record belongs in the asset's evidence pack (`evidence-pack.md`). If the ITAD vendor sanitizes, require this same field set in its serial-level report.
