# Disposal evidence pack and closure

Labels as in `sanitization-decision.md`. Retention periods come from the organization's records schedule and applicable law, not from this file. Where evidence is stored is covered by the `sharepoint-itam-records` skill if SharePoint is the repository.

## 1. Per-asset closure criteria

Do not mark an asset disposed until the required closure evidence exists (AssetForge §25). An asset may move to the final state only when every applicable row is satisfied.

| # | Criterion | Evidence |
|---|---|---|
| 1 | Retirement authorized | Approval record with approver and date |
| 2 | Legal-hold check done | Check record (cleared / not applicable) |
| 3 | Software harvested where applicable | License release or reclaim record |
| 4 | Data handled per policy | Data transfer or retention record, if required |
| 5 | Removed from management and identity services | Task record |
| 6 | Sanitized or destroyed, verified | Per-media record (`sanitization-decision.md` §6) or destruction certificate line |
| 7 | Custody unbroken | Custody events 1–12 (`chain-of-custody.md` §1) present |
| 8 | Final disposition evidenced | Certificate, settlement, lease receipt or donation receipt naming the serial |
| 9 | Asset record closed | Final state, disposal date, method, certificate reference |
| 10 | CI retired or updated | CI status change |
| 11 | Financial retirement | Fixed-asset retirement and any proceeds recorded by Finance |
| 12 | Contract / lease closed | Lease return or contract update |

Lifecycle state names come from the organization (company profile, or the canonical state model in the `itam-hardware-lifecycle` skill). Do not invent state names.

## 2. Batch evidence pack contents

- Batch ID, scope, approver and dates.
- Disposal list exported from the asset repository (with the export date).
- Signed manifest(s) with seal numbers.
- Vendor receiving report.
- Per-item sanitization reports and/or destruction certificates.
- Downstream or recycling certificates.
- Certificate-to-manifest reconciliation result and exception log with closures.
- Settlement statement for resale or buy-back.
- Vendor certification check (registry lookup date and result).
- Sign-off by the disposal manager.

## 3. Evidence quality

Grade each item (adapted from RiskForge §10.3): sufficient, partially sufficient, insufficient, stale, contradictory, unavailable. A process that "probably happened" is not evidence that it happened (AssetForge §14). Evidence should be attributable, complete, accurate, retrievable, time-bound and retained per schedule (RiskForge §29).

## 4. Disposal KPIs

Define numerator, denominator, source and cadence before reporting.

| KPI | Source idea |
|---|---|
| Share of hardware assets that went through the formal disposal process | CAMP S:94; M:23 |
| Share of hardware assets whose data was secured before transfer of ownership | CAMP S:94; M:23 |
| Share of hardware assets whose software was harvested, where applicable | CAMP S:94; M:23 |
| Share of hardware assets, by type, disposed of according to local regulations | CAMP S:87 |
| Certificate completeness (serial-level certificates received / serials shipped) | RiskForge §23 |
| Disposition cycle time (approval to certificate) | AssetForge §26.3 |
| Open custody exceptions and their age | `PRACTICE` |

## 5. Audit questions to prepare for (`PRACTICE`)

| Question | What to show |
|---|---|
| Pick five disposed assets: show they were wiped. | Per-item sanitization record or destruction certificate line, matched by serial |
| How do you know nothing went missing between pickup and the vendor? | Manifest, receipt, reconciliation, exception log |
| How did you choose and how do you monitor the vendor? | Due diligence file, registry checks, audit reports |
| Do retired assets leave the fixed-asset register? | Finance reconciliation of disposals |
| Is disposal stock secured? | Staging access log and counts |
| Who can approve disposal, and is that enforced? | Policy, approval records |

Control definitions and testing for these questions are in the `itam-risk-controls-audit` skill.
