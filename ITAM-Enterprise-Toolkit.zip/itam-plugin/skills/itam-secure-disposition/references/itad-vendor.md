# ITAD vendor due diligence, contract and audit

Labels as in `sanitization-decision.md`. Vendor scorecards and contract obligation registers are built with the `itam-vendor-contract-management` skill; this file supplies the ITAD-specific content.

## Why it matters

The CAMP manual warns that some disposition vendors still skirt commitments and laws: dumping assets, shipping them elsewhere to be dumped, or stripping components without adequate health and safety protection, and that global enforcement is inconsistent (CAMP M:77). Selecting criteria for the disposal vendor, due diligence on that vendor, monitoring disposal cost, and following disposal regulations are named components of disposal management (CAMP M:42; S:93, S:95). Evaluating vendor compliance is a compliance function (CAMP S:90).

## 1. Selection and due diligence checklist

Verify each item with evidence, not only the vendor's statement.

| Area | What to check | Evidence |
|---|---|---|
| Certifications | Which certifications apply (for example R2v3, e-Stewards, NAID AAA, ISO 14001, ISO 45001, ISO/IEC 27001); scope covers the services and the facility that will handle your assets; expiry date | Certificate copy, confirmed in the certifying body's public registry (`VERIFY`) |
| Sanitization capability | Methods by media type, tools and versions, verification process, serial-level reporting, failure handling | Process documents, sample report |
| Destruction capability | Methods, particle size achievable versus policy, witness or video options, on-site service | Equipment list, sample certificate |
| Facility security | Access control, CCTV, segregated secure areas, visitor controls, retention of footage | Site visit notes |
| People | Background checks for staff handling data-bearing devices, training | Policy, attestation |
| Logistics | Owned vs. subcontracted transport, vehicle security, tracking | Transport procedure |
| Downstream | Named downstream processors, their certifications, export policy for whole units and e-waste fractions | Downstream list, policy |
| Environmental and legal | Permits and registrations in the relevant jurisdictions | Permit copies (`VERIFY` with the issuing authority) |
| Insurance | Types and limits (for example general liability, pollution, cyber, errors and omissions) | Certificate of insurance; limits set by the organization's risk team [org] |
| Financial stability | Ability to honor indemnities and revenue share | Financial review |
| Incident handling | Breach notification timing and content | Contract draft |
| Reporting | Portal or files with serial-level status, certificates, settlement | Demo, sample files |
| References | Clients of similar size and sector | Reference calls |

## 2. Contract clauses to cover (`PRACTICE`; Legal drafts)

- Scope of services and the facilities permitted to process the organization's assets.
- Sanitization and destruction standard the vendor must meet, by data classification (link to the organization's matrix).
- Serial-level reporting fields and turnaround for receiving reports and certificates ([org: N days]).
- Title and risk transfer: when ownership and liability pass to the vendor.
- Data breach liability, notification and cooperation.
- Downstream restrictions: approved downstream list, no export of e-waste or untested units without written approval, compliance with environmental law.
- Right to audit, including unannounced visits and downstream audits.
- Revenue share or buy-back pricing, settlement timing and fair-market-value method.
- Insurance and indemnity.
- Subcontracting only with approval.
- Termination, return of the organization's assets and data, and certificate obligations that survive termination.

## 3. Ongoing oversight and audit checklist

| Check | Cadence ([org]) | Method |
|---|---|---|
| Certifications still valid and in scope | Annually and at expiry | Certifying-body registry lookup |
| Certificate turnaround | Per batch | Days from pickup to certificate, against contract |
| Serial reconciliation variance | Per batch | Count of unexplained variances (target zero) |
| On-site audit | [org: e.g. annually] | Walk the process with one of your batches: receipt, staging, sanitization, destruction, resale prep, downstream shipping |
| Witnessed destruction | Sample of batches | Attend or receive video with serials visible |
| Independent sanitization check | Sample of resold or returned devices | Buy back or test sampled devices for recoverable data (`RECOMMENDATION`) |
| Downstream verification | [org] | Downstream certificates, shipping documents |
| Incident review | As needed | Any breach, loss or regulatory action involving the vendor |
| Settlement accuracy | Per settlement | Recovered value versus agreed pricing |

Record findings in the vendor file; failures go to the `itam-risk-controls-audit` skill as control exceptions.

## 4. Vendor metrics

- Certificate turnaround (days) and share of batches on time.
- Serial-level match rate between manifest and certificate.
- Number of open custody exceptions and their age.
- Recovered value per unit by category, versus forecast.
- Audit findings opened and closed.
