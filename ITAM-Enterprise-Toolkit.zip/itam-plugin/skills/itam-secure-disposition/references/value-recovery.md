# Value recovery

Labels as in `sanitization-decision.md`. Value recovery never relaxes the sanitization outcome required for the data and destination. Accounting for gains, losses and write-offs belongs to Finance and the `itam-financial-management` skill.

## 1. Disposition options

Order of preference is an organizational decision. A common `PRACTICE` order, highest retained value first:

| Option | Preconditions | Main risks | Records |
|---|---|---|---|
| Internal redeploy | Meets minimum performance standard and remaining support life; internal-reuse sanitization done; reimaged | Redeploying devices too old to support | Asset re-entered to stock; new assignment |
| Internal secondary use (spares, labs, training) | Owner and purpose named | Untracked "lab" assets become ghosts | Asset kept in inventory with a status |
| Lease return | Lessor's condition, sanitization and accessory requirements met | Missing-asset and damage fees; data leaving under the lessor's process | Return manifest, lessor receipt, certificates |
| Resale / remarketing via ITAD vendor | Sanitization outcome allows reuse; title transfer terms clear | Data exposure if sanitization unverified; low recovery | Settlement statement, serial list |
| Employee purchase | Policy allows it; pricing method; tax treatment; software licenses removed or transferable (`VERIFY` publisher terms) | Perceived favoritism, tax, support expectations, data | Sale record, signed release |
| Donation | Recipient eligibility; sanitization; licensing of any OS or software left on the device (`VERIFY`); liability release | Reputation if the device is later dumped; data | Donation agreement, recipient receipt |
| Parts harvesting | Parts are tracked as spares | Untracked parts with storage (for example SSDs) | Parts inventory |
| Recycling | Certified recycler; downstream controls | Illegal export or dumping (CAMP M:77) | Recycling certificate |

The acquisition stage should already tell the disposal process which assets are leased or owned, which hold sensitive data, which carry harvestable software, and what minimum performance a device needs to be redeployed (CAMP M:36).

## 2. Valuing equipment

- Fair market value is an estimate of what a willing buyer would pay a seller (CAMP M:132). Use the vendor's quotes, buy-back schedules or market data supplied by the user; do not quote prices from memory.
- The disposal manager monitors market values and fair market value as part of the role (CAMP M:113).
- Compare net recovery (proceeds minus logistics, sanitization, data-bearing-device handling and vendor fees) with the cost of the alternative, not gross resale price.
- Timing matters: value usually falls while devices sit in storage, so set a maximum dwell time for disposal stock ([org]).

## 3. Decision record per batch

`batch_id | category | count | condition grade | data classification | chosen option | rationale | expected recovery (source) | actual recovery | variance | approver`

## 4. Metrics

- Recovered value per period and per unit, by category.
- Share of retired devices redeployed internally.
- Cost of disposition per unit.
- Days from retirement approval to final disposition.
- Lease returns on time and fees incurred.
