# Chain of custody and certificates

Labels as in `sanitization-decision.md`. Shipping mechanics for remote returns belong to the `itam-logistics-warehouse` skill; this file covers the custody evidence.

## Contents
1. Custody events
2. Custody record fields
3. Staging and storage
4. Handover and transport
5. Exceptions
6. Certificate types and content
7. Certificate-to-manifest reconciliation

## 1. Custody events

Each event transfers responsibility and leaves a record. A gap between two events is a gap in custody.

| # | Event | From → to | Evidence |
|---|---|---|---|
| 1 | Retirement approved | Owner → disposal process | Approval record |
| 2 | Collected | User / site → collector | Collection record (signature or ticket) |
| 3 | Staged | Collector → secure staging area | Staging log, location |
| 4 | Sanitized on site (if applicable) | — | Per-item sanitization record |
| 5 | Packed and sealed | Staging → container | Container ID, seal numbers, packing list |
| 6 | Manifest signed | Organization → carrier / ITAD vendor | Manifest with serials, counts, signatures of both parties |
| 7 | Transported | Carrier / vendor | Transport record, vehicle, timestamps |
| 8 | Received at facility | Vendor | Receipt with seal check and count |
| 9 | Receiving reconciliation | Vendor → organization | Serial-level receiving report within [org: N days] |
| 10 | Processed | Vendor | Sanitization or destruction report per serial |
| 11 | Final disposition | Vendor → downstream / buyer | Resale, recycling or downstream record |
| 12 | Certificates issued | Vendor → organization | Certificates (see §6) |

## 2. Custody record fields

`custody_event_id | batch_id | asset_tag | serial | event | timestamp | location | released_by | received_by | container_id | seal_number | condition | notes`

## 3. Staging and storage

- Access-controlled area with an access list and log; storage of unused assets costs money and adds risk, so set a maximum dwell time ([org: N days]) (CAMP M:42 on avoiding costly storage of unused assets).
- Separate containers for media awaiting sanitization, sanitized media and media for destruction; label by status.
- Periodic count of staged items against the staging log.

## 4. Handover and transport

- Pre-print the manifest from the asset repository; count and scan serials at handover; both parties sign.
- Seal containers and record seal numbers on the manifest.
- Use the contracted vendor's secured transport or a carrier approved by policy; direct route where the contract requires it.
- Devices with data that has not yet been sanitized need the strongest custody controls; consider on-site sanitization or destruction for the most sensitive classes (`RECOMMENDATION`, decided by policy).

## 5. Exceptions

| Exception | Immediate action | Escalation |
|---|---|---|
| Count mismatch at pickup or receipt | Stop the handover, recount, document | Disposal manager |
| Serial present on manifest but not received | Open exception; search staging and transport records | Security if the device held data; possible incident under the privacy and incident policies |
| Serial received but not on manifest | Hold the item; identify its source | Disposal manager; asset record correction |
| Broken or mismatched seal | Inspect the contents against the packing list | Security |
| Certificate missing past the agreed turnaround | Chase the vendor; mark the batch open | Vendor manager |

Exception record: `exception_id | batch_id | serial | type | detected_at | detected_by | data_risk (Y/N) | owner | actions | status | closure_evidence`.

## 6. Certificate types and content

The CAMP material names disposal documents such as certificates of erasure, disposal and accountability, retained as documentation after disposal (CAMP S:68; M:43). In practice (`PRACTICE`):

| Certificate | Proves |
|---|---|
| Certificate of sanitization / erasure | Named media were sanitized by a stated method with a result |
| Certificate of destruction | Named media or devices were physically destroyed by a stated method |
| Certificate of recycling / downstream disposition | Material went to named, permitted downstream processors |
| Certificate of accountability / custody | The vendor accounts for every item received |

A useful certificate states: vendor and facility, batch or manifest reference, date range, method, a serial-level item list (or an attached report), result per item, and an authorized signatory. A batch certificate with only a total count and no serial list is weak evidence: it cannot prove a specific device was handled. Ask for the serial-level report.

## 7. Certificate-to-manifest reconciliation

1. Load three lists by serial: the asset repository's disposal list, the signed manifest, and the vendor's certificate or serial report.
2. Normalize serials (case, spaces, leading zeros). The `itam-inventory-reconciliation` skill has deterministic matching scripts if volumes are large.
3. Classify each serial: matched on all three; manifest only; certificate only; repository only.
4. Every non-matched serial becomes an exception (§5). Zero unexplained variances is the release criterion.
5. Record the reconciliation result, its date and who performed it in the batch evidence pack.
