# Retirement workflow: preflight and the seven steps

Detail moved from `SKILL.md` (v2 restructure). Labels as in `sanitization-decision.md`. The organization's disposal policy, records schedule and contracts override this file.

## 1. Preflight checklist

Confirm each item, or record it as `ASSUMPTION`:

- **Population:** asset tags, serial numbers, device types and counts; the source list (asset repository export with its date, or pickup manifest).
- **Storage media per device:** HDD, SATA SSD, NVMe, eMMC or soldered flash, removable media, and embedded storage (printers and multifunction devices, network devices, appliances).
- **Data classification** of what the devices held, and whether full-disk encryption was enforced with keys under management.
- **Ownership:** owned, leased (lessor return conditions), or personal / BYOD (only corporate data in scope).
- **Holds:** legal hold, investigation or incident hold on any device or user.
- **Destination:** internal redeploy, resale, donation, lease return, recycling, destruction.
- **Jurisdictions** where devices are located and processed, and whether anything crosses a border.
- **ITAD vendor and contract**, if one is engaged.

If data classification, legal-hold status or destination is unknown and the device holds data, ask before recommending a method. Read `templates/company-profile.md` at the plugin root, if present, for lifecycle state names, the data classification scheme, locations and the contracted ITAD vendor.

## 2. The seven steps

1. **Authorize.** Approved retirement request; legal-hold check; Finance notified; lease status confirmed. CAMP lists the roles that request removal, select the disposal method and remove data (CAMP M:98).
2. **Prepare.** Harvest software licenses (`itam-software-license-management`); back up or transfer data the business must keep under the records policy; release the device from management, enrollment and activation-lock services (`PRACTICE`); revoke certificates and remove directory objects; retire or update the linked CI.
3. **Sanitize.** Choose the outcome with the decision flow in `sanitization-decision.md` §2; run it; verify; record per device serial and per media serial. A failed or unverifiable sanitization escalates to destruction.
4. **Hand over under custody.** Secure staging, sealed containers, signed manifest, receipt at the vendor, count and serial reconciliation (`chain-of-custody.md`).
5. **Final disposition.** Redeploy, resell, donate, return or recycle per the value-recovery decision (`value-recovery.md`); downstream handling per contract and environmental law.
6. **Reconcile certificates** to the manifest by serial number. Every variance becomes an exception with an owner; a missing device that held data is a potential security incident.
7. **Close records.** Asset state, CI status, fixed-asset retirement and any proceeds (to Finance and `itam-financial-management`), license pool, lease or contract. File the evidence pack (`evidence-pack.md`).

## 3. Release checks that are not blocking

- ITAD vendor certifications were verified with the certifying body, not only from the vendor's own claim (`itad-vendor.md`, `standards.md` §6).
- Leased assets meet the lessor's return conditions, and missing-asset fees are identified.
- Value recovery never relaxed the required sanitization outcome.
- Records closed: asset, CI, finance, license, contract (`evidence-pack.md` §1).

## 4. Background

Disposal is more than discarding equipment: the method can be constrained by regulation, vendor licensing agreements and organizational policy, and it touches IT, Finance, HR, Procurement and Legal (CAMP M:42). Data destruction is only half the job; proper handling of the hardware is the other half (CAMP M:77).
