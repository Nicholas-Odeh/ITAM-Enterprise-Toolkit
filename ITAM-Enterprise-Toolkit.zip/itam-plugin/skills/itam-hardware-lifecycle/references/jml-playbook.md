# Joiner-mover-leaver (JML) device playbook

Use this file when designing or troubleshooting how HR events drive device allocation, transfer and recovery. JML is the trigger behind most hardware lifecycle events and the largest source of unrecovered devices.

**Basis:** The sources say little about JML directly. CAMP covers the policy side (employees acknowledge ITAM policies in their HR file; loss prevention, telework and loaned-equipment policies; CAMP M:69-72) and lists HR among ITAM stakeholders (CAMP M:111-116). The procedure below is general professional practice (`PRACTICE`). Every timing, SLA, escalation step and cost-recovery rule is an organizational value: take it from `templates/company-profile.md` or the user, otherwise leave the `[FILL]` in place.

## Contents
1. Principles
2. Event sources and data feed
3. Joiner
4. Mover
5. Leaver
6. Special cases
7. Controls, evidence and metrics
8. RACI starter

## 1. Principles

- **HR (or the identity provider) is authoritative for employment status and dates.** ITAM never decides who is a leaver. ITAM is authoritative for which devices are assigned to whom.
- **Drive device work from an event, not a person remembering.** Each HR event creates a ticket with the person's assigned devices listed from the repository.
- **Recovery starts before the last day.** Most unrecovered devices belong to people who left before anyone asked for the device back.
- **Security actions and asset actions are separate but linked.** Access removal belongs to identity/security; device recovery and state changes belong to ITAM. Both reference the same HR event.
- **Check legal hold before wiping.** A leaver's device may be needed for litigation, investigation or regulatory retention. Confirm with Legal/HR before any wipe or reimage (`RECOMMENDATION`; the hold process is organizational `[FILL]`).

## 2. Event sources and data feed

| Event | Source | Minimum data | Lead time wanted |
|---|---|---|---|
| Joiner (hire, contractor start, rehire) | HR system / contractor onboarding `[FILL]` | Person ID, start date, role/job code, department, cost center, work location or remote address, manager, device profile | `[FILL]` business days before start |
| Mover (role, department, location, cost-center change) | HR system | Person ID, effective date, old and new role/department/location/cost center | `[FILL]` days before effective date |
| Leaver (resignation, termination, contract end, retirement) | HR system | Person ID, last working day, termination type (voluntary / involuntary / immediate), manager, personal contact for return logistics (privacy-controlled) | As soon as known; immediate for involuntary |
| Leave of absence / return | HR system | Person ID, dates | Policy decides whether devices are kept `[FILL]` |

Data quality checks on the feed: the person ID must join to the ITAM `assigned_to` identifier (UPN, employee ID or email; pick one and normalize); effective dates must not be in the past by more than `[FILL]` days when received; every leaver must reach ITAM within `[FILL]` hours of the HR transaction.

## 3. Joiner

1. **Determine entitlement.** Map role/job code to a device profile (standard laptop, developer workstation, phone yes/no, peripherals) from the standard catalog `[FILL]`.
2. **Allocate.** Reserve an `IN_STOCK/AVAILABLE` device of the right model (`→ RESERVED`). Prefer a redeployable device that meets the redeploy standard before a new purchase (`PRACTICE`; CAMP lists redeployment among the main savings levers, S:36).
3. **Build.** Configure / provision (`IN_BUILD`); hand off to the imaging/provisioning skill for build standards.
4. **Deliver.** Desk-side handover, site pickup, or ship to home (`IN_TRANSIT/TO_USER` with tracking). Ship to arrive at least `[FILL]` business days before the start date.
5. **Assign.** On proof of delivery or handover: `IN_USE/INDIVIDUAL`, `assigned_to`, `assigned_date`, `in_service_date` (first deployment only), acknowledgement of the acceptable-use / equipment policy where required.
6. **Close.** Ticket closes only when the record shows `IN_USE` with the joiner as assignee.

Exceptions: start date moved (hold the reservation; release after `[FILL]` days), no-show (recover as a leaver with no use), stock shortage (escalate to procurement; record the delay against M-OPS-06).

## 4. Mover

| Change | Device action | Record action |
|---|---|---|
| Department / cost-center change only | None | Update `department` and `cost_center` (if cost follows the person) on the effective date |
| Location change (office to office, office to remote) | None, or ship peripherals | Update `location`; check country rules for shipping and data if crossing borders `[FILL]` |
| Role change needing a different device | Deliver new device first; recover old one within `[FILL]` days | New device T07; old device T09 → T10 |
| Move into a privileged / regulated role | May require a rebuilt or dedicated device `[FILL]` | Reimage record; reassignment |
| Transfer of a device to another person (manager request) | Reimage if policy requires `[FILL]` | T08 with both identities and a ticket |

Common failure: the device moves with the person but the record keeps the old department, location or cost center. Detect with discovery-vs-ITAM attribute conflicts (reconciliation AT-01).

## 5. Leaver

### 5.1 Timeline (fill in the organization's values)

| When | Action | Owner |
|---|---|---|
| On HR notice (T–`[FILL]` days) | Ticket created listing every device assigned to the person (from ITAM, plus MDM devices where the person is primary user) | ITAM automation / service desk |
| T–`[FILL]` days | Confirm return method with the manager: in-office handover, site drop-off, prepaid return kit, courier pickup | Service desk / logistics |
| T–`[FILL]` days (remote) | Ship return kit with prepaid label and packing instructions | Logistics |
| Last day | Access removed per identity process (not an ITAM step, but recorded on the ticket) | Identity / security |
| Last day | In-office: device handed over and receipted; state `IN_STOCK/PENDING_INSPECTION` | Service desk / stockroom |
| T+`[FILL]` days | Reminder 1 (person and manager) | Service desk |
| T+`[FILL]` days | Reminder 2 / escalation to manager and HR | Service desk / HR |
| T+`[FILL]` days | Device not returned: `MISSING/NOT_RETURNED`; remote lock if not already done; security informed | ITAM / security |
| T+`[FILL]` days | Recovery decision: further collection attempts, cost recovery (only where policy and local law allow; `VERIFY` with HR and Legal), or write-off approval | HR / finance / ITAM |

### 5.2 Receiving a leaver device back

- Confirm the serial against the ticket; record condition and missing accessories.
- **Legal hold check** before wipe; if held, keep the device in a secured location under `PENDING_INSPECTION` with a hold note.
- Remove activation / device locks (for example Apple Activation Lock or MDM enrollment ties) while the account is still accessible, or the device may be unusable for redeployment (`PRACTICE`).
- Reclaim software and subscriptions assigned to the person (SAM process).
- Triage: redeploy (wipe/reimage → `AVAILABLE`), repair, or retire.

### 5.3 Involuntary or immediate leavers

Coordinate with HR and security for same-day recovery, often during the exit meeting. Remote lock may need to happen before the person is told; that decision belongs to HR/security, not ITAM. Record the device actions with the same ticket.

## 6. Special cases

| Case | Handling |
|---|---|
| Contractor / vendor staff | Same flow, triggered by contract end date from the vendor-management or onboarding system `[FILL]`; ensure contractors exist in the identity source ITAM joins on. |
| Rehire within `[FILL]` days | Reissue the same device if it's still `PENDING_INSPECTION` and not wiped, only if policy allows. |
| Leave of absence | Keep or recover per policy `[FILL]`; record expected return date. |
| Deceased employee | Handle through HR with family liaison; no automated reminders. |
| International leaver | Customs, export control of encrypted devices and courier availability; see the logistics skill. |
| Personal (BYOD) device | No device recovery. Selective wipe of corporate data and removal of enrollment; record the action on the enrollment record. |
| Device bought by the leaver (employee purchase) | Only if policy allows `[FILL]`; requires wipe, license removal, transfer of ownership record and `DISPOSED/RESOLD` with proceeds. |

## 7. Controls, evidence and metrics

Controls (`PRACTICE`; owners and frequencies are organizational):

| Control | Type | Frequency | Evidence |
|---|---|---|---|
| Every HR leaver event produces a recovery ticket listing assigned devices | Preventive, automated | Per event | Ticket with device list |
| Inactive identities with `IN_USE` devices are reviewed | Detective | Weekly `[FILL]` | Report and follow-up tickets (reconciliation US-01) |
| Not-returned devices are locked and escalated on schedule | Corrective | Per timeline | MDM action log; escalation records |
| Joiner devices assigned before the start date | Detective | Per event | Assignment date vs. HR start date |

Metrics (definitions in the reporting skill's metrics catalog): leaver recovery rate (M-LC-04), leaver recovery time (M-LC-05), unrecovered leaver devices and value (M-LC-06), joiner on-time delivery (M-OPS-06), return-kit return rate (M-OPS-07).

## 8. RACI starter

| Activity | HR | Hiring manager | Service desk | Logistics / stockroom | ITAM | Identity / security | Legal |
|---|---|---|---|---|---|---|---|
| Publish JML event | A/R | I | I | I | I | I | — |
| Allocate and build joiner device | — | C | R | R | A | — | — |
| Deliver and assign | — | I | R | R | A | — | — |
| Mover record updates | C | I | R | — | A | — | — |
| Leaver device recovery | C | R (escalation) | R | R | A | I | — |
| Remote lock / wipe | — | — | C | — | C | A/R | C (hold) |
| Legal hold decision | C | — | — | — | I | C | A/R |
| Cost recovery / write-off | A | C | — | — | R | — | C |

Replace with the organization's actual RACI; this table is a starting point, not a finding.
