# Special handling: lost/stolen, warranty and RMA, loaners, mobile and BYOD

Use this file for device events outside the normal deploy-use-recover path. States and fields refer to `asset-data-model.md`.

**Basis:** CAMP covers loss-prevention, loaned-equipment, mobile-device and removable-storage policy topics (CAMP M:69-71), RMA handling within asset identification and its indicator "number of RMAs by vendor and asset type" (CAMP M:22, M:38; S:74-76), warranty as a defined term and savings lever (CAMP M:160; S:36), and Mobile Asset Management with its six best-practice goals (CAMP M:76, M:90-91). Procedures are `PRACTICE`; all thresholds and approvals are `[FILL]`.

## Contents
1. Lost or stolen devices
2. Warranty, break-fix and RMA
3. Loaner devices
4. Corporate mobile devices
5. BYOD

## 1. Lost or stolen devices

A lost or stolen device is a **security event first and an asset event second**. ITAM's job is to make sure the security response has accurate device facts and that the record ends in the right state with evidence.

### 1.1 Response sequence

| Step | Action | Owner | Record |
|---|---|---|---|
| 1 | User reports loss/theft to the service desk (and police where policy requires `[FILL]`) | User / service desk | Incident created; `incident_ref` |
| 2 | Look up the device: serial, tag, model, encryption status, last check-in, assigned user, data classification of the user's role | Service desk using ITAM + MDM | Device facts attached to the incident |
| 3 | Remote lock and/or wipe; revoke tokens and certificates; disable the device in identity and MDM | Security / endpoint team | `remote_action_ref` with timestamp |
| 4 | Data exposure assessment: was the device encrypted and locked? What data could be on it? Is breach notification analysis needed? | Security / privacy / legal | Assessment outcome on the incident. Notification duties are legal questions: `VERIFY` with Legal, don't infer. |
| 5 | Set state `MISSING/LOST` or `MISSING/STOLEN` | ITAM | State change with `incident_ref` |
| 6 | Search period `[FILL days]`; watch for the device checking in (reconciliation ST-07) | ITAM / security | Search notes |
| 7a | Found: receive, inspect, reimage before reuse → `IN_STOCK/PENDING_INSPECTION` | Stockroom | T17 |
| 7b | Not found: write-off approval; insurance claim if applicable; fixed-asset retirement; license reclaim → `DISPOSED/WRITTEN_OFF` | Finance / ITAM | T18 |
| 8 | Replacement device for the user follows the joiner allocation steps | Service desk / deployment | New assignment |

### 1.2 Rules and checks

- Don't mark a device lost or stolen without an incident reference.
- Don't retire or write off before the search period ends unless security or finance approves early closure.
- A `MISSING` device that checks in is a priority alert (ST-07): it may be recoverable, or it may indicate misuse.
- Track repeat losses by person, location and transit route; several losses in a pattern are a control problem, not bad luck.
- Metric: lost/stolen rate (M-LC-12) and unrecovered value (M-FIN-05).

## 2. Warranty, break-fix and RMA

### 2.1 Before any repair

1. Check warranty or support entitlement for the serial (manufacturer lookup or contract) and record the lookup date. Paying for a repair that was under warranty is a direct loss; CAMP names effective warranty management as a savings opportunity (S:36).
2. Decide: on-site repair, depot/vendor repair (RMA), swap from stock, or retire (beyond economic repair, threshold `[FILL]`% of replacement cost).
3. If the device leaves custody, decide what happens to the storage: wipe first, remove and retain the drive (where the support contract includes a keep-your-drive option `[VERIFY contract]`), or send under the vendor's data-handling terms `[VERIFY contract]`.

### 2.2 Record handling

| Situation | State | Record action |
|---|---|---|
| Repair on site, same unit | `IN_MAINTENANCE/ONSITE_REPAIR` → back to prior state | Incident reference; parts replaced |
| Vendor depot repair, same unit returns | `IN_MAINTENANCE/DEPOT_OR_RMA` (via `IN_TRANSIT/TO_VENDOR` if shipped) | RMA number; ship and return tracking |
| Motherboard replaced, serial or UUID changes | Back to prior state | Update the serial/UUID with the RMA reference and keep the old value in history; otherwise discovery and ITAM stop matching (reconciliation MT-03 / PR-01) |
| Vendor sends a replacement unit (advance exchange) | Old unit `DISPOSED/RMA_REPLACED`; new unit received as a new record (T03) | Link old and new serials; transfer assignment; check whether warranty restarts or continues `[VERIFY contract]` |
| Dead-on-arrival / wrong item at receiving | Stays in `IN_STOCK/RECEIVING` or `DEFECTIVE` | Vendor claim / RMA; counts toward the CAMP indicator "RMAs by vendor and asset type" (M:22) |

### 2.3 Metrics

RMA count by vendor and model (M-LC-13), repair turnaround (M-LC-14), in-use devices past warranty (M-LC-16), warranty recovery (M-FIN-07). Feed RMA and incident counts per model back to vendor management and acquisition; CAMP describes using per-asset incident history to judge vendor product performance (M:39, M:89).

## 3. Loaner devices

| Element | Practice |
|---|---|
| Pool | Dedicated devices in `IN_STOCK/LOANER_POOL`, sized `[FILL]` per site. Loaned equipment should be covered by a written policy (CAMP M:71). |
| Request | Ticket with purpose (repair cover, travel, short project), requested dates, approver if over `[FILL]` days. |
| Issue | `IN_USE/ON_LOAN`, `assigned_to`, `assignment_type = Loan`, `loan_due_date`; user acknowledges the loan terms. |
| Overdue | Reminder at due date, escalation at +`[FILL]` days, `MISSING/NOT_RETURNED` at +`[FILL]` days. |
| Return | Receive → wipe/reimage every time (`PENDING_INSPECTION` → `LOANER_POOL`). Never hand a loaner to the next person without a wipe. |
| Converted to permanent | Allowed only by approval `[FILL]`; reassignment as `INDIVIDUAL`; backfill the pool. |
| Metrics | Loaner overdue rate (M-LC-15); pool utilization (loan-days ÷ available device-days). |

Common failures: loaners tracked in a spreadsheet outside the repository, loans that silently become permanent, and loaners missing from refresh planning.

## 4. Corporate mobile devices

Mobile Asset Management controls easily transported devices that access corporate data and applications. CAMP's six best-practice goals for mobility are, in paraphrase: a mobile security process, accurate asset tracking, published mobile/BYOD policies, documentation tracking, mobile standards, and a help desk that covers mobile (CAMP M:76). CAMP also treats MDM capability as an essential part of ITAM for mobile (CAMP M:90-91).

| Topic | Practice |
|---|---|
| Identity | Track serial and IMEI on the asset; MDM device ID on the CI/enrollment; phone number and SIM/eSIM as a separate service/line record linked to the device. |
| Enrollment | Corporate devices enrolled in MDM before handover `[FILL: zero-touch / automated enrollment method]`; enrollment ties survive a wipe, which is good for theft protection and must be released before disposal or resale. |
| Carrier | Line activation, plan, contract end; number porting or line cancellation on leaver. |
| Lifecycle | Same canonical states; refresh cycle often tied to OS support end or carrier contract `[FILL]`. |
| Lost/stolen | Section 1, plus carrier suspension of the line and IMEI blocking where available `[FILL]`. |
| Disposition | Release activation/enrollment locks and remove from the MDM and carrier accounts before ITAD; certificate must list IMEI or serial. |

## 5. BYOD

- **No asset record.** The organization doesn't own the device. Track the **enrollment** (MDM / app-protection registration), the user's policy acceptance, and which corporate apps/data it can hold.
- Policy covers which device types are allowed, security minimums, what the organization can and can't see or wipe, support boundaries and the leaver process `[FILL]`. CAMP lists a mobile device policy covering both organization-provided and personal equipment (CAMP M:71) and notes BYOD as a growing risk area (CAMP M:90).
- **Leaver:** selective wipe of corporate data and enrollment removal, recorded on the enrollment record and the leaver ticket. Never full-wipe a personal device unless the user agreed to that in the BYOD terms and Legal confirms `VERIFY`.
- **Reporting:** report BYOD counts separately from hardware assets; don't add them to inventory, refresh or depreciation figures.
- **Stipends or allowances** for personal devices are a finance/HR matter, not an asset record.
