# Hardware lifecycle: preflight, working method and output variants

Detail behind Steps 2, 3 and the output format of `itam-hardware-lifecycle`. Read it for any design, assessment or procedure that will be used by someone other than the requester.

## Contents
1. Preflight checklist
2. Working method
3. Output variants

## 1. Preflight checklist

Confirm, or state as assumptions:
- **Asset classes in scope:** laptops only, all end-user devices, data center hardware, mobile.
- **The organization's state and substate names** and the system of record holding them. Without them, answer in canonical terms and give the mapping worksheet (`asset-data-model.md` §5).
- **Systems involved:** ITAM repository, HR or identity source, MDM and discovery, ERP, ITAD vendor portal.
- **Policy values the answer depends on:** refresh cycles, leaver return SLA and escalation, search period before write-off, loaner terms, capitalization threshold, approvers.
- **Ownership model:** owned, leased, device-as-a-service, BYOD.
- **Audience and output:** a design, a procedure, an assessment, a forecast or a quick answer.

Read `templates/company-profile.md` if present. Ask one question only when the answer would change materially (for example, leased vs. owned changes the whole end-of-life path); otherwise proceed with labeled assumptions.

## 2. Working method

- **Speak in states and transitions.** Express every lifecycle change as from-state → to-state (with substate), naming the trigger, the role, the required fields (`asset-data-model.md` §2) and the evidence (§4.2).
- **Map before redesigning.** For an existing lifecycle, build the mapping (org pair → canonical pair) and the gap list first. Recommend the smallest change: a substate before a new state, a control before a new workflow.
- **Assess with evidence.** For "where are we leaking devices", run the broken-transition tests in `lifecycle-state-model.md` §5 against the user's export and quantify each with counts and formulas. Never infer leakage volume without data.
- **Joiner-mover-leaver:** HR is the trigger and the authority on employment status; recovery starts before the last day; legal hold is checked before any wipe (`jml-playbook.md`).
- **Refresh:** use the template's eligibility rules and the forecast method; leave unknown policy values as `[FILL]`; hand cost and budget questions to `itam-financial-management` (`refresh-policy.md`).
- **Special events:** lost or stolen is a security incident first; an RMA serial change is recorded with the RMA reference; loaners are reimaged every time; BYOD gets no asset record (`special-handling.md`).
- **Disposal detail** (sanitization standards, ITAD vendor diligence, certificates) belongs to `itam-secure-disposition`; this skill covers the states and evidence gates around it.
- **Stockroom movements and physical counts** belong to `itam-logistics-warehouse`; transfers use transitions T06a and T06b.

## 3. Output variants

**Default (practitioner):**
1. **Answer:** the direct answer, design or procedure in two to five sentences.
2. **Detail:** state and transition tables, procedure steps, mapping or forecast table, with labels on material claims.
3. **Controls and evidence:** what proves each step happened and who owns it.
4. **Open items:** `[FILL]` values, assumptions and the questions that would close them.
5. **Risks:** what fails if this isn't done (unrecovered devices, data exposure, audit findings, write-offs).

**Executive variant:** lead with exposure and outcome (devices and value at risk, recovery rate, refresh backlog, audit findings), then three to five recommendations with owners; tables go to an appendix.

**Procedure variant** (when asked for an SOP or runbook): purpose, scope, roles, trigger, numbered steps with state changes, evidence, exceptions and metrics. Formal document control comes from `itam-sop-documentation`.

Sources: AssetForge §7, 11, 19; CAMP M:38-39; S:73-76.
