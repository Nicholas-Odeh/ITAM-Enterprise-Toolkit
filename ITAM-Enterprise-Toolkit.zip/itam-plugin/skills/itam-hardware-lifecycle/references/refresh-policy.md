# Hardware refresh policy template and forecasting method

Use this file to draft or review a refresh policy, decide which devices are eligible, or build a refresh forecast. The policy values are **organizational decisions**: never fill them from memory or "industry standard" figures. If the user hasn't supplied them and `templates/company-profile.md` doesn't have them, leave the `[FILL]` markers and say what's missing.

**Basis:** CAMP treats refresh as part of disposition and redeployment planning (the ITAD course topics include the refresh process; S:11) and lists redeployment, end of lease and disposal among HAM components (S:46); it defines redeployment as reassessing assets no longer needed and re-tasking them elsewhere, such as cascading replaced PCs to another department (CAMP M:149). The template structure is `PRACTICE`. Cost modeling (TCO, depreciation, lease vs. buy) belongs to the financial management skill.

## Part A — Policy template

> **[Organization] Hardware Refresh Policy** · Version `[FILL]` · Owner `[FILL role]` · Approved by `[FILL]` on `[FILL date]` · Next review `[FILL]`

**1. Purpose.** Replace end-user and infrastructure hardware on a predictable cycle so that devices remain supported, secure and productive, and so that refresh costs can be budgeted.

**2. Scope.** Applies to: `[FILL: asset classes, e.g. laptops, desktops, monitors, tablets, smartphones, servers]`. Excludes: `[FILL: e.g. BYOD, lab equipment, leased devices governed by lease terms]`.

**3. Refresh cycles.**

| Asset class | Standard cycle | Age measured from | Extended cycle allowed? | Notes |
|---|---|---|---|---|
| Laptop (standard user) | `[FILL]` months | `[FILL: in_service_date / purchase_date / received_date]` | `[FILL]` | |
| Laptop (high-performance / developer) | `[FILL]` | `[FILL]` | `[FILL]` | |
| Desktop / workstation | `[FILL]` | `[FILL]` | `[FILL]` | |
| Monitor | `[FILL]` (often on failure only) | `[FILL]` | `[FILL]` | |
| Smartphone | `[FILL]` | `[FILL]` | `[FILL]` | Carrier contract terms may apply |
| Tablet | `[FILL]` | `[FILL]` | `[FILL]` | |
| Leased devices | Lease term `[FILL]` | Lease start | No: return by lease end | Return before `lease_end_date` to avoid charges `[VERIFY contract]` |

**4. Eligibility.** A device is eligible for refresh when **any** of these is true:
- it has reached the standard cycle age;
- its model has reached end of support / end of security updates `[FILL: source of lifecycle dates]`;
- it can't run the supported OS or security baseline `[FILL]`;
- repair cost would exceed `[FILL]`% of replacement cost (beyond economic repair);
- it has had `[FILL]` hardware incidents in `[FILL]` months.

A device is **not** refreshed early for cosmetic reasons or preference without approval from `[FILL role]`.

**5. Exceptions and deferrals.** Early refresh or deferral requires `[FILL role]` approval, a reason, and an expiry date. Deferrals beyond `[FILL]` months need `[FILL role]`. Exceptions are recorded on the asset record.

**6. Process.**
1. Forecast eligible devices for the next `[FILL]` quarters (Part B) and agree the budget with `[FILL: IT finance]`.
2. Notify users `[FILL]` weeks before their refresh window.
3. Deliver the new device (joiner-style allocation, build and assignment).
4. Transfer user data per `[FILL: data migration standard]`.
5. Recover the old device within `[FILL]` business days (leaver-style recovery and escalation).
6. Triage the returned device: redeploy if it meets the redeploy standard (`[FILL: minimum remaining life, specification, condition]`), otherwise retire and dispose through the disposition process.

**7. Redeployment (cascade).** Returned devices meeting the redeploy standard go back to stock for `[FILL: e.g. loaner pool, contractors, lower-intensity roles]`. Devices are not redeployed past `[FILL]` months of total age.

**8. Roles.** Policy owner `[FILL]`; forecast and budget `[FILL]`; execution `[FILL]`; recovery `[FILL]`; disposition `[FILL]`.

**9. Measures.** Refresh compliance (M-LC-07), devices past refresh age (M-LC-08), old-device recovery after refresh (M-LC-04 applied to refresh returns), redeployment rate (M-LC-10), forecast variance (M-FIN-06).

**10. Review.** Reviewed every `[FILL]` months and when support or OS lifecycle dates change. (CAMP's policy-management indicators include the share of ITAM policies reviewed on a set cycle; CAMP M:24.)

## Part B — Refresh forecast method

1. **Population.** Devices in `IN_USE` and `IN_STOCK/AVAILABLE` for in-scope classes. Exclude `RETIRED`, `DISPOSED`, `MISSING`, and leased devices (forecast those from lease end dates instead).
2. **Eligibility date per device.** `eligibility_date = age_basis_date + cycle(class)`, or the model's end-of-support date if earlier. If `age_basis_date` is empty, report the device separately as "age unknown"; don't impute it.
3. **Bucket** by quarter (or month) of eligibility. Devices already past eligibility go into a "backlog" bucket, not the current quarter.
4. **Adjust** for known factors only when the user supplies them: approved deferrals, planned headcount change, redeployable stock that offsets new purchases.
5. **Output table:**

| Period | Class | Eligible (new) | Backlog carried | Approved deferrals | Expected redeploy offset | Net devices to buy |
|---|---|---|---|---|---|---|
| `[period]` | `[class]` | count | count | count | count | count |

6. **Cost** = net devices × unit price from the current standard catalog price `[FILL]`; hand off to the financial management skill for budgeting, depreciation and lease analysis.
7. **State assumptions** (cycle values used, age basis, data as-of date, excluded populations) and the count of devices with unknown age. Label each number `FACT` (counted from data) or `ASSUMPTION` (policy value assumed for the forecast).

## Part C — Review checklist for an existing policy

- Cycles stated per class, with the date the age is measured from.
- Eligibility criteria include support/security end dates, not only age.
- Recovery of the old device is required, with a deadline and an escalation path.
- Redeploy standard is defined and measurable.
- Leased devices are handled by lease terms, not the general cycle.
- Exceptions need approval and expire.
- Metrics and review cadence are stated.
- No numeric value is copied from a vendor or analyst default without an owner's approval.
