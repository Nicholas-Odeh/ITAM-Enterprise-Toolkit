# Lifecycle stage model and assessment method

Use this file to design or assess the hardware lifecycle **process**: what happens at each stage, who owns it, what control and evidence it needs, and how to map the organization's own lifecycle onto the canonical one. The record-level states, allowed transitions and field requirements live in `asset-data-model.md`; this file refers to them and doesn't repeat them.

**Basis:** `PRACTICE`, adapted from Nicholas's AssetForge §8 (21-stage lifecycle and per-stage attributes) and Stage 4 (lifecycle assessment), and ProcessForge §11 (broken-transition patterns). CAMP describes a comparable flow (need, assessment, sourcing, negotiation, purchase, deployment, in-service lifecycle, end-of-life decision, disposal or redeployment, with harvesting and documentation at the end) in S:66-68 and the HAM components in S:46. Role names below are responsibilities, not job titles (CAMP M:111); replace them with the organization's RACI.

## Contents
1. Don't force one lifecycle
2. Stage catalog (entry, exit, state, evidence)
3. Stage ownership, controls and KPIs
4. Lifecycle assessment method
5. Broken-transition tests
6. Mapping the organization's lifecycle

## 1. Don't force one lifecycle

Determine the organization's actual lifecycle first, compare it with this model, find the gaps, then map current states to the canonical states (AssetForge §8). Adapt by asset class: a monitor may skip Configure and Sanitize; a server adds change control at Deploy and Retire; a leased laptop ends at lessor return, not disposal. Stages 1–4 happen before an asset record usually exists.

## 2. Stage catalog

| # | Stage | Canonical state on exit | Entry criteria | Exit criteria | Minimum evidence |
|---|---|---|---|---|---|
| 1 | Strategy / need | none | Business need identified (new hire, project, refresh, failure) | Need documented and sized | Demand forecast or need statement |
| 2 | Plan | none | Need accepted | Standard model selected; budget line confirmed | Approved plan / budget |
| 3 | Request | none | Requester authorized | Request with catalog item and cost center | Request record |
| 4 | Approve | none | Request complete | Approved or rejected by delegated authority; non-standard items reviewed | Approval record |
| 5 | Source / acquire | `ON_ORDER` | Approval | PO issued to approved vendor | PO |
| 6 | Receive | `IN_STOCK/RECEIVING` | Delivery arrives | Quantities and serials checked against PO/ASN; discrepancies raised (short ship, damage, wrong model) | Receiving record, packing slip |
| 7 | Identify / record | `IN_STOCK/AVAILABLE` | Received | Tag affixed; record has every `IS+` field | Tag record; complete asset record |
| 8 | Stock / stage | `IN_STOCK` | Recorded | Stored in a controlled stockroom location | Stockroom transaction; cycle count |
| 9 | Configure | `IN_STOCK/IN_BUILD` | Allocated to a request or build batch | Build validated (see the imaging/provisioning skill) | Build and validation record |
| 10 | Deploy | `IN_TRANSIT/TO_USER` or directly `IN_USE` | Device ready | Delivered; receipt confirmed | Shipping record / proof of delivery or handover |
| 11 | Assign | `IN_USE` | Delivered | Assignee or custodian recorded; acknowledgement captured if policy requires | Assignment record; acknowledgement |
| 12 | Operate / use | `IN_USE` | Assigned | Ongoing: device seen by discovery and verified on cadence | Discovery record; attestation |
| 13 | Maintain | `IN_MAINTENANCE` | Fault reported | Repaired, replaced (RMA) or retired | Incident; RMA; repair record |
| 14 | Change / transfer (IMAC, mover) | `IN_USE` (new assignment) or `IN_TRANSIT` | Approved change | Record updated within `[FILL]` days of the physical move | Transfer ticket |
| 15 | Recover | `IN_STOCK/PENDING_INSPECTION` | Leaver, refresh, return or loan end | Device received; serial confirmed; condition assessed | Return receipt; chain of custody for shipped returns |
| 16 | Reuse / reharvest | `IN_STOCK/AVAILABLE` | Inspected | Wiped/reimaged; meets redeploy standard `[FILL]` | Wipe or reimage record |
| 17 | Refresh | `IN_USE` (new device) + old device to stage 15 | Eligible under `refresh-policy.md` | New device deployed and old device recovered | Refresh order; recovery record |
| 18 | Retire | `RETIRED/AWAITING_SANITIZATION` | Not reusable, end of life, beyond economic repair, lease end | Retirement approved; software and subscriptions reclaimed; legal hold checked | Retirement approval; reclaim record |
| 19 | Sanitize | `RETIRED/SANITIZED` | Retired | Sanitization verified per adopted standard `[FILL]` | Per-serial sanitization record |
| 20 | Dispose | `DISPOSED/*` | Sanitized, or handed to ITAD under custody | Certificate received and reconciled to serial | Manifest; certificate |
| 21 | Financial / contractual / record closure | `DISPOSED` (closed) | Disposed | Fixed-asset entry retired; CI retired; contracts and warranties updated; record locked | Finance closure; CI retirement |

CAMP stresses that disposition isn't only data destruction: removing data and software securely is half the responsibility, and disposing of the hardware properly (not to landfill, through a vetted vendor) is the other half (CAMP M:77). It also lists the end-of-life documentation as certificates of erasure, disposal and accountability, plus software harvesting (CAMP S:68).

## 3. Stage ownership, controls and KPIs

Roles are a starting RACI (`PRACTICE`); confirm against the organization's own. KPI IDs refer to the metrics catalog in the `itam-data-analysis-reporting` skill.

| # | Responsible | Accountable | Key control | System of record | Exception path | KPI |
|---|---|---|---|---|---|---|
| 3–4 | Requester; approver | Budget holder | Standard catalog; non-standard review | ITSM request | Rejected / returned for justification | M-LC-01 |
| 5 | Procurement | Procurement lead | PO only from approved request | ERP | Vendor substitution approval | M-LC-01 |
| 6 | Receiver | Hardware asset manager | Three-way check: PO, ASN/packing slip, physical serials | Receiving log / ITAM | Short, damaged or wrong-model shipment → vendor claim or RMA | M-OPS-01, M-OPS-12, M-LC-13 |
| 7 | Receiver / asset analyst | Hardware asset manager | Record complete before the device leaves receiving | ITAM | Missing data → device held in `RECEIVING` | M-LC-02, M-DQ-01 |
| 8 | Stockroom custodian | Hardware asset manager | Cycle count on cadence `[FILL]`; restricted access | ITAM | Count variance → investigation (reconciliation skill) | M-INV-06, M-LC-09 |
| 9 | Desktop engineering / imaging | Endpoint engineering lead | Build validation checklist | Imaging/MDM + ITAM | Failed build → rebuild or `DEFECTIVE` | M-OPS-04, M-OPS-05 |
| 10–11 | Deployment / logistics | Hardware asset manager | No `IN_USE` without assignee and proof of delivery | ITAM | Undelivered → carrier claim; refused → return | M-LC-03, M-OPS-06 |
| 12 | End user (custody); service desk | Asset owner (manager / cost center) | Discovery coverage; periodic attestation | Discovery/MDM + ITAM | Not seen → search (reconciliation PR-02) | M-INV-03, M-INV-05 |
| 13 | Service desk / field service | Hardware asset manager | Warranty check before paid repair; RMA tracking | ITSM + ITAM | Serial changed after repair → record update with RMA reference | M-LC-14, M-FIN-07 |
| 14 | Service desk / deployment | Hardware asset manager | Record update within `[FILL]` days | ITAM | Unrecorded move → attribute conflict exception | M-DQ-08 |
| 15 | Logistics / stockroom | Hardware asset manager (HR triggers) | HR-triggered recovery; escalation ladder | ITAM + HR | Not returned → `MISSING/NOT_RETURNED` | M-LC-04, M-LC-05, M-LC-06 |
| 16 | Imaging / stockroom | Hardware asset manager | Wipe/reimage before redeploy | ITAM | Fails standard → retire | M-LC-10, M-FIN-02 |
| 17 | Asset analyst; deployment | IT finance / hardware asset manager | Refresh eligibility per policy; old device recovered | ITAM | Deferral approved as exception | M-LC-07, M-LC-08 |
| 18 | Hardware asset manager | IT asset program owner | Approval; software reclaim; legal hold check | ITAM + SAM | Legal hold → retain, don't wipe | M-DIS-04 |
| 19 | Imaging / ITAD vendor | Information security | Method per standard; per-serial log | Wipe tool / ITAD portal | Wipe fails → physical destruction | M-DIS-02 |
| 20 | Logistics; ITAD vendor | Hardware asset manager | Signed manifest; certificate reconciled to serials | ITAM + ITAD portal | Serial missing from certificate → vendor escalation | M-DIS-03, M-DIS-05 |
| 21 | Asset analyst; finance; configuration manager | IT asset program owner | Closure checklist | ITAM, fixed-asset register, CMDB | Open item → record stays `RETIRED` | M-DIS-01 |

## 4. Lifecycle assessment method

Use this when asked to assess a lifecycle, find where devices "leak", or prepare for an audit (AssetForge Stage 4). For each stage, record:

- process definition (documented? followed?), owner, control points, systems, the canonical state reached, required data and its quality, handoffs, exceptions, evidence, automation, KPIs, risks, and the ITSM integration point.

Then look for these defects and report each with evidence:

| Defect | What it looks like | How to test |
|---|---|---|
| Missing state | Two different realities share one state (returned-awaiting-wipe vs. available) | Compare org states with the canonical list |
| Duplicate state | Two states mean the same thing | Mapping worksheet: two org pairs → one canonical pair with no distinguishing rule |
| Contradictory state | State conflicts with evidence (retired device checking in) | Reconciliation ST-codes |
| Dead-end state | Records enter and never leave | Count by state with dwell > threshold |
| Uncontrolled transition | Anyone can change any state | Review roles/ACLs and audit history |
| Manual bottleneck | Long dwell at a manual step | Dwell time by stage |
| Unowned transition | No role accountable for the step | RACI gaps |
| Missing evidence | Transition recorded without its required evidence | Sample transitions against `asset-data-model.md` 4.2 |
| Excessive handoffs | Many teams touch a simple step | Process walk-through |
| Lifecycle leakage | Devices exit the process unrecorded (leaver devices never returned, swapped RMA units, e-waste bins) | Reconciliation + leaver recovery rates |

Separate what you **observed** in data (`FACT`), what is **documented**, what is **actually practiced** (from interviews), what you **inferred**, and the **desired** future state. Never treat "the process probably ran" as evidence that it did.

## 5. Broken-transition tests

Run these against an asset export (with history if available). Each maps to a reconciliation exception code where one exists. Basis: ProcessForge §11 pattern list.

| Broken transition | Data test | Reconciliation code |
|---|---|---|
| Purchased, never received | PO line older than lead time + `[FILL]` days with no receipt | PR-09 |
| Received, never recorded | Receiving log serial with no asset record | PR-09 / PR-03 |
| Recorded, never deployed | `IN_STOCK/AVAILABLE` older than the stock-aging threshold | (aging report) |
| Deployed without ownership | `IN_USE` with empty `assigned_to` and no custodian | ST-05 |
| Assigned to a leaver | `IN_USE` with inactive HR status | US-01 |
| Transferred without repository update | Discovery user/location ≠ ITAM assignment | AT-01 |
| Recovered without stockroom receipt | Return ticket closed; record still `IN_USE` | (history test) |
| Retired without sanitization evidence | `RETIRED/SANITIZED` or `DISPOSED` with empty `sanitization_evidence_ref` | (evidence test) |
| Disposed without certificate | `DISPOSED` with empty `certificate_ref` | (evidence test) |
| CI active after asset retirement | Asset `RETIRED`/`DISPOSED`; CI operational or device checking in | ST-01 |
| Asset closed while CI operational | Same as above, from the CMDB side | ST-01 / PR-07 |
| Duplicate asset records | Same serial or tag on two records | DQ-03 |
| Orphaned CI | CI with no asset where the class expects one | PR-07 |
| Impossible state | State/substate pair not in the model, or prohibited transition in history | ST-04 |

## 6. Mapping the organization's lifecycle

1. List the organization's states and substates with counts (export grouped by state + substate).
2. For each pair, write its operational meaning in one sentence (interview the stockroom and service desk; documentation alone is often wrong).
3. Map each pair to one canonical pair in `asset-data-model.md` section 5. Mark gaps: unmapped canonical states, org pairs that need splitting, custom states that should become substates.
4. For each allowed transition (4.2), name the trigger, the system or role that performs it, and where the evidence is stored. Missing answers are findings.
5. Recommend the smallest change: rename or add a substate before adding a state; add a control before adding a workflow.
6. Output: the mapping table, a gap list (each with `FACT`/`INFERENCE` label and risk), and the changes in priority order.
