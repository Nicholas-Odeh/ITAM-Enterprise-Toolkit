---
name: itam-hardware-lifecycle
description: Use when designing, mapping or operating the hardware asset lifecycle: asset states and fields, onboarding and offboarding devices, unreturned leaver laptops, lost or stolen devices, refresh policy, eligibility and volume, warranty and RMA, loaners, mobile and BYOD, or where devices leak out of the lifecycle. Owns the canonical asset data model. Not for matching inventory lists (use itam-inventory-reconciliation), ServiceNow specifics (servicenow-itam), sanitization and ITAD (itam-secure-disposition) cost models (itam-financial-management) or return-kit shipping (itam-logistics-warehouse).
---

# IT Hardware Asset Lifecycle

The states a device record moves through, the fields each requires, and the events that move it. Core principle: **every state change has a trigger, an owner and evidence.** For hardware asset managers, service desk leads and auditors. Owns the canonical asset data model that other skills copy.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Every state change needs a trigger, an owner and evidence.** Never recommend a transition `asset-data-model.md` §4.3 prohibits.
7. **Organizational values stay organizational.** Refresh cycles, SLAs, search periods and approvers come from the user or company profile; otherwise `[FILL]`.
8. **Security and legal actions are not ITAM's call.** Wipe, legal hold, breach notification and employee cost recovery are decided by Security, Legal or HR; this skill records and sequences them.

## When to use

- "What fields must an asset have?", "map our states", "what substates do we need?"
- Onboarding or offboarding devices; "leavers keep their laptops".
- Lost or stolen devices; RMA changed the serial; loaners; refresh policy or forecast.
- "Where do devices leak out of our lifecycle?"

**When not to use:** matching lists or ghost devices (`itam-inventory-reconciliation`); stockroom moves, shipping and physical counts (`itam-logistics-warehouse`); ServiceNow tables and scripts (`servicenow-itam`); ITAD and sanitization (`itam-secure-disposition`); cost or budget (`itam-financial-management`); bench or stockroom capacity (`itam-capacity-planning`).

## Workflow

### Step 1 — Classify

| Request | Load |
|---|---|
| Required fields, field rules | `references/asset-data-model.md` §1–3 |
| State design or mapping | `references/asset-data-model.md` §4–5 |
| Stage design, lifecycle assessment, leakage | `references/lifecycle-state-model.md` |
| Joiner, mover, leaver | `references/jml-playbook.md` |
| Refresh | `references/refresh-policy.md` |
| Lost/stolen, warranty/RMA, loaners, mobile, BYOD | `references/special-handling.md` |

Most requests also need `asset-data-model.md` for state and field names.

### Step 2 — Preflight

Confirm or assume: asset classes; the organization's state names and system of record; policy values the answer depends on; ownership model (owned, leased, BYOD). Checklist: `references/lifecycle-method.md` §1.

### Step 3 — Do the work

- Express every change as from-state → to-state with trigger, role, required fields and evidence.
- Map the existing lifecycle to canonical states before redesigning; prefer a substate to a new state.
- Quantify leakage only from the user's export with the broken-transition tests.
- JML: HR is the trigger; recovery starts before the last day; legal hold before wipe.
- Lost or stolen is a security incident first.

Full method: `references/lifecycle-method.md` §2.

### Step 4 — Verify before release

- ★ Every state and transition named exists in `asset-data-model.md`, or is the user's value mapped to it.
- ★ No recommended transition is prohibited by §4.3; every transition names its evidence.
- ★ No organizational value is invented; each is supplied, `[FILL]` or `ASSUMPTION`.
- ★ Any wipe, lock, disposal or cost-recovery step includes the Security, Legal or HR decision point.
- Asset vs. CI responsibility is right for every field discussed.
- Counts and rates show formula, population and as-of date.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The leaver says it's in the post; mark it returned" | Returned means a stockroom receipt with a serial scan. |
| "It's been missing for months; just dispose of it" | `MISSING` → `DISPOSED` needs write-off approval (T18). |
| "The ITAD pickup happened, so it's disposed" | Disposed needs a certificate reconciled to the serial (T22). |
| "Everyone uses a 4-year refresh" | Not this organization's policy until they say so. |

Stop if you are about to: change a state without its evidence; write off or dispose without approval and certificate; tell ITAM to wipe a device without the Security or Legal decision.

## Common mistakes

| Mistake | Fix |
|---|---|
| Adding states for process nuance | Use substates; states break reporting |
| "Missing" used for both lost and unreturned | Separate `LOST`, `STOLEN`, `NOT_RETURNED` |
| Leaver recovery starts after the last day | Trigger from the HR notice; return kit before exit |
| No "returned, awaiting wipe" stage | Use `IN_STOCK/PENDING_INSPECTION` |

## If connectors are available

- **~~ITSM:** read records, state history and tickets; draft state changes for approval, then re-query.
- **~~HR:** read leaver and mover events (authoritative for status; minimum personal data).
- **~~endpoint management / ~~CMDB:** read last check-in, encryption and linked CIs; lock or wipe only drafted for Security.
- **~~finance / ~~email:** read book value for write-offs; draft leaver reminders, never send.

## Output format

1. **Answer** in two to five sentences.
2. **Detail:** state/transition tables, steps, mapping or forecast.
3. **Controls and evidence.**
4. **Open items:** `[FILL]` values and assumptions.
5. **Risks.**

Executive and procedure variants: `references/lifecycle-method.md` §3.

## Reference files

- `references/asset-data-model.md`: **canonical, shared** fields, attribute authority, state machine, mapping worksheet. Read for any field or state question; after editing run `bash scripts-sync-shared.sh` at the plugin root.
- `references/lifecycle-method.md`: preflight, full method, output variants. Read for substantial work.
- `references/lifecycle-state-model.md`: process stages, assessment, broken-transition tests. Read for process design.
- `references/jml-playbook.md`: joiner, mover, leaver procedures and timelines. Read for onboarding or offboarding.
- `references/refresh-policy.md`: refresh policy template and forecast method. Read for refresh.
- `references/special-handling.md`: lost/stolen, warranty/RMA, loaners, mobile, BYOD. Read for those events.
