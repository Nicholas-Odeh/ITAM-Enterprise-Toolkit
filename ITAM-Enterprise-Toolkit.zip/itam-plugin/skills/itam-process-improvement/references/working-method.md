# Working method: modes, preflight, DMAIC steps and deliverables

Detail moved from `SKILL.md` (v2 restructure). Templates are in `dmaic-templates.md`; tools in `tools-and-techniques.md`; process failure points and KPIs in `itam-process-catalog.md`. Methods condensed from ProcessForge; CAMP frames the same journey as moving from an "is" map to a "should" map (CAMP M:97, M:110), and notes that IAITAM practices build improvement into each process while ITIL treats continual improvement as a practice of its own (CAMP M:82).

## Contents
1. Modes and depth
2. Preflight in full
3. DMAIC, step by step
4. Release checks that are not blocking
5. Deliverables

## 1. Modes and depth

Match the depth to the request (ProcessForge §45):

| Mode | Typical request | Focus |
|---|---|---|
| Brainstorm | "ideas / quick wins to improve X" | Possibilities across the improvement levers, no implementation detail |
| Analysis | "why does X keep happening?" | Evidence and causes |
| Planning | "redesign X", "as-is / to-be" | Future state, owners and roadmap |
| Execution | "control plan", "keep it from slipping back" | Tasks, controls and KPIs |

## 2. Preflight in full

Confirm, or state assumptions for:

- **The process and its boundaries:** trigger, end point, in scope and out of scope, sites and asset classes.
- **The problem in measurable terms,** and who feels it (users, Finance, audit, security).
- **Evidence available:** ticket or request exports with timestamps (state changes, assignment groups), reconciliation results, audit findings, cycle-count results, stockroom aging, survey or complaint data.
- **Current metrics and data sources.** Read `templates/company-profile.md` for systems and lifecycle state names if present.
- **Owners and stakeholders:** process owner, sponsor, the teams in the handoffs.
- **Constraints:** budget, tooling, policy, union or HR rules, deadlines.
- **The decision needed and from whom.**

If information is missing, try in order: retrieve it, ask, assume and label, model scenarios, narrow the scope, escalate (ProcessForge §6). Ask only when the answer would change the recommended direction.

## 3. DMAIC, step by step

- **Define.** Rewrite the complaint as a measurable problem statement without false precision. Draft the charter (`dmaic-templates.md` §1): impact, objective, scope, CTQs, constraints, success measures, governance. Draw the SIPOC.
- **Measure.** Reconstruct the current state from evidence: steps, handoffs, queues, approvals, rework loops, systems, controls and the evidence each one produces. Build the KPI baseline table. Where timestamps exist, measure lead time, wait time and the variants actually followed (`tools-and-techniques.md` §3–4). Check the ITAM lifecycle transitions the process touches for breaks, for example received but never recorded, or retired without sanitization evidence (`itam-process-catalog.md` §1).
- **Analyze.** Separate symptoms from causes. Find waste (including handoffs and manual work, `tools-and-techniques.md` §5) and the bottleneck. Use 5 Whys, a fishbone, Pareto or FMEA as the problem warrants. Test each candidate cause against data before calling it a root cause.
- **Improve.** Generate options across the improvement levers and investment tiers, including a no-cost option. Evaluate them transparently, using weights only if they can be justified. Design the future state with the 15 elements and the design principles in `dmaic-templates.md` §4, and list the steps removed, combined and automated. Plan a pilot with success, expansion and rollback criteria for any significant change. Cost and benefit go through `itam-financial-management`, keeping hard savings, cost avoidance and capacity separate.
- **Control.** Write the control plan (`dmaic-templates.md` §6): KPI, threshold, frequency, owner, data source, response and escalation. Design the exception path, not only the happy path. Define the audit evidence. Hand the new procedure to `itam-sop-documentation`.
- **Trace it.** For audit-sensitive work, link FIND → RC → IMP → CTRL → KPI so every change shows why it exists and how it will be verified (ProcessForge §44).
- **Align (when asked or useful).** Map the process to ITIL 4 practices and the continual improvement model, and to ISO/IEC 19770-1 process areas (`tools-and-techniques.md` §7). State the edition used and mark clause-level claims `VERIFY`.

## 4. Release checks that are not blocking

- The future state covers exceptions and escalations, not just the happy path.
- Asset-record vs. CI ownership is correct in the future state.
- The simplest effective option was considered, and automation follows simplification.
- Significant changes have a pilot and a rollback.
- The red-team questions in `tools-and-techniques.md` §8 are answered.

## 5. Deliverables

**Practitioner package** (default for a full DMAIC; include only the sections the request needs):
1. Summary: problem, key findings, recommendation, next action.
2. Charter.
3. Known facts, assumptions and missing data.
4. SIPOC and current-state map.
5. KPI baseline.
6. Root-cause analysis.
7. Options and trade-offs.
8. Future-state map and specification, with the before/after comparison (`dmaic-templates.md` §4).
9. Control plan.
10. Roadmap: 0–30 days, 31–90 days, 3–6 months, 6–18 months (ProcessForge §26).
11. Risks and open questions.

Use Mermaid flowcharts or numbered swimlane steps for maps.

**Executive brief** (one page, ProcessForge §29): situation, business impact, evidence, recommendation, financial impact (classified), risk of doing nothing, decision required, timeline.

**User communication**, when the change affects end users: what is changing, why, when, what they need to do, and where to get help.
