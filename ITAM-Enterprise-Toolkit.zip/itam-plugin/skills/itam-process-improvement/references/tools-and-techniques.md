# Tools and techniques for ITAM process improvement

Pick only the tools the problem needs (ProcessForge §4.4). The methods are standard Lean and Six Sigma practice (`PRACTICE`), adapted to ITAM. Framework references in §7 are for orientation: VERIFY the edition and wording before citing a requirement.

Contents: 1. 5 Whys · 2. Fishbone and Pareto · 3. Value stream mapping · 4. Event-log analysis (process mining) · 5. Waste, levers and tiers · 6. FMEA · 7. Framework alignment (ITIL, ISO/IEC 19770, IAITAM) · 8. Change, communication and red-team checks

---

## 1. 5 Whys

Ask "why?" repeatedly, starting from a specific, observed problem, until you reach a cause the organization can act on. That usually takes about five rounds, but the number isn't a rule.

Rules:
- Start from a measured symptom, not a general complaint.
- Each answer must be supported by evidence (a ticket, a log entry, an interview note); mark unsupported answers as hypotheses.
- Branch when there are several causes. A single chain often hides contributing factors.
- Stop at a process, control, design or ownership cause. "Human error" is not a root cause; ask why the process allowed the error.

**ITAM example** (illustrative only):
1. Leaver laptops aren't recovered. *Why?*
2. Recovery tasks aren't created for many leavers. *Why?*
3. The task is created only when the manager raises a ticket. *Why?*
4. There is no automated trigger from the HR termination event. *Why?*
5. The HR-to-ITSM integration carries joiners but not leavers.

Result: candidate root cause RC (design gap). Validate it by sampling terminations against recovery tasks.

## 2. Fishbone (Ishikawa) and Pareto

**Fishbone categories adapted to ITAM** (use the ones that fit):

| Category | Example causes |
|---|---|
| Policy and process | no defined trigger, unclear standard vs. non-standard rules, exceptions with no expiry |
| People and roles | no accountable owner, training gaps, incentives favoring speed over recording |
| Systems and integration | missing HR or procurement feed, manual imports, state models that don't match the process |
| Data | inconsistent serial formats, missing assignment or cost center, stale discovery |
| Suppliers and vendors | no ASN or serial list, tags applied wrongly, ITAD certificates without serials |
| Measurement | KPIs measuring activity not outcome, no baseline, inconsistent definitions |
| Location and logistics | remote users, multiple stockrooms, international shipping |

**Pareto.** Rank exception or defect categories by frequency or cost, and show the cumulative percentage. Fix the few categories that drive most of the impact first. Check that the categories are mutually exclusive, and rank by impact (value, risk) as well as count. A rare category can still be the most expensive one.

## 3. Value stream mapping (VSM)

Map the end-to-end flow for one product or service, for example "new starter receives a ready laptop", with information and material flows.

| Metric | Definition |
|---|---|
| Lead time (LT) | elapsed time from when work enters a step to when it leaves, including waiting |
| Process time (PT) | hands-on time to do the step if uninterrupted |
| Wait time | LT − PT |
| % complete and accurate (%C&A) | share of the step's output that the next step can use without correction, clarification or rework |
| Rolled %C&A | product of the step %C&A values: the share that passes the whole stream first time |
| Activity ratio (flow efficiency) | Σ PT ÷ Σ LT |
| Queue / work in progress | items waiting before each step (for example devices awaiting imaging, recovery tasks open) |
| Throughput | items completed per period |

Steps:
1. Choose the value stream and its customer.
2. Walk the current state with the people who do the work.
3. Record LT, PT and %C&A per step from data or a timed sample, labeling estimates.
4. Mark handoffs, queues, approvals and rework loops.
5. Compute the totals.
6. Design the future state: remove, combine and parallelize steps, and fix the low-%C&A handoffs.
7. Write an implementation plan.

In ITAM value streams the biggest losses are usually wait time at handoffs and approvals, and rework caused by bad data upstream (low %C&A on asset data). Look there first.

## 4. Event-log analysis (process mining)

When timestamped records exist (request and task state changes, asset state-change history, approval logs), analyze the process as it actually runs (ProcessForge §14).

- **Minimum event-log fields:** case ID (request, task or asset), activity (state or step), timestamp, plus resource or assignment group if available.
- **Questions:**
  - What paths actually occur and how often?
  - Where do cases wait?
  - Which loops repeat?
  - Which steps are skipped?
  - Where do approvals stall?
  - Which variants breach the SLA?
- Separate retrospective (what happened), diagnostic (why), predictive (what is likely) and prescriptive (what to do). Don't claim causation from correlation; confirm causes with the people involved and with targeted data.
- Spreadsheet-level analysis (pivots of durations between states) is often enough. Dedicated process-mining tools are a Tier 3 investment.

## 5. Waste, improvement levers and tiers

**Lean waste translated to ITAM knowledge work** (ProcessForge §17):

| Waste | ITAM example |
|---|---|
| Waiting | approval queues, devices waiting for imaging, recovery tasks waiting for a manager |
| Over-processing | approvals for standard catalog items, duplicate data entry in procurement and ITAM tools |
| Defects and rework | wrong serials, wrong model shipped, records corrected after reconciliation |
| Excess inventory | over-ordered stock, aged devices in stockrooms, unused licenses |
| Unnecessary movement of information | spreadsheets emailed between teams, re-keying from PDFs |
| Transport | shipping devices between depots unnecessarily |
| Unused knowledge | technicians' workarounds never fed back into the process |
| Duplicate reporting and record-keeping | the same KPI built by hand in several places |
| Excessive exception management | exceptions that have become the normal path |
| Handoffs | a request passing service desk → procurement → receiving → imaging → deskside, each with its own queue and a chance to lose data |
| Manual, repeatable work | re-keying serials, hand-built reconciliations, emailing reminders; candidates for automation only after the step is simplified (rule: simplify before automating) |

The last two rows come from the Operations plugin's process-optimization waste list (waiting, rework, handoffs, over-processing, manual work), which maps onto the rows above. Count handoffs and wait time per handoff in the current-state map (`dmaic-templates.md` §3); each handoff is a likely point of delay and data loss.

**Improvement levers** (ProcessForge §15). Brainstorm across all of them before choosing:
eliminate · simplify · standardize · consolidate · automate · integrate · prevent (mistake-proof) · detect earlier · delegate · reassign ownership · parallelize · self-service · improve data · improve controls · improve policy · improve technology.

Mistake-proofing examples:
- serial capture by scanner instead of typing
- mandatory fields gated by state
- the catalog item that pre-selects the standard model
- automated triggers from HR events

**Investment tiers** (ProcessForge §16). Aim to have something in each tier:
- **Tier 1 (no or low cost):** clarify policy, fix ownership, standard work, report changes, training, remove approvals, clean data.
- **Tier 2 (moderate):** workflow redesign, platform configuration, integrations, automated reconciliation, notifications.
- **Tier 3 (transformational):** lifecycle orchestration, platform modernization, process-mining infrastructure, operating-model change.

The most sophisticated option isn't automatically the best one.

## 6. FMEA (failure mode and effects analysis)

Use it to rank risks in a redesigned process before rollout, or to prioritize failure points.

| Step | Failure mode | Effect | Severity (S) | Cause | Occurrence (O) | Current control | Detection (D) | RPN = S×O×D | Action | Owner | Revised S/O/D |
|---|---|---|---|---|---|---|---|---|---|---|---|

- Agree the rating scales (for example 1–10) and their definitions with the team before scoring, and write them down.
- Address high-severity items even when the RPN is low. The RPN is a prioritization aid, not a risk measure.
- For enterprise risk scoring, defer to the organization's risk methodology (`itam-risk-controls-audit`).

## 7. Framework alignment

**ITIL.** ProcessForge and AssetForge reference both ITIL 4 and a newer "ITIL Version 5". Ask which edition the organization uses. VERIFY the edition and practice names against the official publication before citing them. In ITIL 4, the practices most relevant to ITAM process work are:

| ITIL 4 practice | ITAM process touchpoints |
|---|---|
| IT asset management | the whole catalog |
| Service configuration management | asset ↔ CI linkage, CI retirement on disposal |
| Continual improvement | this skill's DMAIC cycle and improvement register |
| Service request management | P01, P04, P05, P11 |
| Change enablement | changes to the process, tools and integrations; IMAC changes affecting CIs |
| Deployment management | P04, P10 |
| Supplier management | P02, P09, P14, P16 |
| Service financial management | P13, refresh budgeting |
| Information security management | P06, P15, P17 |
| Measurement and reporting | KPIs and the control plan |
| Service desk / incident management | P09, P17, asset-related incidents |

- **The ITIL 4 continual improvement model** asks seven questions in sequence: What is the vision? Where are we now? Where do we want to be? How do we get there? Take action. Did we get there? How do we keep the momentum going? These map naturally onto DMAIC.
- **The ITIL 4 guiding principles** are useful as design checks for the future state: focus on value; start where you are; progress iteratively with feedback; collaborate and promote visibility; think and work holistically; keep it simple and practical; optimize and automate.
- ProcessForge describes an ITIL Version 5 product and service lifecycle (discover, design, acquire, build, transition, operate, deliver, support). Use it only after VERIFYING it against the official publication.

**CAMP / IAITAM.**
- CAMP positions ITAM and ITSM as distinct but complementary. ITAM supplies the asset, financial and contractual facts that service management relies on (CAMP M:78–89).
- The IAITAM practices build improvement into each key process area (KPA), while ITIL treats continual improvement as its own practice (CAMP M:82).
- CAMP's program-building sequence moves through self-assessment, SWOT, an "is" map vs. a "should" map, roles, cost/benefit, business case, buy-in and project planning (CAMP M:96–110).
- Each KPA has example indicators that can serve as process KPIs (CAMP M:22–24).

**ISO/IEC 19770 family.** This is the international standard family for IT asset management. Part 1 specifies requirements for an ITAM management system. Map process improvements to its process areas only from the edition the organization holds. Don't quote clause numbers from memory (VERIFY current edition).

**ISO/IEC TR 33014.** ProcessForge cites it as guidance on process improvement at strategic, tactical and operational levels. VERIFY the edition before citing it.

**NIST SP 1800-5** (IT Asset Management) is a practice guide that ProcessForge lists among the ITAM references. Use it for orientation; VERIFY the content before citing it.

## 8. Change, communication and red-team checks

**Change management** (ProcessForge §28):
- who is affected
- what behavior changes, what work disappears and what new responsibilities appear
- likely objections, training, incentives and the support needed

Treat resistance as information. It may reveal workload, unclear benefit, poor design or legitimate exceptions.

**Communications** (ProcessForge §29–31):
- **Leadership:** situation, impact, evidence, recommendation, financial impact, risk of doing nothing, decision, timeline.
- **Managers:** responsibilities, resources, schedule, metrics, escalation.
- **Users:** what changes, why, when, what to do, where to get help.

**Challenge statements to test with evidence** (ProcessForge §40):
- "We have always done it this way."
- "This needs an approval."
- "The tool can't do it."
- "We need more people."
- "Automation will fix it."
- "The data is accurate."
- "The CMDB is the source of truth."
- "The policy requires it."

**Red-team questions before release** (ProcessForge §43):
- What would make this recommendation wrong?
- Which assumption matters most?
- Who would disagree, and why?
- What unintended effect could occur?
- Where will the bottleneck move?
- Which control could fail?
- Which data could invalidate the analysis?
- Which financial assumption is weakest?
- Which dependency could block execution?
- What simpler option wasn't considered?
