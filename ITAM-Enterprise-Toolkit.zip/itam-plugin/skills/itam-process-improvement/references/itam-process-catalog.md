# ITAM process catalog: failure points and KPIs

Use this file to scope an ITAM process and to seed the current-state analysis. The failure points are **typical patterns** (`PRACTICE`, drawing on ProcessForge §11–12). They are hypotheses to test against the user's evidence, never findings in themselves. KPI targets are deliberately left out: targets are set by the process owner. CAMP example indicators are paraphrased with page citations (CAMP M:22–24). Adapt names and states to the user's lifecycle model (`itam-hardware-lifecycle`, `templates/company-profile.md`).

**Contents:** 1. Lifecycle chain and broken transitions · 2. Process catalog · 3. Data-quality dimensions to test in any ITAM process

## 1. Lifecycle chain and broken transitions

ProcessForge §11 lifecycle: Plan → Request → Approve → Source → Procure → Receive → Identify → Record → Stock → Assign → Deploy → Operate → Maintain → Transfer → Recover → Reconcile → Refresh → Retire → Sanitize → Dispose → Verify closure.

For each stage in the process being improved, determine:
- asset owner, process owner, system of record
- required data and the trigger event
- control and evidence
- upstream and downstream dependencies
- exception path
- state transition
- financial and compliance consequences

**Broken-transition checklist** (each is a detectable query once the data exists):

| Broken transition | Typical detection |
|---|---|
| Purchased, never received | PO lines past their expected date with no receipt |
| Received, never recorded | receipt or ASN serials missing from the asset repository |
| Recorded, never deployed | in-stock assets older than the stock-aging threshold |
| Deployed without an owner | in-use assets with no assigned user or cost center |
| Transferred without a repository update | discovery user or location ≠ asset record |
| Recovered without stockroom receipt | leaver tasks closed "returned" with no stock transaction |
| Retired without sanitization evidence | retired or disposed assets without a wipe record |
| Disposed without a certificate | disposed assets not on an ITAD certificate or settlement |
| CI active after asset retirement | asset retired or disposed while its linked CI is still operational |
| Asset closed while CI still operational | the reverse of the above |
| Duplicate asset records | same normalized serial on more than one asset |
| Orphaned CIs | CIs with no asset where an asset is expected |
| Impossible states | for example in stock with an assigned user, or disposed with recent discovery |

## 2. Process catalog

Format: **Trigger → end** · typical failure points · KPIs (formula) · evidence · related skills.

### P01 Request and approval (standard and non-standard)
- **Trigger → end:** a user or manager request → an approved request ready for fulfillment, or rejected.
- **Failure points:** non-standard requests with no clear approver; approvals chained serially; requests bypassing the catalog (purchase cards, direct vendor orders); no check against available stock before buying.
- **KPIs:**
  - Approval cycle time by standard vs. non-standard (approved time − submitted time)
  - Share of requests that are non-standard
  - Share of requests filled from stock
  - CAMP examples: request and approval counts by department and asset type, standard vs. non-standard; time to approve or reject; fulfillment timeframe (CAMP M:22)
  - % of deployed assets that are part of the IT standard (CAMP M:24)
- **Evidence:** request records, approval history.
- **Related:** `itam-acquisition-procurement`.

### P02 Procure to receive
- **Trigger → end:** approved request → goods received against a PO.
- **Failure points:** PO without asset-relevant data (model, quantity, cost center); no ASN or serial list from the supplier; partial shipments not tracked; contract prices not applied.
- **KPIs:**
  - Order-to-receipt lead time
  - % of POs with a supplier serial list
  - Price variance vs. contract (see invoice reconciliation)
  - CAMP examples: negotiation duration; quality of RFx responses; projected ROI and TCO captured for later comparison (CAMP M:22)
- **Evidence:** PO, ASN, packing list.
- **Related:** `itam-acquisition-procurement`, `itam-vendor-contract-management`.

### P03 Receiving, tagging and registration
- **Trigger → end:** delivery at the dock → an asset record with tag, serial, model, PO, cost and state "in stock".
- **Failure points:** batch data entry days after receipt; serials keyed by hand; tags applied inconsistently by suppliers; no check of received serials against the ASN; assets placed on shelves before they're recorded.
- **KPIs:**
  - Receiving-to-inventory latency (staging time)
  - % of received units recorded within the SLA
  - Serial data-entry error rate
  - CAMP examples: received date and time; time from receipt to inventory; vendor pre-delivery accuracy, such as whether the supplier applied the tag correctly (CAMP M:22)
- **Evidence:** receiving log, asset create audit trail.
- **Related:** `itam-logistics-warehouse`, `servicenow-itam`.

### P04 Provisioning and deployment
- **Trigger → end:** approved request with stock allocated → device in use with the user, and the asset record assigned.
- **Failure points:** imaging rework; deployment not recorded until the user complains; device shipped before the asset is assigned; wrong model allocated.
- **KPIs:**
  - Request-to-deployed cycle time
  - First-pass yield (deployments with no rework ÷ deployments)
  - % of deployments with the assignment recorded on ship or handover
  - Onboarding readiness (devices ready by start date ÷ new starters)
- **Evidence:** fulfillment tasks, shipping records, handover acknowledgment.
- **Related:** `endpoint-imaging-provisioning`, `itam-hardware-lifecycle`.

### P05 IMAC, transfer and reassignment
- **Trigger → end:** move or change request → asset record matches the new user, location and cost center.
- **Failure points:** desk-side swaps without tickets; peer-to-peer handovers; location changes not captured.
- **KPIs:**
  - % of transfers recorded within N days (N set by the owner)
  - Assignment accuracy (sample: physical or discovery user = record user)
  - CAMP example: % of configuration changes tied to a service desk ticket (CAMP M:24)
- **Evidence:** change or request records, discovery user data.
- **Related:** `itam-hardware-lifecycle`.

### P06 Joiner-mover-leaver device recovery
- **Trigger → end:** HR termination or role change → device returned, received, wiped and restocked (or written off).
- **Failure points:** no automated trigger from HR; leaver has no recorded assignment; return kits not sent or not tracked; manager escalation missing; remote leavers in other countries; write-off with no approval.
- **KPIs:**
  - Leaver recovery rate within the SLA (devices recovered within SLA ÷ devices assigned to leavers)
  - Median days to recover
  - Unrecovered value (NBV or replacement cost, from `itam-financial-management`)
  - % of leavers with an accurate assignment at termination
- **Evidence:** HR feed, recovery tasks, carrier tracking, stock receipt.
- **Related:** `itam-hardware-lifecycle`, `itam-logistics-warehouse`.

### P07 Stockroom management and cycle count
- **Trigger → end:** stock movements and a count schedule → stock records match the shelves; variances resolved.
- **Failure points:** issues without transactions; returns left in a "pending" area; no blind counts; adjustments posted by the counter without approval; aged stock not redeployed.
- **KPIs:**
  - Count accuracy (matched ÷ book records counted)
  - Variance units and value
  - Stock aging (days in stock by state)
  - Redeployment rate (deployments filled from used stock ÷ deployments)
  - CAMP examples: how, by whom and when inventory increased or decreased; reconciliation errors vs. physical inventory (CAMP M:22)
- **Evidence:** count sheets, adjustment approvals.
- **Related:** `itam-logistics-warehouse`; workbook in `itam-spreadsheet-models` (F).

### P08 Inventory reconciliation
- **Trigger → end:** scheduled cycle → exceptions classified, assigned and closed.
- **Failure points:** no authoritative source per field; inconsistent serial formats; discovery coverage gaps treated as missing assets; exceptions listed but never owned; the same exceptions recurring every cycle.
- **KPIs:** (AssetForge §26.1)
  - Reconciliation match rate
  - Discovery coverage
  - Ownership completeness
  - Exception aging
  - Recurrence rate (exceptions seen in the previous cycle ÷ exceptions)
  - CAMP example: reconciliation errors between inventory and e-discovery (CAMP M:22)
- **Evidence:** reconciliation output, exception log.
- **Related:** `itam-inventory-reconciliation`, `servicenow-itam`.

### P09 Break-fix, warranty and RMA
- **Trigger → end:** fault reported → device repaired or replaced, with the asset record updated (serial swap, state).
- **Failure points:** paying for out-of-warranty repairs on in-warranty units; replacement serial not recorded; RMA units not tracked back; no failure data by model.
- **KPIs:**
  - % of repairs claimed under warranty when eligible
  - RMA turnaround
  - Failure rate by model
  - CAMP example: number of RMAs by vendor and asset type (CAMP M:22)
- **Evidence:** incident and repair records, warranty claims.
- **Related:** `itam-hardware-lifecycle`, `itam-vendor-contract-management`.

### P10 Hardware refresh
- **Trigger → end:** asset reaches its refresh age or lease end → new device deployed, old device recovered and dispositioned.
- **Failure points:** forecast built on bad purchase dates; old devices not recovered after a swap; refresh batches outrunning imaging capacity; refreshing devices that could be redeployed.
- **KPIs:**
  - Refresh completion vs. plan
  - Old-device recovery rate after a swap
  - Forecast variance
  - Units past their refresh age (backlog)
- **Evidence:** refresh plan, swap records.
- **Related:** `itam-hardware-lifecycle`, `itam-financial-management`.

### P11 Software request, install and reharvest
- **Trigger → end:** software request → licensed install or assignment; unused licenses reclaimed.
- **Failure points:** installs outside the request process; no usage data; reclaimed licenses never returned to the pool; SaaS assignments surviving the leaver.
- **KPIs:**
  - Request-to-install time
  - Reharvested licenses per period, and their value (split hard vs. avoidance)
  - % of SaaS assignments removed within N days of leaving
  - CAMP example: % of software downloads where licensing information reached ITAM (CAMP M:22)
- **Evidence:** request, install and usage data.
- **Related:** `itam-software-license-management`.

### P12 License compliance, true-up and audit response
- **Trigger → end:** renewal, true-up date or audit letter → effective license position with evidence; response delivered.
- **Failure points:** entitlement proof scattered; normalization gaps; the position calculated only at audit time; no single coordinator for publisher contact.
- **KPIs:**
  - % of installed titles compliant with license terms (CAMP M:23)
  - % of license agreements managed by ITAM and linked to assets (CAMP M:23)
  - Days to produce the ELP
  - Unbudgeted true-up spend
- **Evidence:** ELP, proof of entitlement.
- **Related:** `itam-software-license-management`, `itam-risk-controls-audit`.

### P13 Invoice reconciliation and chargeback
- **Trigger → end:** invoice received or period close → invoice matched to PO, receipt and asset; costs charged or shown to cost centers.
- **Failure points:** no serials on invoices; recurring billing for returned or disposed assets; cost center missing on asset records; disputes unresolved across cycles.
- **KPIs:**
  - % of invoices reconciled for accuracy of charge; % of software invoices reconciled to the purchase description; % of contracts reviewed for financial terms before signing (all CAMP M:24)
  - Variance found and recovered
  - Unallocated cost share
- **Evidence:** reconciliation log, credit notes, allocation report.
- **Related:** `itam-financial-management`.

### P14 Lease return
- **Trigger → end:** lease end approaching → units returned (or bought out) with lessor receipt; billing stopped.
- **Failure points:** lease end dates missing from asset records; late notice; units not found; wipe before return not evidenced; holdover rent.
- **KPIs:**
  - % of units returned by lease end
  - Holdover cost
  - Non-return or damage charges
  - % of leased assets with an end date on the record
- **Evidence:** lease schedule, return receipts.
- **Related:** `itam-financial-management`, `itam-secure-disposition`.

### P15 Retirement, sanitization and disposal
- **Trigger → end:** retirement decision → data sanitized with evidence, asset disposed or remarketed, certificate matched, record closed, linked CI retired.
- **Failure points:** devices waiting unsecured; wipe evidence not linked to the serial; certificates listing quantities rather than serials; software not harvested; CI left active.
- **KPIs:**
  - % of assets through formal disposal; % with data secured before ownership transfer; % with software harvested where applicable (all CAMP M:23)
  - % of hardware disposed per local regulations (CAMP M:23)
  - Retirement-to-certificate cycle time
  - Recovered value
- **Evidence:** wipe logs, chain of custody, certificates of destruction or recycling.
- **Related:** `itam-secure-disposition`.

### P16 Vendor performance review
- **Trigger → end:** review period → scorecard reviewed with the vendor, actions agreed.
- **Failure points:** scorecards built from anecdotes; no evidence links; actions not tracked between reviews.
- **KPIs:**
  - Scorecard reviews completed on schedule (with a captured review date and time); frequency of issue-resolution meetings; vendor contact data kept current; the vendor's ability to meet contractual obligations (all CAMP M:24)
- **Evidence:** scorecard, minutes, SLA reports.
- **Related:** `itam-vendor-contract-management`; workbook in `itam-spreadsheet-models` (E).

### P17 Lost or stolen device
- **Trigger → end:** loss reported → device locked or wiped remotely, incident logged, asset state updated, write-off approved.
- **Failure points:** late reporting; no link between the security incident and the asset record; write-off without approval; device later rediscovered but still marked lost.
- **KPIs:**
  - Time from report to remote lock
  - % of losses with an incident reference
  - Loss rate per 1,000 devices
  - Written-off NBV
- **Evidence:** incident record, MDM action log, approval.
- **Related:** `itam-hardware-lifecycle`, `itam-risk-controls-audit`.

## 3. Data-quality dimensions to test in any ITAM process

From ProcessForge §12:
- **Completeness:** the expected population exists.
- **Accuracy:** attributes are right.
- **Consistency:** authoritative systems agree.
- **Timeliness:** changes are recorded promptly.
- **Uniqueness:** no duplicates.
- **Validity:** formats and lifecycle logic hold.
- **Ownership:** every controlled asset has an accountable owner.
- **Lifecycle integrity:** state values are logically consistent.
- **Traceability:** the asset can be followed from acquisition to disposal.

Express findings as: population → match → mismatch → exception → root cause → remediation → owner → verification.
