# DMAIC templates for ITAM

Condensed from ProcessForge §8–10, 18–19, 22–23, 26–27, 33, 44. Fill in only what the decision needs. Leave a field blank or write "unknown — <how to obtain>" rather than inventing a value.

Contents: 1. Charter · 2. SIPOC · 3. Process maps and KPI baseline · 4. Future-state specification · 5. Options, pilot and roadmap · 6. Control plan · 7. Traceability

---

## 1. Improvement charter (Define)

| Field | Content |
|---|---|
| Title | |
| Problem statement | What is wrong, where and since when, measurably. No cause and no solution in the statement. |
| Business impact | Effect on cost, compliance or audit, security, user experience, data integrity. Quantify only from evidence. |
| Objective | What should improve, in which direction. The target value is `RECOMMENDATION` (proposed) until the owner sets it. |
| In scope | process start and end, sites, asset classes, systems |
| Out of scope | |
| Customers / stakeholders | who experiences the problem; who is in the handoffs |
| Critical-to-quality (CTQ) | the measurable outcomes customers care about, for example "device ready on day 1", "leaver device recovered" |
| Constraints | budget, tools, policy, staffing, deadlines |
| Success measures | primary KPI plus guardrail KPIs (what must not get worse) |
| Governance | sponsor, process owner (one accountable person), team, approver |
| Timeline / gates | Define, Measure, Analyze, Improve and Control gates, with dates if known |
| Known data sources | |

**Problem-statement example** (ProcessForge §8, adapted):
- Weak: "Inventory is inaccurate."
- Better: "Asset records for in-scope laptops don't reliably agree with discovery, stockroom and disposal records, so ownership and lifecycle status can't be relied on for audit or refresh planning." Then add the measured gap once it's measured.

## 2. SIPOC

| Suppliers | Inputs | Process (5–7 high-level steps) | Outputs | Customers |
|---|---|---|---|---|
| who provides each input | data, requests, devices, approvals | verb–noun steps from trigger to end | records, devices, evidence, reports | who receives each output |

Rules: name the system of record for each input and output (asset record vs. CI). Mark the evidence each output leaves behind. Keep it high level; the detailed map comes next.

## 3. Process maps and KPI baseline (Measure)

**Current-state map.** Reconstruct it from evidence (tickets, logs, interviews), not from the written procedure alone. Record, per step:
- step ID, actor or role, system
- input, output and evidence produced
- wait before the step, and the step's own process time (measured or `ASSUMPTION`)
- handoff to; rework loops and how often they happen
- control performed (if any)

**Notation.** Use numbered swimlane lists for text, or Mermaid for diagrams. Example:

```mermaid
flowchart LR
  A[HR leaver notice] --> B{Device assigned in asset record?}
  B -- yes --> C[Create recovery task]
  B -- no --> X[Exception: no assignment - investigate]
  C --> D[Ship return kit] --> E{Returned within SLA?}
  E -- yes --> F[Receive, verify serial, set state In stock - pending wipe]
  E -- no --> G[Escalate to manager, then write-off review]
```

**Variants.** Where timestamped data exists, list the paths actually followed and their frequency. The documented path is often not the most common one.

**KPI baseline table:**

| KPI | Definition / formula | Baseline | Period | Source | Reliability (high / med / low) | Desired direction |
|---|---|---|---|---|---|---|
| | | value, or "Baseline unavailable — measurement required" | | | | |

**Measurement plan** (for any missing baseline): what to capture, from which system or field, sample size or period, owner, start date.

## 4. Future-state specification (Improve)

Define each element for the redesigned process (ProcessForge §18):

| # | Element | Content |
|---|---|---|
| 1 | Trigger | |
| 2 | Inputs | |
| 3 | Steps | |
| 4 | Decision points | |
| 5 | Systems (system of record per data item) | |
| 6 | Automation | |
| 7 | Roles (one accountable owner per critical activity) | |
| 8 | Controls | |
| 9 | Evidence produced | |
| 10 | Exceptions | |
| 11 | Escalations | |
| 12 | Outputs | |
| 13 | Downstream handoffs | |
| 14 | KPIs | |
| 15 | Exit criteria | |

Then list the delta from the current state: steps removed, steps combined, steps automated, controls added, controls removed (with the reason), ownership changed, system behavior changed, data requirements changed.

**Future-state design principles** (`PRACTICE`; adapted from the Operations plugin's process-optimization skill, ordered so that simplification comes first):

1. **Eliminate** steps that add no value for the requester, audit or the asset record.
2. **Reduce handoffs:** give one role the whole step where skills allow; where a handoff stays, define its inputs and acceptance check.
3. **Parallelize** independent steps (for example imaging while the shipping label is prepared), keeping the dependency that really exists.
4. **Use checkpoints, not gates,** where the risk allows: a detective check after the fact instead of an approval that blocks every case. Keep gates for high-risk steps (disposal, write-off, bulk changes) and say why.
5. **Automate** what remains repeatable and stable, after steps 1–4 (`tools-and-techniques.md` §5).

**Before/after comparison** (the minimum improvement deliverable when a full DMAIC isn't needed):

| Measure | Current state (source, period) | Future state (target, labeled `RECOMMENDATION`) | How it will be measured |
|---|---|---|---|
| Steps / handoffs / approvals | | | |
| Lead time per cycle (median, P90) | | | |
| Wait time share | | | |
| Error or rework rate | | | |
| Cost per cycle (classified: hard / avoidance / capacity) | | | |
| Staff and requester experience (survey or complaints) | | | |

A current-state value without data reads "Baseline unavailable — measurement required". A future-state value is a target, never a result, until measured after the change.

## 5. Options, pilot and roadmap

**Option comparison** (ProcessForge §22–23). Include at least a minimum-viable option, a balanced option and a strategic option where budget is constrained:

| Option | Root cause addressed | Cost | Benefit (classified: hard / avoidance / capacity / risk) | Risk | Effort and complexity | Time to value | Dependencies | Control strength | Reversibility |
|---|---|---|---|---|---|---|---|---|---|

Use a weighted score only when the weights can be justified by the sponsor. Otherwise show the trade-offs in words.

**Decision-quality test** before recommending (ProcessForge §39). Does the option:
- address the root cause?
- have sufficient evidence?
- improve the actual outcome?
- make financial sense?
- fit what the organization can implement, govern and measure?
- make failure detectable?
- avoid creating new risk?
- preserve the user experience?
- fit the ITAM/ITSM model?
- And is there a simpler option that would do as well?

**Pilot plan** (ProcessForge §27):

| Field | Content |
|---|---|
| Scope (site, team, asset class) | |
| Baseline (from §3) | |
| Participants | |
| Success criteria | |
| Observation period | |
| Expected failure modes | |
| Measurement method | |
| Expansion criteria | |
| Rollback criteria and method | |

**Roadmap** (ProcessForge §26):

| Action ID | Action | Owner | Priority | Dependencies | Start | Target | Resources / cost | Risk | Success test | Status |
|---|---|---|---|---|---|---|---|---|---|---|

Group the actions into immediate (0–30 days), near term (31–90 days), medium term (3–6 months) and long term (6–18+ months), adapted to the scale. Mark quick wins, decision gates, the critical path, training and communications.

## 6. Control plan (Control)

| KPI / control | Owner | Data source | Frequency | Threshold / trigger | Control activity | Evidence | Response when triggered | Escalation | Review cadence |
|---|---|---|---|---|---|---|---|---|---|

Rules (ProcessForge §19, §33, §38):
- Answer "How will we know the process is starting to fail again?" with a leading indicator, not just the original lagging KPI.
- Classify each control as preventive, detective or corrective, and as manual, automated or hybrid. Each one needs a purpose, an owner, evidence and a test method.
- Don't keep a control only because it already exists.
- **Exceptions:**
  - Define the expected exceptions, their owner, the approval authority, the evidence, expiry and remediation.
  - A recurring exception is a design defect. Redesign the process rather than approving the same exception again.
- **KPI definition format:** name | purpose | formula | source | owner | frequency | target (proposed until set) | threshold | action trigger.
- For stable, high-volume measures, a control chart (for example a p-chart for the proportion of defective records) separates real shifts from noise. For low volumes, use simple run charts.

## 7. Traceability IDs

For audit-sensitive work (ProcessForge §44):

`OBJ-##` objective · `REQ-##` requirement · `FIND-##` finding · `RC-##` root cause · `RISK-##` risk · `CTRL-##` control · `IMP-##` improvement · `ACT-##` action · `KPI-##` metric · `QA-##` validation

Chain example: FIND-01 (leaver devices not recovered) → RC-02 (no trigger from HR termination to asset task) → IMP-03 (automated recovery task on termination) → CTRL-04 (weekly report of terminated users with assigned assets) → KPI-05 (leaver recovery rate within SLA) → QA-06 (sample of terminations reconciled to asset returns).
