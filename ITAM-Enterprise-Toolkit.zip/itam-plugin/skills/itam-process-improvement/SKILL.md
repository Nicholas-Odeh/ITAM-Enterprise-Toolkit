---
name: itam-process-improvement
description: Use when an ITAM process (request-to-deploy, receiving, leaver device recovery, stockroom, reconciliation, reharvest, invoice matching, refresh, disposal) is slow, error-prone, costly or failing audits, or someone says "this process is broken", "too many steps", "bottleneck", "why does this keep happening" or asks for an as-is/to-be map. Covers DMAIC, SIPOC, value streams, waste, root cause, future state, control plans, ITIL alignment. Not for writing the SOP (use itam-sop-documentation) or program roadmaps (use itam-program-governance).
---

# ITAM Process Improvement

Find out why an ITAM process underperforms, then redesign it so the fix is measurable and stays fixed. Applies DMAIC and Lean to ITAM processes and connects them to ITIL. For process owners, asset managers and improvement leads.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Diagnose before redesigning.** No future state until the current state is rebuilt from evidence and causes are tested. An untested cause is a hypothesis (`INFERENCE`), never a root cause (ProcessForge §13).
7. **Never invent baselines or targets.** Without data write "Baseline unavailable — measurement required" and say how to measure it. Targets stay `RECOMMENDATION` until the process owner sets them.
8. **Simplify before automating.** Eliminate, combine and standardize steps first; automating a defective process makes the defect faster (ProcessForge §41).

## When to use

- An ITAM process is slow, error-prone, costly or failing audit.
- Process maps, as-is/to-be, SIPOC, value stream; root cause; quick wins.
- Charter, process KPIs, control plan; ITIL 4 or ISO/IEC 19770-1 alignment.

**When not to use:** writing the resulting SOP → `itam-sop-documentation`; maturity and roadmaps → `itam-program-governance`; control testing and audit findings → `itam-risk-controls-audit`; a single change's impact and rollback → `itam-change-request`.

## Workflow

### Step 1 — Classify the request

| Request | Load (in `references/`) |
|---|---|
| "Fix this broken process" (full DMAIC) | `dmaic-templates.md`, `itam-process-catalog.md` |
| Map, as-is/to-be, SIPOC, value stream | `dmaic-templates.md` §2–4, `tools-and-techniques.md` §3 |
| Root cause; ideas, waste, quick wins | `tools-and-techniques.md` §1–2, §5 |
| Charter; KPIs and control plan | `dmaic-templates.md` §1, §6 |
| ITIL or ISO alignment | `tools-and-techniques.md` §7 |

Depth per mode: `working-method.md` §1.

### Step 2 — Preflight

Confirm or label (`working-method.md` §2): process trigger, end point and scope; the problem in measurable terms; timestamped evidence; current metrics; owner and sponsor; constraints; the decision needed. Ask only when the answer would change the recommended direction.

### Step 3 — Do the work

Define (charter, SIPOC) → Measure (current state from evidence, KPI baseline, waste incl. handoffs and manual work) → Analyze (test causes against data) → Improve (options across levers and tiers; future state using eliminate → reduce handoffs → parallelize → checkpoints not gates → automate; before/after comparison; pilot) → Control (control plan, exception path, SOP handoff). Detail: `working-method.md` §3.

### Step 4 — Verify before release

- ★ Every baseline comes from supplied data, or says "Baseline unavailable — measurement required".
- ★ Every change traces to an evidenced root cause, or is labeled as testing a hypothesis.
- ★ Every new or changed control has an owner, frequency, evidence and threshold.
- ★ No framework clause is asserted without a source; the ITIL or ISO edition is stated or marked `VERIFY`.
- ★ Savings are classified, and none is presented as guaranteed cash.
- Non-blocking checks: `working-method.md` §4.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Everyone knows the cause is X" | Consensus is a hypothesis. Test it against data. |
| "Cycle time is about two weeks" | A number estimated by eye is not a baseline. Measure it or say it's unavailable. |
| "Let's automate it" | Simplify first, or you speed up the defect. |
| "Target: 50% faster" | Targets are owner decisions; label `RECOMMENDATION`. |

Stop if you are about to: draw a future state before the current state; present a target as a result; remove a control without saying why.

## Common mistakes

| Mistake | Fix |
|---|---|
| Mapping the documented process, not the real one | Rebuild from timestamps and variants actually followed. |
| Happy path only | Design exceptions and escalations. |
| Approvals as gates everywhere | Use checkpoints where the risk allows; keep gates for high-risk steps. |
| Every tool used at once | Use only the Lean or Six Sigma tool that answers the question. |

## If connectors are available

- **~~ITSM:** read request exports with state-change timestamps for lead and wait time.
- **~~CMDB / ~~endpoint management:** read state history to find broken transitions.
- **~~project tracker / ~~knowledge base:** read current procedures; draft roadmap and pilot tasks.

## Output format

1. **Summary:** problem, key findings, recommendation, next action.
2. **Current state and baseline** (or "measurement required").
3. **Root causes** with evidence.
4. **Options and the future state,** with the before/after comparison.
5. **Control plan and roadmap.**
6. **Risks and open questions.**

Full package, executive brief and user communication: `working-method.md` §5.

## Reference files

- `references/working-method.md`: modes, preflight, DMAIC step detail, deliverables.
- `references/dmaic-templates.md`: charter, SIPOC, maps, future state and before/after, options, pilot, control plan.
- `references/itam-process-catalog.md`: ITAM processes with failure points, KPIs and broken-transition checklist.
- `references/tools-and-techniques.md`: 5 Whys, fishbone, Pareto, VSM, waste, levers, FMEA, ITIL/ISO alignment, red-team checks.
