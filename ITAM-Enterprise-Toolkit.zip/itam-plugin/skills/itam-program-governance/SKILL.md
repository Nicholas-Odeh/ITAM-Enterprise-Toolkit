---
name: itam-program-governance
description: Use when building, assessing or funding an ITAM program: strategy, charter, maturity or KPA gap assessment, target operating model, roadmap, steering committee, RACI and decision rights, which ITAM policies are needed and how they are approved and enforced, awareness and training plans, or a business case for tools or headcount. Covers the 12 IAITAM KPAs. Not for procedures (use itam-sop-documentation), control testing (itam-risk-controls-audit), KPI definitions (itam-data-analysis-reporting) or status reports (itam-status-report).
---

# ITAM Program Governance

The program layer of ITAM: purpose, maturity, decision rights, policies, education and executive support. Core principle: **assess on evidence, then design the smallest program the business drivers need.** For program owners, asset managers writing a strategy or charter, and leaders deciding whether to invest.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **No score without evidence.** No maturity level, KPA rating or benefit figure without supporting evidence; use `NOT ASSESSED` or a labeled estimate with its basis.
7. **Aligned, not certified.** Say "aligned with IAITAM best-practice principles" (or ISO/IEC 19770, ITIL) unless a formal assessment says otherwise. IAITAM content is proprietary: paraphrase and cite `(CAMP M:<page>)`.
8. **Roles, not people; one Accountable.** Each activity has exactly one Accountable role; don't default everything to the ITAM team. Policy is enforced by the organization (typically HR and Legal), not by ITAM alone.

Read `templates/company-profile.md` at the plugin root first if it exists.

## When to use

- "ITAM strategy for the next three years", charter, target operating model.
- "How mature is our ITAM?", KPA gap analysis, "where do we start?"
- "Who owns what?", RACI, steering committee, decision rights.
- "Which ITAM policies do we need?", approval, acknowledgement, enforcement.
- Training and awareness plans; a business case for the CIO.

**When not to use:** step-by-step procedures (`itam-sop-documentation`); control testing and audit readiness (`itam-risk-controls-audit`); KPI definitions and dashboards (`itam-data-analysis-reporting`); recurring program status reports (`itam-status-report`); exact TCO or NPV (`itam-financial-management`).

## Workflow

### Step 1 — Classify

| Request | Load |
|---|---|
| Strategy, roadmap, operating model, charter | `references/strategy-roadmap.md`, `references/kpa-catalog.md` |
| Maturity, gap or program-health review | `references/maturity-model.md`, `references/kpa-catalog.md` |
| Roles, ownership, forums, decision rights | `references/raci-template.md` |
| Policy set or a policy | `references/policy-topics.md`, then `itam-sop-documentation` for procedures |
| Communication and education | `references/communication-education-plan.md` |
| Business case, executive buy-in | `references/business-case-template.md` |

### Step 2 — Preflight

Confirm or assume: decision and audience; scope; current-state evidence; business drivers; constraints and sponsor. Ask one question if the decision or sponsor is unknown (`references/program-method.md` §1).

### Step 3 — Do the work

- **Assess before designing:** self-assessment → SWOT → is/should map (CAMP M:96-104). Foundation KPAs first (Program, Policy, Communication & Education).
- **Maturity 0–5 on evidence only;** targets by business need, not "5 everywhere".
- **Roadmap in five waves** (Stabilize, Standardize, Integrate, Automate, Optimize); each initiative has owner, dependency, investment basis and measure.
- **Policy and procedure** live in separate documents.

Full method: `references/program-method.md` §2.

### Step 4 — Verify before release

- ★ No maturity level, benefit, cost or headcount figure without a cited basis or an estimate label.
- ★ No claim of IAITAM, ISO/IEC 19770 or ITIL conformance or certification; CAMP paraphrased with page cites.
- ★ Every RACI row has exactly one Accountable role; no role responsible for a decision it can't make.
- ★ Every policy names an owner, approver, enforcement route and review date (or `[TBD]`).
- Recommendations link to a driver and a measurable outcome; no late-wave item depends on unfinished wave 1 work.
- Current and target state are separate; KPAs outside ITAM appear as interfaces with owners.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The CIO wants a maturity number today" | Score only what has evidence; the rest is `NOT ASSESSED`. |
| "Calling it IAITAM-compliant helps the pitch" | It is a false claim. Say "aligned with". |
| "Industry says ITAM saves 30%" | An unsourced benchmark is not this organization's benefit. Label it or drop it. |

Stop if you are about to: assign a score without evidence; give a RACI row two Accountables; publish a policy without an enforcement route.

## Common mistakes

| Mistake | Fix |
|---|---|
| Framework-first roadmap ("implement all 12 KPAs") | Sequence from business drivers and evidence |
| Policy and procedure in one document | Split; procedures go to `itam-sop-documentation` |
| Everything assigned to ITAM | Assign to the role with authority; show interfaces |
| Benefits with no "do nothing" baseline | Show the cost of not acting |

## If connectors are available

- **~~document repository / ~~knowledge base:** read existing policies, charters and audit findings; cite file and version.
- **~~ITSM / ~~HR:** read metric baselines and role structure (minimum personal data).
- **~~project tracker / ~~email / ~~chat:** draft roadmap items or messages for approval; never send.

## Output format

1. **Summary:** recommendation, drivers, and the ask.
2. **Current state** (evidence; maturity table if asked).
3. **Target state.**
4. **Roadmap.**
5. **Governance artifacts** (RACI, policies, communication plan).
6. **Assumptions, gaps and decisions needed.**

Executive and practitioner variants: `references/program-method.md` §3.

## Reference files

- `references/program-method.md`: preflight, full method, output variants. Read for any substantial deliverable.
- `references/kpa-catalog.md`: the 12 KPAs, interfaces, indicators. Read for KPA or scope questions.
- `references/maturity-model.md`: levels 0–5, evidence tests, scoring. Read for maturity work.
- `references/strategy-roadmap.md`: strategy, operating model, roadmap, charter. Read for strategy work.
- `references/raci-template.md`: roles, RACI rules, forums, decision rights. Read for ownership design.
- `references/policy-topics.md`: policy lifecycle, topics, enforcement. Read for policy requests.
- `references/communication-education-plan.md`: audiences, channels, training plan. Read for awareness work.
- `references/business-case-template.md`: cost/benefit, measures, pitch. Read for funding requests.
