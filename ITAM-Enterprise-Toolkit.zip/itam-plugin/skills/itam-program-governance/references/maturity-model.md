# ITAM maturity model and assessment method

A practical 0–5 maturity scale for ITAM capabilities, the evidence needed for each level, and the assessment method. The scale is the plugin's own (adapted from AssetForge §27); it is not an IAITAM or ISO rating and must not be presented as one.

## Contents
1. Rules
2. Maturity levels with evidence tests
3. What to assess: capabilities and dimensions
4. Assessment method (self-assessment → SWOT → is/should)
5. Scoring table and output
6. Setting targets and prioritizing gaps
7. Interview guide

## 1. Rules

- **No level without evidence.** Each rating cites evidence (document, record, report, interview attributed to a role). If evidence is missing, the rating is `NOT ASSESSED`, not a guess.
- **Rate the weakest essential element.** A capability with a documented process but no owner is not Level 3.
- **Don't average across capabilities to hide a gap.** Report the profile, not a single number. If an overall figure is requested, show it alongside the lowest-rated critical capabilities.
- **Target levels follow business need.** Level 5 everywhere is neither necessary nor cheap.
- **Re-assess with the same method** so changes over time are comparable; record the date and assessors.

## 2. Maturity levels with evidence tests

| Level | Name | Description | Evidence test (all must hold) |
|---|---|---|---|
| 0 | Absent | The capability effectively does not exist | No process, owner or records; activity happens only by accident |
| 1 | Ad hoc | Done inconsistently, depending on who is involved | Some records exist; no written process; outcomes vary by person or site |
| 2 | Repeatable | Common practices exist but depend on individuals | Practitioners can describe a consistent approach; partial documentation; knowledge concentrated in a few people |
| 3 | Defined | Documented, standardized process | Approved procedure; named owner; defined roles; process used across the scope; records produced as designed |
| 4 | Managed | Controlled, measured and governed | Level 3 plus: KPIs with targets reported on a cadence; controls with evidence of operation; exceptions tracked and aged; management review acts on results |
| 5 | Optimized | Integrated, automated, predictive, continually improving | Level 4 plus: integrated with adjacent systems (procurement, HR, finance, security); automated where sensible; trend or predictive use of data; documented improvement cycle with measured results |

Typical evidence by level (`PRACTICE`):

| Level | Examples of evidence |
|---|---|
| 1 | Spreadsheets kept by individuals; email approvals |
| 2 | Team checklists; a shared tracker; consistent but undocumented steps |
| 3 | Approved SOP with version and owner; RACI; training records |
| 4 | KPI dashboard with targets; control logs; exception register with aging; steering minutes with actions |
| 5 | Workflow integrations (e.g. HR leaver event → recovery task); automated reconciliation; forecast models; improvement backlog with before/after measures |

## 3. What to assess: capabilities and dimensions

Assess **capabilities** (rows) across **dimensions** (what you check for each row). Choose the rows that are in scope; don't rate what nobody asked about.

**Capabilities (rows).** Either the 12 KPAs (see `kpa-catalog.md`) or a lifecycle view:

| Lifecycle capability | Related KPA |
|---|---|
| Strategy and program governance | PRG |
| Policy and standards | POL |
| Communication and training | C&E |
| Request and acquisition | ACQ |
| Receiving, tagging and recording | AID |
| Inventory, discovery and reconciliation | AID |
| Deployment, assignment, moves and recovery (incl. joiner-mover-leaver) | AID |
| Software and SaaS entitlement management | CMP, DOC |
| Contract and document management | DOC, VEN |
| Financial management (TCO, depreciation, chargeback) | FIN |
| Vendor management | VEN |
| Retirement and disposal | DIS |
| Compliance, audit and legislation | CMP, LEG |
| ITAM–CMDB/ITSM integration | PRG |
| Reporting and metrics | PRG |

**Dimensions (what to check per row):** governance and ownership; people and skills; process; technology; data quality; integration; controls and evidence; reporting; automation; adoption.

## 4. Assessment method

Adapted from the IAITAM best-practice sequence (CAMP M:96-104).

1. **Self-assessment (inventory of the program, not just the assets).** For each in-scope KPA, collect what exists: assets and data available, current steps, roles, policies, tools, budgets, schedules, known issues. Gather from IT, procurement, finance, legal and end-user groups, including contractors (CAMP M:96, M:67).
2. **SWOT.** Sort what you found into strengths to build on, weaknesses to fix, opportunities to take, threats that could derail the work (CAMP M:96-97).
3. **Alignment check.** For each KPA, identify the other KPAs, departments, data flows and systems it depends on; a data-flow diagram helps (CAMP M:97).
4. **"Is" map.** Summarize the current environment, end to end, across departments and roles.
5. **"Should" map.** Describe the best achievable target for the KPA. It may take several years; it generates the backlog of projects (CAMP M:97).
6. **Roles.** Identify the roles involved and their responsibilities (see `raci-template.md`).
7. **Needs and business drivers.** Relate each gap to drivers such as cost reduction, risk mitigation or innovation, and to the needs of major departments; this sets priority (CAMP M:99).
8. Then proceed to cost/benefit and business case (`business-case-template.md`) and roadmap (`strategy-roadmap.md`).

SWOT template:

| Strengths | Weaknesses |
|---|---|
| | |
| **Opportunities** | **Threats** |
| | |

Is/should template (per KPA or capability):

| Aspect | Is (current, with evidence) | Should (target) | Gap | Business driver | Priority |
|---|---|---|---|---|---|
| Process | | | | | |
| Roles | | | | | |
| Data and systems | | | | | |
| Controls and evidence | | | | | |
| Measures | | | | | |

## 5. Scoring table and output

The example rows below are illustrative only; they show the level of evidence detail expected.

| Capability | Current level | Evidence (source, date) | Gap | Target level | Business driver | Priority | Recommendation | Owner |
|---|---:|---|---|---:|---|---|---|---|
| Inventory and reconciliation | 2 | Team checklist; no reconciliation report since 2026-03 (`FACT`, interview with Asset Manager) | No scheduled reconciliation; no exception aging | 4 | Audit finding AF-12 | High | Monthly reconciliation with exception register | Asset Manager |
| Disposal | NOT ASSESSED | No disposal records supplied | — | — | — | — | Request certificates for last 2 quarters | Disposal Manager |

Presentation:
- A profile chart or table (current vs. target per capability) is more useful than one overall score.
- List the three to five gaps with the largest risk or value first.
- State the evidence base: who was interviewed, which documents and data, dates.

## 6. Setting targets and prioritizing gaps

Prioritize each gap by:

| Factor | Question |
|---|---|
| Risk reduction | Does closing it reduce audit, security, compliance or financial exposure? |
| Value | Does it reduce cost or avoid spend measurably? |
| Dependency | Do other improvements depend on it (e.g. reliable inventory before automation)? |
| Effort and cost | What does it take (people, tooling, time)? |
| Sponsor interest | Does it serve a stated executive priority? |

Rule of thumb (`PRACTICE`): fix foundation gaps (ownership, policy authority, inventory accuracy) before investing in automation or optimization; a Level 5 tool on a Level 1 process produces fast wrong answers.

## 7. Interview guide

Ask each interviewee (attribute answers to the role, not the person):

1. What ITAM-related activities does your team perform, and what triggers them?
2. What systems and records do you use? Which do you trust, and why?
3. Who approves exceptions? How are they recorded?
4. What goes wrong most often? How do you find out?
5. What reports or measures do you see? Who acts on them?
6. What policies apply to your work? When did you last see them?
7. What would you change first?

Sources: AssetForge §19.4, 27; CAMP M:96-104, M:67; RiskForge §24.
