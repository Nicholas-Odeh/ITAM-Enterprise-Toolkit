# IAITAM Key Process Area (KPA) catalog

A paraphrased working catalog of the 12 IAITAM KPAs for scoping, assessing and governing an ITAM program. The source is proprietary IAITAM course material (CAMP manual v2.1.3 and slides). Descriptions here are summaries in our own words; cite pages, don't reproduce text. For the exact IAITAM wording, use the licensed IAITAM Best Practice Library.

## Contents
1. How the KPAs fit together
2. KPA cards (12)
3. KPA-to-functional-area and plugin-skill map
4. Quick program-health questionnaire

## 1. How the KPAs fit together

IAITAM treats ITAM as a permanent business competency (a *program*) made of processes, policies, roles, procedures and documentation, not a job title or a single department (CAMP M:25, M:28). It defines 12 KPAs as the full scope of ITAM processes (CAMP M:21). Organizations may run some KPAs outside the ITAM team; the program still needs to see and coordinate them.

| Group | KPAs | Role in the program | Source |
|---|---|---|---|
| Core (foundation) | Program, Policy, Communication & Education | Set direction, authority and awareness; every other KPA depends on them | CAMP M:25-27; S:39, S:54 |
| Operating | Acquisition, Asset Identification, Disposal, Documentation | The physical and contractual work across the lifecycle | CAMP M:27 |
| Controlling | Project, Financial, Vendor, Compliance, Legislation | Constrain and check the work: money, suppliers, obligations, change | CAMP M:27 (slides show Compliance and Legislation together, S:39) |

Practical reading (`PRACTICE`): build the three foundation KPAs first, even in lightweight form, because without a mandate, policy authority and awareness, operating improvements don't stick.

## 2. KPA cards

Each card: purpose, typical components, main interfaces, example indicators (paraphrased from CAMP M:22-24), assessment questions (`PRACTICE`, ours), and the evidence that would show it is working.

### PRG — Program Management (core)
- **Purpose:** define, run and market the ITAM program: mission, strategy, objectives, measures, priorities and executive support; coordinate processes owned by other departments (CAMP M:25-28; S:51-57).
- **Components:** mission statement, strategy and objectives, roadmap, measurement, prioritization by business driver, program marketing and success reporting.
- **Interfaces:** every KPA; executive sponsor; ITSM; finance.
- **Example indicators:** share of ITAM processes owned by other departments that ITAM monitors; share of deployed assets that are on the IT standard; share of configuration changes tied to a service desk ticket.
- **Assessment questions:** Is there a written mission and a named executive sponsor? Are program objectives tied to business drivers? Is there a periodic program report to leadership? Who prioritizes ITAM work?
- **Evidence:** charter, mission statement, steering minutes, program scorecard.

### POL — Policy Management (core)
- **Purpose:** create, approve, communicate, enforce, measure and maintain the policies that set ITAM scope, authority and expected behavior (CAMP M:29-32, M:57-71; S:119-125).
- **Components:** policy creation, enforcement, maintenance, measurement; oversight to remove overlap and duplicates and keep policy separate from procedure.
- **Interfaces:** all KPAs supply requirements; Legislation and Compliance feed obligations; HR and Legal enforce; Documentation controls access and format.
- **Example indicators:** share of ITAM policies reviewed on the defined cycle (the manual gives six months); share of policies managed against metrics.
- **Assessment questions:** see `policy-topics.md` §7.
- **Evidence:** approved policies with owners and review dates, acknowledgement records, enforcement cases.

### C&E — Communication & Education Management (core)
- **Purpose:** plan, deliver, measure and refresh communication and training so every stakeholder understands ITAM policies, processes and their role (CAMP M:33-35, M:50-56; S:77-85).
- **Components:** educational events, communication methods, training content, communication schedule, training measurement.
- **Interfaces:** all KPAs (each supplies its messages and training needs); HR (onboarding), corporate communications, training department.
- **Example indicators:** share of general users, power users, software administrators, on-site vendors and new hires trained on ITAM policies.
- **Assessment questions:** Is there a communication plan with a calendar? Do new hires and contractors receive ITAM policy training? Is training completion measured?
- **Evidence:** plan, training records, acknowledgement rates, feedback results.

### ACQ — Acquisition Management (operating)
- **Purpose:** gatekeep how IT assets are requested, justified, sourced, approved and purchased; create the first asset records; route non-standard requests through formal review (CAMP M:35-37; S:58-70).
- **Components:** business objectives and requirements, asset justification (TCO/ROI), supplier identification, RFP/RFQ, contract negotiation, standard catalog, redeployment check before buying.
- **Interfaces:** Policy (acquisition authority), Vendor, Financial, Asset Identification (receiving), Legal.
- **Example indicators:** requests and approvals by department, asset type and standard vs. non-standard; request-to-fulfillment time; negotiation duration; time to approve standard and non-standard requests; projected TCO/ROI kept for later comparison.
- **Assessment questions:** Can assets be bought outside the process (credit cards, departmental budgets)? Is reuse checked before purchase? Are non-standard requests approved by a defined role?
- **Evidence:** approved requests, PO-to-request linkage, exception approvals.

### AID — Asset Identification Management (operating)
- **Purpose:** uniquely identify and track assets from receipt to disposal: receiving and acceptance, tagging, recording, discovery, reconciliation, moves and returns (CAMP M:38-40; S:71-76).
- **Components:** decide what to track, unique tags, receiving notification, acceptance, order reconciliation, inventory management, return merchandise authorization (RMA).
- **Interfaces:** Acquisition (orders), Financial (fixed-asset register), Disposal, Documentation, discovery and endpoint tools.
- **Example indicators:** RMAs by vendor and type; receipt-to-inventory (staging) time; who and when inventory was increased or decreased; reconciliation errors vs. discovery and vs. physical counts; vendor pre-delivery accuracy (for example tags applied correctly).
- **Assessment questions:** Is there a written "what we track" rule? How long from dock to record? How often are physical and electronic inventories reconciled, and who resolves differences?
- **Evidence:** receiving logs, tag records, reconciliation reports, exception tickets.

### DIS — Disposal Management (operating)
- **Purpose:** remove assets from the environment under control: secure data removal, software harvesting, vendor selection and oversight, regulatory compliance, chain-of-custody records, value recovery (CAMP M:42-43; S:91-95).
- **Components:** record keeping in the asset repository, disposal storage and policy monitoring, disposal vendor selection criteria and due diligence, disposal cost monitoring, disposal regulations.
- **Interfaces:** Security, Legal/Legislation, Vendor, Financial (write-off, recovery), Documentation (certificates), SAM (harvest).
- **Example indicators:** share of hardware going through the formal disposal process; share with data secured before ownership transfer; share with software harvested where applicable.
- **Evidence:** disposal orders, sanitization records, certificates (erasure, disposal, accountability), retired asset records. Use `itam-secure-disposition` for the method.

### DOC — Documentation Management (operating)
- **Purpose:** control all physical and electronic ITAM documents and link them to assets: contracts, license agreements, proofs of purchase, warranties, SLAs, approvals, disposal certificates; access, retention, archiving and destruction (CAMP M:43-45; S:96-103).
- **Components:** document identification, format, security, access, archiving, destruction management.
- **Interfaces:** every KPA produces documents; Policy sets format and access rules; Legal sets retention.
- **Example indicators:** share of licensing agreements managed by ITAM; share annotated with role-based content; share of documents reviewed before filing; share of documents linkable to their asset.
- **Evidence:** repository with metadata keyed to asset and contract IDs, retention schedule, access lists. Use `sharepoint-itam-records` for repository design.

### FIN — Financial Management (controlling)
- **Purpose:** manage IT asset financial data: budgeting, forecasting, invoice reconciliation, chargeback, TCO and ROI, strategic view of IT spend (CAMP M:45-46, M:91-94; S:104-109).
- **Components:** budgeting, forecasting, billing, justification, strategic-fit review.
- **Interfaces:** Acquisition, Vendor, Finance department, Disposal (recovery and write-off).
- **Example indicators:** share of invoices reconciled for charge accuracy; share of software invoices reconciled for description; share of asset types monitored for TCO/ROI; share of contracts reviewed for financial terms before signature.
- **Evidence:** reconciliation logs, TCO models, budget vs. actual. Use `itam-financial-management` for calculations.

### PRJ — Project Management (controlling)
- **Purpose:** run bounded ITAM change efforts with defined scope, plan, schedule, budget, risk, change control and closure; review the organization's projects for asset impacts (CAMP M:46-48; S:126-133).
- **Components:** deliverables, project plan, milestones, timeline, status meetings and reporting, scope management, document and change management.
- **Interfaces:** Program (portfolio), Policy (project information handling), C&E (change communication), Vendor (suppliers).
- **Example indicators:** share of ITAM projects on time and on budget; share of organizational projects reviewed for IT asset requirements; share of projects with a post-deployment review.

### VEN — Vendor Management (controlling)
- **Purpose:** manage relationships with IT suppliers: selection, communication rules, performance scorecards, review meetings, issue and crisis management, vendor data (CAMP M:48-49; S:134-151).
- **Components:** scorecard development and maintenance, vendor council meetings, performance analysis, managed vendor selection, vendor communication, vendor database.
- **Interfaces:** Acquisition, Financial, Compliance, Documentation, Legal.
- **Example indicators:** dated scorecard reviews; frequency of issue-resolution meetings; vendor contact data currency; ability to meet contractual obligations; vendor staff infractions. Use `itam-vendor-contract-management` for the method.

### CMP — Compliance Management (controlling)
- **Purpose:** verify conformance with license terms, contracts, internal policy and applicable rules; run internal audits and respond to external audits (CAMP M:40-42; S:86-90).
- **Components:** audit response, internal IT audit process, communicating compliance requirements.
- **Interfaces:** Policy, Legislation, Documentation (proof), SAM, Vendor, Legal.
- **Example indicators:** share of installed titles compliant with license terms (all, and within the managed library); share of hardware disposed per local regulation; share of ITAM processes audited against program requirements.
- **Evidence:** license positions, audit reports, remediation records. Use `itam-risk-controls-audit` and `itam-software-license-management`.

### LEG — Legislation Management (controlling)
- **Purpose:** identify and monitor laws and pending legislation that affect asset use, tracking, reporting and disposal, by jurisdiction; work with Legal; feed changes into policy and controls (CAMP M:40-42; S:110-118).
- **Components:** identify legislation, monitor trends, manage obligations per geography, communicate legislation.
- **Interfaces:** Legal, Policy, Compliance, Disposal, Financial.
- **Example indicators:** frequency of meetings with Legal on new or upcoming requirements; share of current legislative requirements reviewed from an ITAM view.
- **Note:** ITAM tracks and routes obligations; Legal interprets them. Don't state legal requirements without a legal source.

## 3. KPA-to-functional-area and plugin-skill map

The KPAs are applied across functional areas: program administration, SAM, HAM, mobile (MAM), disposition (ITAD), and security coordination (CAMP M:72-77; S:38-39).

| KPA | Most relevant plugin skill(s) |
|---|---|
| Program, Policy, C&E | `itam-program-governance` (this skill) |
| Acquisition | `itam-acquisition-procurement` |
| Asset Identification | `itam-hardware-lifecycle`, `itam-inventory-reconciliation`, `itam-logistics-warehouse` |
| Disposal | `itam-secure-disposition` |
| Documentation | `sharepoint-itam-records`, `itam-sop-documentation` |
| Financial | `itam-financial-management` |
| Project | `itam-process-improvement` |
| Vendor | `itam-vendor-contract-management` |
| Compliance, Legislation | `itam-risk-controls-audit`, `itam-software-license-management` |

## 4. Quick program-health questionnaire

For a fast first pass, rate each item Yes / Partly / No / Unknown and record the evidence. Unknown is a finding, not a No.

| # | Question | KPA |
|---|---|---|
| 1 | Is there a written ITAM mission and a named executive sponsor? | PRG |
| 2 | Is the program's scope (asset classes, units, regions) written down? | PRG |
| 3 | Are ITAM policies approved by executive management, with HR/Legal-agreed enforcement? | POL |
| 4 | Do employees and contractors acknowledge ITAM policies at hire and periodically? | POL, C&E |
| 5 | Is there a communication and training plan with measured completion? | C&E |
| 6 | Can IT assets be purchased outside the approved process? | ACQ |
| 7 | Is every received asset tagged and recorded within a defined time? | AID |
| 8 | Are physical, discovery and repository inventories reconciled on a schedule? | AID |
| 9 | Does every disposed asset have sanitization and disposal evidence? | DIS |
| 10 | Are contracts and proofs of purchase linked to asset records and retrievable? | DOC |
| 11 | Are invoices reconciled against orders and receipts? | FIN |
| 12 | Are strategic vendors reviewed against a scorecard? | VEN |
| 13 | Is there a current license position for the top publishers? | CMP |
| 14 | Does someone track legal and regulatory changes affecting assets, with Legal? | LEG |
| 15 | Are ITAM changes run as projects with owners and closure reviews? | PRJ |

Sources: CAMP Part I §B–D, L (M:21-49, M:72-77; S:34-39, S:51-151); AssetForge §6.
