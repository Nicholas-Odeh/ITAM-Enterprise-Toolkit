# ITAM strategy, operating model, roadmap and charter

Templates and rules for an ITAM strategy that leads to decisions and execution, not a list of generic recommendations.

## Contents
1. Strategy structure
2. Mission, vision and objectives
3. Target operating model
4. Five-wave roadmap
5. Initiative backlog template
6. Aligning ITAM to the enterprise scorecard
7. Program charter template
8. Common strategy failures

## 1. Strategy structure

| Section | Content | Evidence needed |
|---|---|---|
| Strategic context | Enterprise objectives, technology strategy, risk and regulatory context, sourcing model, financial priorities, service-management priorities, major changes (M&A, cloud move, tool replacement) | Strategy documents, sponsor interview |
| Current state | Maturity profile, key metrics, audit findings, pain points | `maturity-model.md` output |
| Vision | The desired future state in one or two sentences | Sponsor agreement |
| Strategic objectives | 4–7 objectives, each measurable | Business drivers |
| Capability assessment | Governance, people, process, technology, data, integration, controls, reporting, automation, adoption | Assessment |
| Target operating model | Organization, roles, services, processes, governance, systems, data, controls, decision rights | Section 3 |
| Roadmap | Initiatives by wave, with dependencies | Section 4 |
| KPIs and benefits | How success is measured; expected benefits with basis | `business-case-template.md` |
| Risks | Delivery and adoption risks, with mitigations | — |

Every major recommendation is expressed as: **ITAM capability → measurable operational change → business outcome** (AssetForge §21).

## 2. Mission, vision and objectives

**Mission statement.** Says what the program does, why the ITAM team matters, and what value the organization gets; it must be clear to executives, since it is the basis for their confidence and buy-in (CAMP M:25-26).

Template:
> The ITAM program [does what: e.g. maintains trusted records of what IT assets we own, where they are and who is accountable] so that [organization] can [business value: control cost, meet license and regulatory obligations, protect data, support services], measured by [2–3 headline measures].

**Strategic objective menu** (pick what the business drivers support):

| Objective | Example measure (formula, not target) |
|---|---|
| Trusted asset data | Inventory accuracy = verified accurate assets ÷ assets tested |
| Lifecycle control | Leaver device recovery rate = devices recovered within SLA ÷ devices assigned to leavers |
| Reduced cost / optimized utilization | Reuse rate = redeployed assets ÷ (redeployed + new purchases) for the class |
| Reduced compliance exposure | Share of top publishers with a current license position |
| Security visibility | Discovery coverage = assets seen by approved discovery ÷ expected discoverable assets |
| ITSM integration | Asset–CI link rate for in-scope classes |
| Auditability | Evidence completeness for sampled transactions |
| Vendor leverage | Contracts reviewed before renewal notice date ÷ contracts renewing |
| Sustainability | Share of retired assets reused, resold or certified recycled |

Targets are set by the organization: write `[TBD: target — sponsor to approve]` until agreed.

## 3. Target operating model

| Element | Decide |
|---|---|
| Organization | Central, federated or hybrid ITAM team; where it reports; which KPAs sit elsewhere (procurement, finance, legal) |
| Roles | Program owner, HAM and SAM leads, asset analysts, receiving/depot, interfaces (see `raci-template.md`) |
| Services | What ITAM provides to others: asset records, license positions, reclamation, disposal, reporting, audit support |
| Processes | Lifecycle processes in scope and their owners |
| Governance | Forums, decision rights, escalation, policy approval route |
| Systems | System of record per attribute; discovery sources; integrations (HR, procurement, finance, ITSM, security) |
| Data | Canonical asset data model and state model; data owners; quality rules |
| Controls | Key controls and the evidence each produces |
| Decision rights | Who approves non-standard purchases, exceptions, write-offs, disposal methods, vendor selection |

## 4. Five-wave roadmap

Waves are ordered by dependency and value. Adapt them to the evidence; skip what is already in place.

| Wave | Focus | Typical initiatives | Exit criteria (examples) |
|---|---|---|---|
| 1 — Stabilize | Inventory, ownership, governance, critical controls | Sponsor and charter; scope; baseline inventory and reconciliation; owner for every in-scope asset class; fix critical control gaps (e.g. leaver recovery, disposal evidence) | Baseline accuracy measured; owners named; critical exceptions in a register with owners |
| 2 — Standardize | Policy, lifecycle, data model, processes | Approve ITAM policy set; lifecycle state model; data dictionary; core SOPs; standard catalog | Policies approved and acknowledged; SOPs published; state model in the system of record |
| 3 — Integrate | CMDB, discovery, procurement, HR, finance, security | HR leaver feed; PO-to-asset linkage; finance register reconciliation; asset–CI sync; security tool feeds | Key integrations live with reconciliation reports |
| 4 — Automate | Reconciliation, exceptions, lifecycle actions, reporting | Scheduled reconciliation; automated exception routing; recovery workflows; self-service reports | Manual effort reduced (measured); exceptions aged automatically |
| 5 — Optimize | Forecasting, utilization, cost optimization, predictive analytics | Refresh forecasting; reharvest; utilization-based rightsizing; vendor consolidation | Savings tracked against baseline; forecasts within agreed variance |

Horizon view for leadership (RiskForge §25): Immediate (contain exposure, preserve evidence, assign owners) → Short term → Medium term → Long term. For each horizon state objective, initiatives, dependencies, owner, investment, risk reduction and success measures.

Dependency rules (`PRACTICE`):
- Automation and analytics depend on reliable inventory and agreed definitions.
- Integrations depend on a defined system of record per attribute.
- Policy enforcement depends on executive approval and an HR/Legal enforcement agreement.

## 5. Initiative backlog template

| ID | Initiative | Wave | Finding / gap addressed | Business driver | Owner | Dependencies | Effort / cost basis | Success measure | Status |
|---|---|---|---|---|---|---|---|---|---|

Project discipline for each initiative (CAMP M:101-103; S:131): charter, scope, stakeholders, plan with milestones, change management plan, communication plan, closure review comparing results with the business case. Remember the deliverable of an ITAM project is usually an ongoing process; success is the process sustaining its value after the project closes (CAMP M:102-103).

## 6. Aligning ITAM to the enterprise scorecard

If the organization uses a balanced scorecard, map ITAM measures to it rather than reporting in isolation. The CAMP material suggests the following mapping of KPA groups (CAMP M:105-108):

| KPA group | Standard balanced scorecard | IT balanced scorecard |
|---|---|---|
| Core (Program, Policy, C&E) | Organizational capacity (learning and growth) | Operating excellence |
| Operating (Acquisition, Asset ID, Disposal, Documentation) | Internal processes | User orientation |
| Controlling (Project, Financial, Vendor, Compliance/Legislation) | Financial | Corporate contribution |

The metrics themselves rarely change between the two views; their emphasis does (CAMP M:108). If the organization uses OKRs or another scheme, map to that instead.

## 7. Program charter template

```
ITAM Program Charter — [Organization]            Version [x.y]   Date [ ]
Executive sponsor:      [role, name]
Program owner:          [role]
Approved by:            [governance forum / role]   Date: [ ]

1. Mission              [one paragraph, section 2 template]
2. Business drivers     [cost / risk / compliance / security / service — with evidence]
3. Scope                In: [asset classes, business units, regions, lifecycle stages]
                        Out: [explicit exclusions]
4. Objectives and measures   [objective → measure (formula) → target or TBD]
5. Authority            [what the program may require of other departments; policy reference]
6. Governance           [forums, cadence, decision rights, escalation path]
7. Roles                [summary; full RACI in appendix]
8. Interfaces           [procurement, finance, HR, legal, security, ITSM/CMDB, vendors]
9. Funding and resources [budget source, headcount, tooling]
10. Roadmap summary     [waves and key milestones]
11. Risks and dependencies
12. Review              [charter review cadence and trigger events]
```

## 8. Common strategy failures

| Failure | Fix |
|---|---|
| Recommendations copied from a framework with no business driver | Tie each to a driver and a measure |
| Tool purchase as the strategy | Sequence tool after ownership, policy and data model decisions |
| Everything assigned to ITAM | Show interfaces and owners in other functions |
| Targets invented to look precise | Use `[TBD]` until the sponsor sets them |
| Roadmap without dependencies | Order by dependency; show the critical path |
| Maturity "5 everywhere" | Set targets by need and cost |

Sources: AssetForge §19, 21; RiskForge §25; CAMP M:25-28, M:96-110; S:131.
