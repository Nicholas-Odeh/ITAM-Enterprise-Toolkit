# ITAM policy management and policy topics

How to decide which ITAM policies an organization needs, how to write and approve them, and how to keep them enforced and current. Write the procedures underneath them with `itam-sop-documentation`.

## Contents
1. Policy vs. standard vs. procedure
2. Policy lifecycle
3. Policy document structure
4. ITAM policy topic catalog
5. Enforcement, acknowledgement and feedback
6. Review cycle and trigger events
7. Policy self-assessment
8. Writing rules

## 1. Policy vs. standard vs. procedure

| Document | Says | Approved by | Changes | Example |
|---|---|---|---|---|
| Policy | **What** must happen, **who** it applies to and has authority, **why** (CAMP M:57-58; S:124) | Executive management, validated by HR and Legal | Rarely | "All IT assets are acquired through the approved acquisition process." |
| Standard | The specific mandatory values or choices that support a policy | Policy owner or delegated authority | Occasionally | "Standard laptop models are X and Y; refresh at N years." |
| Procedure (SOP) | **How** to do it, step by step (CAMP M:58) | Process owner | Often | Receiving and tagging SOP |
| Work instruction | Task-level how-to for one role or system | Process owner or team lead | Often | "Tagging a device in the stockroom app" |

Keep them in separate documents. Policies are general statements of intent and need higher approval; procedures change faster and are owned closer to the work (CAMP M:58). Mixing them forces every procedure tweak through policy approval, or lets procedure edits change policy by accident.

## 2. Policy lifecycle

Adapted from CAMP M:61-66.

| Stage | Activities | Output |
|---|---|---|
| 1. Identify the need | Driver (audit finding, incident, new asset class, legislation, M&A); scope statement | Policy request |
| 2. Form the team | Cross-functional representatives: ITAM, IT operations, HR, Legal, Finance, Security, a front-line manager | Named policy team and owner |
| 3. Needs analysis and research | Does a policy already exist or overlap? How does it fit other documents? Is it enforceable? Does it fit the culture? | Research note |
| 4. Draft | Use the structure in §3; plain language; what/who/why | Draft |
| 5. Validate | Selective circulation for feedback; check the audience understands it | Revised draft, feedback log |
| 6. Secure support | Visible executive sponsorship before investing heavily; drop or pause if absent (CAMP M:62) | Sponsor confirmation |
| 7. Approve | Executive approval of topic, language and enforcement; HR and Legal agree enforcement and consequences; a role is given authority to implement (CAMP M:62) | Approval record |
| 8. Publish and communicate | One accessible location; communication plan including why the policy exists and the risk of non-compliance | Publication, communications |
| 9. Acknowledge | Sign-off at hire and periodically (§5) | Acknowledgement records |
| 10. Enforce and measure | Uniform enforcement; compliance checks; metrics | Enforcement records, metrics |
| 11. Review and update | §6 | New version |

## 3. Policy document structure

Based on the structure suggested in CAMP M:68, extended with document-control fields.

```
[Organization] — [Policy title]
Policy ID: [ ]   Version: [ ]   Status: Draft / Approved   Classification: [ ]
Policy owner: [role]   Approved by: [role/forum]   Approval date: [ ]
Effective date: [ ]   Next review: [ ]   Supersedes: [ ]

1. Policy statement     What the policy governs, stated clearly and specifically.
2. Purpose              Why: the risks it reduces and the benefits it brings.
3. Accountability       The policy owner: the role ultimately responsible for issuing,
                        updating and monitoring compliance.
4. Scope                Who and what it applies to (employees, contractors, vendors;
                        asset classes; locations); exclusions.
5. Definitions          Terms that could be read differently.
6. Policy requirements  Numbered "must" statements, each enforceable and checkable.
7. Standards            Supporting standards referenced or defined (or links to them).
8. Roles                Summary of responsibilities (detail in RACI).
9. Exceptions           How to request one, who approves, how long it lasts, where recorded.
10. Implementation and enforcement  Rollout, awareness, compliance monitoring,
                        consequences as agreed with HR and Legal.
11. Related documents   Policies, standards, procedures, forms required for compliance.
12. Revision history    Version, date, change, approver.
```

## 4. ITAM policy topic catalog

The CAMP material lists more than 30 ITAM policy topics (CAMP M:57); the ones below are paraphrased from its catalog (CAMP M:69-71), grouped, with the controls each typically enables. Organizations often combine several into one document. Topics marked `PRACTICE` are additions not in that list.

| Group | Topic | What it establishes | Enables (examples) |
|---|---|---|---|
| Authority | Scope and authority for managing IT assets | The ITAM program's mandate and the asset manager's authority | Everything else; cross-department cooperation |
| Authority | Policy notification and acceptance | How policies are developed, published and formally accepted | Acknowledgement records |
| Authority | Contracting and compliance authorization | Who may accept agreements and compliance documents; central record of acceptances | Contract control, click-through prevention |
| Acquisition | Computing hardware acquisition | Standard acquisition route for hardware | Purchase control, standard catalog |
| Acquisition | Software acquisition and installation | Standard route for buying and installing software | License compliance, install control |
| Acquisition | Supported hardware and software standards, approved alternatives, exception management | Use of standards and the existence of an exception process | Standard catalog, non-standard approval |
| Acquisition | Trial-use, promotional and donated software | Whether "free" software may be installed, used, patched or removed, and by whom | License and security exposure control |
| Use | End-user use of computing devices (desktops, laptops, mobile) | What users may and may not do; consequences | Acceptable use enforcement |
| Use | Software code of ethics | Expected behavior of users of the organization's software | License compliance culture |
| Use | Anti-piracy and copyright | Legal obligations on copyrighted material; penalties | Compliance |
| Use | Use of internet and electronic communication | Acceptable internet and messaging use | Security, HR |
| Use | Use of removable storage | Rules and loss-prevention requirements for removable media | Data protection |
| Use | Mobile devices (corporate and personal) | Rules, security and data protection for mobile and BYOD | MAM, data protection |
| Use | Telecommuting / work from home | Use of company assets off-site; approvals for software and hardware changes | Remote asset control |
| Use | Privacy of information | No expectation of privacy on organization equipment and networks (Legal to confirm wording per jurisdiction) | Monitoring, discovery |
| Use | Loaned equipment | Whether and how loaned equipment may be used | Loaner control |
| Control | Removal of unauthorized or unlicensed software | Authority to remove software or files that don't meet standards or can't be proven licensed | License remediation |
| Control | Internal audit | Purpose, process and authority of internal ITAM audits | Audit cooperation |
| Control | Response to external audit requests | Roles, audit response team, communication rules during vendor or third-party audits | Audit containment |
| Control | Loss prevention | Handling of any loss; how, where and by whom assets may be used and transported off-site | Lost/stolen process |
| Control | Maintenance standards | What maintenance covers and exceptions | Warranty and support use |
| Vendors | Vendor communication | Who may talk to vendors and about what | Negotiation and audit protection |
| Vendors | Vendor negotiation | Acceptable and unacceptable negotiation practices | Commercial control |
| Records | Document management and retention | Retention of ITAM documents, aligned with organizational retention policy | Audit evidence |
| Records | Data management, backup and recovery | Data management and backup requirements | Continuity |
| Disposal | Asset disposal | Authorizes the disposal program; legal compliance; data security; required documentation | Sanitization and certificate controls |
| Lifecycle | Joiner-mover-leaver asset handling (`PRACTICE`) | Device issue on joining, transfer on moving, return deadline on leaving; manager and HR duties | Leaver recovery |
| Lifecycle | Asset tracking threshold (`PRACTICE`) | Which asset types are individually tracked vs. consumables | Inventory scope |
| Cloud | SaaS and cloud subscriptions (`PRACTICE`) | Who may subscribe, approval route, ownership of subscriptions | Shadow IT and spend control |

Choosing a starting set (`PRACTICE`): begin with scope and authority, acquisition (hardware and software), end-user use, disposal, external audit response and joiner-mover-leaver; add the others as the program matures or as risks appear.

## 5. Enforcement, acknowledgement and feedback

- **Three goals** for policy success (CAMP M:59-60): effective implementation including awareness; uniform enforcement across and within policies, with demonstrable consequences; periodic review to stay relevant.
- **Enforcement is agreed, not assumed.** HR and Legal define the enforcement procedure and consequences; executive management usually designates them as enforcers (CAMP M:62).
- **Acknowledgement.** Signed acknowledgement raises awareness; annual sign-off is suggested as a minimum, and new staff and contractors acknowledge at orientation (CAMP M:66). Extend to contractors, visitors and partners with access to assets (CAMP M:67).
- **Feedback mechanism.** Give staff a way to ask questions and suggest changes, for example a service desk category routed to the policy owner with a response target; this also yields metrics and revision input (CAMP M:65-66).
- **Explain the why.** Communications state why the policy exists, its benefits, and the risks and costs of non-compliance (CAMP M:66).

Acknowledgement template (draft for HR and Legal to adapt; not legal advice):

```
ITAM Policy Acknowledgement
I confirm that I have received and read the following IT asset management policies:
[list with IDs and versions]. I understand my responsibilities for the IT assets
assigned to me, including [return on leaving / reporting loss within TBD hours / no
unauthorized software]. I understand that breaches are handled under [HR policy reference].
Name: [ ]   Employee/contractor ID: [ ]   Date: [ ]   Signature or electronic record: [ ]
Record retained by: [HR / system — TBD]
```

## 6. Review cycle and trigger events

- **Cadence.** The CAMP material suggests reviewing a new policy about two months after it takes effect, adjusting and re-checking, then moving to roughly a six-month cycle; its program indicator counts policies reviewed every six months (CAMP M:24, M:62-63). The organization sets its own cycle: `[TBD: review frequency — policy owner]`.
- **Keep reviews light,** for example by checking service desk records for compliance (CAMP M:63).
- **Trigger events for out-of-cycle review:** new legislation; audit finding; significant incident (loss, breach, audit claim); new asset class or delivery model (SaaS, BYOD, AI tools); organizational change; merger or acquisition (review and integrate the other entity's asset policies; a merger may also prompt vendor audits, CAMP M:66-67); tool or system-of-record change.

## 7. Policy self-assessment

Paraphrased and condensed from the IAITAM self-assessment list (CAMP M:67). Interview IT, Procurement, Finance, Legal and user groups, including contractors.

1. Is there a complete list of IT-related policies, with owners?
2. Who is authorized to develop and review ITAM policies?
3. Does executive management approve policies?
4. Have HR and Legal agreed enforcement procedures and consequences?
5. Do employees and contractors understand, acknowledge and accept policies? What share sign off each year?
6. How is ongoing understanding and compliance checked (spot checks, surveys, audits)?
7. Do policies state what, why and, where needed, who?
8. Are policies in one accessible location?
9. How are questions and concerns handled, and how quickly?
10. How often are policies reviewed, and how is enforcement verified? Is it uniform?
11. How are policy changes handled during mergers and acquisitions?

## 8. Writing rules

- Prefer simple, broad statements that are hard to evade over long lists of technologies (CAMP M:63-64).
- Avoid letting legal language dominate; policies must be understood to be followed (CAMP M:64).
- Use "must" only for requirements the organization will enforce; put recommendations in guidance.
- Every requirement should be checkable: someone could gather evidence that it is met.
- Don't put procedures, system navigation or named individuals in a policy.
- Don't invent legal obligations, retention periods or thresholds; use `[TBD: … — Legal/owner to confirm]`.

Sources: CAMP M:24, M:29-32, M:57-72, M:103-104; S:119-125; AssetForge §12.
