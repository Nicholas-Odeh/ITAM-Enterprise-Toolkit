# Program governance: preflight and working method

Detail behind Steps 2 and 3 of `itam-program-governance`. Read it for any strategy, assessment, governance design or business case that will go to a sponsor.

## Contents
1. Preflight checklist
2. Working method
3. Output variants

## 1. Preflight checklist

Confirm, or state as assumptions:
- **Decision and audience:** what is being decided (fund, approve, restructure, prioritize) and by whom.
- **Scope:** asset classes (hardware, software, SaaS, mobile, cloud), business units, regions; which KPAs sit inside ITAM and which sit elsewhere (procurement, finance, legal).
- **Current-state evidence:** existing policies, org chart or role list, current tools and systems of record, metrics or audit findings, known pain points. Interviews or self-assessment answers count as evidence when attributed.
- **Business drivers:** cost reduction, risk and compliance, security visibility, audit findings, M&A, tool replacement. The program's priorities follow these, not the framework.
- **Constraints:** budget, headcount, timeline, regulatory environment, sponsor.

Ask one specific question if the decision or the sponsor is unknown. Otherwise proceed, label assumptions, and mark unassessed areas `NOT ASSESSED`.

## 2. Working method

- **Assess before designing.** Follow the self-assessment sequence (CAMP M:96-104): inventory what exists per KPA → SWOT → "is" map → "should" map → roles → needs and business drivers → cost/benefit → business case → executive buy-in → project plan → prioritization → processes → policy updates → communication and education plan. Detail: `maturity-model.md` §4.
- **Use the KPAs as a checklist, not a bureaucracy.** Start with the three foundation KPAs (Program, Policy, Communication & Education), then the operating KPAs the business drivers point at. Not every organization needs every KPA formalized at once (`kpa-catalog.md`).
- **Maturity:** rate capabilities 0–5 only on evidence (`maturity-model.md`); record evidence and gap per row; set target levels by business need, not "5 everywhere".
- **Roadmap:** sequence by dependency in five waves (Stabilize, Standardize, Integrate, Automate, Optimize) and give each initiative an owner, a dependency, an investment basis and a success measure (`strategy-roadmap.md` §4–5).
- **Governance:** define forums, decision rights, escalation, exception authority and review cadence. Check for responsibility without authority, authority without accountability, overlapping ownership, and policies with no operating control (`raci-template.md` §5–7).
- **Policy:** policy states what, who and why; procedure states how. Keep them in separate documents. Every policy needs an owner, executive approval, an enforcement agreement with HR and Legal, communication and acknowledgement, and a review cycle (`policy-topics.md`).
- **Business case:** connect each benefit to a business driver and a source; show what happens if nothing is done; flag every estimate as such (`business-case-template.md`).
- **Program health measures:** take metric definitions from the `itam-data-analysis-reporting` metrics catalog so the program and its reports use the same names; the KPA indicators in `kpa-catalog.md` map to it.

## 3. Output variants

**Default program deliverable:**
1. **Summary:** the decision or recommendation, the business drivers it serves, and the ask (money, people, sponsorship, approval).
2. **Current state:** evidence-based; maturity table where requested.
3. **Target state:** mission, objectives, operating model, governance.
4. **Roadmap:** waves with initiatives, owners, dependencies and measures.
5. **Governance artifacts:** RACI, policy set, communication plan, as requested.
6. **Assumptions, gaps and decisions needed.**

**Executive variant:** one page: the problem in business terms, the decision required, options with cost and risk, the recommended option, expected outcomes and how they will be measured, and what is needed from the executive. Detail goes to an appendix.

**Practitioner variant:** the full maturity table with evidence, KPA-by-KPA gaps, RACI, policy drafts and the initiative backlog.

Sources: CAMP M:25-28, M:58, M:96-110; AssetForge §19, 21, 27.
