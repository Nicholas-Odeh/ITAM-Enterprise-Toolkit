# Communication and education plan

Communication & Education is one of the three foundation KPAs: it is how policies and processes become behavior (CAMP M:25, M:33-35). Without a plan, communication is ad hoc and less effective (CAMP M:55). This file gives a plan structure, audience map, channel options, measures and a template.

## Contents
1. Principles
2. Audience map
3. Message design
4. Channels and cadence
5. Training plan
6. Measures
7. Plan template
8. Typical campaigns

## 1. Principles

- **Communication and education are different.** Communication shares information so people understand what needs doing; education teaches skills and is planned, with an agenda, materials and a check of understanding (CAMP M:33, M:54).
- **The communicator owns the result.** Success means the recipient understood and can act, so close the loop and check understanding (CAMP M:51-52).
- **Start early.** People told about ITAM policies and their value from day one are more likely to follow them (CAMP M:55).
- **Plan it, run it as a process, review it.** Use a cross-departmental team to plan events and gather feedback on effectiveness (CAMP M:55, M:104).
- **Reuse existing channels** (HR onboarding, corporate communications, training) before creating new ones (CAMP M:35).

## 2. Audience map

| Audience | What they need to know or do | Typical trigger |
|---|---|---|
| Executives and sponsors | Program value, risks, decisions needed, results | Steering cycle, budget cycle |
| Line managers | Their duties for joiners, movers and leavers; approvals; policy enforcement | Onboarding of managers, process change |
| General users | Acceptable use; how to request; care of assets; return on leaving; report loss promptly; no unauthorized software | Hire, annual refresh, policy change |
| Power users and software administrators | Install rules, license compliance, SAM responsibilities | Role assignment, annual |
| IT staff (service desk, field services, engineering) | Lifecycle procedures; record updates; evidence requirements | Process change, new hire into IT |
| Procurement and Finance | Acquisition route, asset record creation, invoice reconciliation, capitalization handoffs | Process change |
| HR and Legal | Leaver triggers, enforcement, retention | Policy change |
| On-site vendors and contractors | Policies that apply to them; asset handling | Contract start |
| ITAD and logistics vendors | Chain of custody, evidence requirements | Contract start, audit |

## 3. Message design

For each message, answer who, what, where and why before writing (CAMP M:54), and state:

- **The ask:** the specific action and deadline.
- **The why:** the benefit to the reader and the organization, and the risk or cost of not doing it (CAMP M:66).
- **How:** the link, form or contact.
- **Check:** how understanding is confirmed (acknowledgement, quiz, completion record, observed behavior).

The SPUR model in the CAMP material is a simple loop for this: prepare the information (Seek), deliver it with attention to medium and emphasis (Present), confirm it was received and understood (Understand), and close with a recap or follow-up (Recapture/Reinforce) (CAMP M:51-52; S:83).

Keep messages short, specific and in plain language. One action per message where possible.

## 4. Channels and cadence

| Channel | Good for | Notes |
|---|---|---|
| Onboarding / orientation session | Policy awareness and acknowledgement for new staff and contractors | Through HR; record completion |
| E-learning module | Repeatable training with a completion record and quiz | Assign by role |
| Intranet / policy portal | One authoritative location for policies and procedures | Link everywhere else to it |
| Email or chat announcement | Changes, deadlines, reminders | Short; link to the portal |
| Manager briefing pack | Duties for managers; cascade to teams | Include a one-page checklist |
| Webinar or classroom | Process changes for IT staff; Q&A | Record and publish |
| One-to-one | Executives, key stakeholders, difficult changes | Prepare with the stakeholder's goals in mind |
| Newsletter, posters, staff meetings | Awareness and program success stories | The program also markets ITAM value (CAMP M:26; S:52) |
| Service desk knowledge articles | Just-in-time how-to | Keep aligned with SOPs |

Cadence options (CAMP M:35): one-time (on hire or on change), periodic (quarterly, annual), event-driven (policy change, audit finding, new tool). Set the actual cadence in the plan: `[TBD]`.

## 5. Training plan

| Course | Audience | Content | Format | Frequency | Completion evidence | Owner |
|---|---|---|---|---|---|---|
| ITAM policy essentials | All staff and contractors | Acceptable use, care, return, loss reporting, software rules | E-learning + acknowledgement | On hire; `[TBD]` refresh | LMS record, acknowledgement | `[TBD]` |
| Manager duties | Line managers | JML duties, approvals, enforcement | Briefing pack + short module | On promotion; on change | LMS record | `[TBD]` |
| Lifecycle procedures | Service desk, field services | Deploy, recover, transfer, record updates, evidence | Workshop + SOP walkthrough | On hire into role; on SOP change | Attendance, competency check | `[TBD]` |
| SAM essentials | Software administrators, packagers | License rules, install approval, reclaim | Module | On role; annual | LMS record | `[TBD]` |
| ITAM team development | ITAM staff | Program skills, certifications, tools | Mixed, internal and external | Annual plan | Development records | Program owner |

## 6. Measures

From the CAMP indicator list (CAMP M:23; S:79), paraphrased, plus effectiveness measures (`PRACTICE`):

| Measure | Formula |
|---|---|
| Policy training coverage (by audience: general users, power users, software administrators, on-site vendors, new hires) | Trained in audience ÷ total in audience |
| Policy acknowledgement rate | Current acknowledgements ÷ in-scope staff and contractors |
| Time to train new hires | Median days from start date to policy training completion |
| Behavior outcome (`PRACTICE`) | e.g. leaver devices returned on time; unauthorized installs per 1,000 devices; loss reports within the required time |
| Policy questions volume and response time | Count and median time for policy queries via the feedback channel |

Measure behavior, not just attendance. If training completion rises but leaver returns don't improve, change the message or the process.

## 7. Plan template

```
ITAM Communication & Education Plan — [period]
Owner: [role]   Approved by: [role/forum]   Version: [ ]

1. Objectives        [what behavior or awareness should change, with measures]
2. Audiences         [from section 2, with sizes if known]
3. Key messages      [per audience: ask, why, how]
4. Calendar
   | Date/trigger | Audience | Message/course | Channel | Owner | Evidence | Status |
5. Training plan     [section 5 table]
6. Measures          [section 6, baseline and target or TBD]
7. Feedback loop     [how feedback is gathered and reviewed; who adjusts the plan]
8. Dependencies      [HR onboarding, LMS, corporate comms approvals]
```

## 8. Typical campaigns

| Campaign | Audience | Core message |
|---|---|---|
| Program launch | All staff, managers | What ITAM is, why it matters to them, what changes, where to find policies |
| Leaver device return | Managers, departing staff, HR | Return deadline and method; why (data protection, cost); who to contact |
| Software install rules | All staff, power users | How to request software; why unapproved installs create license and security exposure |
| Lost or stolen device reporting | All staff | Report immediately via [channel]; what happens next |
| Audit readiness | IT staff, software administrators | Evidence to keep; who speaks to vendors; don't respond to auditors directly |
| Policy change notice | Affected audiences | What changed, effective date, what to do differently |

Sources: CAMP M:23, M:25-26, M:33-35, M:50-56, M:66, M:104; S:77-85.
