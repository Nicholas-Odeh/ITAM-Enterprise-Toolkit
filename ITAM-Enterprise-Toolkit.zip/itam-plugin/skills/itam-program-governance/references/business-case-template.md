# ITAM business case and executive buy-in

Use this file to justify an ITAM program, initiative, tool, headcount or KPA build. A business case tells executives the story without making them redo the research: why, how, what happens with and without it, when the benefits arrive, and what it costs (CAMP M:100). For exact depreciation, TCO or NPV calculations, use the `itam-financial-management` skill.

## Contents
1. Rules for numbers
2. Business case structure
3. Cost/benefit worksheet
4. Benefit catalog with evidence basis
5. Financial measures
6. Sensitivity and risk of not acting
7. Preparing the executive pitch
8. Release checklist

## 1. Rules for numbers

- Every cost and benefit line has a **basis**: supplied data (`FACT`), a vendor quote (`FACT`, quote ref), a calculation from supplied data, or an explicit estimate (`ASSUMPTION` with the reasoning).
- **Never insert industry benchmark savings** ("ITAM saves 30%") as if they applied here. If the user wants a benchmark, it must come from a named, supplied source and be labeled `STANDARD`/`PRACTICE`, separate from the organization's numbers.
- Discount rate, hurdle rate, cost of capital, labor rates and capitalization rules come from Finance: `[TBD: discount rate — Finance]`.
- Separate **cash savings** (budget reduces), **cost avoidance** (spend that would have happened doesn't) and **risk reduction** (expected loss reduced). Executives and Finance treat them differently; don't add them into one "savings" figure without saying so.
- Show the **negative case** honestly. If the analysis comes out negative, that is a useful result: reassess or stop before money is spent (CAMP M:100).

## 2. Business case structure

| Section | Content |
|---|---|
| 1. Executive summary | The ask (money, people, approval), the problem in business terms, the recommended option, headline benefits and payback, decision deadline |
| 2. Problem and drivers | Current situation with evidence (audit findings, incidents, cost leakage, unrecovered devices, license exposure); which business drivers it hits (cost, risk, compliance, security, productivity) |
| 3. Objectives | Measurable outcomes the investment must produce |
| 4. Options | At least: do nothing, minimum fix, recommended option. For each: scope, cost, benefits, risks, timeline |
| 5. Recommended option | How it solves the problem; what changes in process, people, technology, data |
| 6. Costs | One-off and recurring, by year; people, tooling, services, change effort |
| 7. Benefits | By category and year, with basis; when and where they are realized (CAMP M:100) |
| 8. Financial summary | ROI, NPV, payback (section 5); assumptions table |
| 9. Risk of not acting | What happens if the plan isn't funded (CAMP M:99-100) |
| 10. Implementation | Phases, milestones, dependencies, owner, resources |
| 11. Measures and benefit tracking | KPIs, baseline, target or TBD, who reports, when the benefits are reviewed against the case |
| 12. Risks and mitigations | Delivery, adoption, data, vendor risks |
| 13. Decision requested | Exactly what the executive is asked to approve, by when |
| Appendix | Data, calculations, sensitivity, assumptions register |

## 3. Cost/benefit worksheet

A spreadsheet is the usual tool (CAMP M:99). Minimum layout:

| Line | Category | Year 0 | Year 1 | Year 2 | Year 3 | Basis / source | Label |
|---|---|---:|---:|---:|---:|---|---|
| Tool licenses | Cost (recurring) | | | | | Quote ref | `FACT` |
| Implementation services | Cost (one-off) | | | | | SOW ref | `FACT` |
| Internal effort | Cost | | | | | Hours × rate from Finance | `ASSUMPTION` until confirmed |
| Change / training | Cost | | | | | | |
| Redeployment instead of new purchase | Cost avoidance | | | | | Units × unit cost, from asset data | |
| License reharvest | Cash saving or avoidance | | | | | Reclaimable seats × price, from license data | |
| Invoice errors recovered | Cash saving | | | | | Sample error rate × spend | |
| Reduced audit exposure | Risk reduction | | | | | Exposure estimate method stated | `INFERENCE` |
| **Net cash flow** | | | | | | | |
| **Cumulative** | | | | | | | |

## 4. Benefit catalog with evidence basis

Savings areas named in the CAMP material include reuse and redeployment, contract and volume negotiation, invoice reconciliation, effective use of warranties, cost reduction and investment planning (CAMP S:104-109; M:88-93). The table adds the data you need to quantify each.

| Benefit | How to quantify | Evidence needed |
|---|---|---|
| Redeployment / reuse | Units redeployed × avoided purchase price | Stock of reusable assets, purchase price, demand forecast |
| Leaver device recovery | Additional devices recovered × replacement cost (net of refurbishment) | Leaver list, unrecovered device count, unit cost |
| License reharvest and rightsizing | Reclaimed seats × price, or avoided true-up | Usage data, entitlement records, price list |
| Audit exposure reduction | Shortfall × list price (unpaid exposure), probability stated as assumption | License position, contract audit terms |
| Invoice reconciliation | Errors found × value | Invoice sample, PO and receiving records |
| Warranty use | Repairs under warranty × out-of-warranty repair cost | Repair tickets, warranty dates |
| Contract negotiation | Price difference vs. previous or quoted price | Quotes, contracts |
| Lease management | Avoided late-return or over-term charges | Lease schedules, return dates |
| Disposal value recovery | Resale or recycling credit | ITAD settlement reports |
| Productivity | Hours saved × loaded rate (only if the time is redeployed or the cost avoided) | Time studies, ticket data |
| Security / data protection | Fewer unaccounted devices with data; faster response | Incident data, unmanaged device counts |

TCO is the basis for many of these; check that the TCO includes acquisition, operation, support, licensing, financing, redeployment and disposal costs, and compare projections with actuals later (CAMP M:91-94; S:104-109).

## 5. Financial measures

Use the measures Finance uses. Definitions (CAMP M:107-108 lists these among common measures):

| Measure | Formula | Notes |
|---|---|---|
| ROI | (Total benefits − total costs) ÷ total costs | State the period and whether benefits are cash or avoidance |
| Net present value (NPV) | Σ (net cash flow in year t) ÷ (1 + r)^t, for t = 0…n | r = discount rate from Finance |
| Internal rate of return (IRR) | The r at which NPV = 0 | Compare to the hurdle rate from Finance |
| Payback period | Time until cumulative net cash flow turns positive | Simple payback ignores discounting; say which you used |
| TCO | Sum of lifecycle costs per asset or service | See `itam-financial-management` |

Show formulas and inputs; recompute the headline figures by a second route before release.

## 6. Sensitivity and risk of not acting

- **Sensitivity:** show the result if the two or three most uncertain inputs are 25–50% worse (for example recovery rate, adoption speed, unit price). If the decision flips, say so.
- **Risk of not acting:** list what continues if nothing is funded, using current data (for example devices unrecovered per quarter × cost; open audit findings; license exposure). Express probability and impact as estimates with their basis, never as facts.

## 7. Preparing the executive pitch

From the CAMP guidance on gaining buy-in (CAMP M:100-101), condensed:

1. **Know the executive:** their responsibilities, stated goals, current concerns and presentation preferences.
2. **Relate the plan to their goals.** Show the direct benefit to their area.
3. **Summarize hard.** Executives have little time; lead with the decision and the numbers, but be ready to defend any figure on the spot.
4. **Anticipate "what does this mean for me?"** and close with it.
5. **Show confidence through preparation:** clear summary documents, consistent numbers, honest risks.

One-page executive brief:

```
Decision requested: [approve X budget / headcount / policy] by [date]
Problem: [one or two sentences, in business terms, with the key evidence]
Recommendation: [option] — [what changes]
Cost: [one-off] + [recurring/yr]          Basis: [quotes / estimates]
Benefits: [cash] + [avoidance] + [risk reduction], realized [when]
Payback: [months]   NPV: [value at r = TBD]   Confidence: [HIGH/MODERATE/LOW + why]
If we don't: [consequence, with evidence]
Measures we will report: [2–3 KPIs], first review [date]
```

## 8. Release checklist

- ★ Every number has a basis and label; no unsourced benchmark savings.
- ★ Cash savings, cost avoidance and risk reduction are shown separately.
- ★ Formulas shown; headline ROI/NPV/payback recomputed.
- The do-nothing option is included and honest.
- Benefits have owners and a review date to compare actuals with the case.
- Assumptions register lists each estimate, its owner and how to confirm it.

Sources: CAMP M:88-94, M:99-101, M:107-108; S:104-109; AssetForge §21–22.
