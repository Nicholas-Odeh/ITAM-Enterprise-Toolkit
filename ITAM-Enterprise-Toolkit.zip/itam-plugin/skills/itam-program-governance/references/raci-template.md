# Roles, RACI and governance structure

Use this file to design ownership and decision rights for an ITAM program. The starter RACI is general practice (`PRACTICE`), not the organization's actual assignment; replace it with confirmed roles before publishing.

## Contents
1. Principles
2. Role catalog
3. RACI rules
4. Starter RACI for core ITAM activities
5. Governance forums
6. Decision-rights matrix
7. Governance gap checks
8. Segregation-of-duties checks

## 1. Principles

- **Roles, not people or job titles.** A role is a set of responsibilities in a process; one person may hold several roles and one role may be shared by several people (CAMP M:98, M:111, M:116).
- **Name the role in every control.** "The organization" or "IT" is not an owner (AssetForge §12).
- **Don't put everything on ITAM.** Finance owns book value, HR owns employment status, Legal interprets law and contracts, Security owns sanitization standards, Procurement owns purchasing. ITAM coordinates and holds the asset record.
- **Make a RACI when ambiguity creates risk,** not for every activity.

## 2. Role catalog

Roles described in the CAMP material (paraphrased, CAMP M:111-116), plus roles the Forge method adds (AssetForge §12). Use what applies; rename to the organization's titles.

| Role | Core responsibilities | Typical reporting / home |
|---|---|---|
| Executive sponsor | Sponsors the program, approves policy and funding, removes blockers | Executive (CIO/CFO/COO) |
| ITAM Program Owner / Program Manager | Owns mission, strategy, roadmap, measures; coordinates KPAs; reports to leadership | IT or Finance leadership |
| Acquisition Manager | Gatekeeper for IT purchases; justification; checks redeployment first; runs RFQ/RFP for non-standard items; ensures receiving and RMA processes | Program Manager (CAMP M:111) |
| Asset Identification Manager | Directs tagging and tracking of asset types the program decides to track | Program Manager (CAMP M:111) |
| Asset Identification Personnel | Accept assets, assign unique identifiers, record in ITAM repository and fixed-asset register, notify parties of status | Asset Identification Manager |
| Receiver | Receives shipments, inspects for damage, rejects or starts acceptance, notifies parties | Asset Identification Manager (CAMP M:115) |
| Compliance & Legislation Manager / Personnel | Research laws and pending regulation affecting assets; communicate obligations; ensure program compliance; support audit response and negotiation teams | Program Manager (CAMP M:112) |
| Disposal Manager / Personnel | Run disposal; ensure regulation and documentation; work with Security on data protection; track market value and harvest | Program Manager (CAMP M:113) |
| Documentation Manager / Personnel | Own the ITAM document repository, archiving, retention, change control, offsite storage | Program Manager (CAMP M:113) |
| Finance Manager / Personnel | Purchase orders and payments; invoice reconciliation; budget support; financial document retention | Program Manager in the CAMP model; often Finance in practice (CAMP M:113-114) |
| Communication Manager | Plan and track ITAM communications, with corporate communications | Program Manager (CAMP M:114) |
| Education Manager | Plan and track ITAM training, with the corporate training function | Program Manager (CAMP M:114) |
| Policy Manager / Personnel | Create and maintain ITAM policies; agree enforcement with HR and Legal | Program Manager (CAMP M:114) |
| Project Manager / Team | Run ITAM projects: charter, plan, buy-in, delivery, closure | Program Manager (CAMP M:115) |
| Technical Personnel | Evaluate, configure and install assets to standard; monitor via discovery; report status | Program Manager in the CAMP model; usually IT operations in practice (CAMP M:115) |
| Vendor Manager / Personnel | Monitor strategic vendors; scorecards; performance; crisis management; corrective actions | Program Manager (CAMP M:115-116) |
| Disaster Recovery Personnel | Support continuity across KPAs | Outside ITAM (CAMP M:112) |
| Hardware Asset Manager / Software Asset Manager | Run HAM and SAM functional areas | ITAM |
| Configuration Manager | Owns CMDB, CI classes and relationships | ITSM / IT operations |
| Service, product, application, business and technical owners | Own services and applications that consume assets | Business / IT |
| Custodian / end user | Uses and safeguards assigned assets; returns them | All staff |
| Service desk / field services | Deploy, swap, recover and update records | IT operations |
| Procurement | Purchasing, supplier contracting | Procurement |
| HR | Joiner-mover-leaver events; policy enforcement with Legal | HR |
| Legal | Contract and legal interpretation; policy validation and enforcement | Legal |
| Information Security | Security standards, sanitization standard, incident handling for lost/stolen | Security |
| Internal Audit | Independent assurance | Audit |
| ITAD / disposal vendor | Collection, sanitization, certificates, recycling or resale | External |

## 3. RACI rules

- **R** Responsible: does the work. **A** Accountable: owns the outcome and final decision. **C** Consulted: gives required input before. **I** Informed: told after.
- Exactly one **A** per activity, unless a source explicitly requires shared accountability.
- Every activity has at least one **R**. The **A** may also be **R**.
- Too many **C**s slow decisions; keep them to roles whose input changes the outcome.
- Add an **Evidence** column: what artifact proves the activity happened (AssetForge §12).
- Check every row against authority: is the **A** role actually empowered (by policy or charter) to decide?

Template:

| Activity | Accountable | Responsible | Consulted | Informed | Evidence |
|---|---|---|---|---|---|

## 4. Starter RACI for core ITAM activities

`PRACTICE` starter only. Abbreviations: SP sponsor, PO ITAM program owner, AM asset manager (HAM), SAM software asset manager, SD service desk/field services, PR procurement, FN finance, HR, LG legal, SEC security, CM configuration manager, LM line manager, EU end user, VD ITAD vendor, IA internal audit.

| Activity | A | R | C | I | Evidence |
|---|---|---|---|---|---|
| Approve ITAM policy | SP | PO | LG, HR, SEC, FN | All staff | Signed approval record |
| Maintain and review ITAM policy | PO | PO | LG, HR | SP | Review log, version history |
| Enforce policy breaches | HR | LM | LG, PO | PO | Case record |
| Approve non-standard purchase | PO | AM | FN, SEC | Requester | Approval record |
| Raise purchase order | PR | PR | AM | FN | PO |
| Receive, tag and record asset | AM | AM (receiving staff) | PR | FN | Receiving record, asset record |
| Deploy and assign device | AM | SD | EU | LM | Assignment record, user acknowledgement |
| Recover leaver device | AM | SD | HR, LM | SEC | Return record, asset state change |
| Reconcile inventory (repository vs. discovery vs. physical) | AM | AM | CM, SD | PO | Reconciliation report |
| Resolve reconciliation exceptions | AM | SD | CM | PO | Exception register with closure evidence |
| Maintain asset–CI relationships | CM | CM | AM | PO | CMDB health report |
| Maintain software license position | SAM | SAM | PR, LG | PO, FN | License position report |
| Respond to vendor audit | PO | SAM | LG, PR, FN | SP | Audit response file |
| Approve disposal method | PO | AM | SEC, FN, LG | IA | Disposal approval |
| Sanitize and dispose | AM | VD | SEC | FN | Sanitization record, certificate of destruction |
| Maintain fixed-asset register | FN | FN | AM | PO | Register reconciliation |
| Reconcile invoices | FN | FN | AM, PR | PO | Reconciliation log |
| Review strategic vendor performance | PO | AM or SAM | PR, FN | SP | Dated scorecard |
| Deliver ITAM training and communications | PO | PO (comms/education lead) | HR | All staff | Training records, acknowledgement rate |
| Report program KPIs | PO | AM, SAM | FN | SP | KPI pack, steering minutes |

## 5. Governance forums

Typical structure (`PRACTICE`); size it to the organization.

| Forum | Members | Cadence | Decides | Inputs | Outputs |
|---|---|---|---|---|---|
| ITAM steering committee | Sponsor (chair), program owner, Finance, Procurement, Security, HR, Legal as needed | `[TBD: e.g. quarterly]` | Priorities, funding, policy approval route, risk acceptance above threshold | KPI pack, roadmap status, top risks, decisions requested | Decision log, actions |
| ITAM operations review | Program owner (chair), HAM, SAM, service desk, CMDB owner | `[TBD: e.g. monthly]` | Exception handling, process changes within policy, backlog | Exception register, reconciliation results, SLA metrics | Action log |
| Policy review | Policy owner, Legal, HR, Security | On the policy review cycle and on trigger events | Policy changes to propose for approval | Feedback, incidents, legal changes | Revised policy drafts |
| Change advisory (existing) | Per ITSM | Per ITSM | Changes affecting asset/CI data or integrations | Change requests | Approved changes |

## 6. Decision-rights matrix

| Decision | Decides | Must consult | Escalates to | Recorded in |
|---|---|---|---|---|
| Add an asset class to ITAM scope | `[TBD]` | | | |
| Approve a policy exception | `[TBD]` | | | |
| Accept a risk (e.g. unrecovered device, license shortfall) | `[TBD]` | | | |
| Write off a lost or missing asset | `[TBD]` | | | |
| Select a disposal method or ITAD vendor | `[TBD]` | | | |
| Approve a non-standard device | `[TBD]` | | | |
| Change the system of record for an attribute | `[TBD]` | | | |

Fill from the organization's delegation of authority. Don't invent thresholds (for example a write-off value limit); use `[TBD: threshold — Finance to confirm]`.

## 7. Governance gap checks

Look for these patterns (RiskForge §24):

| Gap | Symptom |
|---|---|
| Responsibility without authority | ITAM is asked to recover devices but cannot compel managers or HR |
| Authority without accountability | A committee approves exceptions but nobody tracks them |
| Overlapping ownership | Service desk and asset team both "own" assignment updates |
| Missing approval authority | No one can approve disposal or write-off |
| Uncontrolled exceptions | Exceptions approved by email, never expire |
| Ineffective escalation | Overdue items escalate to a mailbox nobody reads |
| Unclear decision thresholds | "Significant" purchases need approval, undefined |
| Policy without operating control | Policy requires annual inventory, no procedure or evidence |
| No review cadence | Policies and RACI last reviewed years ago |

## 8. Segregation-of-duties checks

`PRACTICE`; confirm with Internal Audit for the organization's control framework.

- The person who approves a purchase should not also receive it and record it without review.
- The role that records an asset as disposed should not be the only role confirming the certificate.
- Write-offs of missing assets need approval outside the team that lost them.
- Changes to reconciliation rules or system-of-record precedence go through change control.

Sources: CAMP M:98, M:111-116; S:50, S:146-150; AssetForge §12; RiskForge §20, 24.
