#!/usr/bin/env python3
"""Depreciation schedules and net book value (NBV) for IT assets.

Methods
  sl  straight-line: (cost - salvage) / life per full period, final period plugs rounding.
  db  declining balance: opening NBV x (factor / life) per period, never below salvage.
      By default it switches to straight-line over the remaining life when that is larger
      (the behavior of Excel's VDB with no_switch=FALSE). --no-switch disables this; the
      remaining NBV above salvage is then taken in the last period of the life.

Periods and first-period conventions
  --period month : calendar months.   --period year : fiscal years (see --fy-start-month).
  full    the period containing the in-service date counts as a full period
  next    depreciation starts in the period after the in-service date
  half    the first period counts as half; the life ends half a period later
  prorate first period prorated (month: by days; year: by months left in the fiscal year)

The method, life, salvage and convention are accounting policy. Take them from the
organization's finance policy; this script does not choose them.

Input CSV columns (header row required):
  asset_id, cost, in_service_date (YYYY-MM-DD), life_months  (or life_years)
  optional per-row overrides: salvage, method, db_factor, convention

Output: per-period schedule (default) or an as-of summary (--report summary --as-of DATE),
as CSV or JSON. Amounts use decimal arithmetic rounded per period (--decimals, default 2).
"As of" totals include only periods that END on or before the as-of date, so use a
period-end date (for monthly schedules, a month-end).

Exit codes: 0 ok; 2 usage error or no valid rows; 3 some rows rejected (listed on stderr).

Examples
  python3 depreciation.py --asset-id LT-001 --cost 1500 --in-service 2025-03-14 \
      --life-months 36 --method sl
  python3 depreciation.py --input assets.csv --period year --fy-start-month 7 \
      --method db --db-factor 2 --format json
  python3 depreciation.py --input assets.csv --report summary --as-of 2026-06-30
"""

import argparse
import calendar
import csv
import json
import sys
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation

METHODS = ("sl", "db")
CONVENTIONS = ("full", "next", "half", "prorate")
MAX_PERIODS = 2400  # safety stop (200 years of months)


class RowError(ValueError):
    pass


def parse_date(text):
    try:
        y, m, d = (int(x) for x in str(text).strip().split("-"))
        return date(y, m, d)
    except Exception:
        raise RowError("invalid date %r (expected YYYY-MM-DD)" % text)


def parse_dec(text, field, allow_blank=False, default=None):
    if text is None or str(text).strip() == "":
        if allow_blank:
            return default
        raise RowError("missing %s" % field)
    try:
        return Decimal(str(text).strip().replace(",", ""))
    except InvalidOperation:
        raise RowError("invalid number for %s: %r" % (field, text))


def fmt_num(x, places=None):
    """Plain decimal string without exponent; optional rounding."""
    if places is not None:
        x = x.quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)
    s = format(x, "f")
    return s.rstrip("0").rstrip(".") if "." in s else s


def add_months(d, n):
    y, m = divmod(d.month - 1 + n, 12)
    return date(d.year + y, m + 1, 1)


def month_end(d):
    return date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])


def fy_start_for(d, fy_start_month):
    year = d.year if d.month >= fy_start_month else d.year - 1
    return date(year, fy_start_month, 1)


def period_bounds(start, period):
    """Return (start, end) of the period beginning at start."""
    if period == "month":
        return start, month_end(start)
    nxt = add_months(start, 12)
    return start, nxt - timedelta(days=1)


def period_label(pstart, pend, period):
    if period == "month":
        return "%04d-%02d" % (pstart.year, pstart.month)
    return "FY%04d" % pend.year  # fiscal year named by the calendar year it ends in


def first_period(in_service, period, convention, fy_start_month):
    """Return (start date of first depreciating period, fraction of that period)."""
    if period == "month":
        start = date(in_service.year, in_service.month, 1)
        days = calendar.monthrange(in_service.year, in_service.month)[1]
        prorate = Decimal(days - in_service.day + 1) / Decimal(days)
        step = 1
    else:
        start = fy_start_for(in_service, fy_start_month)
        months_left = 12 - ((in_service.month - fy_start_month) % 12)
        prorate = Decimal(months_left) / Decimal(12)
        step = 12
    if convention == "full":
        return start, Decimal(1)
    if convention == "next":
        return add_months(start, step), Decimal(1)
    if convention == "half":
        return start, Decimal("0.5")
    return start, prorate


def build_schedule(a, opts):
    q = Decimal(1).scaleb(-opts.decimals)

    def rnd(x):
        return x.quantize(q, rounding=ROUND_HALF_UP)

    cost, salvage = a["cost"], a["salvage"]
    base = cost - salvage
    life = a["life_months"] if opts.period == "month" else a["life_months"] / Decimal(12)
    start, frac0 = first_period(a["in_service"], opts.period, a["convention"], opts.fy_start_month)
    step = 1 if opts.period == "month" else 12
    rate = a["db_factor"] / life
    sl_per_period = base / life

    rows, nbv, acc, remaining = [], cost, Decimal(0), life
    pstart, k = start, 0
    while acc < base and remaining > 0 and k < MAX_PERIODS:
        frac = frac0 if k == 0 else Decimal(1)
        if frac > remaining:
            frac = remaining
        last_of_life = (remaining - frac) <= 0
        if a["method"] == "sl":
            dep = sl_per_period * frac
        else:
            dep = nbv * rate * frac
            if not a["no_switch"]:
                dep = max(dep, (nbv - salvage) / remaining * frac)
        dep = rnd(min(max(dep, Decimal(0)), nbv - salvage))
        if last_of_life or acc + dep >= base:
            dep = base - acc  # final period absorbs rounding
        opening = nbv
        nbv -= dep
        acc += dep
        remaining -= frac
        ps, pe = period_bounds(pstart, opts.period)
        rows.append({
            "asset_id": a["asset_id"],
            "method": a["method"] + ("" if a["method"] == "sl" else "(x%s%s)" % (
                fmt_num(a["db_factor"]), ",no-switch" if a["no_switch"] else "")),
            "period_no": k + 1,
            "period_label": period_label(ps, pe, opts.period),
            "period_start": ps.isoformat(),
            "period_end": pe.isoformat(),
            "fraction": fmt_num(frac, 6),
            "opening_nbv": str(rnd(opening)),
            "depreciation": str(rnd(dep)),
            "accumulated_depreciation": str(rnd(acc)),
            "closing_nbv": str(rnd(nbv)),
        })
        pstart = add_months(pstart, step)
        k += 1
    return rows


def summarize(a, rows, as_of, decimals):
    q = Decimal(1).scaleb(-decimals)
    done = [r for r in rows if parse_date(r["period_end"]) <= as_of]
    acc = Decimal(done[-1]["accumulated_depreciation"]) if done else Decimal(0)
    nbv = a["cost"] - acc
    return {
        "asset_id": a["asset_id"],
        "method": rows[0]["method"] if rows else a["method"],
        "cost": str(a["cost"].quantize(q)),
        "salvage": str(a["salvage"].quantize(q)),
        "in_service_date": a["in_service"].isoformat(),
        "life_months": fmt_num(a["life_months"]),
        "periods_elapsed": len(done),
        "periods_total": len(rows),
        "accumulated_depreciation": str(acc.quantize(q)),
        "nbv": str(nbv.quantize(q)),
        "fully_depreciated": bool(rows) and len(done) == len(rows),
        "first_period": rows[0]["period_label"] if rows else "",
        "last_period": rows[-1]["period_label"] if rows else "",
    }


def normalize_row(raw, opts, rownum):
    get = lambda k: (raw.get(k) or "").strip()
    asset_id = get("asset_id") or "row%d" % rownum
    cost = parse_dec(get("cost"), "cost")
    if cost <= 0:
        raise RowError("cost must be > 0")
    salvage = parse_dec(get("salvage"), "salvage", True, opts.salvage)
    if salvage < 0 or salvage >= cost:
        raise RowError("salvage must be >= 0 and < cost")
    in_service = parse_date(get("in_service_date"))
    lm = parse_dec(get("life_months"), "life_months", True, None)
    if lm is None:
        ly = parse_dec(get("life_years"), "life_years", True, None)
        lm = ly * 12 if ly is not None else opts.life_months
    if lm is None or lm <= 0:
        raise RowError("life_months (or life_years) must be > 0")
    method = (get("method") or opts.method).lower()
    if method not in METHODS:
        raise RowError("method must be one of %s" % ", ".join(METHODS))
    factor = parse_dec(get("db_factor"), "db_factor", True, opts.db_factor)
    if method == "db" and factor <= 0:
        raise RowError("db_factor must be > 0")
    conv = (get("convention") or opts.convention).lower()
    if conv not in CONVENTIONS:
        raise RowError("convention must be one of %s" % ", ".join(CONVENTIONS))
    return {"asset_id": asset_id, "cost": cost, "salvage": salvage, "in_service": in_service,
            "life_months": lm, "method": method, "db_factor": factor,
            "no_switch": opts.no_switch, "convention": conv}


def main(argv=None):
    p = argparse.ArgumentParser(
        description=__doc__.split("\n\n")[0],
        epilog=__doc__.split("\n", 1)[1],
        formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p.add_argument_group("input (CSV or a single asset)")
    src.add_argument("--input", help="CSV file of assets (see column list below)")
    src.add_argument("--asset-id", default="ASSET")
    src.add_argument("--cost", help="acquisition cost (single asset)")
    src.add_argument("--in-service", help="in-service date YYYY-MM-DD (single asset)")
    src.add_argument("--life-months", type=Decimal, help="useful life in months (default for CSV rows)")
    src.add_argument("--life-years", type=Decimal, help="useful life in years (alternative)")
    pol = p.add_argument_group("policy (defaults; CSV columns override per row)")
    pol.add_argument("--method", choices=METHODS, default="sl")
    pol.add_argument("--db-factor", type=Decimal, default=Decimal("2"),
                     help="declining-balance factor: 2 = double declining, 1.5 = 150%% (default 2)")
    pol.add_argument("--no-switch", action="store_true", help="declining balance: do not switch to straight-line")
    pol.add_argument("--salvage", type=Decimal, default=Decimal("0"), help="salvage/residual value (default 0)")
    pol.add_argument("--convention", choices=CONVENTIONS, default="full")
    pol.add_argument("--period", choices=("month", "year"), default="month")
    pol.add_argument("--fy-start-month", type=int, default=1, help="first month of the fiscal year (1-12, default 1)")
    out = p.add_argument_group("output")
    out.add_argument("--report", choices=("schedule", "summary"), default="schedule")
    out.add_argument("--as-of", help="as-of date YYYY-MM-DD for --report summary")
    out.add_argument("--format", choices=("csv", "json"), default="csv")
    out.add_argument("--decimals", type=int, default=2)
    out.add_argument("--output", help="write to this file instead of stdout")
    opts = p.parse_args(argv)

    if not 1 <= opts.fy_start_month <= 12:
        p.error("--fy-start-month must be 1-12")
    if opts.life_months is None and opts.life_years is not None:
        opts.life_months = opts.life_years * 12
    if opts.report == "summary" and not opts.as_of:
        p.error("--report summary needs --as-of")
    as_of = None
    if opts.as_of:
        try:
            as_of = parse_date(opts.as_of)
        except RowError as e:
            p.error(str(e))

    if opts.input:
        with open(opts.input, newline="", encoding="utf-8-sig") as fh:
            raw_rows = [{(k or "").strip().lower(): v for k, v in r.items()} for r in csv.DictReader(fh)]
    elif opts.cost and opts.in_service:
        raw_rows = [{"asset_id": opts.asset_id, "cost": opts.cost, "in_service_date": opts.in_service}]
    else:
        p.error("give --input CSV, or --cost, --in-service and --life-months for one asset")

    assets, errors = [], []
    for i, raw in enumerate(raw_rows, start=2):  # row 1 is the header
        try:
            assets.append(normalize_row(raw, opts, i))
        except RowError as e:
            errors.append({"row": i, "asset_id": (raw.get("asset_id") or "").strip(), "error": str(e)})

    schedules = [(a, build_schedule(a, opts)) for a in assets]
    params = {k: (str(v) if isinstance(v, Decimal) else v) for k, v in vars(opts).items()
              if k in ("method", "db_factor", "no_switch", "salvage", "convention", "period",
                       "fy_start_month", "decimals", "as_of", "report")}

    fh = open(opts.output, "w", newline="", encoding="utf-8") if opts.output else sys.stdout
    try:
        if opts.report == "summary":
            summ = [summarize(a, rows, as_of, opts.decimals) for a, rows in schedules]
            tot = lambda k: str(sum((Decimal(s[k]) for s in summ), Decimal(0)))
            if opts.format == "json":
                json.dump({"parameters": params, "summary": summ,
                           "totals": {"assets": len(summ), "cost": tot("cost"),
                                      "accumulated_depreciation": tot("accumulated_depreciation"),
                                      "nbv": tot("nbv")},
                           "errors": errors}, fh, indent=2)
                fh.write("\n")
            else:
                if summ:
                    w = csv.DictWriter(fh, fieldnames=list(summ[0].keys()))
                    w.writeheader()
                    w.writerows(summ)
        else:
            if opts.format == "json":
                json.dump({"parameters": params,
                           "assets": [{"asset_id": a["asset_id"], "cost": str(a["cost"]),
                                       "salvage": str(a["salvage"]),
                                       "in_service_date": a["in_service"].isoformat(),
                                       "life_months": fmt_num(a["life_months"]),
                                       "convention": a["convention"],
                                       "total_depreciation": rows[-1]["accumulated_depreciation"] if rows else "0",
                                       "schedule": rows} for a, rows in schedules],
                           "errors": errors}, fh, indent=2)
                fh.write("\n")
            else:
                allrows = [r for _, rows in schedules for r in rows]
                if allrows:
                    w = csv.DictWriter(fh, fieldnames=list(allrows[0].keys()))
                    w.writeheader()
                    w.writerows(allrows)
    finally:
        if opts.output:
            fh.close()

    for e in errors:
        print("REJECTED row %(row)s (%(asset_id)s): %(error)s" % e, file=sys.stderr)
    if not assets:
        return 2
    return 3 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
