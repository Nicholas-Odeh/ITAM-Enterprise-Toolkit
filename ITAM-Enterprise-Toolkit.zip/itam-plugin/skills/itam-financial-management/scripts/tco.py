#!/usr/bin/env python3
"""TCO, NPV, IRR, ROI, payback and equivalent periodic cost for one or more options.

Use it for total cost of ownership per device or fleet, lease-vs-buy comparisons,
business cases and refresh-option comparisons. Every option must cover the same service
period and units, or the comparison is not like-for-like.

Input CSV columns (header row required):
  option     name of the alternative, e.g. Buy-48m, Lease-36m, Status quo
  period     integer >= 0. Period 0 = today (not discounted); period t is discounted as
             a cash flow at the END of period t.
  kind       cost | benefit
  category   free text, e.g. purchase, lease_payment, support, imaging, disposal,
             residual_value, labor_saved
  amount     number. Costs are positive; a credit that reduces cost (residual or resale
             value, rebate) is a NEGATIVE cost so that TCO nets it.

Discounting: --rate is the ANNUAL discount rate from Finance (for example 0.08 or 8%).
It is required; pass 0 for undiscounted TCO. With --periods-per-year 12 the period rate is
(1 + rate)^(1/12) - 1.

Outputs per option: total and present-value (PV) cost and benefit, NPV (PV benefits - PV
costs), equivalent periodic cost (EAC: PV cost spread evenly over the horizon at the
period rate), cost per unit (--units), simple ROI ((benefits - costs) / costs,
undiscounted), discounted ROI (NPV / PV cost), simple and discounted payback (periods,
interpolated), and IRR of the net cash flow (per period and annualized; flagged when the
flow changes sign more than once). Options are ranked by PV cost.

Exit codes: 0 ok; 2 usage error or no valid rows; 3 some rows rejected (listed on stderr).

Examples
  python3 tco.py --input flows.csv --rate 0.08 --units Buy=500 --units Lease=500
  python3 tco.py --input flows.csv --rate 8% --periods-per-year 12 --format json
  python3 tco.py --input flows.csv --rate 0 --detail --output detail.csv
"""

import argparse
import csv
import json
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, getcontext

getcontext().prec = 34


class RowError(ValueError):
    pass


def parse_rate(text):
    t = str(text).strip()
    pct = t.endswith("%")
    try:
        v = Decimal(t.rstrip("%").strip())
    except InvalidOperation:
        raise argparse.ArgumentTypeError("invalid rate %r" % text)
    v = v / 100 if pct else v
    if v <= -1:
        raise argparse.ArgumentTypeError("rate must be greater than -100%")
    return v


def npv_at(flows, r):
    """flows: list of (period, amount) floats; r per-period rate (float)."""
    return sum(a / (1.0 + r) ** t for t, a in flows)


def irr(flows):
    """Bisection IRR on per-period net flows. Returns (rate or None, note)."""
    amounts = [a for _, a in sorted(flows) if a != 0]
    if not amounts or min(amounts) >= 0 or max(amounts) <= 0:
        return None, "no sign change in net cash flow"
    changes = sum(1 for x, y in zip(amounts, amounts[1:]) if (x < 0) != (y < 0))
    note = "multiple sign changes; IRR may not be unique" if changes > 1 else ""
    grid = [-0.99, -0.9, -0.75, -0.5, -0.25, -0.1, 0.0, 0.05, 0.1, 0.2, 0.35, 0.5, 0.75,
            1.0, 1.5, 2.0, 3.0, 5.0, 10.0]
    vals = [npv_at(flows, g) for g in grid]
    for (lo, flo), (hi, fhi) in zip(zip(grid, vals), zip(grid[1:], vals[1:])):
        if flo == 0:
            return lo, note
        if (flo < 0) != (fhi < 0):
            for _ in range(200):
                mid = (lo + hi) / 2
                fm = npv_at(flows, mid)
                if (fm < 0) == (flo < 0):
                    lo, flo = mid, fm
                else:
                    hi = mid
            return (lo + hi) / 2, note
    return None, "IRR not found between -99% and 1000% per period"


def payback(series):
    """series: list of (period, flow) sorted; returns interpolated period when the
    cumulative flow first turns from negative to >= 0 and stays >= 0, else None."""
    cum, prev_cum, prev_t, result = Decimal(0), None, None, None
    for t, f in series:
        prev_cum, cum = cum, cum + f
        if cum >= 0 and result is None:
            if prev_t is None or prev_cum >= 0:
                result = Decimal(t)
            else:
                result = Decimal(prev_t) + (-prev_cum) / f * Decimal(t - prev_t)
        elif cum < 0:
            result = None
        prev_t = t
    return result


def q(x, places):
    if x is None:
        return None
    return str(Decimal(x).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP))


def analyze(name, rows, opts, period_rate):
    places = opts.decimals
    periods = sorted({r["period"] for r in rows})
    horizon = periods[-1]
    cost_t = {t: Decimal(0) for t in range(horizon + 1)}
    ben_t = {t: Decimal(0) for t in range(horizon + 1)}
    cats = {}
    for r in rows:
        df = (1 + period_rate) ** r["period"]
        (cost_t if r["kind"] == "cost" else ben_t)[r["period"]] += r["amount"]
        key = (r["kind"], r["category"])
        c = cats.setdefault(key, {"kind": r["kind"], "category": r["category"],
                                  "total": Decimal(0), "pv": Decimal(0)})
        c["total"] += r["amount"]
        c["pv"] += r["amount"] / df
    dfs = {t: (1 + period_rate) ** t for t in range(horizon + 1)}
    total_cost = sum(cost_t.values(), Decimal(0))
    total_ben = sum(ben_t.values(), Decimal(0))
    pv_cost = sum((cost_t[t] / dfs[t] for t in cost_t), Decimal(0))
    pv_ben = sum((ben_t[t] / dfs[t] for t in ben_t), Decimal(0))
    npv = pv_ben - pv_cost
    if horizon == 0:
        eac = None
    elif period_rate == 0:
        eac = pv_cost / horizon
    else:
        eac = pv_cost * period_rate / (1 - (1 + period_rate) ** (-horizon))
    units = opts.units.get(name)
    has_ben = total_ben != 0
    net = [(t, ben_t[t] - cost_t[t]) for t in range(horizon + 1)]
    pv_net = [(t, (ben_t[t] - cost_t[t]) / dfs[t]) for t in range(horizon + 1)]
    irr_p, irr_note = irr([(t, float(a)) for t, a in net]) if has_ben else (None, "no benefits supplied")
    detail, cum, cum_pv = [], Decimal(0), Decimal(0)
    for (t, a), (_, pa) in zip(net, pv_net):
        cum += a
        cum_pv += pa
        detail.append({"option": name, "period": t, "cost": q(cost_t[t], places),
                       "benefit": q(ben_t[t], places), "net": q(a, places),
                       "discount_factor": q(1 / dfs[t], 6), "pv_net": q(pa, places),
                       "cumulative_net": q(cum, places), "cumulative_pv_net": q(cum_pv, places)})
    summary = {
        "option": name,
        "units": str(units) if units is not None else "",
        "horizon_periods": horizon,
        "total_cost": q(total_cost, places),
        "total_benefit": q(total_ben, places),
        "net": q(total_ben - total_cost, places),
        "pv_cost": q(pv_cost, places),
        "pv_benefit": q(pv_ben, places),
        "npv": q(npv, places),
        "eac_per_period": q(eac, places),
        "tco_per_unit": q(total_cost / units, places) if units else "",
        "pv_cost_per_unit": q(pv_cost / units, places) if units else "",
        "roi_simple": q(((total_ben - total_cost) / total_cost), 4) if has_ben and total_cost > 0 else "",
        "roi_discounted": q(npv / pv_cost, 4) if has_ben and pv_cost > 0 else "",
        "payback_periods": q(payback(net), 2) if has_ben else "",
        "discounted_payback_periods": q(payback(pv_net), 2) if has_ben else "",
        "irr_per_period": q(irr_p, 6) if irr_p is not None else "",
        "irr_annual": q((1 + irr_p) ** opts.periods_per_year - 1, 6) if irr_p is not None else "",
        "irr_note": irr_note,
    }
    by_cat = [{"kind": c["kind"], "category": c["category"], "total": q(c["total"], places),
               "pv": q(c["pv"], places)} for c in sorted(cats.values(), key=lambda c: (c["kind"], c["category"]))]
    return summary, by_cat, detail


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0],
                                epilog=__doc__.split("\n", 1)[1],
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", required=True, help="cash-flow CSV (columns listed below)")
    p.add_argument("--rate", required=True, type=parse_rate,
                   help="annual discount rate from Finance, e.g. 0.08 or 8%%; 0 = undiscounted")
    p.add_argument("--periods-per-year", type=int, default=1, help="1 = annual periods (default), 12 = monthly")
    p.add_argument("--units", action="append", default=[], metavar="OPTION=N",
                   help="units covered by an option, for cost per unit (repeatable)")
    p.add_argument("--format", choices=("csv", "json"), default="csv")
    p.add_argument("--detail", action="store_true", help="CSV: per-period rows instead of the summary")
    p.add_argument("--decimals", type=int, default=2)
    p.add_argument("--output", help="write to this file instead of stdout")
    opts = p.parse_args(argv)
    if opts.periods_per_year < 1:
        p.error("--periods-per-year must be >= 1")
    units = {}
    for u in opts.units:
        name, _, n = u.rpartition("=")
        try:
            units[name.strip()] = Decimal(n)
            if units[name.strip()] <= 0 or not name.strip():
                raise InvalidOperation
        except InvalidOperation:
            p.error("--units expects OPTION=N with N > 0, got %r" % u)
    opts.units = units
    period_rate = (1 + opts.rate) ** (Decimal(1) / opts.periods_per_year) - 1

    rows, errors = [], []
    with open(opts.input, newline="", encoding="utf-8-sig") as fh:
        for i, raw in enumerate(csv.DictReader(fh), start=2):
            raw = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
            try:
                if not raw.get("option"):
                    raise RowError("missing option")
                try:
                    period = int(raw.get("period", ""))
                except ValueError:
                    raise RowError("period must be an integer >= 0")
                if period < 0:
                    raise RowError("period must be an integer >= 0")
                kind = raw.get("kind", "").lower()
                if kind not in ("cost", "benefit"):
                    raise RowError("kind must be cost or benefit")
                try:
                    amount = Decimal(raw.get("amount", "").replace(",", ""))
                except InvalidOperation:
                    raise RowError("invalid amount %r" % raw.get("amount"))
                rows.append({"option": raw["option"], "period": period, "kind": kind,
                             "category": raw.get("category") or "uncategorized", "amount": amount})
            except RowError as e:
                errors.append({"row": i, "option": raw.get("option", ""), "error": str(e)})

    for e in errors:
        print("REJECTED row %(row)s (%(option)s): %(error)s" % e, file=sys.stderr)
    if not rows:
        print("no valid rows", file=sys.stderr)
        return 2

    names = list(dict.fromkeys(r["option"] for r in rows))
    for n in units:
        if n not in names:
            print("WARNING: --units given for unknown option %r" % n, file=sys.stderr)
    results = {n: analyze(n, [r for r in rows if r["option"] == n], opts, period_rate) for n in names}
    horizons = {results[n][0]["horizon_periods"] for n in names}
    warnings = []
    if len(horizons) > 1:
        warnings.append("options have different horizons %s; compare EAC, not PV cost, or align the "
                        "service periods" % sorted(horizons))
    ranked = sorted(names, key=lambda n: Decimal(results[n][0]["pv_cost"]))
    low = Decimal(results[ranked[0]][0]["pv_cost"])
    for rank, n in enumerate(ranked, start=1):
        s = results[n][0]
        s["pv_cost_rank"] = rank
        s["pv_cost_vs_lowest"] = q(Decimal(s["pv_cost"]) - low, opts.decimals)
    for w in warnings:
        print("WARNING: " + w, file=sys.stderr)

    fh = open(opts.output, "w", newline="", encoding="utf-8") if opts.output else sys.stdout
    try:
        if opts.format == "json":
            json.dump({"parameters": {"annual_rate": str(opts.rate),
                                      "periods_per_year": opts.periods_per_year,
                                      "period_rate": q(period_rate, 8),
                                      "timing": "period 0 undiscounted; period t at end of period t"},
                       "options": [{"summary": results[n][0], "by_category": results[n][1],
                                    "periods": results[n][2]} for n in names],
                       "ranking_by_pv_cost": ranked, "warnings": warnings, "errors": errors},
                      fh, indent=2)
            fh.write("\n")
        else:
            data = ([d for n in names for d in results[n][2]] if opts.detail
                    else [results[n][0] for n in names])
            w = csv.DictWriter(fh, fieldnames=list(data[0].keys()))
            w.writeheader()
            w.writerows(data)
    finally:
        if opts.output:
            fh.close()
    return 3 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
