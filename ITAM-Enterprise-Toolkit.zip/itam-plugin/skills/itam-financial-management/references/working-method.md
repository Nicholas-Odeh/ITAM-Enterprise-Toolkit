# Working method by request type

Detail moved from `SKILL.md` (v2 restructure). Formulas live in `financial-methods.md`; policy values in `finance-policy.md`. Labels as in the `itam-operating-standard` skill.

## Contents
1. Preflight in full
2. Method per request type
3. Scripts
4. Release checks that are not blocking
5. Output variants

## 1. Preflight in full

Confirm, or state assumptions for:

- **The decision and audience:** a budget submission, an acquisition choice, an audit question, a chargeback design or a savings claim. This sets the precision and the evidence needed.
- **Scope and period:** which assets, cost centers and fiscal periods; the as-of date; the fiscal year start.
- **Currency and tax basis:** one currency; prices with or without sales tax or VAT; nominal or inflation-adjusted.
- **Policy values:** capitalization threshold, useful life by asset class, method, convention, salvage, discount rate. Read `finance-policy.md` and `templates/company-profile.md` if present.
- **Lease terms**, if leases are in scope: term, payment, lease rate factor, end-of-term options, return conditions, charges for missing or damaged equipment. These come from the signed lease schedule, never from memory.
- **Data sources and their dates:** asset extract, PO lines, invoices, the fixed-asset register, contracts.

If a missing policy value changes the answer (for example, whether a purchase is capitalized), ask one question. Otherwise run labeled scenarios (for example 36 vs. 48 months) and never present either one as policy.

## 2. Method per request type

- **Depreciation / NBV.** Get method, life, salvage and convention from policy. Run `python3 scripts/depreciation.py`, using `--report summary --as-of <period end>` for book value. Hand-check one asset (for straight-line, (cost − salvage) ÷ life). Compare the totals with the fixed-asset register and show any difference rather than forcing a tie. For a loss or disposal, the NBV at the disposal period is the indicative write-off; Finance posts it.
- **TCO.** Agree the cost boundary first. CAMP suggests a cost belongs in TCO when it is predictable, can be measured the same way each time, and is worth the effort to obtain (CAMP M:93). Use the category list in `financial-methods.md` §1. Model every option over the same service period and units. Include deployment, support, end-of-life costs and residual value (as a negative cost). Run `python3 scripts/tco.py`, then test the two biggest drivers for sensitivity. Plan a later projected-vs-actual review, as CAMP recommends (CAMP M:94).
- **TCO for a vendor or acquisition decision.** `itam-vendor-contract-management` and `itam-acquisition-procurement` gather the cost lines (license or subscription, implementation and migration, training, support, exit costs); this skill turns them into a cash-flow CSV for `tco.py` and returns PV cost, EAC and cost per unit for each option on the same horizon.
- **ROI / NPV / payback.** Use Finance's discount rate. State the ROI definition used. When NPV and simple ROI point different ways, explain why (timing). Use only benefits Finance will accept; productivity capacity is shown separately.
- **Lease vs. buy.** Compare present value over the same service period, including lease-end costs (return logistics, data wipe before return, non-return and damage charges, holdover rent) and, for buying, financing, post-warranty support, disposal and residual value. Then list the non-financial factors (refresh discipline, flexibility, tracking burden). Balance-sheet and lease-classification effects go to Finance (`financial-methods.md` §5).
- **Chargeback / showback.** Define the cost pool, the allocation driver and the rate. Prove the allocated total equals the pool. Show unallocated cost (no cost center, stockroom, retired) as its own line.
- **Invoice reconciliation.** Match invoice lines to PO, receipt and asset records, assign exception codes and quantify the variance (`invoice-reconciliation.md`). For serial-level matching, reuse `itam-inventory-reconciliation` and its scripts if they are installed.
- **Forecast.** Build a driver-based forecast: units due × unit cost + deployment + disposal − recovery, by period and scenario. Keep actual, budget and forecast in separate columns. Count and list the exclusions (missing dates, unknown models).
- **Savings.** Classify every item with the taxonomy in `forecasting-and-savings.md` §2. Record the baseline, the evidence and the Finance confirmer. Keep hard (realized) savings, cost avoidance, productivity capacity and risk reduction separate, and projected separate from realized (ProcessForge §21; AssetForge §22).

## 3. Scripts

- `python3 scripts/depreciation.py`: schedules and as-of NBV, straight-line or declining balance (with or without the switch to straight-line), monthly or fiscal-year periods, `full`/`next`/`half`/`prorate` conventions. CSV in; CSV or JSON out. Example: `python3 scripts/depreciation.py --input assets.csv --method sl --report summary --as-of 2026-06-30`.
- `python3 scripts/tco.py`: per option, total and PV cost and benefit, NPV, EAC, cost per unit, simple and discounted ROI, payback, IRR, and a ranking by PV cost. `--rate` is required (use 0 for undiscounted). Example: `python3 scripts/tco.py --input flows.csv --rate 8% --units Buy=500 --units Lease=500`.

Run either script with `--help` for the input columns. Both reject bad rows to stderr and exit with code 3 rather than guessing. A computed figure is only as strong as its weakest input: a result built on an `ASSUMPTION` is an assumption-based estimate, not a `FACT`.

## 4. Release checks that are not blocking

- Options are compared over the same horizon and units (or by EAC), in one currency and tax basis.
- Sensitivity or scenarios cover the assumptions that drive the result.
- Exclusions and data-quality limits are counted, not hidden.
- Asset-record financial fields are not attributed to CIs.

## 5. Output variants

- **Executive:** one page. Lead with the decision, the money (PV or annual), the confidence, and what Finance must confirm. Calculations go to an appendix.
- **Practitioner:** full tables, the CSV or JSON from the scripts, and the exception list.
