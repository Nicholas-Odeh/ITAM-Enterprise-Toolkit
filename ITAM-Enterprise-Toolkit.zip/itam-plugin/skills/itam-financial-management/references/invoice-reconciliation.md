# Invoice-to-asset reconciliation

How to prove that what was billed matches what was ordered, received and recorded, and to catch recurring billing for assets the organization no longer has. CAMP places invoice reconciliation at the center of IT asset financial management: a core component and recurring function (CAMP M:45; S:105–108), one of the savings sources (CAMP S:36), and the basis of two Financial KPA indicators, the share of invoices reconciled for accuracy of charge and the share of software invoices reconciled for accuracy of purchase description (CAMP M:24).

## 1. The legs to match

| Leg | Typical source | Key fields |
|---|---|---|
| Order | PO / contract price list | PO number, PO line, SKU/part number, quantity, unit price, contract ID |
| Receipt | receiving record, ASN, packing list | PO number and line, quantity received, serial numbers, receipt date |
| Invoice | AP system / supplier invoice | invoice number, invoice line, PO reference, SKU, quantity, unit price, tax, freight |
| Asset record | ITAM repository | asset tag, serial, model, PO number, cost, status, cost center |
| Payment (optional) | AP | invoice number, amount paid, date |

Accounts payable usually performs the three-way match (PO, receipt and invoice). ITAM adds the fourth leg: every billed serialized unit should exist as an asset record, and every asset record should trace to a PO and an invoice (`PRACTICE`).

## 2. Matching approach

Normalize first: trim and uppercase serials and part numbers, give dates one format, use one currency, and give amounts one tax basis. If `itam-inventory-reconciliation` is installed, use its normalization and match scripts for serials.

| Tier | Keys | Confidence |
|---|---|---|
| 1 Deterministic | serial number (invoice/ASN serial ↔ asset serial) | high |
| 2 Composite | PO number + PO line + SKU, quantities compared | medium-high |
| 3 Review-required | SKU + date window + supplier, no PO line | needs human review; never auto-close |

Tolerances (price and quantity) are a Finance or AP rule. Record them in `finance-policy.md` or ask; never invent them.

## 3. Exception codes

| Code | Condition | Typical cause | Typical action |
|---|---|---|---|
| INV-PRICE | invoice unit price ≠ PO or contract price beyond tolerance | price change, wrong price list, missed discount | dispute or credit request |
| INV-QTY | quantity billed ≠ quantity received | partial shipment, billing error | hold payment for the difference |
| INV-NOREC | billed, not received | billed ahead of shipment, lost shipment | hold; confirm with the carrier and supplier |
| INV-DUP | same invoice or line billed twice | resubmitted invoice | reject the duplicate |
| INV-SKU | billed item ≠ ordered item | substitution | accept by approval or return |
| INV-NOASSET | received and billed, no asset record | receiving or tagging gap | create the record; fix the receiving step |
| INV-NOINV | asset record with no invoice | RMA replacement, no-charge unit, missed invoice, data error | classify; confirm with Procurement |
| INV-TAXFRT | unexpected tax, freight or fees | terms mismatch | check the contract terms |
| INV-RECUR | recurring charge (lease, maintenance, subscription) for an asset that is returned, disposed or reassigned to another contract | missed notice, no change sent to the vendor | claim a credit; fix the offboarding step |
| INV-REVIEW | tier-3 match or conflicting evidence | — | human review |

`itam-inventory-reconciliation/references/exception-codes.md` covers asset-side finance exceptions (FN-01 deployed but still held as inventory by Finance; FN-02 repository cost ≠ invoice; PR-05/PR-06 register vs. repository presence). Report those under their codes. Use the INV codes above only for invoice and billing-line exceptions, and crosswalk them rather than keeping two competing lists.

## 4. Recurring billing checks (high value)

For lease schedules, maintenance contracts and per-device subscriptions, compare the vendor's **billed asset list** with the **active asset records** for the same period:
- Billed but returned, disposed or lost (with the date it left service): candidate credits.
- Billed at the wrong tier or rate.
- Active but not billed: possible under-billing; confirm before raising it.
- Lease units past their end date still being billed (holdover rent).

Quantify each check as count × rate × periods. Treat the total as a claim until the vendor confirms it; it isn't a realized saving until a credit is received (`forecasting-and-savings.md` §2).

## 5. Output

| Exception ID | Invoice / line | PO / line | Serial / asset | Code | Billed | Expected | Variance | Evidence | Confidence | Action | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

**Control totals.** Show these and never force them to agree:
- invoice lines evaluated
- matched by tier
- exceptions by code
- total billed
- total expected
- net variance
- variance under dispute
- credits received

**Metrics** (paraphrasing CAMP M:24, plus `PRACTICE`):
- % of invoices reconciled for accuracy of charge = invoices reconciled ÷ invoices received × 100
- % of software invoices reconciled to the purchase description
- Variance found (currency) and variance recovered (credits received)
- Exception aging (days open by code)
- INV-NOASSET rate. A rising rate signals a receiving or tagging control failure; refer it to `itam-process-improvement`.
