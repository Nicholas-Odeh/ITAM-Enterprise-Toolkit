# Finance policy for IT assets (fill-in template)

**Purpose.** This file holds the organization's finance rules that drive every ITAM calculation. The financial-management workflow reads it before any depreciation, capitalization, TCO, lease, chargeback or savings work.

**How to fill it in.** Copy values from approved finance policy or from a written answer by the Finance owner. Record the source and effective date for every section. **Leave a field blank rather than guessing.** A blank means "unknown": the workflow will request clarification or run clearly labeled scenarios marked "confirm with Finance", and will never present a blank as a decided value. Keep secrets, bank details and personal data out of this file.

If `templates/company-profile.md` also has a Finance section, the two must agree. When they don't, report the conflict instead of selecting a value.

---

**Contents:** 1. Ownership and sources · 2. General parameters · 3. Capitalization · 4. Depreciation by asset class · 5. Disposal, loss and write-off · 6. Leases · 7. Cost centers and chargeback / showback · 8. Savings recognition · 9. Accounting treatments to confirm with Finance

## 1. Ownership and sources

| Item | Value |
|---|---|
| Finance owner for IT assets (role) | |
| Fixed-asset register system (book of record for NBV) | |
| Accounting framework used for the books (for example US GAAP, IFRS, local GAAP) | |
| Policy document name, version and effective date | |
| Last confirmed with Finance (date, by whom) | |

## 2. General parameters

| Parameter | Value | Source |
|---|---|---|
| Reporting currency | | |
| Fiscal year start month | | |
| Fiscal year naming (by the calendar year it ends in, or starts in) | | |
| Prices recorded with or without sales tax / VAT | | |
| Which costs are included in an asset's capitalized cost (freight, tax, setup, imaging labor, accessories) | | |
| Discount rate / hurdle rate for NPV and lease-vs-buy (annual) | | |
| Inflation assumption for multi-year forecasts, if any | | |
| Rounding rule for depreciation (per period to cents, final period absorbs remainder, or other) | | |

## 3. Capitalization

| Parameter | Value | Source |
|---|---|---|
| Capitalization threshold (amount and currency) | | |
| Threshold applies per item, per invoice line, or per pooled group | | |
| Pooled / bulk capitalization of low-value items allowed? Rules | | |
| Treatment of items below threshold (expensed; tracked for control?) | | |
| Software: perpetual licenses capitalized? Threshold? | | |
| Software and SaaS implementation or configuration costs: treatment | | |
| Upgrades and components added to an existing asset: treatment | | |

## 4. Depreciation by asset class

Methods: `SL` (straight-line) or `DB` (declining balance, with a factor such as 2.0 or 1.5, and whether it switches to straight-line). Conventions: `full` (in-service period counts fully), `next` (start the following period), `half` (half-period first and last), `prorate` (by days or months). The script `scripts/depreciation.py` supports these options; if your policy uses something else, write it here and flag that the script does not support it.

| Asset class | Capitalize? | Useful life (months) | Method | DB factor | Switch to SL? | Convention | Salvage (amount or % of cost) | Period (monthly / annual) | Source |
|---|---|---|---|---|---|---|---|---|---|
| Laptops | | | | | | | | | |
| Desktops | | | | | | | | | |
| Monitors and docks | | | | | | | | | |
| Mobile phones | | | | | | | | | |
| Tablets | | | | | | | | | |
| Servers | | | | | | | | | |
| Storage | | | | | | | | | |
| Network equipment | | | | | | | | | |
| Peripherals / accessories | | | | | | | | | |
| Software (perpetual) | | | | | | | | | |
| Leased equipment (right-of-use, if applicable) | | | | | | | | | |
| *(add classes)* | | | | | | | | | |

Book depreciation only. Tax depreciation is a separate schedule owned by Tax and is out of scope for this skill unless Tax supplies the rules.

## 5. Disposal, loss and write-off

| Parameter | Value | Source |
|---|---|---|
| Depreciation in the disposal period (full, none, prorated) | | |
| Who approves write-offs for lost or stolen assets, and the threshold | | |
| Treatment of proceeds from resale or ITAD value recovery | | |
| Evidence Finance needs for a disposal entry (certificate, ITAD settlement, approval) | | |

## 6. Leases

Lease accounting and classification (for example under ASC 842 or IFRS 16; VERIFY which applies and the current requirements) are decided by Finance. Record their decisions here; do not infer them.

| Parameter | Value | Source |
|---|---|---|
| Lease vs. buy policy (when leasing is allowed or preferred) | | |
| Who classifies leases and records them on the books | | |
| Short-term or low-value lease elections, if Finance uses them | | |
| Required notice period before lease end (days) | | |
| Lease-end alert schedule (for example days before end) | | |

**Lease portfolio** (one row per lease schedule; take every value from the signed schedule):

| Lessor | Agreement / schedule ID | Asset class | Units | Start | End | Monthly payment or lease rate factor | End-of-term options (return, buyout, extend) | Return conditions and charges | Source document |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |

## 7. Cost centers and chargeback / showback

| Parameter | Value | Source |
|---|---|---|
| Model: none, showback only, or chargeback | | |
| Cost-center source of truth (HR, ERP, ITAM) | | |
| Cost pool contents (hardware depreciation or lease, support, software, ITAM overhead) | | |
| Allocation driver (per device, per user, per seat, usage) | | |
| Rate-card review cycle and approver | | |
| Treatment of unassigned assets (stockroom, in transit, no cost center) | | |
| Dispute process and owner | | |

Cost center list (or a pointer to where it lives):

| Cost center | Name | Owner | Active? |
|---|---|---|---|
| | | | |

## 8. Savings recognition

| Parameter | Value | Source |
|---|---|---|
| Who confirms savings (role) | | |
| Which categories Finance counts in budget reporting (hard savings only? cost avoidance?) | | |
| Baseline rule (for example last price paid, current budget, contracted renewal quote) | | |
| Recognition period (first 12 months only, life of contract, other) | | |
| Evidence required per category | | |

## 9. Accounting treatments to confirm with Finance

Tick each one when Finance has confirmed it in writing, and note where.

- [ ] Capitalization threshold and unit of account
- [ ] Useful lives, methods and conventions per class
- [ ] Salvage values
- [ ] Discount rate for NPV and lease-vs-buy
- [ ] Lease classification and balance-sheet treatment
- [ ] Software and SaaS implementation cost treatment
- [ ] Write-off and disposal accounting
- [ ] Savings categories that count in budget reporting
