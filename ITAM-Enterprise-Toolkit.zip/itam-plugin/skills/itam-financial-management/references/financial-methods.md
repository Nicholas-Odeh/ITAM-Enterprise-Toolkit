# Financial methods for IT assets

Methods, formulas and checks behind the `itam-financial-management` skill. CAMP concepts are paraphrased with page citations. Formulas are standard finance (`PRACTICE`). Accounting treatments are named only for orientation and must be confirmed with Finance.

Contents: 1. TCO · 2. Investment appraisal (ROI, NPV, IRR, payback, EAC) · 3. Depreciation · 4. Capitalization and CapEx/OpEx · 5. Leases and lease vs. buy · 6. Chargeback and showback

---

## 1. Total cost of ownership (TCO)

**What it is for.** CAMP treats TCO as the main financial input to IT acquisition decisions. Beyond the purchase, an ITAM program also uses it to manage the portfolio through use and disposal (CAMP M:93). CAMP's glossary describes TCO as an estimate of direct and indirect costs, a form of full cost accounting (CAMP M:157). Financial Management is expected to produce projected, monitored and finalized TCO and ROI for hardware and software (CAMP S:109).

**Inclusion test.** "Total" doesn't mean every conceivable cost. CAMP's criteria: a cost belongs in a routine TCO if it is predictable, can be measured the same way each time, and is cost-effective to obtain (CAMP M:93). Write down every cost you leave out and why.

**Cost categories** (`PRACTICE`; use only those that can be measured or reliably estimated):

| Category | Typical items | Usual source |
|---|---|---|
| Acquisition | unit price, tax (per policy), freight, accessories, asset tagging | PO, invoice |
| Provisioning and deployment | imaging/provisioning labor, kitting, shipping to user, setup visit | service catalog cost, labor rate × time |
| Software allocated to the device | OS, endpoint security, management agents, per-device subscriptions | contracts, SAM data |
| Financing | lease payments, interest, lease-end charges | lease schedule |
| Support and maintenance | extended warranty, maintenance contracts, break-fix parts and labor, service desk contacts per device | contracts, ticket data × cost per ticket |
| Management overhead | ITAM, inventory and reconciliation effort per asset | labor model |
| Moves and changes | IMAC, reassignment, re-imaging on redeploy | ticket data |
| End of life | recovery logistics, data sanitization, ITAD fees, certificates, e-waste fees | ITAD contract and invoices |
| Residual value (credit) | resale or recovery value, entered as a negative cost | ITAD settlements |
| Loss | lost or stolen write-offs, only if measured historically | finance / security records |

**Rules.**
- Use the same horizon (service period) and units for every option. If the lives differ, compare EAC (§2).
- Separate one-time costs from recurring costs, and CapEx from OpEx, per policy.
- Label each data point `FACT` (from a PO or contract), `INFERENCE` (from history) or `ASSUMPTION`.
- Vendor TCO calculators are a starting point, not evidence. CAMP advises an ITAM team to define its own data points so it can put vendor TCO and ROI models into perspective (CAMP M:93).

**After the purchase (closing the loop).** CAMP recommends revisiting TCO against actual results (CAMP M:94). Paraphrased:
- Were the right cost data points chosen? Did new ones appear that should be used next time?
- Did assets last as long as projected? What share deviated, and why (for example, failure rates)?
- What did vendor negotiation achieve (volume or bundle discounts)? How did the vendor perform?
- How close was projected TCO to actual? Was one input wrong, or was the error widespread?

Record projected TCO at purchase, so that the CAMP Financial indicator "percentage of assets monitored for TCO and ROI" can be measured (CAMP M:24).

---

## 2. Investment appraisal

CAMP lists ROI, NPV, IRR and payback period among the financial measures an ITAM program should be able to support, alongside return on capital, ROIC and real-options valuation (CAMP M:107–108). Definitions are paraphrased from CAMP M:107–108 and the glossary (M:143, M:151).

Notation: CFₜ = net cash flow in period t (benefits − costs); t = 0 is today; r = discount rate per period; n = horizon in periods.

| Measure | Formula | Notes |
|---|---|---|
| Simple ROI | (Σ benefits − Σ costs) ÷ Σ costs | Undiscounted. Always state which costs and benefits are included. |
| Discounted ROI | NPV ÷ PV(costs) | Use when timing matters. |
| NPV | Σₜ CFₜ ÷ (1 + r)ᵗ | Positive NPV means the investment returns more than the discount rate. |
| IRR | r such that NPV = 0 | Can be missing or non-unique when the cash flow changes sign more than once. Never use it to rank mutually exclusive options of different sizes; use NPV. |
| Payback period | first t where the cumulative CF turns non-negative, interpolated within the period | Ignores flows after payback and the time value of money. |
| Discounted payback | the same, using discounted CF | |
| Equivalent annual (periodic) cost, EAC | PV(costs) × r ÷ (1 − (1 + r)⁻ⁿ); if r = 0, PV ÷ n | Compares options with different lives (for example 3-year vs. 4-year refresh). |
| Per-unit TCO | Σ costs ÷ units (or PV ÷ units) | State the units and horizon. |

**Discount rate.** It comes from Finance (for example a hurdle rate or cost of capital). Never assume one. If it's missing, show results at 0% (undiscounted) plus a Finance-supplied or clearly labeled scenario rate.

**Converting periods.** For a monthly rate from an annual rate, use (1 + annual)^(1/12) − 1, not annual ÷ 12, unless Finance specifies otherwise.

**Excel equivalents** (cross-check `scripts/tco.py`):
- `NPV(rate, values)` discounts its first value by one period. For a period-0 outlay, use `=CF0 + NPV(rate, CF1:CFn)`. Forgetting this is the most common NPV error.
- `IRR(values)` for periodic flows. `XNPV` / `XIRR` for dated, irregular flows.
- `PMT(rate, n, -PV)` gives the EAC for the same inputs.

**Benefits.** Count only benefits Finance accepts as cash (reduced spend, avoided purchases with evidence). Show productivity capacity and risk reduction separately (see `forecasting-and-savings.md` §2). CAMP's cost/benefit guidance puts a value on every benefit, including mitigated risk and productivity gains, even where that value has to be estimated (CAMP M:99–100). Label those estimates and keep them apart from cash savings (`PRACTICE`).

**Worked check** (`tco.py` test case): outlay 1,000 at t0; benefits of 400 at t1, t2 and t3; r = 10%.
- PV of benefits = 400 × (0.909091 + 0.826446 + 0.751315) = 994.74, so NPV = −5.26.
- IRR ≈ 9.70%.
- Simple ROI = 200 ÷ 1,000 = 20%.
- Payback: the cumulative flow is −200 after t2, so payback = 2 + 200 ÷ 400 = 2.5 periods. The discounted flow never pays back.

---

## 3. Depreciation

**Concepts.**
- Depreciable base = cost − salvage.
- Net book value (NBV) = cost − accumulated depreciation.
- The useful life, method, convention and salvage value are set by policy.

CAMP's glossary describes a fixed asset as a depreciable item on the financial records, with the depreciation period set under applicable accounting rules, normally by the CFO or Finance (CAMP M:133). ITAM's role is to keep the inputs right (cost, in-service date, class, status, location) and to reconcile with the fixed-asset register. CAMP gives asset identification staff responsibility for recording assets in Finance's fixed-asset information where appropriate (CAMP M:111), and lists a fixed-asset update among Financial Management functions (CAMP S:109).

**Straight-line (SL).** Depreciation per period = (cost − salvage) ÷ life in periods. Round each period; the final period absorbs the rounding.
- Example: 1,200 over 36 months → 33.33 for 35 months, then 33.45 in the final month (total 1,200.00).

**Declining balance (DB).** Rate per period = factor ÷ life (factor 2 = double declining balance; 1.5 = 150%). Depreciation = opening NBV × rate. The rate applies to NBV, not to cost − salvage, and depreciation stops at salvage. Most policies switch to SL over the remaining life once SL gives a larger charge. That matches Excel `VDB(..., no_switch=FALSE)`. Without the switch, the remainder above salvage is taken in the final period of life.
- Example (annual, 2× DB): cost 10,000, salvage 1,000, 5 years → 4,000, 2,400, 1,440, 864, 296. Total 9,000, closing NBV 1,000.
- Same asset with salvage 0 and the switch: 4,000, 2,400, 1,440, 1,080, 1,080.

**Conventions** (the first period's fraction; policy decides):

| Convention | First period | Effect |
|---|---|---|
| `full` | the period containing the in-service date counts fully | simplest; common for monthly schedules |
| `next` | depreciation starts the following period | |
| `half` | half a period; the life ends half a period later | half-year or mid-month conventions |
| `prorate` | days remaining in the month, or months remaining in the fiscal year | |

**Monthly vs. annual DB.** Applying factor ÷ life-in-months each month gives different numbers from applying factor ÷ life-in-years each year. The policy must say which one applies.

**Excel functions** for cross-checks: `SLN`, `DDB(cost, salvage, life, period, factor)`, and `VDB(cost, salvage, life, start, end, factor, no_switch)` for cumulative depreciation between periods. Excel's `DB` function is a fixed-declining-balance variant with its own rate formula. It won't match a factor-based policy, so don't use it for one.

**Book vs. tax.** Tax depreciation follows separate national rules and is owned by Tax. Don't mix it with book depreciation.

**ITAM uses of NBV.**
- Write-off value for lost or stolen devices (indicative; Finance posts).
- Disposal gain or loss against recovery proceeds.
- Fully depreciated assets still in service (a refresh-planning input, not a reason to retire).
- Reconciling ITAM cost fields with the fixed-asset register by tag or serial.

---

## 4. Capitalization and CapEx / OpEx

Capitalization is decided by the organization's accounting policy and framework. Examples of standards Finance may apply: US GAAP property, plant and equipment and internal-use software guidance (ASC 360, ASC 350-40), and under IFRS, IAS 16 and IAS 38. These are named for orientation only; VERIFY current requirements with Finance. Do not interpret these requirements as approved financial policy.

Questions that must be answered by policy (`finance-policy.md` §3):
- The threshold, and whether it applies per item, per invoice line or per pooled group. Pooling can capitalize many sub-threshold laptops bought together.
- Which costs are capitalizable (freight, tax, setup, imaging labor).
- Software licenses, SaaS subscriptions and implementation costs. Subscriptions are usually operating expense, but implementation costs can differ; Finance decides.
- Upgrades and added components.

ITAM consequences (`PRACTICE`):
- Below-threshold assets are often expensed but still tracked for security, data and recovery control. Capitalization status doesn't decide whether an asset is managed.
- Keep capitalization status, fixed-asset ID, cost and in-service date on the asset record (not the CI).

---

## 5. Leases and lease vs. buy

**CAMP terms** (paraphrased, CAMP M:133, M:140, M:144):
- A **lease** gives the lessee the right to use the lessor's property for a set time in return for payment. CAMP's glossary generally treats rentals longer than a year as leasing.
- An **operating lease** gives use without transfer of ownership.
- A **financial (capital) lease** is described by CAMP as one where ownership passes to the lessee under a negotiated payment stream.
- A **lease rate factor** is a negotiated multiplier that sets the periodic payment (payment = equipment cost × factor) and can improve with volume.

CAMP also notes that Acquisition should tell Disposal, at purchase, whether each asset is leased or owned (CAMP M:36), and places lease-vs-buy strategy within Vendor Management (CAMP M:48).

**Accounting caution.** CAMP's definitions are general vocabulary. Current lease accounting standards (for example ASC 842 under US GAAP and IFRS 16) set their own classification tests and put most leases on the lessee's balance sheet. They don't simply follow the ownership-transfer test above. Lease classification and balance-sheet effects are Finance's call (VERIFY with Finance). In ITAM analysis, compare cash flows and record the Finance classification as supplied.

**Lease vs. buy method** (`PRACTICE`):
1. Use the same service period and units for both options. If the buy option will be kept longer than the lease term, either model the lease being renewed or compare EAC.
2. **Buy cash flows:** purchase (t0), financing if borrowed, deployment, support beyond warranty, repairs, end-of-life costs (sanitization, ITAD), residual value (negative cost).
3. **Lease cash flows:** payments per the schedule (check whether payments are in advance or in arrears), deployment, support not covered by the lease, and lease-end costs: return logistics, data wipe before return, charges for missing or damaged units, early-termination fees, and holdover or month-to-month rent for late returns.
4. Discount at Finance's rate (`scripts/tco.py`, one option per scenario) and compare PV cost and EAC.
5. Run sensitivity on the residual value, the late-return rate and the support cost.
6. Add the non-financial factors: enforced refresh cadence, flexibility, ownership of disposal and data risk, and the inventory-accuracy burden. Leased assets must be found and returned.

**Lease controls for ITAM** (`PRACTICE`): put the lease schedule ID and end date on each asset record; send lease-end alerts per policy; reconcile the units billed with the units held; prove return with a lessor receipt; make buyout decisions before the notice deadline.

---

## 6. Chargeback and showback

**Definitions.**
- **Chargeback:** CAMP's glossary describes it as compensation one department requires for equipment or services it provides to another department (CAMP M:123).
- **Showback** (`PRACTICE`): the same cost reporting without moving any money. It is often the first step before chargeback.

**Why ITAM data matters.** CAMP points out that the cost of a service can't be accumulated for chargeback unless you know which items make up the service (CAMP M:83). It also notes that detailed asset usage information strengthens price discussions when chargeback is in place, and can change user behavior even without fund transfers (CAMP M:86–87). Chargebacks appear among Financial Management's recurring functions (CAMP M:45; S:108–109).

**Models** (`PRACTICE`):

| Model | Rate basis | Fits when |
|---|---|---|
| Per-device or per-seat rate card | (annual cost pool for the class) ÷ (average units in service) | standard endpoints |
| Tiered | separate rates for standard, power-user and specialist devices | clear service tiers |
| Direct assignment | actual cost of assets assigned to the cost center | high-value or unique assets |
| Consumption-based | cost ÷ usage units | SaaS or cloud with reliable usage data |

**Build steps.**
1. Finance defines the cost pool: depreciation or lease, support, software, overhead.
2. Choose the driver.
3. Rate = pool ÷ driver volume for the period.
4. Allocate.
5. Reconcile.

**Controls.**
- Allocated total = cost pool (± documented rounding).
- Every in-service asset has a valid cost center; the unassigned bucket is shown, not spread silently.
- Retired, lost, in-stock and in-transit assets are excluded from the per-user charge (or treated per policy).
- No double charging between leased and owned records.
- Rate-card changes are approved and versioned.
- Disputes are logged with an owner and resolved before the next cycle.

Data dependency: ownership and cost-center completeness (see `itam-data-analysis-reporting` metrics). Poor data turns chargeback into a dispute process.
