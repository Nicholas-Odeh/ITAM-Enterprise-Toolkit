# Budget and refresh forecasting, and savings tracking

## 1. Budget and refresh forecasting

CAMP lists forecasting and budgeting among the recurring functions of Financial Management, alongside a strategic, portfolio view of IT spend (CAMP M:45; S:106–108). AssetForge §26.5 adds forecast variance as a financial metric.

### 1.1 Driver-based model (`PRACTICE`)

For each period p (fiscal quarter or year) and device class c:

```
units_due[p,c]   = in-scope assets of class c whose refresh due date falls in p
                   (+ backlog policy: overdue units placed in p per the business rule)
                   (+ growth: forecast new hires × device ratio, if in scope)
                   (+ break-fix replacements: fleet × historical out-of-warranty failure rate, if measured)
refresh_cost[p,c] = units_due[p,c] × (unit_price[c] + deployment_cost[c] + disposal_cost[c])
                   − units_due[p,c] × recovery_value[c]
```

- **Due date** = age basis date + refresh cycle. The cycle comes from refresh policy (`itam-hardware-lifecycle` or `templates/company-profile.md`). The age basis is the purchase date or in-service date; state which, and count the assets that fall back to another date.
- **Backlog** (assets already past due) is a business-rule choice: all in the current period, spread over N periods, or deferred. Don't decide it silently; show it as its own line.
- **Unit prices** come from current contract or catalog prices, labeled with source and date. If price escalation is assumed, label it as an assumption.
- **CapEx vs. OpEx split** follows the capitalization policy. Leased units appear as lease payments over the term, not as a purchase in the due period.
- **Lease-ends** generate refresh demand on the lease end date regardless of age.

### 1.2 Scenarios and sensitivity

At minimum, show:
- **Baseline:** current policy and prices.
- **Alternative cycle:** for example, extending the refresh cycle by 12 months for a class.
- **Price scenario:** ± a stated percentage on unit price.

Report units and cost by period for each one, plus the difference from baseline. Identify the assumption with the biggest influence on the total. Never present one scenario as the forecast without labeling its assumptions.

### 1.3 Separation and control

- Keep **actual**, **budget** and **forecast** in separate columns, never overwritten. Forecast variance = (actual − forecast) ÷ forecast, by period.
- **Exclusions:** count assets with no date, unknown class or unknown status, and list them. The forecast covers in-scope assets only.
- **Tie-out:** Σ units_due across periods + exclusions + not-yet-due = in-scope population.
- Show the formulas so Finance can recompute. `/refresh-forecast` (plugin command) runs this workflow with `itam-hardware-lifecycle`.

### 1.4 Output table

| Period | Device class | Units due | Of which backlog | Unit price (source) | Deploy + dispose − recovery | Total cost | CapEx | OpEx | Scenario |
|---|---|---|---|---|---|---|---|---|---|

---

## 2. Savings tracking

CAMP frames Financial Management as the backbone of ITAM savings (CAMP S:105). It names savings opportunities such as redeployment, reduced costs, investment planning, invoice reconciliation and effective warranty management (CAMP S:36), and lists the ITAM functions with savings examples, including license, lease, inventory, procurement and disposal management (CAMP S:37). The CAMP optimization themes add recovering unused software and subscriptions, and spotting over-ordering of low-value items (CAMP M:91–92).

### 2.1 Taxonomy

The categories combine ProcessForge §21 and AssetForge §22. Whether each category counts in budget reporting is a Finance rule; record it in `finance-policy.md` §8.

| Category | Definition | Example | Evidence required | Counts as budget reduction? |
|---|---|---|---|---|
| Hard savings (realized) | spend that has actually fallen against a documented baseline, in a budget line | cancelled maintenance on disposed servers; reduced renewal quantity; vendor credit received | baseline invoice or quote, new invoice or contract, credit note | yes, once confirmed by Finance |
| Cost avoidance | spend that would have happened but didn't; the budget isn't reduced | laptop request filled from redeployed stock; true-up avoided by reharvesting licenses; price increase negotiated away | approved demand plus evidence that it was met without purchase, and the price that would have been paid | usually no; reported separately |
| Productivity capacity (soft) | staff time freed | automated reconciliation saves 20 hours a month | time study or ticket data | no; capacity, not cash, unless headcount or contractor spend actually falls |
| Risk reduction | lower probability or impact of a loss | audit exposure reduced by an accurate ELP | risk assessment | no; describe it, don't add it to savings totals |
| Strategic value | capability or decision quality | better refresh timing | narrative | no |
| Projected | expected in the future, not yet happened | planned renewal reduction | plan and quote | no, until realized |
| Theoretical opportunity | possible if action is taken | unused licenses identified, not yet reclaimed | discovery data | no |

**Rules.**
- One saving is counted once, in one category, in one period.
- Avoidance requires an actual avoided demand, not a hypothetical one.
- Price × quantity, with the source of each.
- Savings move from projected → realized only with evidence.
- The recognition period (for example 12 months) is Finance's rule.

### 2.2 Savings register

| Saving ID | Description | Category | Asset / contract / license | Baseline (value, source, date) | New cost (value, source) | Amount | Period recognized | Status (identified, projected, realized, rejected) | Evidence link | Confirmed by (Finance) | Date |
|---|---|---|---|---|---|---|---|---|---|---|---|

Report totals by category and status. **Never add categories together into a single "savings" number** without showing the split.

### 2.3 Financial KPIs

From AssetForge §26.5 and CAMP M:24 (paraphrased). Targets are organizational decisions; leave them blank until set.

| KPI | Formula | Source |
|---|---|---|
| Cost per asset (by class) | total lifecycle cost ÷ assets in service | TCO model |
| Invoices reconciled for accuracy of charge | invoices reconciled ÷ invoices received × 100 | AP / reconciliation log |
| Software invoices reconciled to purchase description | reconciled ÷ received × 100 | SAM / AP |
| Assets monitored for TCO / ROI (by type) | assets with recorded projected TCO ÷ assets of that type × 100 | asset records |
| Contracts reviewed for financial terms before signing | reviewed ÷ signed × 100 | contract log |
| Recovered value | Σ resale or ITAD recovery proceeds | ITAD settlements |
| Reuse savings (avoidance) | redeployed units × avoided unit price | stockroom / request data |
| Software reclamation savings | reclaimed licenses × price, split hard vs. avoidance | SAM |
| Unused subscription cost | unused seats × price | SaaS data |
| Forecast variance | (actual − forecast) ÷ forecast | budget vs. actual |
