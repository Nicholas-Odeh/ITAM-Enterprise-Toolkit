---
name: itam-financial-management
description: Use when someone asks what a device or fleet really costs, needs a depreciation schedule, useful life or net book value, compares leasing with buying, needs the ROI, NPV or payback numbers for a business case, designs chargeback rates, matches invoices to POs and assets, forecasts refresh spend or budget, or must prove ITAM savings to Finance. Covers TCO, depreciation, capitalization, chargeback, invoice reconciliation, forecasts, savings. Not for building the workbook (use itam-spreadsheet-models) refresh policy and cycles (use itam-hardware-lifecycle), or the program funding case itself (use itam-program-governance).
---

# IT Asset Financial Management

Put defensible numbers on IT assets: lifetime cost, book value, chargeback, invoice accuracy, refresh spend and real savings. Finance owns the accounting; this skill produces the analysis and evidence, and owns the TCO math the vendor and acquisition skills rely on.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Accounting treatment is Finance's decision.** Capitalization threshold, useful life, method, convention, salvage, discount rate, lease classification and savings recognition come from `references/finance-policy.md`, the company profile or the user. If missing, ask, or run labeled scenarios marked "confirm with Finance". The fixed-asset register is the book of record for net book value.
7. **Exact math, shown.** Use `python3 scripts/depreciation.py` and `python3 scripts/tco.py` for schedules, NPV, IRR, payback and EAC. Show inputs and formula, and hand-check one figure.
8. **Savings honesty.** Keep hard savings, cost avoidance, capacity and risk reduction separate, and projected separate from realized.

## When to use

- Lifetime cost per device; TCO of vendor or acquisition options.
- Depreciation, NBV at a date, write-off of a lost device; lease vs. buy; CapEx/OpEx.
- Chargeback rates; invoice vs. PO vs. asset matching.
- Refresh budget forecast; savings register for Finance.

**When not to use:** workbook layout → `itam-spreadsheet-models`; refresh cycles → `itam-hardware-lifecycle`; lease or contract clause interpretation → `itam-vendor-contract-management`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| Depreciation, NBV | `financial-methods.md` §3, `finance-policy.md`, `depreciation.py` |
| TCO, ROI, NPV, payback | `financial-methods.md` §1–2, `tco.py` |
| Lease vs. buy | `financial-methods.md` §5, `tco.py` |
| Capitalization, CapEx/OpEx | `finance-policy.md`, `financial-methods.md` §4 |
| Chargeback, showback | `financial-methods.md` §6 |
| Invoice reconciliation | `invoice-reconciliation.md` |
| Forecast, savings | `forecasting-and-savings.md` |

All files are in `references/`. Method per type: `references/working-method.md` §2.

### Step 2 — Preflight

Confirm or label (`working-method.md` §1): decision and audience; scope, period and as-of date; currency and tax basis; policy values; lease terms from the signed schedule; data sources and dates. If a missing policy value changes the answer, ask once; otherwise run labeled scenarios.

### Step 3 — Do the work

Agree the cost boundary, build inputs as CSV, run the script, hand-check one figure, then test the two biggest drivers for sensitivity. Compare options over the same period and units. Tie totals to the register, the cost pool or the invoice variance, and show any difference instead of forcing a tie.

### Step 4 — Verify before release

- ★ Every policy value traces to policy, profile or user, or is a scenario marked "confirm with Finance".
- ★ Every figure comes from a script run or shown formula; at least one is hand-checked in the output.
- ★ Totals tie out: depreciation over life = cost − salvage; allocated = pool; exceptions sum to the variance.
- ★ No savings labeled hard or realized without evidence of reduced spend.
- ★ No accounting, tax or lease-classification statement presented as fact without a Finance source.
- Non-blocking checks: `working-method.md` §4.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "I can do this NPV in my head" | Numbers computed by eye are not evidence. Run the script and show the command. |
| "Straight-line over 36 months is obvious" | Method, life and convention are Finance policy. Ask, or run labeled scenarios. |
| "Avoided purchases are savings" | Cost avoidance is not a budget reduction. Classify it. |
| "It's close to the register; force the tie" | Show the difference and its drivers. |

Stop if you are about to: present a scenario (life, rate, threshold) as policy; publish a figure without a hand-check.

## Common mistakes

| Mistake | Fix |
|---|---|
| Options over different horizons | Same period and units, or compare by EAC. |
| Mixing tax-inclusive and net prices | One currency and tax basis, stated. |
| Leaving lease-end charges out | Include return, wipe, non-return and holdover costs. |
| Spreading unassigned cost silently | Show unallocated cost as its own line. |

## If connectors are available

- **~~finance:** read the fixed-asset register, cost centers and GL actuals, with read time.
- **~~procurement:** read POs, receipts, invoices and lease schedules.
- **~~ITSM / ~~CMDB:** read asset financial fields and states (asset records, not CIs).
- **~~office suite:** draft the workbook or memo; Finance confirms before it is shared.

## Output format

1. **Answer:** number or decision, confidence, main assumption.
2. **Inputs:** value | label | source.
3. **Calculation:** results, one hand-check, the script command.
4. **Scenarios; items for Finance to confirm; risks.**

Executive and practitioner variants: `working-method.md` §5.

## Reference files

- `references/finance-policy.md`: policy values; read first for policy-dependent math.
- `references/financial-methods.md`: TCO categories, formulas, depreciation, leases, chargeback.
- `references/working-method.md`: preflight, method per type, script usage.
- `references/invoice-reconciliation.md`: invoice and billing work.
- `references/forecasting-and-savings.md`: forecasts and savings.
- `scripts/depreciation.py`, `scripts/tco.py`: `--help` lists input columns; bad rows exit 3.
