# Build method, xlsx handoff and deliverables

Detail moved from `SKILL.md` (v2 restructure). Standards are in `workbook-standards.md`; QA in `workbook-qa-and-audit.md`; model layouts in `workbook-blueprints.md`.

## Contents
1. Preflight in full
2. Build sequence
3. Handoff to the `xlsx` skill
4. Release checks that are not blocking
5. Deliverable formats

## 1. Preflight in full

Confirm, or state assumptions for:

- **The decision the workbook supports, and its users** (an analyst, Finance, an auditor, a manager). This sets the controls and documentation depth.
- **Excel environment:** Microsoft 365 or an older perpetual version; desktop, web or Mac; whether dynamic arrays (`XLOOKUP`, `FILTER`, `UNIQUE`, `LET`), Power Query and macros are allowed. Don't silently assume Microsoft 365. Give `INDEX`/`MATCH` and `SUMPRODUCT` alternatives when compatibility is unknown.
- **Sources:** for each extract, the system, owner, extraction date and method, row count, key field and refresh cadence. Read `templates/company-profile.md` for system names if present.
- **Business rules and owners:** tolerances, refresh cycles, useful lives, license metrics, scoring weights and stale-data thresholds. Financial rules come from `itam-financial-management/references/finance-policy.md` if present. Unknown rules become `REQUIRED: <owner>` input cells.
- **Scale and refresh:** rows now and expected; one-off or recurring; who refreshes it.
- **Deliverable:** a design spec only, a built file (via `xlsx`), or an audit report.

## 2. Build sequence

1. **Pick the minimum architecture.** The full layering is `README → Inputs → Lists → Raw_* → Stg_* → Calc_* → QA → Exceptions → Output → Change_Log` (`workbook-standards.md` §1). Merge or drop layers when the workbook is small, but always keep README, Inputs, raw data separate from calculations, QA and Exceptions.
2. **Lay out the model from its blueprint.** Use the sheets, tables, columns, key formulas, controls and open business rules from `workbook-blueprints.md`. Rename to the user's systems and fields. For a model with no blueprint (warranty tracker, lease schedule, loaner log), adapt the closest one and say what was adapted.
3. **Ingest reproducibly.** Use Power Query from the source files where it's available and the job recurs. Otherwise paste values into a raw table. Either way, keep source, extraction date and row count.
4. **Centralize inputs.** Put every rule, threshold and the as-of date in named cells on Inputs, each with its owner and source. Use the as-of date input instead of `TODAY()`, so results can be reproduced.
5. **Calculate in structured tables,** with one consistent formula per column and no hard-coded constants.
6. **Build the QA sheet:** each control returns PASS, FAIL or REVIEW, with one master status cell shown on the Output sheet (`workbook-qa-and-audit.md` §1–2).
7. **Write the documentation tab** (`workbook-standards.md` §6).
8. **Hand off to `xlsx`** with the specification (§3). Then have it recalculate, report any formula errors, and run the failure tests that apply (`workbook-qa-and-audit.md` §3).
9. **For financial models,** cross-check a sample against `itam-financial-management`'s `scripts/depreciation.py` or `scripts/tco.py` if that skill is installed (`python3 scripts/depreciation.py --help` from its folder). A second method counts as independent verification; recalculating the same formula doesn't.

## 3. Handoff to the `xlsx` skill

Pass:

- the sheet order;
- for each table: its name, columns, data types and formulas (in structured-reference form);
- named input cells with values or `REQUIRED` markers;
- validation lists;
- conditional-format rules;
- the QA checks;
- any sample or synthetic data.

Ask for a recalculation and a list of error cells. Feed the results back into the QA step. Don't write openpyxl or other file-handling code from this skill.

## 4. Release checks that are not blocking

- Formulas are consistent down every calculated column; no whole-column references in large tables.
- Validation is applied to every user-input column.
- The documentation tab is complete: purpose, owner, sources, refresh steps, calculation dictionary, control register, known limitations, change log.
- It works in the stated Excel version (functions, Power Query, macros).
- Asset financial and contractual fields aren't sourced from CMDB CI attributes unless the user's architecture says so.

## 5. Deliverable formats

**Design deliverable** (no file yet):
1. Purpose and decision.
2. Sheet map (sheet | purpose | inputs | outputs).
3. Table specifications (columns, types, formulas).
4. Inputs and open business rules, with owners.
5. Control register.
6. Build notes for `xlsx`.

**Build deliverable:** the file (via `xlsx`), plus a short note: what was built, QA status, open `REQUIRED` inputs, the independent check performed, and known limitations.

**Audit deliverable:**
1. Verdict.
2. Findings table (ID | finding | evidence (cell/range) | impact | severity | fix).
3. Remediation order.
4. What was not tested.

Executives get the verdict and business impact first; formula detail goes in an appendix.
