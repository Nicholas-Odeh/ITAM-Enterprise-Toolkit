# ITAM workbook blueprints

Six models. Each one gives the decision it supports, its sheets, its key tables and columns, its key formulas (Microsoft 365 syntax with structured references), its QA controls, its outputs, and the business rules someone must supply. Rename tables and columns to the user's systems. For older Excel, use the alternatives in `workbook-standards.md` §3. All layouts are `PRACTICE` unless cited.

Shared conventions:
- `in_AsOfDate` is the as-of date input (a month-end where periods matter).
- `REQUIRED` marks a business rule with no value yet.
- QA status values are PASS, FAIL and REVIEW.
- The master status formula, used in every model, is:
  `=IF(COUNTIF(tQA[Status],"FAIL")>0,"FAIL",IF(COUNTIF(tQA[Status],"REVIEW")>0,"REVIEW","PASS"))`
  Use the critical-aware version in `workbook-qa-and-audit.md` §1 when only some controls block release.

Contents: A. Inventory reconciliation · B. Depreciation schedule · C. Refresh plan · D. License position · E. Vendor scorecard · F. Stockroom cycle count

---

## A. Inventory reconciliation (repository vs. discovery vs. finance vs. count)

**Decision:** which records are trustworthy, and which exceptions need action and by whom. The CAMP Asset Identification indicators include the number of reconciliation errors between inventory and electronic discovery, and between inventory and physical counts (CAMP M:22). The matching method itself (normalization rules, tiers, exception codes) belongs to `itam-inventory-reconciliation`. Use its `match-rules.md` and `exception-codes.md`, and where possible load the output of its `match_tiers.py` as a Raw table instead of re-matching in formulas. This blueprint is the workbook around them, and it uses that skill's codes.

**Sheets:** README · Inputs · Lists · Raw_ITAM · Raw_Discovery · Raw_FA · Raw_Count (optional) · Stg_* · Excluded_* · Calc_Recon · QA · Exceptions · Summary · Change_Log

**Inputs:**
- `in_AsOfDate`
- `in_StaleDays` (days without discovery before a device counts as stale): REQUIRED, ITAM owner
- `in_MaxExtractAgeDays`: REQUIRED
- `tAuthority` [Field, AuthoritativeSource]: which source wins for serial, user, location, cost and state

**Lists:**
- `tJunkValues` [Value, Reason]: placeholder serials to exclude, maintained by the owner
- `tPatternRules` [Pattern, Category, ExceptionCode, DefaultOwner, Priority]
- `tRetiredStates` [State]

**Staging tables** (built by Power Query; key = `SerialKey`, normalized per the match rules):
- `tStgITAM` [SerialKey, AssetTag, Model, State, AssignedTo, CostCenter, Location]
- `tStgDisc` [SerialKey, DeviceName, LastSeen, PrimaryUser, Source]
- `tStgFA` [SerialKey, FAID, Cost, InServiceDate, FAStatus]
- `tStgCount` [SerialKey, CountLocation, CountDate]

Each staging table has a matching `tExcl<Source>` with a [Reason] column.

**`tRecon`** — one row per distinct `SerialKey`, appended from all staging tables (Power Query append + remove duplicates):

| Column | Formula |
|---|---|
| nITAM | `=COUNTIFS(tStgITAM[SerialKey],[@SerialKey])` |
| nDisc / nFA / nCount | same pattern on each staging table |
| Pattern | `=IF([@nITAM]>0,"R","-")&IF([@nDisc]>0,"D","-")&IF([@nFA]>0,"F","-")&IF([@nCount]>0,"C","-")` |
| DupFlag | `=OR([@nITAM]>1,[@nDisc]>1,[@nFA]>1,[@nCount]>1)` |
| ITAMState | `=XLOOKUP([@SerialKey],tStgITAM[SerialKey],tStgITAM[State],"")` |
| LastSeen | `=XLOOKUP([@SerialKey],tStgDisc[SerialKey],tStgDisc[LastSeen],"")` |
| DaysSinceSeen | `=IF([@LastSeen]="","",in_AsOfDate-[@LastSeen])` |
| Stale | `=AND([@nITAM]>0,ISNUMBER([@DaysSinceSeen]),[@DaysSinceSeen]>in_StaleDays)` |
| RetiredButSeen | `=AND(COUNTIFS(tRetiredStates[State],[@ITAMState])>0,ISNUMBER([@DaysSinceSeen]),[@DaysSinceSeen]<=in_StaleDays)` |
| Category | `=XLOOKUP([@Pattern],tPatternRules[Pattern],tPatternRules[Category],"UNMAPPED PATTERN")` |
| ExceptionCode | `=IFS([@DupFlag],"DQ-03",[@RetiredButSeen],"ST-01",[@Stale],"ST-03",TRUE,XLOOKUP([@Pattern],tPatternRules[Pattern],tPatternRules[ExceptionCode],"UNMAPPED"))` (codes from `itam-inventory-reconciliation/references/exception-codes.md`) |
| Owner | lookup from `tPatternRules[DefaultOwner]`, overridable in Exceptions |

For matched rows, add attribute checks: user (repository vs. discovery primary user), location, and missing cost center. Each one is a separate TRUE/FALSE column, counted on Summary.

**Example pattern rules** (the user confirms the categories and owners; codes per `itam-inventory-reconciliation`):

| Pattern | Meaning | Typical category | Code |
|---|---|---|---|
| `RDF-` | in repository, discovery and finance | Matched; run attribute checks (AT/US codes) | — |
| `RD--` | not on the fixed-asset register | capitalization step missed, or below the capitalization threshold | PR-06 if flagged capitalized; else none |
| `R-F-` / `R---` | not discovered | offline, in stock, lost, or a discovery coverage gap | PR-02 (if in a discoverable state) |
| `-D--` / `-DF-` | discovered, no repository record | unrecorded or unmanaged device | PR-01 |
| `--F-` | finance only | disposed but still on the books, or capitalized without an asset record | PR-05 |
| `---C` / `-D-C` | counted, not recorded | receiving skipped, or return not re-recorded | PR-03 |
| `R` without `C`, at a counted location | recorded, not found in the count | unrecorded move, theft or count error | PR-04 |

**QA controls (`tQA`):**

| ID | Check | Formula (PASS condition) |
|---|---|---|
| QA-01 | Required inputs filled | `=COUNTBLANK(Inputs!InputValues)=0` (InputValues is a defined name for the input value range) |
| QA-02 | Extract freshness | `=in_AsOfDate-MIN(tExtractLog[ExtractDate])<=in_MaxExtractAgeDays` → else REVIEW |
| QA-03 | Raw = staged + excluded (per source) | `=ROWS(tRawITAM)=ROWS(tStgITAM)+ROWS(tExclITAM)` |
| QA-04 | No null keys in staging | `=COUNTBLANK(tStgITAM[SerialKey])=0` |
| QA-05 | Duplicate keys per source (REVIEW if > 0; they're listed) | `=SUMPRODUCT(--(COUNTIFS(tStgITAM[SerialKey],tStgITAM[SerialKey])>1))` |
| QA-06 | Every staged key reached tRecon | `=SUMPRODUCT(--(COUNTIFS(tRecon[SerialKey],tStgITAM[SerialKey])=0))=0` |
| QA-07 | tRecon keys unique | `=ROWS(tRecon)=ROWS(UNIQUE(tRecon[SerialKey]))` |
| QA-08 | All patterns mapped | `=COUNTIF(tRecon[Category],"UNMAPPED PATTERN")=0` |
| QA-09 | Summary counts sum to the population | `=SUM(tSummary[Count])=ROWS(tRecon)` |
| QA-10 | Every exception has an owner and status | `=COUNTIFS(tExceptions[Owner],"")+COUNTIFS(tExceptions[Status],"")=0` |
| QA-11 | No error cells in calculations | `=SUMPRODUCT(--ISERROR(tRecon))=0` |

**Outputs:** counts by pattern, category and exception code; aging of exceptions; and these metrics (AssetForge §26.1):
- Reconciliation match rate = matched ÷ evaluated × 100
- Discovery coverage = repository in-use assets seen within `in_StaleDays` ÷ repository in-use assets × 100
- Ownership completeness = assets with a valid owner ÷ in-scope assets × 100

**REQUIRED rules:** stale window; authoritative source per field; junk-value list; pattern categories and owners; in-scope asset classes and states.

---

## B. Depreciation schedule

**Decision:** NBV by asset, class and cost center at a period end; depreciation expense by fiscal year; write-off values. Method and policy come from `itam-financial-management` (`references/finance-policy.md`). The fixed-asset register remains the book of record, so this model reconciles to it rather than replacing it.

**Sheets:** README · Inputs · Raw_Assets · Raw_FARegister (optional) · Calc_Assets · Calc_Schedule (optional long table) · QA · Exceptions · Output · Change_Log

**Inputs:**
- `in_AsOfDate`, validated as a month-end: `=in_AsOfDate=EOMONTH(in_AsOfDate,0)`
- `in_FYStartMonth`
- `tPolicy` [AssetClass, CapThreshold, LifeMonths, Method (SL/DB), DBFactor, NoSwitch (TRUE/FALSE), Convention (full/next), SalvagePct, Source]. Every value comes from finance policy; blanks show REQUIRED.

**Raw_Assets:** AssetTag, Serial, FAID, AssetClass, Cost, InServiceDate, DisposalDate, CostCenter, Status.

**`tDep` (Calc_Assets):**

| Column | Formula |
|---|---|
| PolicyFound | `=COUNTIFS(tPolicy[AssetClass],[@AssetClass])=1` |
| LifeMonths / Method / DBFactor / NoSwitch / Convention | `=XLOOKUP([@AssetClass],tPolicy[AssetClass],tPolicy[LifeMonths])` (same pattern for each) |
| Salvage | `=ROUND([@Cost]*XLOOKUP([@AssetClass],tPolicy[AssetClass],tPolicy[SalvagePct]),2)` |
| Capitalized | `=[@Cost]>=XLOOKUP([@AssetClass],tPolicy[AssetClass],tPolicy[CapThreshold])` (per-item threshold only; pooled rules need their own design) |
| StartMonth | `=IF([@Convention]="next",EOMONTH([@InServiceDate],0)+1,EOMONTH([@InServiceDate],-1)+1)` |
| EndBoundary | `=IF([@DisposalDate]="",in_AsOfDate,MIN(in_AsOfDate,EOMONTH([@DisposalDate],0)))` (the disposal-month treatment is a policy rule; adjust it) |
| MonthsElapsed | `=IF([@StartMonth]>[@EndBoundary],0,MIN([@LifeMonths],DATEDIF([@StartMonth],[@EndBoundary]+1,"m")))` |
| AccumDep | `=IF([@Method]="SL",IF([@MonthsElapsed]=[@LifeMonths],[@Cost]-[@Salvage],ROUND(([@Cost]-[@Salvage])/[@LifeMonths],2)*[@MonthsElapsed]),VDB([@Cost],[@Salvage],[@LifeMonths],0,[@MonthsElapsed],[@DBFactor],[@NoSwitch]))` |
| NBV | `=[@Cost]-[@AccumDep]` |
| FullyDepreciated | `=[@MonthsElapsed]=[@LifeMonths]` |

Notes:
- The SL formula matches `depreciation.py` (round per month; the final month absorbs rounding).
- `VDB` doesn't round per period, so DB results can differ from the script by cents. Record that as the cross-check tolerance.
- With `NoSwitch=TRUE`, `VDB` leaves the remainder above salvage undepreciated at end of life, whereas the script takes it in the final period. Use the script's behavior, or add an end-of-life plug, according to policy.
- `half` and `prorate` conventions aren't modeled here. Generate the schedule with `depreciation.py` and load it as Raw.

**Calc_Schedule** (optional; one row per asset per month) is generated by Power Query (a list of months per asset) or loaded from `depreciation.py` output. Per-month formula for month index k:
- SL: `=IF(k<L,ROUND((C-S)/L,2),IF(k=L,(C-S)-ROUND((C-S)/L,2)*(L-1),0))`
- DB: `=VDB(C,S,L,k-1,k,F,NS)`

Pivot it by fiscal year × cost center for expense forecasts.

**QA controls:**
- Policy exists for every class in use: `=SUMPRODUCT(--(COUNTIFS(tPolicy[AssetClass],tDep[AssetClass])=0))=0`
- No blank policy fields.
- As-of date is a month-end.
- Excluded rows (missing cost, date or class) are counted and listed.
- NBV never below salvage: `=SUMPRODUCT(--(tDep[NBV]<tDep[Salvage]-0.005))=0`
- Fully depreciated rows have AccumDep = Cost − Salvage.
- If the schedule exists, for each asset Σ schedule depreciation = Cost − Salvage.
- Independent recompute: a sample of assets (at least one per method and class) run through `depreciation.py`; differences within the documented rounding tolerance.
- Tie to the fixed-asset register by FAID: Σ NBV vs. register NBV, with differences listed as REVIEW and never plugged.

**Outputs:** NBV by class and cost center; expense by fiscal year; fully depreciated assets still in service (count and cost); write-off candidates (lost or stolen with NBV > 0).

**REQUIRED rules:** everything in `tPolicy`; disposal-month treatment; register tie-out tolerance (Finance).

---

## C. Refresh plan

**Decision:** how many devices are due, when, and at what cost, under each scenario. The refresh cycle belongs to `itam-hardware-lifecycle` and the company profile; unit costs come from contracts or the catalog. The `/refresh-forecast` command follows the same logic.

**Sheets:** README · Inputs · Lists · Raw_Assets · Calc_Refresh · Summary · QA · Exceptions · Output · Change_Log

**Inputs:**
- `in_AsOfDate`, `in_FYStartMonth`
- `in_AgeBasis` (Purchase / InService)
- `in_Scenario` (validated from `tScenario`)
- `in_BacklogRule` (list) and `in_BacklogFYs`
- `tRefresh` [DeviceClass, RefreshMonths, UnitPrice, PriceSource, PriceDate, DeployCost, DisposalCost, RecoveryValue]: REQUIRED owners
- `tScenario` [Scenario, PriceMultiplier, CycleDeltaMonths], for example Baseline 1.00 / 0; Extend +12 1.00 / 12
- `tInScopeStates` [State]

**Named formula:** `in_CurrentFY` `=YEAR(in_AsOfDate)+IF(AND(in_FYStartMonth>1,MONTH(in_AsOfDate)>=in_FYStartMonth),1,0)` (fiscal years named by the calendar year they end in, matching `depreciation.py`)

**Raw_Assets:** AssetTag, Serial, Model, DeviceClass, PurchaseDate, InServiceDate, LeaseEndDate, Status, CostCenter, Location.

**`tRef` (Calc_Refresh):**

| Column | Formula |
|---|---|
| InScope | `=COUNTIFS(tInScopeStates[State],[@Status])>0` |
| BasisDate | `=IF(in_AgeBasis="Purchase",IF([@PurchaseDate]<>"",[@PurchaseDate],[@InServiceDate]),IF([@InServiceDate]<>"",[@InServiceDate],[@PurchaseDate]))` |
| BasisFallback | `=IF(in_AgeBasis="Purchase",[@PurchaseDate]="",[@InServiceDate]="")` |
| PolicyFound | `=COUNTIFS(tRefresh[DeviceClass],[@DeviceClass])=1` |
| Excluded | `=AND([@InScope],OR(NOT([@PolicyFound]),AND([@BasisDate]="",[@LeaseEndDate]="")))` |
| Cycle | `=IF([@PolicyFound],XLOOKUP([@DeviceClass],tRefresh[DeviceClass],tRefresh[RefreshMonths])+XLOOKUP(in_Scenario,tScenario[Scenario],tScenario[CycleDeltaMonths]),"")` |
| DueDate | `=IF([@Excluded],"",IF([@LeaseEndDate]<>"",[@LeaseEndDate],EDATE([@BasisDate],[@Cycle])))` (a lease end drives refresh for leased units) |
| Overdue | `=AND(ISNUMBER([@DueDate]),[@DueDate]<=in_AsOfDate)` |
| DueFY | `=IF([@DueDate]="","",YEAR([@DueDate])+IF(AND(in_FYStartMonth>1,MONTH([@DueDate])>=in_FYStartMonth),1,0))` |
| DueFQ | `=IF([@DueDate]="","","Q"&(INT(MOD(MONTH([@DueDate])-in_FYStartMonth,12)/3)+1))` |
| PlanFY | `=IF([@Overdue],in_CurrentFY,[@DueFY])` for the "all backlog in current FY" rule. For a spread rule, assign overdue rows across `in_BacklogFYs` by BasisDate rank and document it. Backlog stays flagged either way. |
| UnitCost | `=IF([@PolicyFound],XLOOKUP([@DeviceClass],tRefresh[DeviceClass],tRefresh[UnitPrice])*XLOOKUP(in_Scenario,tScenario[Scenario],tScenario[PriceMultiplier])+XLOOKUP([@DeviceClass],tRefresh[DeviceClass],tRefresh[DeployCost])+XLOOKUP([@DeviceClass],tRefresh[DeviceClass],tRefresh[DisposalCost])-XLOOKUP([@DeviceClass],tRefresh[DeviceClass],tRefresh[RecoveryValue]),"")` |

**Summary** (FY × class): Units `=COUNTIFS(tRef[PlanFY],[@FY],tRef[DeviceClass],[@DeviceClass],tRef[InScope],TRUE,tRef[Excluded],FALSE)`, plus Backlog units, and Cost `=SUMIFS(tRef[UnitCost],tRef[PlanFY],[@FY],tRef[DeviceClass],[@DeviceClass],tRef[InScope],TRUE,tRef[Excluded],FALSE)`.

**QA controls:**
- In-scope = Σ units over all FYs (including beyond the horizon) + excluded.
- Every class in use has a policy row.
- Each price has a source and a date, and its age is within the REQUIRED window.
- The BasisFallback count is shown.
- Leased units appear once.
- Cost cross-check: Σ Summary cost = Σ (units × UnitCost by class).
- Baseline and selected scenario are shown side by side.

**Outputs:** units and cost by FY and quarter per scenario; backlog; exclusions with counts; difference from baseline.

**REQUIRED rules:** refresh months per class; unit, deploy, disposal and recovery costs with sources; age basis; backlog rule; in-scope states; price-age window.

---

## D. Software license position (ELP)

**Decision:** surplus or shortfall per product and metric, with the evidence behind each. License metrics and counting rules come from the **contract**, via `itam-software-license-management`. Never use the model's memory of publisher rules. CAMP describes compliance as being able to demonstrate that the licenses in use are paid for and accounted for, including invoice evidence for upgrades (CAMP M:91). The CAMP Compliance indicators include the share of installed titles that comply with license terms (CAMP M:23).

**Sheets:** README · Inputs · Lists · Raw_Entitlements · Raw_Installs · Raw_Assignments (SaaS / user-based) · Stg_* · Calc_ELP · QA · Exceptions · Output · Change_Log

**Inputs:**
- `in_AsOfDate`
- `in_InstallLastSeenDays`: REQUIRED
- `tMetricRules` [Publisher, Product, Metric, CountingMethod (DistinctDevices / DistinctUsers / AssignedUsers / NotModeled), RuleSource (agreement + clause / doc ref)]: REQUIRED
- `tPrices` [Product, Metric, UnitPrice, PriceSource]

**Lists:** `tNormalization` [RawTitle, RawPublisher, Product, Licensable (TRUE/FALSE)], maintained by the SAM owner.

**Staging:**
- `tEnt` [EntitlementID, Product, Metric, Qty, AgreementID, PONumber, StartDate, EndDate, ProofDocRef, Active]
  - Active = `=AND([@StartDate]<=in_AsOfDate,OR([@EndDate]="",[@EndDate]>=in_AsOfDate))`
- `tInst` [DeviceKey, RawTitle, RawPublisher, Product, LastSeen, DeviceState, InScope]
  - Product = `=XLOOKUP([@RawTitle]&"|"&[@RawPublisher],tNormalization[RawTitle]&"|"&tNormalization[RawPublisher],tNormalization[Product],"UNMAPPED")`
  - InScope = licensable, device active, and seen within the window
- `tAssign` [UserKey, Product, UserStatus, LastActive]

**`tELP`** — one row per Product × Metric from `tMetricRules`:

| Column | Formula |
|---|---|
| Entitled | `=SUMIFS(tEnt[Qty],tEnt[Product],[@Product],tEnt[Metric],[@Metric],tEnt[Active],TRUE)` |
| DevicesUsing | `=LET(d,UNIQUE(FILTER(tInst[DeviceKey],(tInst[Product]=[@Product])*(tInst[InScope]=TRUE),"")),SUM(--(d<>"")))` |
| UsersAssigned | `=COUNTIFS(tAssign[Product],[@Product],tAssign[UserStatus],"Active")` |
| Consumed | `=SWITCH([@CountingMethod],"DistinctDevices",[@DevicesUsing],"AssignedUsers",[@UsersAssigned],"RULE NOT MODELED")` |
| Position | `=IF(ISNUMBER([@Consumed]),[@Entitled]-[@Consumed],"")` |
| Status | `=IF([@Position]="","RULE NOT MODELED",IF([@Position]<0,"Shortfall",IF([@Position]>0,"Surplus","Balanced")))` |
| ExposureEstimate | `=IF(AND(ISNUMBER([@Position]),[@Position]<0),-[@Position]*XLOOKUP([@Product]&"|"&[@Metric],tPrices[Product]&"|"&tPrices[Metric],tPrices[UnitPrice],0),0)`. Label it as an estimate at contract unit price. An actual audit or true-up settlement follows contract terms. |

Rights such as downgrade, virtualization, secondary use, multiplexing, core or processor metrics and CALs must be modeled per contract. Until they are, the product shows `RULE NOT MODELED` and is handled outside the workbook. It is never left showing a falsely clean position.

**QA controls:**
- Unmapped install titles = 0, or listed as REVIEW.
- Every product with in-scope installs has a `tMetricRules` row.
- Every metric rule has a RuleSource.
- Every active entitlement has a ProofDocRef (REVIEW if not).
- Expired entitlements are excluded and listed.
- Install rows = in scope + excluded (by reason).
- Installs on devices retired in the asset repository are listed.
- Consumption data is fresher than the window.
- No Position is computed where CountingMethod = NotModeled.

**Outputs:** position by product and metric; shortfall exposure estimate; reclaim candidates (installed but unused, if usage data exists); proof-of-entitlement coverage.

**REQUIRED rules:** metric and counting rule per product (from contract); normalization map; last-seen window; price per product and metric; scope (legal entities, regions).

---

## E. Vendor scorecard

**Decision:** how each vendor performed against agreed criteria this period, and the trend. Criteria and SLA thresholds come from contracts and the vendor manager, via `itam-vendor-contract-management`. CAMP's Vendor indicators include capturing scorecard review results with a date and timestamp, and the vendor's ability to meet contractual obligations (CAMP M:24).

**Sheets:** README · Inputs · Raw_Perf · Calc_Scores · Vendor_Summary · QA · Exceptions · Output · Change_Log

**Inputs:**
- `in_Period`, `in_PriorPeriod`
- `tCriteria` [CriterionID, Category, Criterion, Definition, Unit, Direction (HigherBetter / LowerBetter), Weight, DataSource, EvidenceRequired]: weights REQUIRED and summing to 100%
- `tBands` [CriterionID, Threshold, Score]: REQUIRED. For HigherBetter rows, thresholds are lower bounds. For LowerBetter rows, they are upper bounds.
- `in_MissingDataRule` (Exclude and renormalize / Score as 0 / Block total): REQUIRED
- `tRatingBands` [MinScore, Rating]: REQUIRED

**Raw_Perf:** Vendor, Period, CriterionID, Value, EvidenceRef, CollectedBy, CollectedDate.

**`tScore`** — one row per Vendor × Criterion for `in_Period`:

| Column | Formula |
|---|---|
| nRows | `=COUNTIFS(tPerf[Vendor],[@Vendor],tPerf[CriterionID],[@CriterionID],tPerf[Period],in_Period)` |
| Value | `=XLOOKUP(1,(tPerf[Vendor]=[@Vendor])*(tPerf[CriterionID]=[@CriterionID])*(tPerf[Period]=in_Period),tPerf[Value],"NO DATA")` |
| Direction / Weight | lookups from `tCriteria` |
| Score | `=IF([@Value]="NO DATA","",XLOOKUP([@Value],FILTER(tBands[Threshold],tBands[CriterionID]=[@CriterionID]),FILTER(tBands[Score],tBands[CriterionID]=[@CriterionID]),"NO BAND",IF([@Direction]="LowerBetter",1,-1)))` |
| HasScore | `=ISNUMBER([@Score])` |
| Weighted | `=IF([@HasScore],[@Score]*[@Weight],0)` |

**Vendor_Summary:**
- Total (renormalize rule): `=SUMIFS(tScore[Weighted],tScore[Vendor],[@Vendor])/SUMIFS(tScore[Weight],tScore[Vendor],[@Vendor],tScore[HasScore],TRUE)`
- DataCompleteness: `=COUNTIFS(tScore[Vendor],[@Vendor],tScore[HasScore],TRUE)/COUNTIFS(tScore[Vendor],[@Vendor])`
- Rating: `=XLOOKUP([@Total],tRatingBands[MinScore],tRatingBands[Rating],"",-1)`
- Trend vs. `in_PriorPeriod`
- ReviewedOn (date and time), ReviewedBy

**QA controls:**
- Weights sum to 1: `=ROUND(SUM(tCriteria[Weight]),6)=1`
- Every criterion has bands.
- `NO BAND` count = 0.
- nRows ≤ 1 (no duplicate submissions).
- Every Value has an EvidenceRef.
- The NO DATA count is shown, and the missing-data rule is applied as stated.
- The review date is recorded for each vendor.

**Outputs:** ranked table with rating, completeness and trend; per-criterion heat map; criteria below threshold with evidence links for the review meeting.

**REQUIRED rules:** criteria, weights, bands, missing-data rule, rating bands, data sources per criterion.

---

## F. Stockroom cycle count

**Decision:** does the stockroom hold what the system says? Which variances need investigation, adjustment or escalation? The receiving and stockroom procedures themselves belong to `itam-logistics-warehouse`; the reconciliation method to `itam-inventory-reconciliation`. The CAMP Asset Identification indicators include reconciliation errors between inventory records and physical inventory results (CAMP M:22).

**Sheets:** README · Inputs · Raw_Book · Raw_Scans · Raw_Movements · Calc_Count · QA · Exceptions · Output · Change_Log

**Inputs:**
- `in_CountID`, `in_Stockroom`
- `in_CountStart`, `in_CountEnd` (date-times)
- `in_BlindCount` (TRUE: counters don't see the book quantities)
- `in_RecountRule`: REQUIRED
- `in_AdjustApprovalThreshold`: REQUIRED. This is the value or count above which an adjustment needs higher approval.

**Raw data:**
- **Raw_Book** is a snapshot of system stock for the stockroom taken at count start: AssetTag, Serial, Model, Bin, State, Cost. Record the snapshot time in the extraction log.
- **Raw_Scans:** ScanID, ScanValue, ScanType (Tag / Serial), Bin, Counter, ScanTime.
- **Raw_Movements:** issues and receipts during the count window, from ITAM transactions.

**Staging:** `tScan[Key]` resolves serial scans to asset tags via `XLOOKUP` against the book or a full repository extract. Unresolved scans keep the raw value and are flagged.

**`tCount`** — one row per distinct Key from the book and the scans:

| Column | Formula |
|---|---|
| InBook | `=COUNTIFS(tBook[Key],[@Key])>0` |
| ScanCount | `=COUNTIFS(tScan[Key],[@Key])` |
| BookBin | `=XLOOKUP([@Key],tBook[Key],tBook[Bin],"")` |
| ScanBin | `=XLOOKUP([@Key],tScan[Key],tScan[Bin],"")` |
| MovedDuringCount | `=COUNTIFS(tMove[Key],[@Key])>0` |
| Result | `=IFS([@MovedDuringCount],"Moved during count",AND([@InBook],[@ScanCount]=0),"Missing",AND(NOT([@InBook]),[@ScanCount]>0),"Unrecorded",[@ScanCount]>1,"Duplicate scan",[@BookBin]<>[@ScanBin],"Wrong bin",TRUE,"Matched")` |
| RecountNeeded | per `in_RecountRule`, for example `=[@Result]<>"Matched"` |
| RecountResult · ResolutionCode · Resolution · CountedBy · AdjustedInSystemRef · ApprovedBy · ApprovalDate | manual entry with validation lists |

**QA controls:**
- Scans loaded = raw scan rows.
- Unresolved scan values are counted.
- Book snapshot time ≤ count start.
- Every non-matched row has a resolution or an open status with an owner.
- Approver ≠ counter: `=SUMPRODUCT((tCount[ApprovedBy]<>"")*(tCount[ApprovedBy]=tCount[CountedBy]))=0`
- Adjustments above the threshold carry the higher approval.
- Every adjustment has a system reference.

**Outputs and metrics:**
- Count accuracy = Matched ÷ book records × 100 (the inventory accuracy rate pattern, AssetForge §26.1)
- Variance by result type (units and, if cost is present, value)
- Recount rate
- Adjustments posted
- Open items with aging

**REQUIRED rules:** recount rule, approval threshold, in-scope states for stock, blind-count policy, whether serialized peripherals are counted individually.
