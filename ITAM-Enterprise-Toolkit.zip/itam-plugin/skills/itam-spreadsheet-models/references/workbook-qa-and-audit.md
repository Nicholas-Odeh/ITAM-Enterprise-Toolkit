# Workbook QA, failure testing and audit

Adapted from SheetForge §17.6, 29–31, 39–44. A workbook is released only when its critical controls pass, or when each failure is visible and explained. A polished workbook does not compensate for incorrect math (SheetForge §5, §39).

**Contents:** 1. Control register (QA sheet) · 2. Standard control checks · 3. Failure tests (run before release) · 4. Workbook audit (existing workbook) · 5. Remediation and change control

## 1. Control register (QA sheet)

One row per control, in table `tQA`:

| Column | Content |
|---|---|
| ControlID | `QA-01`… |
| Control | what it checks, in words |
| Type | completeness, accuracy, uniqueness, tie-out, freshness, rule, error |
| Critical | TRUE / FALSE (TRUE = a FAIL blocks release) |
| Formula / method | the formula, or "manual: <procedure>" |
| Result | the measured value (count, difference) |
| Status | PASS / FAIL / REVIEW |
| Owner | who fixes a failure |
| Evidence | where the result can be seen (exceptions tab filter, sheet range) |

Show the master status on the Output sheet:
`=IF(COUNTIFS(tQA[Status],"FAIL",tQA[Critical],TRUE)>0,"FAIL",IF(COUNTIF(tQA[Status],"FAIL")+COUNTIF(tQA[Status],"REVIEW")>0,"REVIEW","PASS"))`

## 2. Standard control checks

Use the ones the model needs. Each blueprint lists its specific controls.

| Check | Purpose | Typical formula |
|---|---|---|
| Required inputs present | no rule left blank | `=COUNTBLANK(InputValues)=0`; also `=COUNTIF(InputValues,"REQUIRED*")=0` |
| Extract freshness | stale data flagged | `=in_AsOfDate-MIN(tExtractLog[ExtractDate])<=in_MaxExtractAgeDays` |
| Row conservation | nothing lost between layers | `=ROWS(tRaw)=ROWS(tStg)+ROWS(tExcl)` |
| Null keys | every record identifiable | `=COUNTBLANK(tStg[Key])=0` |
| Duplicate keys | uniqueness | `=SUMPRODUCT(--(COUNTIFS(tStg[Key],tStg[Key])>1))` |
| Coverage | every source key reached the calc table | `=SUMPRODUCT(--(COUNTIFS(tCalc[Key],tStg[Key])=0))=0` |
| Mapping completeness | no unmapped categories, patterns, titles | `=COUNTIF(tCalc[Category],"UNMAPPED*")=0` |
| Sum of parts | category counts or amounts add up to the total | `=SUM(tSummary[Count])=ROWS(tCalc)` |
| Control-total tie-out | amounts agree with the source system or register | `=ABS(SUM(tCalc[Amount])-in_SourceControlTotal)<=in_Tolerance` (tolerance from the owner) |
| Range / logic | impossible values | for example `=COUNTIFS(tCalc[NBV],"<0")=0`; dates not after the as-of date |
| Error cells | no hidden errors | `=SUMPRODUCT(--ISERROR(tCalc))=0` |
| Override count | manual overrides are visible | `=COUNTIF(tCalc[Override],"<>")` → REVIEW if > 0 |
| Exceptions actionable | every exception has an owner and status | `=COUNTIFS(tExceptions[Owner],"")+COUNTIFS(tExceptions[Status],"")=0` |
| Independent recompute | material result verified by another method | manual: a script run, an alternative formula, or a hand sample, with the result recorded |

**Never** declare a reconciliation successful because most records matched, or because row counts agree. Row-count agreement isn't reconciliation (SheetForge §17.6, §45).

## 3. Failure tests (run before release)

Adapted from SheetForge §40 to ITAM data. Feed a small synthetic sample (in a scratch copy, never the user's live file) containing:

| Test | ITAM example | Expected behavior |
|---|---|---|
| Blank key | serial missing on a repository row | routed to Excluded with a reason; QA counts it |
| Placeholder key | junk BIOS serial such as an OEM placeholder string | excluded by `tJunkValues`, not matched to other junk rows |
| Duplicate key | same serial on two asset records | DupFlag set; listed on Exceptions |
| Key formatting | lower case, spaces, leading zeros, hyphens | normalized per the match rules; leading zeros preserved (keys stored as text) |
| Number stored as text / text as number | cost "1,299.00" as text | type-cast in staging, or flagged; never silently zero |
| Missing lookup target | asset class not in the policy table | `PolicyFound=FALSE`; excluded and counted, not `#N/A` |
| New category | a state or device class that isn't in the list | flagged UNMAPPED; QA REVIEW |
| Zero / negative | zero-cost asset, negative credit line | handled per the rule; no `#DIV/0!` |
| Date edges | month-end, fiscal-year boundary, leap day, in-service date after the as-of date | correct period assignment; future dates flagged |
| Threshold edge | cost exactly at the capitalization threshold; a device exactly at its refresh age | consistent `>=` vs. `>` as the rule states |
| Changed table size | 10× rows | formulas extend (tables), no whole-column slowdowns, controls still pass |
| Renamed or missing source column | a vendor export changes a header | Power Query fails visibly, or QA FAIL; never silently blank |
| Stale source | extract older than the freshness rule | QA REVIEW |
| Reconciliation variance | the source control total differs | variance shown and classified, not plugged |

Record the tests run and the results on the README (or the QA sheet).

## 4. Workbook audit (existing workbook)

Assess the dimensions that apply (SheetForge §30):

| Dimension | Look for |
|---|---|
| Architecture | inputs mixed into calculations; outputs feeding back; no raw/calc separation; undocumented sheets |
| Data | duplicates, null keys, mixed types, totals or blank rows inside data, merged cells, stale extracts |
| Formulas | inconsistent formulas down a column, hard-coded numbers, broken references, whole-column references, `IFERROR` masking, volatile functions, off-by-one ranges, wrong anchoring |
| Model / logic | business rule not documented or not matching policy; unit errors (months vs. years, % vs. decimal); rounding by format |
| Controls | no tie-out to source; no exception list; protection used as "security" |
| Automation | macros or scripts without error handling or logging; unbounded ranges; destructive steps without backup |
| Performance | oversized used ranges, excessive conditional formats, array formulas over whole columns, external links |
| Documentation | no owner, no sources, no refresh steps, no change log |

**Severity scale** (`PRACTICE`):
- **Critical:** a wrong result that someone acts on, or an audit-relevant figure that can't be reproduced.
- **High:** likely to produce a wrong result under normal change (new rows, a new category).
- **Medium:** maintainability or control weakness.
- **Low:** presentation or efficiency.

**Findings table:**

| ID | Finding | Evidence (sheet!range) | Impact | Severity | Root cause | Fix | Validation |
|---|---|---|---|---|---|---|---|

For each defect, trace it: symptom → formula or data condition → root cause → repair → recalculation → validation (SheetForge §11). Fix the cause, not only the visible cell.

## 5. Remediation and change control

- **Remediation order:** critical math, data and control defects first; then structural repair; then documentation and performance. Sequence by dependency and value rather than by arbitrary dates.
- **Destructive changes** (deleting sheets, restructuring tables, mass edits) follow this sequence: work on a copy, record the current state, state the intended result, make the change, re-observe, verify (SheetForge §25). Read permission isn't edit permission.
- **Revalidate after any material change** to a business rule, source format, key, formula, tolerance, query or Excel version. Rerun QA and the relevant failure tests, and log it in the change log (SheetForge §42).
- Don't mark remediation complete until its validation has passed.
