# Workbook standards for ITAM models

Engineering standards adapted from SheetForge (§5–10, 18–22, 33). Apply them as far as the model needs; a 2-sheet tracker doesn't need 10 layers (`PRACTICE`).

## 1. Architecture layers

| Layer | Sheet name | Holds | Rules |
|---|---|---|---|
| Documentation | `README` | purpose, owner, sources, refresh steps, calculation dictionary, control register, limitations | first sheet; always present |
| Inputs | `Inputs` | as-of date, business rules, thresholds, scenario selector | named cells; each with owner, source, date; input cell style |
| Lists | `Lists` | validation lists and mapping tables (states, classes, cost centers, pattern→code) | maintained tables, not typed lists inside validation |
| Raw | `Raw_<Source>` | extracts exactly as received | never edited; extraction metadata kept |
| Staging | `Stg_<Source>` | typed, trimmed, normalized copies with keys | built by Power Query or formulas; exclusions logged |
| Calculation | `Calc_<Name>` | matching, classification, measures | structured tables; one formula per column |
| QA | `QA` | control checks with PASS/FAIL/REVIEW and a master status | read-only to users |
| Exceptions | `Exceptions` | every record needing action, with reason, owner, status | actionable; never deleted, only closed |
| Output | `Output` / `Dashboard` | summaries, pivots, charts | reads only from Calc and QA; shows the QA master status |
| Change log | `Change_Log` | date, author, change, reason, revalidated? | for recurring or audit-relevant workbooks |

Data flows one way: Raw → Stg → Calc → Output. Output never feeds back into Calc.

## 2. Naming and structure

- **Tables:** prefix `t`, PascalCase. For example `tRawITAM`, `tStgDiscovery`, `tRecon`, `tPolicy`, `tQA`.
- **Named input cells:** prefix `in_`. For example `in_AsOfDate`, `in_StaleDays`, `in_PriceTolerancePct`, `in_FYStartMonth`.
- **Cell styles:** input cells in one consistent style (for example a light fill), calculated cells in another, and `REQUIRED` cells highlighted by conditional formatting until filled.
- **Data layout:** one record per row and one field per column. Explicit headers. No merged cells, blank separator rows, subtotal rows or repeated headings inside data tables.
- **Metadata:** keep `SourceSystem`, `ExtractDate` and `SourceFile` columns on staged data (or in an extraction log table) so lineage survives copy-paste.
- **Keys:** stable and explicit. Build a normalized key column (for example `SerialKey`) rather than matching on display text.

## 3. Formula standards

- Every material formula implements a rule written in the README calculation dictionary.
- **Structured references** (`tRecon[@SerialKey]`) over A1 ranges. Never use whole-column references (`A:A`) in large models.
- **No hard-coded constants.** Thresholds, rates, dates and lists live on Inputs or Lists.
- **No volatile functions for reproducibility.** Use `in_AsOfDate`, not `TODAY()`/`NOW()`. Avoid `INDIRECT` and `OFFSET` unless justified in the README.
- **Error handling is deliberate.** Use the `if_not_found` argument of `XLOOKUP` or the `if_empty` argument of `FILTER` only where "not found" is an expected, separately counted outcome. Never wrap a calculation in `IFERROR(...,0)` or `IFERROR(...,"")`. Unexpected errors must surface and be counted by QA.
- **Readability:** use `LET` to name intermediate values in long formulas. Prefer helper columns over deep nesting.
- **Consistency:** one formula per calculated column; no row-level overrides. If an override is truly needed, use an `Override` column plus an `OverrideReason` column, with the formula picking the override when present, and count the overrides on QA.
- **Units:** state currency, months vs. years, and percent vs. decimal in column headers (for example `LifeMonths`, `UnitPriceUSD`, `TolerancePct`).
- **Rounding:** round only where a business rule says so (for example per-period depreciation to cents), and round explicitly with `ROUND`, never by display format alone.

**Compatibility.** If the user's Excel version is unknown or older than Microsoft 365, give alternatives (`PRACTICE`; VERIFY function availability for the user's exact version):

| Modern function | Older alternative |
|---|---|
| `XLOOKUP(k, keys, vals, "", 0)` | `IFNA(INDEX(vals, MATCH(k, keys, 0)), "")` |
| `ROWS(UNIQUE(FILTER(...)))` | a pivot table distinct count (Data Model), or a helper column `=--(COUNTIFS($A$2:A2,A2)=1)` summed |
| `FILTER` lists | a pivot table or an advanced filter |
| `LET` | helper columns |

## 4. Power Query pipeline

Use Power Query when ingestion recurs, when sources are files or exports, or when joins and cleaning are repeated. Don't use it to replace a simple formula (SheetForge §18).

Pipeline: `Source → Staging (types) → Cleaning → Normalization → Join/Append → Business transforms → Validation → Output`.

- **Parameterize** file paths and folders (a parameter table on Inputs). No hard-coded user paths.
- **Set data types explicitly** in staging. Remove unneeded columns early.
- **Normalize keys:** `Text.Trim`, `Text.Upper`, and removal of characters the matching rules allow (document which). Junk values (for example BIOS placeholder serials) are filtered using a maintained `tJunkValues` table, not a hard-coded list in M.
- **Don't let rows disappear silently.** Route rows with null keys, type errors or junk values to an `Excluded_<Source>` query with a reason column, and load it so QA can count it. Use "Keep Errors" on a referenced query to capture conversion errors.
- **Document joins:** join kind (left, anti and so on), keys, and the expected cardinality. A merge that multiplies rows is a defect; add a row-count check after each merge.
- **Separate staging queries from output queries.** Reference rather than duplicate queries.
- **Refresh:** record refresh steps and order in the README. If the workbook is used in Excel for the web or on Mac, VERIFY Power Query refresh support for those platforms and the data sources involved before relying on it.

## 5. Data validation and protection

- **Lists** come from `Lists` tables (states, device classes, cost centers, exception status, owners), not typed values.
- **Numbers:** costs ≥ 0; percentages between 0 and 1; lives and cycles are whole months > 0.
- **Dates:** within a plausible window (for example not after `in_AsOfDate` for purchase dates). Month-end-only where the model needs a period end (`=in_AsOfDate=EOMONTH(in_AsOfDate,0)`).
- **Required fields** are highlighted when blank. QA counts the blanks.
- **Duplicate prevention** on manual-entry keys: a custom validation rule such as `=COUNTIF(ScanKeys,B2)=1`. Here `ScanKeys` is a defined name pointing at `tCount[ScanKey]`, because validation and conditional-format rules don't accept structured references directly. Alternatively, flag duplicates with conditional formatting and count them on QA.
- **Protection:** lock formula and QA areas against accidental edits. Worksheet protection isn't security. Access control comes from where the file is stored (for example SharePoint permissions). Never put credentials in a workbook.

## 6. Documentation tab (README)

Adapted from SheetForge §33. Minimum for any recurring or audit-relevant ITAM workbook:

1. **Purpose and decision supported.**
2. **Owner and users** (roles), and the review or approval cadence.
3. **Data sources:** system, owner, extraction method, extraction date, row count, authority (which source wins for which field).
4. **Sheet map:** sheet, purpose, inputs, outputs.
5. **Table map:** table, grain (one row per…), key.
6. **Calculation dictionary:** ID (`FORMULA-01`…), column/measure, business rule in words, formula, source of the rule.
7. **Inputs and assumptions register:** name, value, unit, owner, source, date, and status (confirmed / `REQUIRED` / assumption).
8. **KPI dictionary** (if there are outputs): name, definition, formula, unit, source, period, target (blank until set), owner.
9. **Control register:** pointer to the QA sheet (format in `workbook-qa-and-audit.md` §1).
10. **Refresh procedure:** numbered steps, including what to check after refresh.
11. **Known limitations** and open questions.
12. **Change log:** date, author, change, reason, revalidated (Y/N).
