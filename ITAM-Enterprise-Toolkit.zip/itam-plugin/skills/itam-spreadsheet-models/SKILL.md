---
name: itam-spreadsheet-models
description: Use when someone wants an ITAM spreadsheet, workbook, tracker or template designed, built, fixed or reviewed, asks for the tabs, columns, formulas or Power Query steps for one, says "totals don't tie" or "#N/A everywhere", or asks whether a workbook is audit-ready. Covers reconciliation, depreciation, refresh, license, scorecard and cycle-count models, QA sheets, documentation tabs. Not for the finance method (use itam-financial-management), license rules (use itam-software-license-management) or file mechanics (use the xlsx skill).
---

# ITAM Spreadsheet Models

Decide what an ITAM workbook should contain and how it proves itself correct: sheets, tables, formulas, controls and the documentation tab. For ITAM analysts and the Finance or audit reviewers who rely on their workbooks. The built-in `xlsx` skill does the file work; this skill supplies the design and the acceptance checks.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Design here, file mechanics in `xlsx`.** Pass it the specification, then feed its recalculation and error results back into QA. Don't write openpyxl or file-handling code here.
7. **No invented business rules.** Tolerances, lives, metrics, weights and thresholds are owned inputs. Unknown ones get a `REQUIRED: <owner>` cell, and QA fails until it is filled. Never hard-code a guess.
8. **Exceptions stay visible.** Raw data is never edited in place; no `IFERROR` hides a defect; no reconciliation is forced to tie. Every unmatched, duplicate or invalid record lands on an exceptions table.

## When to use

- "Build a reconciliation / depreciation / refresh / license position / scorecard / cycle-count workbook."
- Broken lookups, #N/A, totals that don't tie, adding a sheet.
- "Is this workbook audit-ready?"
- A formula or Power Query step for an ITAM export.

**When not to use:** the finance method behind the numbers → `itam-financial-management`; license metrics → `itam-software-license-management`; KPI definitions and dashboards → `itam-data-analysis-reporting`; scripted pipelines → `itam-automation-scripting`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| New model (six blueprints) or similar tracker | `references/workbook-blueprints.md` + `references/workbook-standards.md` |
| Repair or extend | `references/workbook-qa-and-audit.md` §4–5, then the blueprint |
| Audit or review | `references/workbook-qa-and-audit.md` |
| Formula or Power Query only | `references/workbook-standards.md` §3–4 |

### Step 2 — Preflight

Confirm or label (`build-method.md` §1): the decision and users; Excel version and whether dynamic arrays, Power Query and macros are allowed; each source's system, date and row count; business rules and their owners; scale and refresh; deliverable (design, file or audit). Don't silently assume Microsoft 365.

### Step 3 — Do the work

Minimum architecture → blueprint layout → reproducible ingest → named inputs with owners and an as-of date → structured-table calculations → QA sheet with a master status → documentation tab → handoff to `xlsx` → failure tests (`build-method.md` §2–3). Cross-check financial models against `itam-financial-management` scripts when installed.

### Step 4 — Verify before release

- ★ QA master status is PASS, or every FAIL and REVIEW is listed with its reason.
- ★ Raw data is unmodified; raw row counts reconcile to staging plus documented exclusions.
- ★ No business rule is hard-coded or invented; every rule cell has an owner and source, or shows `REQUIRED`.
- ★ No formula errors remain unexplained, and none are hidden by `IFERROR`.
- ★ Key totals tie out, and at least one material result was independently recomputed.
- Non-blocking checks: `build-method.md` §4.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Wrap it in IFERROR so it looks clean" | That hides defects. Route them to Exceptions. |
| "I'll hard-code 48 months for now" | An invented rule. Make it a `REQUIRED` input. |
| "The total is off by a few; add a plug" | A forced tie hides variance. Show it as an exception. |
| "I checked the formula, it's right" | Re-reading isn't verification. Recompute a result another way. |

Stop if you are about to: edit raw data in place; release with QA status FAIL unlisted; report a total you computed by eye.

## Common mistakes

| Mistake | Fix |
|---|---|
| `TODAY()` in calculations | Use an as-of date input. |
| Whole-column references in large tables | Structured references. |
| Assuming Microsoft 365 functions | Ask, or give `INDEX`/`MATCH` alternatives. |
| No row-count control between raw and staging | Add it to the QA sheet. |

## If connectors are available

- **~~office suite:** read the existing workbook; draft changes as a copy, never overwrite the original.
- **~~ITSM / ~~endpoint management / ~~finance:** read source extracts with system, owner and extraction time recorded.
- **~~document repository:** draft the filed version and change log entry; saving needs approval.

## Output format

- **Design:** purpose, sheet map, table specs, open rules with owners, control register, build notes.
- **Build:** the file via `xlsx`, plus QA status, open `REQUIRED` inputs, independent check, limitations.
- **Audit:** verdict, findings table, remediation order, what was not tested.

Full templates: `build-method.md` §5.

## Reference files

- `references/workbook-blueprints.md`: sheets, columns, formulas and controls for the six ITAM models.
- `references/workbook-standards.md`: architecture, naming, formulas, Power Query, validation, documentation tab.
- `references/workbook-qa-and-audit.md`: control checks, failure tests, audit dimensions, change control.
- `references/build-method.md`: preflight, build sequence, `xlsx` handoff, deliverable templates.
