# Publisher license profile: [PUBLISHER NAME]

> **How to use this template.** Copy it to `publishers/<publisher>.md` (lowercase, hyphenated) and fill it **only from the organization's signed agreements, order documents and the publisher terms those agreements incorporate by reference.** Do not fill any row from memory, forum posts or general knowledge of the publisher. Every row needs a source (document + clause or section) and a verifier. A row without a source stays `VERIFY` and must not be used to calculate a position.
>
> Publisher terms change over time and differ by agreement, program and date of purchase. Record the version or date of each incorporated terms document.

**Contents:** 0. Profile control · 1. Agreements in force · 2. Products in scope · 3. Metric definitions and counting rules · 4. Use rights and restrictions · 5. Data sources and measurement · 6. Reporting, true-up and renewal obligations · 7. Audit clause summary · 8. Organization-specific risk notes · 9. Contacts · 10. Change log

## 0. Profile control

| Field | Value |
|---|---|
| Profile owner | [name / role] |
| Last verified | [date] |
| Verified against | [list of documents and versions] |
| Next review | [date or trigger, e.g. renewal, new order] |
| Status | DRAFT / VERIFIED / SUPERSEDED |

## 1. Agreements in force

| Agreement ID | Type (e.g. enterprise, volume, subscription, OEM, cloud marketplace) | Start | End | Contracting entity | Affiliates / entities covered | Governing terms documents (version / date) | Source |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

## 2. Products in scope

| Product | Editions | Agreement ID | Metric (from §3) | Maintenance / subscription term | Source |
|---|---|---|---|---|---|
| | | | | | |

## 3. Metric definitions and counting rules

One block per metric used. Quote the contract's definition by reference; do not paraphrase from memory.

| Field | Value | Source (document, clause) | Verified by |
|---|---|---|---|
| Metric name as written in the contract | | | |
| What is counted (device, user, processor, core, capacity, population, transaction) | | | |
| Counting method (snapshot date, peak, average, period) | | | |
| Minimums or multipliers | | | |
| Virtualization / cluster / container rules | | | |
| Cloud and hosted deployment rules (incl. bring-your-own-license) | | | |
| Non-production (dev, test, training) | | | |
| Disaster recovery / failover / backup | | | |
| Indirect, multiplexed or third-party access | | | |
| User types (employees, contractors, external, service accounts) | | | |
| Exclusions | | | |

## 4. Use rights and restrictions

| Right | Granted? (Y / N / conditional) | Conditions | Source | Verified by |
|---|---|---|---|---|
| Downgrade / prior versions | | | | |
| Upgrade rights (and dependency on maintenance) | | | | |
| Transfer / reassignment (frequency limits) | | | | |
| Transfer between legal entities or countries | | | | |
| Secondary, home or portable use | | | | |
| License mobility to hosted or cloud environments | | | | |
| Effect of maintenance lapse | | | | |
| Termination or end-of-term rights (perpetual vs. subscription) | | | | |

## 5. Data sources and measurement

| Metric | System that measures it | Coverage and known gaps | Owner | How to extract | Tool mapping (e.g. ServiceNow publisher pack, other SAM tool) `VERIFY` |
|---|---|---|---|---|---|
| | | | | | |

## 6. Reporting, true-up and renewal obligations

| Item | Value | Source |
|---|---|---|
| True-up or reporting obligation (Y/N) | | |
| Due date / anniversary | | |
| Counting date or period | | |
| Reductions allowed? When? | | |
| Price basis for additions | | |
| Renewal / non-renewal notice period | | |
| Auto-renewal | | |

## 7. Audit clause summary

| Item | Value | Source |
|---|---|---|
| Notice period | | |
| Frequency limit | | |
| Who may audit (publisher, named or approved auditor) | | |
| Method (self-assessment, tool or script, on-site) | | |
| Confidentiality / NDA | | |
| Cost-shifting threshold or remedy | | |
| Pricing basis for any shortfall found | | |
| Dispute process | | |

Legal reviews this section. Not legal advice.

## 8. Organization-specific risk notes

From the organization's own history only (prior audits, true-up findings, known architecture risks). No generic publisher folklore.

| Date | Observation | Evidence | Action / control | Owner |
|---|---|---|---|---|
| | | | | |

## 9. Contacts

| Role | Name | Organization | Notes |
|---|---|---|---|
| Publisher account manager | | | Route all contact via the audit lead during an audit |
| Reseller / partner | | | |
| Internal license owner | | | |
| Legal contact | | | |

## 10. Change log

| Date | Change | By | Source |
|---|---|---|---|
| | | | |
