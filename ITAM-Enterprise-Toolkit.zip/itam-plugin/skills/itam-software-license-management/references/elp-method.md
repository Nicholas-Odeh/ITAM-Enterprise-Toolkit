# Effective license position (ELP) method

Labels: `FACT`, `STANDARD`, `PRACTICE`, `INFERENCE`, `ASSUMPTION`, `RECOMMENDATION`, `VERIFY`. Publisher-specific rules live only in `publishers/<publisher>.md`.

## Contents
1. Five things that are not the same
2. Proof of entitlement and evidence grades
3. Metric families (generic)
4. ELP procedure
5. Worksheet columns
6. Status vocabulary
7. Common errors that distort a position

## 1. Five things that are not the same

Keep these as separate columns, never one blended number (AssetForge §23):

| Concept | Question it answers | Typical source |
|---|---|---|
| Entitlement | What rights did we buy or receive, under which agreement? | Contracts, order forms, license portals, invoices |
| Installation | Where is the software present? | Discovery / endpoint management / server inventory |
| Access | Who or what is able to use it? | Directory groups, SSO assignments, SaaS admin consoles |
| Usage | Who or what actually used it, and when? | Metering, last-login, application telemetry |
| Consumption | How many rights does the contract say we need, given the above? | Calculated with the publisher profile's metric rules |

The contract decides which of installation, access or usage drives consumption. Never assume it (`VERIFY` in the publisher profile).

## 2. Proof of entitlement and evidence grades

Being compliant means being able to show the right number of licenses paid for and accounted for. Upgrades and version changes need the original purchase records behind them (CAMP M:91; M:124, competitive upgrade). Proof of purchase can include paid invoices, receipts and vendor records showing the organization bought and paid for the product (CAMP M:147).

Grade each entitlement line (`PRACTICE`):

| Grade | Evidence held |
|---|---|
| A | Signed agreement or order + publisher portal/certificate record + proof of payment, all linked to the entitlement record |
| B | Agreement or order + proof of payment, no publisher-side confirmation |
| C | Publisher portal or reseller report only, or invoice only |
| D | Internal record with no external document |

Grade C and D lines are at risk in an audit. Report the share of entitled quantity by grade. Remediation is document retrieval (reseller, publisher, accounts payable), not re-purchase.

Also capture for each line: maintenance/subscription status and dates (lapse can remove upgrade or use rights, `VERIFY` per contract), the legal entity that owns it, and any transfer or reassignment restrictions.

## 3. Metric families (generic)

These describe how licenses are commonly counted. They are not a publisher's rules. The publisher's definition, exceptions and multipliers come only from its contract (`VERIFY`).

| Family | Generic idea | What to confirm in the contract |
|---|---|---|
| Per device / install | Each device or install with the software needs a right | Does access from another device count? Virtual machines? |
| Named user | Each named person allowed to use it needs a right | Definition of user; reassignment limits; service accounts |
| Concurrent | A defined number of users may use it at the same time (CAMP M:125) | Peak measurement method and period |
| Capacity | Rights depend on hardware or virtual capacity (processors, cores, memory) | Counting unit, multipliers, minimums, virtualization and cluster rules |
| Organization-wide | Rights depend on a headcount or other organization measure | Definition of the counted population; affiliates |
| Subscription | Time-bound quantity, often per user | Renewal, true-forward, mid-term adds, reduction rights |
| Usage / consumption | Charges or rights based on measured use | Measurement source, billing period, overage terms |

## 4. ELP procedure

1. **Scope and date.** Publisher, products, entities, environments (production, non-production, DR, cloud), and the position date.
2. **Entitlement baseline.** One row per right line, with agreement reference, quantity, metric, edition, dates and evidence grade. Exclude expired subscriptions and record why.
3. **Consumption baseline.** Pull installs, access and usage as the metric requires. Normalize publisher / product / edition / version. De-duplicate across discovery sources by device or user key. Exclude retired, disposed or out-of-scope items only with evidence (disposal record, decommission ticket).
4. **Apply the metric.** Convert to required units with the publisher profile's counting rules. Write each rule used next to the result, with its contract reference.
5. **Apply use rights.** Only rights the contract grants and the profile records: downgrade, upgrade with maintenance, secondary or home use, dev/test, DR, license mobility. Each applied right needs its clause reference.
6. **Calculate.** Position = entitled units − required units, per product, edition and metric. Do not net different metrics or editions against each other unless the contract allows it.
7. **Value.** Value a shortfall only with a supplied price source (contract price, current quote, list price), and name the source. If none is supplied, report units only. Audit settlements may be priced differently from contract price (`VERIFY` audit clause).
8. **Explain.** For each gap, list drivers (for example unmanaged installs, unassigned leavers, edition mismatch, virtualization) and remediation options with owners.
9. **Record.** File the position with its date, data sources and versions, and the approver, so it can be reproduced.

## 5. Worksheet columns

`publisher | product | edition | version_scope | metric | agreement_ref | entitled_units | evidence_grade | consumption_source | source_date | raw_count | exclusions (with evidence) | required_units | rule_refs | position | status | value_basis | exposure_value | drivers | remediation | owner`

## 6. Status vocabulary

| Status | Meaning |
|---|---|
| Surplus | Entitled exceeds required; candidate for reharvest, reduction at renewal or reallocation |
| Balanced | Entitled equals required within the stated data tolerance |
| Shortfall | Required exceeds entitled |
| Insufficient evidence | One side of the ledger is missing or unreliable |
| Not assessed | Out of scope this cycle |

Never print "Compliant" for a whole publisher when any in-scope product is Shortfall or Insufficient evidence.

## 7. Common errors that distort a position

- Installs that never reached normalization, so the product looks absent (see `servicenow-itam` `references/sam.md` §8 for the ServiceNow chain).
- Counting the same device twice from two discovery sources, or a renamed / re-imaged device as two.
- Stale records: devices disposed or users departed but still counted, or still holding an assignment.
- Entitlements loaded against the wrong product or edition, or counted at the parent agreement and the order line.
- Ignoring virtualization, cloud or container deployments that the contract counts.
- Treating "no entitlement loaded" as "no exposure" when the tool skips unentitled products (`servicenow-itam` `references/sam.md` §4).
- Assuming dev/test or DR deployments are free without a contract clause.
- Mixing position dates: entitlements as of today, installs from last quarter.
- Counting allocations or assignment records rather than the units the metric actually consumes.
