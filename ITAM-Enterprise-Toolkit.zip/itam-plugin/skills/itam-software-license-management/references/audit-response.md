# Publisher audit response playbook

Labels as in `elp-method.md`. **Not legal advice.** Legal counsel owns interpretation of the audit clause, any admission, and any settlement. The workflow prepares analysis and drafts; the named audit lead and Legal approve and send.

## Contents
1. Kinds of audit and review
2. Readiness before any letter arrives
3. Phase-by-phase response
4. Audit response log
5. Do and don't

## 1. Kinds of audit and review

| Kind | What it is | First check |
|---|---|---|
| Contractual audit | Publisher exercises the audit clause in the agreement | Audit clause: notice, scope, frequency, who performs it, confidentiality, cost-shifting (`VERIFY` in publisher profile §7) |
| Third-party auditor | Audit firm acting for the publisher under the clause | Is the auditor named or permitted by the clause? NDA in place? |
| Compliance agency | A member organization representing publishers that educates on copyright and gathers information on non-compliance; some are authorized to audit on members' behalf (CAMP M:124) | What authority does it claim, and under which agreement or law? Route to Legal immediately |
| "License review" / self-assessment | Informal request, often from a sales or compliance team | Is it under the audit clause or voluntary? Treat as an audit until Legal says otherwise |
| Forced audit | Compliance audit without the organization's consent (CAMP M:133) | Legal-led from the first minute |

A software audit confirms copyright compliance by discovering and documenting the copyrighted products on systems and media (CAMP M:154). Compliance Management is the focal point for audit response: prepare for compliance events, run periodic internal discovery, and settle non-compliance (CAMP M:40; S:88–89).

## 2. Readiness before any letter arrives

- **Audit response team** trained before an audit: lead, SAM analyst, Legal, Procurement, publisher relationship owner, infrastructure owners (CAMP M:120 defines the team and the audit response report it produces).
- **Policies** covering external audit requests and vendor communication: who may talk to vendors and what they may say (CAMP M:70).
- **Current ELPs** for the highest-exposure publishers, refreshed on a set cadence.
- **Publisher profiles** with the audit clause summarized.
- **Entitlement evidence** retrievable within days, not weeks.
- **Contact routing:** a published rule that any audit-like contact goes to the audit lead unanswered.

## 3. Phase-by-phase response

Durations are set by the contract and by Legal. Fill in the organization's targets.

| Phase | Activities | Output |
|---|---|---|
| 0 Receive | Log the letter (date received, sender, method, deadlines stated). Do not reply substantively. Route to the audit lead and Legal. | Audit log entry |
| 1 Triage | Read the audit clause; confirm the agreement, entities and products named; check notice and frequency limits; identify who must be involved; issue an internal communication rule (single point of contact, no direct contact with the publisher or auditor). | Triage memo for Legal |
| 2 Preserve | With Legal, decide on preserving records and on any freeze of license-relevant changes during the audit. Do not uninstall, back-date or alter records to change the outcome. | Preservation instruction |
| 3 Scope and terms | Negotiate in writing: products, entities, geographies, period, data collection method, timeline, NDA, data use limits, and the auditor's script or tool (review what it collects before running it). | Agreed scope letter |
| 4 Internal position first | Run the ELP (`elp-method.md`) for the agreed scope before releasing data. Identify likely gaps and their drivers. Collect entitlement evidence. | Privileged internal ELP (as directed by Legal) |
| 5 Data provision | Provide only what the agreed scope requires. Review every file before sending: scope, accuracy, no unrelated personal or confidential data. Record exactly what was sent, when and to whom. | Data release log |
| 6 Review findings | Reconcile the auditor's draft line by line with the internal ELP. Challenge: missing entitlements, wrong metric application, duplicates, retired systems, non-production rights, entities out of scope, pricing basis. | Written response with evidence |
| 7 Settle | Commercial resolution led by Procurement and Legal: options, pricing, release language, future-state terms. Hand clause work to `itam-vendor-contract-management`. | Settlement record |
| 8 Close | Confirm the release; update entitlements and the publisher profile; root-cause each confirmed gap; add or fix controls; report lessons learned. | Closure report and control actions |

## 4. Audit response log

`log_id | date | direction (in/out) | from | to | channel | summary | documents | approved_by | deadline | status`

Every outbound item has an approver. The log is itself evidence.

## 5. Do and don't

**Do**
- Acknowledge receipt only as instructed by Legal, through the single point of contact.
- Keep the internal ELP and analysis under Legal's direction.
- Ask for every auditor calculation with its rule and data source.
- Treat the audit as an input to controls: each confirmed gap gets a root cause and an owner.

**Don't**
- Let engineers or end users answer auditor questions directly.
- Run publisher-supplied scripts without reviewing what they collect.
- Volunteer data outside the agreed scope.
- Accept the auditor's metric interpretation without checking the contract.
- Delete installs or change records during the audit without Legal's direction.
- Present an estimate of exposure as a settled figure.
