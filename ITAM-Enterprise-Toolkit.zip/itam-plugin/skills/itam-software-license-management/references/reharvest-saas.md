# Reharvest, reclaim and SaaS sprawl

Labels as in `elp-method.md`. Thresholds, notice periods and exclusion lists are organization decisions: record them in `templates/company-profile.md` or the SAM policy, never invent them.

## Contents
1. Reharvest triggers
2. Reharvest workflow and controls
3. Transfer and reassignment limits
4. SaaS sprawl: discovery, ownership, rationalization, reclaim
5. Trial, promotional, free and donated software
6. Metrics

## 1. Reharvest triggers

| Trigger | Source | Notes |
|---|---|---|
| Leaver | HR termination feed / joiner-mover-leaver process | Highest volume; tie to the leaver workflow in `itam-hardware-lifecycle` |
| Mover / role change | HR or directory change | Role-based bundles may no longer apply |
| Device retirement | Disposal request | Harvest before sanitization; disposal reporting tracks the share of retired hardware whose software was harvested (CAMP S:94; M:23) |
| Non-use | Usage metering, last login | Threshold set by policy, e.g. [org: N days without use] |
| Project end | Project closure | Project-scoped licenses return to pool |
| Duplicate capability | Rationalization review | Two products doing the same job |

Software no longer used can quietly keep a subscription running; regular checks of installed versus used software are the fix (CAMP M:91).

## 2. Reharvest workflow and controls

| Step | Activity | Control / evidence |
|---|---|---|
| 1 Identify | Generate candidates from the trigger sources | Candidate list with data date and rule applied |
| 2 Validate | Remove exclusions (privileged, seasonal, legal hold, executive, regulated roles) | Exclusion list approved by the license owner |
| 3 Notify | Tell the user and their manager, with a response deadline | Notification record |
| 4 Approve | License owner or delegated approver confirms | Approval record |
| 5 Remove / unassign | Uninstall, unassign the subscription, or remove group membership | Change or task record |
| 6 Verify | Confirm absence in the next discovery or admin export | Verification record; failure loops back to step 5 |
| 7 Return to pool | Update the entitlement's available quantity | Updated pool |
| 8 Report | Record avoided purchases or reduced renewals | Savings record: cost avoidance vs. hard savings |

`RECOMMENDATION`: pilot automated reclaim on a small population before enabling it broadly, and keep a user appeal path.

## 3. Transfer and reassignment limits

Not every right can move. Some are bound to a device (for example licenses pre-installed by the hardware manufacturer), some to a named user with reassignment limits, and some cannot cross legal entities or geographies. Check the publisher profile §4 before returning a right to the pool (`VERIFY`).

## 4. SaaS sprawl

Bring-your-own software and subscription buying spread license and data risk across departments, and renewal dates must now be watched constantly (CAMP M:91).

**Discovery sources** (`PRACTICE`; use what the organization has): identity provider / SSO application list; accounts-payable and corporate-card spend; expense claims; contract repository; network, proxy or cloud-access-security logs; browser or endpoint agents; SaaS management platforms; department surveys (CAMP M:91 suggests surveys to compare what exists with what is used).

**Inventory record per SaaS application:** name, vendor, business owner, IT owner, contract or purchasing route, subscription quantity and tier, renewal date and notice period, auto-renew flag, SSO integration status, data classification held, security review status, offboarding method, cost and cost center.

**Rationalization:** group applications by capability; for overlaps, compare cost, usage, security posture and integration; propose consolidate, retain, or retire, with an owner and a renewal deadline.

**Reclaim:** use last-login or activity data over the agreed look-back; follow the workflow in §2; deprovision on leaver events. Unused subscription cost is a standard financial metric (AssetForge §26.5).

**Risk:** a SaaS application without an owner, without SSO, or holding regulated data is a security and privacy issue as well as a license one. Route it to Security and to the `itam-risk-controls-audit` skill.

## 5. Trial, promotional, free and donated software

The CAMP reference names a policy topic on whether "free" software may be installed, used or removed, and who may patch it (CAMP M:71). Practical points (`PRACTICE`):

- "Free" for personal use is often not free for commercial use. Check the license terms.
- Trials convert or expire; track the end date and the owner so a trial does not silently become a paid subscription or an unlicensed install.
- Open-source licenses carry obligations (attribution, source disclosure) handled by the organization's open-source policy, not by count-based ELP.
- Donated or academic licenses usually carry eligibility restrictions (`VERIFY`).

## 6. Metrics

Define numerator, denominator, source and cadence for each before reporting:

- Reclaimed rights per period, and value (cost avoidance vs. hard savings).
- Share of leavers whose licenses were reclaimed within [org: N days].
- Share of retired devices with software harvested (CAMP S:94).
- Unused subscription cost (AssetForge §26.5).
- Share of SaaS applications with a named business owner, and with SSO.
- Share of installed titles compliant with license terms (CAMP S:87).
