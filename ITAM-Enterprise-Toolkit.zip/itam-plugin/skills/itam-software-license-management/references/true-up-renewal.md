# True-up preparation and renewal right-sizing

Labels as in `elp-method.md`. Contract terms override everything here. Negotiation tactics and clause extraction belong to the `itam-vendor-contract-management` skill.

## 1. What a true-up is (generic)

Under many volume and enterprise agreements, the organization periodically reports growth in licensed quantities and pays for the increase. Under-preparation can turn into an expensive true-up or audit settlement (CAMP M:91). Everything specific — whether a true-up exists, the counting date, what counts, whether quantities can go down, pricing of additions, and the reporting format — comes from the agreement (`VERIFY`, record it in the publisher profile).

## 2. Information to pull from the contract first

| Item | Where recorded |
|---|---|
| Anniversary / true-up due date and submission method | publisher profile §6 |
| Counting date or period (snapshot vs. peak vs. average) | publisher profile §3 |
| Products and metrics in the true-up | publisher profile §2–3 |
| Whether reductions are allowed, and when | publisher profile §6 |
| Price basis for additions (prorated, full-year, fixed) | publisher profile §6 |
| Consequence of a late or zero report | publisher profile §6 |
| Notice period for renewal or non-renewal | publisher profile §6 and the contract skill's renewal tracker |

## 3. Preparation timeline

Offsets are organization-specific: fill them in `templates/company-profile.md` or agree them with the license owner. A `PRACTICE` starting point is shown in brackets.

| Phase | Offset before due date | Activities |
|---|---|---|
| Plan | [org: e.g. 90 days] | Confirm contract terms, owners and data sources; schedule discovery refresh |
| Baseline | [org: e.g. 60 days] | Run ELP (`elp-method.md`); list surplus and shortfall by product |
| Clean | [org: e.g. 45 days] | Reharvest genuinely unused rights (`reharvest-saas.md`); correct data errors with evidence; close stale records |
| Re-measure | [org: e.g. 20 days] | Re-run the ELP on the counting date or period |
| Approve | [org: e.g. 10 days] | License owner, Finance and Procurement sign off the count and the budget impact |
| Submit and file | due date | Submit in the contract's format; file submission, approval and the dataset behind it |

## 4. Integrity rules

- Reharvesting before the counting date is legitimate only when the software is really removed or unassigned, and the removal is dated and verifiable in discovery.
- Do not exclude devices, users or entities from the count unless the contract excludes them and the exclusion is evidenced.
- Do not hold back known deployments to "wait for the audit". A known, unreported shortfall increases audit and legal risk. Escalate the decision to the license owner and Legal.
- Keep the true-up dataset unchanged after submission; it is audit evidence.

## 5. Renewal right-sizing

Before a renewal or subscription term ends:

1. Run the ELP and a usage view (access vs. actual use over an agreed look-back, for example last login).
2. Classify each product: grow, hold, reduce, replace, retire.
3. Quantify shelfware (owned, not deployed or not used) and reclaim candidates.
4. Check reduction rights, minimum commitments and co-terming in the contract.
5. Note the decision deadline: the notice period, not the end date, is the real deadline.
6. Hand the right-sized quantities, usage evidence and deadlines to the `itam-vendor-contract-management` skill for negotiation preparation.

## 6. Outputs

- True-up worksheet: product | metric | prior quantity | counted quantity | change | price basis | cost | evidence | approver.
- Renewal sizing brief: product | current quantity | used quantity | recommended quantity | rationale | contract constraint | deadline.
