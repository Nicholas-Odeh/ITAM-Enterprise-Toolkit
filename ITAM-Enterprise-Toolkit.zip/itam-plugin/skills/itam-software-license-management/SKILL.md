---
name: itam-software-license-management
description: Use when someone asks "are we compliant on X", needs an effective license position (ELP), is preparing a true-up or sizing a renewal quantity, wants to reclaim shelfware or unused licenses, is rationalizing SaaS or shadow-IT subscriptions, or has received a publisher audit letter. Covers entitlement vs. consumption, metrics, reharvest, SaaS, audit response. Not for renewal commercial or SLA terms (use itam-vendor-contract-management) or ServiceNow SAM tables and License Workbench (use servicenow-itam).
---

# Software License Management (SAM and SaaS)

License compliance is an evidence exercise: what the organization is entitled to, what it consumes under the contract's metric, and the documented gap (CAMP M:91). For SAM managers, ITAM analysts and audit response teams, any publisher, any tool.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Contracts, not memory, define license rules.** Metrics, counting rules, use rights, virtualization and audit clauses come only from the signed agreements, recorded in `references/publishers/<publisher>.md`. With no profile, mark every metric assumption `VERIFY`.
7. **No verdict without both sides of the ledger.** A status needs verified entitlement and verified consumption for the same product, edition, metric and date. Otherwise it is `INSUFFICIENT EVIDENCE`.
8. **Audit communications go through people.** Prepare drafts only; the audit lead and Legal approve and send. Nothing here is legal advice.

## When to use

- "Are we compliant / over-licensed on X?", shortfall, proof of entitlement.
- True-up, agreement anniversary, renewal quantity.
- Shelfware, leaver licenses, reclaim; shadow-IT or duplicate SaaS.
- Audit letter, self-assessment or auditor data request.

**When not to use:** renewal negotiation, SLAs or clause extraction → `itam-vendor-contract-management`; ServiceNow SAM tables, reconciliation results or publisher packs → `servicenow-itam`; designing SAM controls → `itam-risk-controls-audit`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| License position, compliance, shortfall | `references/elp-method.md` + publisher profile |
| True-up, renewal right-sizing | `references/true-up-renewal.md` |
| Reharvest, reclaim, SaaS sprawl, trial or free software | `references/reharvest-saas.md` |
| Publisher audit or license review | `references/audit-response.md` + `elp-method.md` |
| Record a publisher's rules | `references/publishers/_template.md` |

Read `templates/company-profile.md` at the plugin root if present.

### Step 2 — Preflight

Confirm or label `ASSUMPTION`: products, editions and entities in scope; entitlement evidence (CAMP M:147); consumption source, coverage and date; the metric and its profile; purpose. Live audit: notice date, deadlines, NDA, audit lead, Legal. Ask if the metric or entitlement source is unknown and decides the answer.

### Step 3 — Do the work

- **ELP:** `elp-method.md` §4. Position = entitled − required, per product, edition and metric.
- **True-up:** `true-up-renewal.md` §3–4; legitimate reharvest before the counting date.
- **Reharvest and SaaS:** `reharvest-saas.md` §2; verify removal in the next discovery cycle.
- **Audit:** `audit-response.md` §3; internal ELP before any data leaves.

### Step 4 — Verify before release

- ★ Every metric, counting rule and use right cites a contract or publisher profile, or is marked `VERIFY`.
- ★ Every status has dated entitlement and consumption evidence, or reads `INSUFFICIENT EVIDENCE`.
- ★ Nothing publisher-facing is presented as ready to send without an approval step.
- ★ No step hides, deletes or back-dates deployments to lower a count.
- Totals reconcile to source row counts; coverage, data date and blind spots stated.
- Shortfall values name their price source, or are omitted.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "No shortfall showed up, so we're compliant" | Missing entitlement or consumption data is `INSUFFICIENT EVIDENCE`, not compliance. |
| "VM, dev/test and DR installs don't count; downgrade rights are standard" | Only if the contract grants it. Cite the clause or mark `VERIFY`. |
| "Uninstall it before we answer the auditor" | Changing records mid-audit needs Legal's direction. Never back-date. |
| "The auditor's count looks right" | Reconcile line by line against the internal ELP first. |

Stop if you are about to: print "Compliant" while any line is Shortfall or Insufficient evidence; release audit data unapproved; value exposure without a price source.

## Common mistakes

| Mistake | Fix |
|---|---|
| One device counted from two discovery sources | De-duplicate on device or user key first. |
| Entitlements today, installs from last quarter | One position date for both sides. |
| Netting editions or metrics | Calculate each separately unless the contract allows netting. |
| Counting assignments, not consumed units | Apply the profile's counting rule. |

## If connectors are available

- **~~endpoint management / ~~CMDB:** read installs and last-seen dates; record source and read time.
- **~~procurement / ~~document repository:** read orders, agreements, proof of entitlement.
- **~~ITSM / ~~email:** draft reharvest tasks, user notices and audit letters; nothing is sent or unassigned without approval.

## Output format

1. **Answer** with the position date.
2. **Position table:** product | edition | metric | entitled | required | position | status | evidence grade.
3. **Drivers and remediation**, with owners.
4. **Assumptions, gaps, verification steps; risks.**

Executive variant: exposure range (or why it can't be quantified yet), decisions and deadlines; tables in an appendix.

## Reference files

- `references/elp-method.md`: any position, entitlement grading, metric families, ELP errors.
- `references/true-up-renewal.md`: true-up preparation and renewal right-sizing.
- `references/reharvest-saas.md`: reclaim, SaaS rationalization, trial or free software.
- `references/audit-response.md`: when an audit letter or data request arrives.
- `references/publishers/_template.md`: fill from the contracts before any position for that publisher.
