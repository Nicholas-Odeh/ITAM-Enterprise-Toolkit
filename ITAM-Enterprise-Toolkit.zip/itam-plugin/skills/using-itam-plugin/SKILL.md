---
name: using-itam-plugin
description: Use when starting any IT asset management conversation or task, such as hardware, devices, software licenses, inventory, ServiceNow or SharePoint asset records, imaging, shipping, disposal, contracts, asset costs, audits, procedures, change requests or status reports. Establishes which ITAM skill to load before answering, including before asking a clarifying question.
---

# Using the ITAM plugin

ITAM skills hold what general knowledge lacks: evidence rules, write-safety gates, exception codes and formulas. Load the matching skill before answering, including before a clarifying question; the skill says which question matters. If it doesn't fit, drop it. A subagent with a narrow brief uses the skills it names.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.

User and company instructions (CLAUDE.md, `templates/company-profile.md`, direct requests) take precedence over skills; skills take precedence over default behavior.

## Routing

| Request | Skill |
|---|---|
| Strategy, maturity, roadmap, RACI, which policies | `itam-program-governance` |
| Lifecycle states, joiner-mover-leaver, refresh policy, lost/stolen, warranty | `itam-hardware-lifecycle` |
| Comparing asset lists, ghost devices, inventory accuracy | `itam-inventory-reconciliation` |
| Entitlements, ELP, true-up, reharvest, SaaS, publisher audit | `itam-software-license-management` |
| Wipe proof, certificates, ITAD vendors | `itam-secure-disposition` |
| Autopilot, Intune, MECM or Apple builds | `endpoint-imaging-provisioning` |
| Receiving, tagging, stockroom, shipping, returns | `itam-logistics-warehouse` |
| TCO, depreciation, lease vs. buy, chargeback, budget | `itam-financial-management` |
| Existing contract, SLA credits, scorecard | `itam-vendor-contract-management` |
| New purchase, catalog, RFP, vendor selection | `itam-acquisition-procurement` |
| Risk register, controls, internal or external audit | `itam-risk-controls-audit` |
| CAB change record, rollback plan | `itam-change-request` |
| Periodic status, RAG, decisions needed | `itam-status-report` |
| Staffing, bench throughput, stockroom or spares sizing | `itam-capacity-planning` |
| KPI definitions, dashboards, data quality | `itam-data-analysis-reporting` |
| Workbook design | `itam-spreadsheet-models` |
| Scripts, APIs, bulk updates | `itam-automation-scripting` |
| Slow or failing process, root cause | `itam-process-improvement` |
| SOP, work instruction, runbook, policy text | `itam-sop-documentation` |
| ServiceNow tables, HAM/SAM, CMDB | `servicenow-itam` |
| SharePoint libraries, retention labels, flows | `sharepoint-itam-records` |
| Confidence, provenance, conflicting sources, draft QA | `itam-operating-standard` |

**Tie-breaks**
- **Cycle count:** counting shelves is logistics; comparing with records is reconciliation.
- **Renewal:** terms and notice dates are vendor-contract; license quantities, licensing; cost, financial.
- **TCO:** the method is financial; the workbook adds spreadsheet-models.
- **Chain of custody:** in transit is logistics; from retirement onward, disposition.
- **SOP or improvement:** documenting a process or runbook is sop-documentation; fixing a broken one starts with process-improvement.
- **KPIs or status:** defining or analyzing metrics is data-analysis; a periodic update is status-report.
- **Imaging bench:** builds and build failures are imaging; staffing and throughput are capacity.
- **Bulk change:** the CAB record is change-request; the code is automation-scripting.
- **Leaver devices:** JML process and records are lifecycle; return kits are logistics; a failing recovery rate is process-improvement.
- **ServiceNow:** a named table, module or script adds `servicenow-itam` to the domain skill, and it leads for GlideRecord and encoded queries; platform-neutral questions don't.

**Priority:** `itam-operating-standard` as background, then domain skill (what), method skill (form), platform skill (where).

## Red flags

| Thought | Reality |
|---|---|
| "It's a simple question" | Simple ITAM questions hide counts, dates and rules that need a source. |
| "I know ITAM" | General knowledge is not this organization's rules, codes or gates. |
| "I'll just give the number" | Unsourced numbers get reused as fact. Source or label it. |
