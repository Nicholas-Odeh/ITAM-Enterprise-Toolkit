# Document type templates

Pick the lightest document that controls the work. All types carry document control (ID, version, owner, approver, effective date, review date) and follow the same no-invention rules as the SOP.

## Contents
1. Choosing the document type
2. Work instruction
3. Runbook (technical or operational)
4. Process standard
5. Checklist / job aid
6. Knowledge article
7. Policy document text
8. One-page process summary (executive variant)
9. Lightweight process document

## 1. Choosing the document type

| Type | Answers | Audience | Use when | Approved by |
|---|---|---|---|---|
| Policy | What, who, why | Everyone in scope | Setting rules and authority | Executive management (see `itam-program-governance`) |
| Process standard | Mandatory values or design rules for a process | Process owners, designers | Fixing choices across sites (e.g. tag format, state model, evidence set) | Policy owner or delegate |
| SOP | How the end-to-end process runs across roles | All roles in the process, auditors | Cross-role process with approvals, controls and handoffs | Process owner |
| Work instruction | How one role does one task in one system | A single role | Detailed task steps under an SOP step | Process owner or team lead |
| Runbook | How to operate, recover or change a technical system or job | Engineers, operators | Repeatable technical operations with verification and rollback | Technical owner |
| Checklist / job aid | What to confirm at a point in the process | Practitioners | Short repeatable checks; quality gates | Process owner |
| Knowledge article | How a user or agent resolves a common question | End users, service desk | Self-service and just-in-time guidance | Knowledge owner |

Rule: the SOP references the work instructions and checklists; they don't repeat the SOP. Changes to policy-level statements go through policy approval, not through an SOP edit.

## 2. Work instruction

```
[WI ID] [Task name] — Work Instruction
Parent SOP: [ID, step reference]   Role: [single role]   System: [name as in sources]
Version / owner / approver / effective date / review date

1. Purpose (one sentence)
2. When to use (trigger) and when not to
3. Before you start: access, equipment, inputs
4. Steps
   1. [Imperative action] — [field/value/check]  → expected result
   2. ...
   [SCREENSHOT PLACEHOLDER — capture the confirmed screen showing: ...]
5. Check your work: [how to confirm the task succeeded; evidence to attach]
6. If something goes wrong: [symptom → action → escalate to TBD]
7. Records created and where they are stored
```

Keep it to one role and one task; if it branches across roles, it is an SOP.

## 3. Runbook (technical or operational)

A runbook lets someone who did not write it run a recurring technical or operational task the same way every time, and know at each step whether it worked. The skeleton below adapts the Operations plugin `runbook` template (purpose, prerequisites, steps each with an expected result and a failure action, verification, troubleshooting, rollback, escalation, run history) and keeps the controls this plugin needs (scope, change control, evidence). The modular documentation pattern of NIST SP 1800-5 noted in the research findings points the same way.

```
[RB ID] Runbook: [Task name]
Owner: [role/team]   Frequency: [daily / weekly / monthly / on trigger]
Version / approver / effective date / review date   Last run: [date]
Change control reference: [TBD: change record required? which type?]

1. Purpose
   What this runbook accomplishes, when to use it, and when not to.
2. Scope
   Systems, environments, record sets, asset classes; out of scope.
3. Prerequisites
   [ ] Access or role needed (no credentials in the text: [SECURE CREDENTIAL STORAGE LOCATION])
   [ ] Tools and versions
   [ ] Input data or files, with expected freshness
   [ ] Window, backups or approvals needed before starting
4. Pre-checks
   What to verify before starting; expected counts or states.
5. Procedure
   Step N: [name]
     Action:          [exact command, screen action or instruction]
     Expected result: [what you should see: output, count, status]
     If it fails:     [stop / retry once / go to Troubleshooting row / roll back / escalate]
     Evidence:        [what to keep, if this step produces a record]
6. Verification
   [ ] How to prove the task completed (counts before/after, re-query, sample records)
   [ ] What to check that is easy to miss
7. Troubleshooting
   | Symptom | Likely cause | Fix |
8. Rollback
   Trigger for rollback, steps, and how to verify the rollback worked.
9. Escalation
   | Situation | Contact (role/queue) | Method | After how long |
10. Evidence and records
   Logs, outputs and approvals to retain, and where.
11. Run history
   | Date | Run by | Result (counts) | Issues / observations |
```

Rules:
- **Be exactly specific.** "Run the script" is not a step; give the command, the working location and the flags. Unknown values are `[TBD]`, not guesses.
- **Every step states its expected result and its failure action.** A step without them can't be verified or recovered.
- **Verification is evidence, not a feeling.** The verification section must name what the operator reads (a count, a re-query, a report) before saying the run is complete (`itam-operating-standard`, Iron Law).
- **Bulk changes to asset records** (imports, mass state changes, scripts) need a dry run that counts affected records, a scope limit, a sub-production test, explicit approval and a rollback plan. Route script content to `itam-automation-scripting` or `servicenow-itam`.
- **Test it with someone unfamiliar** with the task. Fix every place they hesitate or ask a question, then record the test in the run history.
- **Escalation contacts are roles or queues** confirmed by the owner, never invented names.

### Worked example (ITAM): weekly endpoint-to-repository reconciliation run

Illustrative only; every `[FILL]` and `[TBD]` comes from the organization.

```
RB-ITAM-007 Runbook: Weekly endpoint-to-repository reconciliation
Owner: ITAM analyst team   Frequency: weekly, [FILL day]   Last run: [date]
Change control: not required (read-only run) [TBD: confirm with change manager]

1. Purpose: match the endpoint-management export to the ITAM repository export,
   produce coded exceptions and the weekly match-rate figure. Not for correcting
   records (corrections go through the record-correction SOP [TBD: ID]).
2. Scope: [FILL: platforms, sites]; asset classes laptop and desktop.
3. Prerequisites:
   [ ] Read access to the repository export report [TBD: report name]
   [ ] Read access to the endpoint-management device export [TBD]
   [ ] Python 3 and the itam-inventory-reconciliation scripts
   [ ] Last week's config file recon.json [TBD: location]
4. Pre-checks: both exports dated the same day; row counts within [FILL]% of last week.
5. Procedure:
   Step 1: Profile identifiers
     Action:          python3 scripts/normalize_serials.py [export].csv -o [export]_norm.csv
                        --map "[serial column]=serial" --summary-json [export]_profile.json
     Expected result: placeholder and duplicate serial rates printed for each export
     If it fails:     column names changed → update the column map in recon.json; re-run
   Step 2: Run the match
     Action:          python3 scripts/match_tiers.py --config recon.json --out-dir out/[date] --as-of [date]
     Expected result: exit code 0; matches.csv, clusters.csv, exceptions.csv, summary.json written
     If it fails:     exit code 2 → fix the config error named in the message; never edit outputs by hand
     Evidence:        keep out/[date]/ and both raw exports unchanged
   Step 3: Check the run
     Action:          compare records in per source with rows in matches.csv; read notes in summary.json
     Expected result: counts equal; no unmapped states
     If it fails:     unmapped state → add it to state_map, re-run Step 2
6. Verification:
   [ ] Match rate reported with numerator, denominator and as-of date from summary.json
   [ ] Review-required (Tier 3) matches excluded from the matched count
   [ ] Exception counts by code sum to the exceptions.csv row count
7. Troubleshooting:
   | Symptom                         | Likely cause                         | Fix                               |
   | Match rate drops sharply        | Export filter changed; source outage | Compare row counts to last week   |
   | Many serials look like 1.23E+11 | Export opened and saved in Excel     | Re-export as CSV; don't open first|
8. Rollback: none needed (read-only). Delete the out/[date] folder only if the run is repeated.
9. Escalation:
   | Situation                       | Contact            | Method      | After  |
   | Export missing or empty         | [TBD: tool owner]  | [TBD queue] | 1 day  |
   | Severity-High exceptions > [FILL] | ITAM manager     | [TBD]       | same day |
10. Evidence: out/[date]/ and raw exports to [TBD: repository location], retained [TBD].
11. Run history: | Date | Run by | Records in / matched / exceptions | Notes |
```

## 4. Process standard

```
[STD ID] [Standard name]
Parent policy: [ID]   Owner / approver / version / effective / review

1. Purpose and scope
2. Requirements (numbered, each checkable)
   STD-1 [requirement] — Rationale — How compliance is checked — Evidence
3. Values and specifications (tables: e.g. tag format, required fields per state, evidence set per disposal method)
4. Exceptions: request route, approval authority, maximum duration, record location
5. Related procedures
```

Values must come from the organization. Where none exist, propose them as `[RECOMMENDED …]` for approval.

## 5. Checklist / job aid

```
[CL ID] [Checklist name]   Used at: [SOP step]   Role: [ ]   Version: [ ]

Before you start
[ ] [check] — pass criterion
During
[ ] [check] — pass criterion — evidence
Before closing
[ ] [check] — pass criterion — evidence
If any item fails: [action / exception reference]
Completed by: [ ]  Date: [ ]  Record kept in: [TBD]
```

Each item is binary and observable. A checklist that records evidence can serve as a control artifact; say so in the SOP control matrix.

## 6. Knowledge article

```
Title: [user's words, e.g. "How do I return my laptop when I leave?"]
Applies to: [audience, asset type, locations]
Summary: [one or two sentences with the answer]
Steps: [numbered, user-facing; no internal-only details]
What happens next: [what the user can expect]
Need help: [contact route — TBD exact queue/channel]
Related: [policy, SOP for agents]
Owner / last reviewed: [ ]
```

Write for the reader's situation, not the process owner's. Don't expose internal controls, credentials or other users' data. Keep it aligned with the SOP; when the SOP changes, the article's review is triggered.

## 7. Policy document text

When asked to draft the policy text itself, use the policy structure in `itam-program-governance` (`references/policy-topics.md` §3): statement, purpose, accountability, scope, definitions, requirements, standards, roles, exceptions, implementation and enforcement, related documents, revision history.

Drafting rules specific to policies:
- No procedure steps, system navigation or named individuals.
- Requirements are enforceable and checkable; "must" only where the organization will enforce.
- Enforcement and consequences reference the HR/Legal-agreed process; don't invent disciplinary terms.
- Legal statements (privacy notices, regulatory obligations) are marked for Legal review: `[TBD: Legal to confirm wording]`.

## 8. One-page process summary (executive variant)

```
[Process name] — Process Summary          Owner: [role]   Status: [draft/approved]
Purpose:       [one sentence]
Trigger:       [event]            End state: [condition]
Phases:        1 [name] → 2 [name] → 3 [name] → 4 [name]
Owners:        [phase → role]
Key controls:  [control → evidence] (3–5)
Measures:      [metric → formula → target or TBD] (2–3)
Open decisions:[owner decisions required before approval]
```

## 9. Lightweight process document

For a low-risk internal process that has no audit, compliance or financial consequence and lives in one team (for example how the stockroom team rotates shelf labels), a full SOP is more document than the work needs. This shape adapts the Operations plugin `process-doc` template. Use the full SOP instead as soon as the process changes an asset record's state, carries a control, crosses teams, or will be audited.

```
Process Document: [Process name]
Owner: [role/team]   Last updated: [date]   Review cadence: [quarterly / annually / TBD]

Purpose:        why the process exists and what it accomplishes
Scope:          what is included and excluded
RACI:           | Step | Responsible | Accountable | Consulted | Informed |
Process flow:   text or simple ASCII flow: trigger → step → decision → step → end state
Detailed steps: Step N: [name]  Who: [role]  When: [trigger/timing]  How: [instructions]  Output: [result]
Exceptions and edge cases: | Scenario | What to do |
Metrics:        | Measure | Target (or "no approved target") | How measured |
Related documents: [policy, SOP, work instructions]
```

Capture tips:
- **Start from how it works today,** however messy the description; structure it afterwards. Gaps become `[TBD]`.
- **Ask for the exceptions.** "Usually we do X, but sometimes Y" is often the most valuable line in the document; put each one in the exceptions table.
- **Record roles, not names,** in the document; if the user names people, note the role they hold.

Source: DocuForge §13, 15, 17; Operations plugin 1.3.0 `runbook` and `process-doc` templates (adapted); prompt-engineering research findings §4.6 (NIST SP 1800-5 documentation pattern); CAMP M:57-58, M:68.
