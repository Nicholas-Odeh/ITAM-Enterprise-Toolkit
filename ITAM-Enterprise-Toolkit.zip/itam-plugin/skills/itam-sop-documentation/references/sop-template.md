# Default SOP template

Use the organization's approved template when one is supplied; keep its headings and add a section only when its absence would leave a material gap (mark it "proposed addition"). Otherwise use this structure. Omit a section only if it genuinely doesn't apply, and say so in the readiness summary.

## Contents
1. Fill-in skeleton
2. Section guidance
3. Standard tables
4. Placeholders and markers

## 1. Fill-in skeleton

```
[SOP TITLE]

DOCUMENT CONTROL
| Field | Value |
|---|---|
| Document ID | [TBD: document ID] |
| Process name | |
| Business unit / scope | |
| Document owner | [role] |
| Process owner | [role] |
| Approving authority | [role or forum] |
| Version | 0.1 (draft) |
| Status | Draft / In review / Approved |
| Effective date | [TBD] |
| Review frequency / next review | [TBD] |
| Supersedes | [document ID or "none"] |
| Classification | [Internal / Confidential / TBD] |
| Published location | [TBD: controlled repository location] |

APPROVAL RECORD
| Approver role | Name | Responsibility | Date | Approval record location |
|---|---|---|---|---|
| [role] | [blank until approved] | [what they approve] | [blank] | [TBD] |

1. PURPOSE
2. SCOPE
   2.1 In scope   2.2 Out of scope   2.3 Process start and end points
3. INTENDED AUDIENCE
4. GOVERNING REQUIREMENTS AND REFERENCES
5. DEFINITIONS AND ACRONYMS
6. ROLES AND RESPONSIBILITIES (with RACI)
7. PROCESS OVERVIEW (trigger, inputs, phases, decisions, outputs, end state; text flow)
8. PREREQUISITES AND REQUIRED ACCESS
9. INPUTS, SYSTEMS, TOOLS AND RECORDS
10. STANDARD PROCEDURE
    10.1 Phase 1 — [name]  (entry criteria → steps → exit criteria)
    10.2 Phase 2 — [name]
11. DECISION RULES
12. EXCEPTIONS, ERRORS AND ESCALATIONS
13. CONTROLS AND COMPLIANCE REQUIREMENTS
14. RECORDS, EVIDENCE AND RETENTION
15. SERVICE LEVELS AND PERFORMANCE MEASURES
16. TRAINING AND COMPETENCY
17. RELATED DOCUMENTS AND RESOURCES
18. REVISION HISTORY
19. APPENDICES (only those that apply)
```

## 2. Section guidance

| # | Section | Must contain | Common mistakes |
|---|---|---|---|
| — | Document control and approval record | All fields; blanks or `[TBD]` where unknown | Fabricated names, signatures, approval dates |
| 1 | Purpose | Why the SOP exists, what outcome it standardizes, the control objective it supports | Restating the whole procedure |
| 2 | Scope | Processes, roles, systems, locations, transactions included; explicit exclusions; start and end boundaries | Scope that doesn't match the steps |
| 3 | Audience | Roles that use, administer, supervise or review it | "All staff" for a technician procedure |
| 4 | Governing requirements | Laws, policies, standards, control requirements, related procedures, forms, KB articles that actually apply | Listing frameworks with no stated relationship |
| 5 | Definitions | Process terms, system terms, **status values**, acronyms, ambiguous terms | Undefined state names |
| 6 | Roles and responsibilities | Per role: duties, approval authority, reviews, handoffs, escalation, recordkeeping; RACI if several roles or handoffs | More than one Accountable per activity |
| 7 | Process overview | Trigger, inputs, major phases, main decisions, outputs, completion state; short text flow | Replacing the procedure with the overview |
| 8 | Prerequisites and access | Training, permissions, system access, forms, approvals, equipment, preconditions | Access levels not confirmed by sources |
| 9 | Inputs, systems, tools, records | Per item: name, purpose, owner, whether system of record, where the authoritative record lives, access restrictions | Two names for the same system |
| 10 | Standard procedure | Phases with entry criteria, numbered steps, decision points, handoffs, verification, evidence, exit criteria; step table for complex flows | Controls only in section 13, not at the step |
| 11 | Decision rules | IF/THEN criteria for approval, routing, eligibility, priority, classification, acceptance, escalation, closure | Decisions buried in prose |
| 12 | Exceptions, errors, escalations | Per exception: trigger, containment, handler, notification, approval authority, documentation, evidence, escalation timeframe, resume point, termination conditions | Invented escalation contacts |
| 13 | Controls and compliance | Per control: objective, activity, owner, frequency, trigger, evidence, evidence location, reviewer, exception handling, related requirement; type (preventive/detective/corrective; manual/automated/hybrid) | Controls with no evidence |
| 14 | Records, evidence, retention | Per record: name, creator, content, storage location, system of record, retention period, disposal method, access limits, related control | Inferred retention periods |
| 15 | Service levels and measures | Confirmed targets; per metric numerator, denominator, frequency, source, owner | Invented targets |
| 16 | Training and competency | Required training, competencies, recertification, evidence, owner | Unconfirmed requirements stated as mandatory |
| 17 | Related documents | Official title and ID; how each is used | Unexplained lists |
| 18 | Revision history | Version, date, change, reason, author, approver; substantive vs. editorial | Missing change reason |
| 19 | Appendices | RACI, process flow, checklist, decision matrix, control matrix, required-data matrix, evidence matrix, exception matrix, glossary, form instructions, screenshot register, traceability matrix | Fabricated screenshots |

## 3. Standard tables

**Step table (section 10, complex procedures)**

| Step | Responsible role | Action | System / form | Control or evidence | Output / next step |
|---|---|---|---|---|---|
| 2.1 | Receiving Technician | Compare the serial number on the device with the packing slip and the PO line | PO in [TBD: procurement system]; packing slip | Serial match recorded on receiving record | IF match → 2.2. ELSE → Exception E-01 |

**RACI (section 6)**

| Activity | [Role A] | [Role B] | [Role C] | [Role D] |
|---|---|---|---|---|
| | A | R | C | I |

**Exception matrix (section 12)**

| ID | Trigger | Containment | Handler | Notify | Approval authority | Evidence | Escalate after | Resume at |
|---|---|---|---|---|---|---|---|---|

**Control matrix (section 13)**

| Control ID | Objective | Activity (step ref) | Type | Owner | Frequency | Evidence | Evidence location | Reviewer |
|---|---|---|---|---|---|---|---|---|

**Records table (section 14)**

| Record | Created by (step) | Content | Location / system of record | Retention | Disposal | Access | Supports control |
|---|---|---|---|---|---|---|---|

**Metrics table (section 15)**

| Measure | Numerator | Denominator | Frequency | Source | Owner | Target |
|---|---|---|---|---|---|---|

**Revision history (section 18)**

| Version | Date | Change | Type (substantive / editorial) | Reason | Author | Approver |
|---|---|---|---|---|---|---|

## 4. Placeholders and markers

| Marker | Use |
|---|---|
| `[TBD: what is missing — owner to confirm]` | Unknown organization-specific value or decision |
| `[RECOMMENDED — not confirmed as an existing requirement]` | Proposed content for the owner to accept |
| `[SCREENSHOT PLACEHOLDER — capture the confirmed screen showing: …]` | Where a screenshot would help; never invent one |
| `[CONFIRMED STATUS]` / `[STATE: …]` | Where a status value goes but the exact name isn't confirmed |
| `[SECURE CREDENTIAL STORAGE LOCATION]`, `[EMPLOYEE IDENTIFIER]` etc. | Sensitive values |
| "Proposed addition" | A section added to the organization's template |

Source: DocuForge §13, 20; AssetForge §32 (Mode C), §35.
