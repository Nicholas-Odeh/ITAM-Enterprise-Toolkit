# ITAM procedure checklists

Prompts that make sure an asset-related procedure covers what ITAM auditors and operators need. Everything here is `PRACTICE` unless the user's sources confirm it: use it to find gaps and ask questions, not to fill the SOP with assumed facts. State names below are generic descriptions; write the organization's exact names (from the company profile or the canonical data model) or `[STATE: … — TBD exact name]`.

## Contents
1. ITAM elements every asset procedure must identify
2. Lifecycle process prompts
3. Evidence catalog
4. Control record fields
5. Exception record fields and types
6. Process metrics menu

## 1. ITAM elements every asset procedure must identify

Adapted from DocuForge §17 and AssetForge §7, 35. For each, the SOP either states it (sourced) or carries a `[TBD]`.

- [ ] System of record for each record changed (asset, CI, ticket, PO, fixed-asset register)
- [ ] Asset record vs. CI: which is updated, by whom, automatically or manually
- [ ] Record ownership (who may change which fields)
- [ ] Lifecycle state and substate before and after each transition
- [ ] Physical or logical location and stockroom
- [ ] Assigned user or custodian, and acknowledgement
- [ ] Discovery or inventory source that will later confirm the change
- [ ] Linked request, incident, task, change or case record
- [ ] Required approvals
- [ ] Reconciliation activity that would detect the step being skipped
- [ ] Audit evidence produced and where it is stored
- [ ] Chain of custody whenever the asset changes hands or location
- [ ] Data-quality validation at entry (serial, model, tag format)
- [ ] Sanitization or disposal evidence where data-bearing devices leave control
- [ ] Exception queue and record remediation path
- [ ] Platform navigation (ServiceNow, SharePoint, others) only when confirmed by the sources

Don't assume every lifecycle phase is in scope; state the start and end boundaries.

## 2. Lifecycle process prompts

For each process: typical trigger, the transition, decisions to make explicit, controls and evidence to look for, exceptions the SOP must handle. Domain detail lives in the named skill.

### Request and acquisition (`itam-acquisition-procurement`)
- **Trigger:** approved request or catalog order. **Transition:** none → on order.
- **Decisions:** standard vs. non-standard; reuse from stock before purchase; approval route by value or type `[TBD thresholds]`.
- **Controls / evidence:** approval record; PO linked to request; standard catalog check.
- **Exceptions:** purchase outside the process; urgent request; out-of-stock standard model.

### Receiving and intake (`itam-logistics-warehouse`)
- **Trigger:** delivery arrives. **Transition:** on order → in stock (receiving).
- **Decisions:** accept or reject (damage, wrong item, quantity); serial matches PO/ASN.
- **Controls / evidence:** receiving record with date/time, receiver, PO line, serials; damage photos; RMA reference.
- **Exceptions:** damaged, short or over shipment; unexpected delivery with no PO; serial mismatch.

### Tagging and recording
- **Trigger:** accepted receipt. **Transition:** record created in system of record.
- **Decisions:** tracked individually or as consumable `[TBD threshold]`; tag format.
- **Controls / evidence:** tag applied and recorded; required fields complete; fixed-asset register entry where capitalized; receipt-to-record time.
- **Exceptions:** duplicate serial; missing model; vendor-applied tag wrong.

### Stockroom placement and storage
- **Trigger:** recorded asset. **Transition:** in stock, available (or substate).
- **Controls / evidence:** stockroom and bin recorded; restricted access; stock counts.
- **Exceptions:** wrong location; defective on arrival.

### Configuration / imaging handoff (`endpoint-imaging-provisioning`)
- **Trigger:** allocation to a request. **Transition:** in stock → configured / ready.
- **Controls / evidence:** build version recorded; validation checklist; enrollment confirmed.
- **Exceptions:** failed build; driver or BIOS mismatch.

### Deployment and assignment (`itam-hardware-lifecycle`)
- **Trigger:** fulfilment task. **Transition:** in stock / ready → in use.
- **Decisions:** in-person handover vs. shipment; replacement (old device return required?).
- **Controls / evidence:** identity check; user acknowledgement (signed or electronic); assigned-to and location updated; old device recovery task opened if a swap.
- **Exceptions:** user not available; wrong device delivered; shipment lost.

### Move, transfer and reassignment
- **Trigger:** mover event, transfer request. **Transition:** assignment, location or cost center change; in transit for physical moves.
- **Controls / evidence:** transfer record; receiving confirmation at destination; custody chain.
- **Exceptions:** item not received at destination; department change without device change.

### Loaner issue and return
- **Trigger:** loaner request. **Transition:** in stock (loaner pool) → in use (loaner) → returned.
- **Controls / evidence:** due date; reminder schedule; return inspection; reimage on return.
- **Exceptions:** overdue loaner; loaner converted to permanent assignment.

### Leaver recovery (joiner-mover-leaver)
- **Trigger:** HR termination or leaving notice. **Transition:** in use → returned / in transit → in stock (pending wipe or inspection).
- **Decisions:** return method (in person, return kit, courier); remote lock or wipe if not returned `[TBD security rule]`.
- **Controls / evidence:** recovery task per assigned asset; tracking number; receipt record; wipe record; manager and HR notifications; aging.
- **Exceptions:** non-response; device reported lost; leaver disputes; contractor with no HR record.

### Inventory and cycle count (`itam-inventory-reconciliation`)
- **Trigger:** schedule or event. **Transition:** none, unless investigation changes a record.
- **Controls / evidence:** count sheet or scan file; counter and reviewer different `[confirm]`; variance list; investigation notes before any record change.
- **Exceptions:** found asset not on record; recorded asset not found; wrong location.

### Reconciliation (repository vs. discovery vs. finance vs. physical)
- **Trigger:** schedule. **Transition:** none directly; exceptions raised.
- **Controls / evidence:** dated extracts; match rules and thresholds; exception register with owners and aging; sign-off of results.
- **Exceptions:** each exception type in section 5.

### Repair, warranty and RMA
- **Trigger:** fault ticket. **Transition:** in use → in repair / pending repair → back to use or stock, or to disposal.
- **Controls / evidence:** warranty check; RMA number; data handling for devices sent out `[TBD: wipe or drive retention rule]`; return receipt.
- **Exceptions:** out of warranty; vendor replaces with a different serial (update the record and keep the link).

### Lost or stolen
- **Trigger:** user report or failed recovery. **Transition:** in use → missing (lost/stolen).
- **Controls / evidence:** report record with date; security notification; remote lock/wipe evidence; police report where required `[TBD]`; write-off approval; reinstatement path if found.
- **Exceptions:** found later; contains regulated data (route to incident process).

### Retirement and disposal (`itam-secure-disposition`)
- **Trigger:** end of life, damage beyond repair, refresh. **Transition:** in stock (pending disposal) → retired (disposed / sold / donated / recycled).
- **Decisions:** reuse, resale, donation, recycling, destruction; on-site vs. vendor sanitization.
- **Controls / evidence:** retirement approval; software harvest; sanitization record per device; chain-of-custody form at handover; certificate of erasure/destruction/recycling from the vendor; financial write-off or disposal entry; record closed with correct reason.
- **Exceptions:** certificate missing or serials don't match; device lost in transit to vendor; data-bearing device without sanitization record.

### Software reclaim and license harvest (`itam-software-license-management`)
- **Trigger:** non-use threshold, leaver, retirement. **Transition:** allocation removed; entitlement returned to pool.
- **Controls / evidence:** usage evidence; user/manager notice; uninstall confirmation; entitlement record updated.
- **Exceptions:** user objects; license not transferable under contract terms.

### Vendor or external audit response (`itam-risk-controls-audit`)
- **Trigger:** audit letter. **Transition:** none.
- **Controls / evidence:** single point of contact; legal review; data provided log; response deadlines from the contract.
- **Exceptions:** staff contacted directly by auditor; data requests outside contract scope.

## 3. Evidence catalog

Evidence types an ITAM SOP may need to produce (AssetForge §14). For each one used, the SOP states the control it supports, owner, repository, retention (or `[TBD]`), timestamp and reviewer.

| Stage | Evidence |
|---|---|
| Request and acquisition | Approved request; approval record; purchase order; invoice |
| Receipt and identification | Receiving record; asset tag record; inventory scan; system record |
| Deployment and use | Deployment record; user acknowledgement; discovery record |
| Movement | Transfer record; chain-of-custody record; return record |
| End of life | Retirement approval; data-sanitization evidence; disposition evidence; certificate of destruction; vendor record |
| Control and assurance | Reconciliation report; exception approval; remediation record; control execution log; management review record |

A process "probably happening" is not evidence that it happened.

## 4. Control record fields

For each control the SOP defines (AssetForge §13): control ID; objective; risk addressed; description; type (preventive / detective / corrective); execution (manual / automated / hybrid); frequency; owner; performer; input; procedure step reference; expected result; evidence; evidence location; retention; exception criteria; escalation; dependencies; test method; pass criteria. A control is incomplete if nothing observable shows it ran.

## 5. Exception record fields and types

Fields: exception ID; type; asset or population; date identified; source; description; expected state; observed state; business impact; risk; root cause; control failure (if any); owner; priority; remediation; target date; age; status; escalation; validation method; closure evidence (AssetForge §15).

Types: approved policy exception; data-quality exception; process failure; control failure; technical integration failure; ownership failure; lifecycle exception; compliance exception; audit finding. Track aging, and don't let long-running exceptions become an undocumented alternate process.

## 6. Process metrics menu

Pick the few the process owner will act on; formulas need numerator, denominator, source and owner. Targets are `[TBD]` unless supplied.

| Metric | Formula |
|---|---|
| Receipt-to-record time | Median time from delivery to asset record created |
| Deployment cycle time | Median time from request approval to user acknowledgement |
| Leaver recovery rate | Devices recovered within the required time ÷ devices assigned to leavers in period |
| Recovery aging | Count of open recovery tasks by age band |
| Cycle-count accuracy | Locations or items with no variance ÷ counted |
| Reconciliation match rate | Records matched ÷ records evaluated |
| Exception aging | Open exceptions by age band and type |
| Disposal evidence completeness | Disposed assets with sanitization record and certificate ÷ disposed assets |
| Loaner overdue rate | Overdue loaners ÷ loaners issued |

Sources: DocuForge §17; AssetForge §7, 13–15, 26, 35; CAMP M:38-43, M:72-77.
