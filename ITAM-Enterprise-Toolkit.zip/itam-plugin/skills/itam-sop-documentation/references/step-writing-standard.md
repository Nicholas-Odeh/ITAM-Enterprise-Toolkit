# Step-writing standard

How to turn a process model into steps someone can execute and an auditor can test.

## Contents
1. The 12-question step decomposition
2. Procedure quality questions (whole process)
3. Decision-logic patterns
4. Verbs, voice and modal verbs
5. Numbering and structure
6. Terminology consistency
7. Weak-to-strong rewrites
8. Handoffs and parallel work
9. Drafting sequence (SKILL Step 3 in full)

## 1. The 12-question step decomposition

For each step, answer as many as apply (DocuForge §10):

| # | Question | Where it shows up in the step |
|---|---|---|
| 1 | Who performs it? | Role at the start of the step |
| 2 | What action? | One principal verb |
| 3 | When? | Trigger or timing ("within [TBD] business days of the HR termination notice") |
| 4 | Where? | Location or system |
| 5 | Which system, form, record, report or tool? | Named exactly as in the sources |
| 6 | What information is reviewed or entered? | Fields, values, documents |
| 7 | What validation must occur? | The check and its pass criterion |
| 8 | What decision determines the next step? | IF/THEN |
| 9 | What evidence is created? | Record, attachment, log, signature |
| 10 | What output or status results? | State change, ticket status, deliverable |
| 11 | What happens if the expected result doesn't occur? | Exception reference |
| 12 | Where does the process continue? | Next step number |

If a question can't be answered from the sources and matters, put a `[TBD: …]` in that step.

## 2. Procedure quality questions (whole process)

A procedure isn't complete because steps are listed. Before release, confirm the document answers (AssetForge §35):

- Who performs each activity, and what triggers it?
- What input is required, and which system is used?
- What state change occurs (asset state, ticket status)?
- What control applies, and what evidence it produces?
- What happens when the normal path fails, and who approves exceptions?
- What closes the activity?
- What metric monitors performance?

## 3. Decision-logic patterns

Use explicit forms; never hide decisions in narrative paragraphs.

| Pattern | Example |
|---|---|
| IF … THEN … ELSE … | IF the serial number matches the PO line, THEN go to Step 2.3. ELSE place the device in [STATE: quarantine — TBD exact name] and raise Exception E-01. |
| WHEN [event], [role] MUST [action] | WHEN HR sends a termination notice, the Asset Coordinator must open a recovery task for every asset assigned to the leaver. |
| DO NOT proceed until … | Do not change the asset state to Retired until the certificate of destruction is attached. |
| ESCALATE to [role] when … | Escalate to [TBD: escalation role] when a device is not returned [TBD: n] days after the leaving date. |
| Multi-way decisions | Use a decision table: condition columns, outcome column, next step column. |

Decision table example:

| Device condition | Data-bearing? | Under warranty? | Action | Next step |
|---|---|---|---|---|
| Working | — | — | Reimage and return to stock | 4.1 |
| Faulty | — | Yes | Raise warranty claim | 5.1 |
| Faulty | Yes | No | Sanitize, then route to disposal | 6.1 |
| Faulty | No | No | Route to disposal | 6.1 |

Every decision lists **all** its outcomes, including "unknown / can't determine".

## 4. Verbs, voice and modal verbs

- **Active voice, observable actions:** "The Asset Coordinator verifies…", "Select…", "Record…", "Attach…", "Compare…", "Submit…", "Approve…", "Escalate…", "Retain…".
- **Avoid vague instructions:** "handle as needed", "process appropriately", "ensure everything is correct", "follow the normal procedure", "contact the appropriate team", "update the system accordingly", "perform any necessary follow-up".
- **Modal verbs, used deliberately:**

| Word | Meaning | Use only when |
|---|---|---|
| must / shall | Binding requirement | A law, contract, approved policy/standard or the user confirms it |
| should | Recommended or preferred practice | Recommendation or good practice |
| may | Permitted option | The option is genuinely allowed |
| can | Capability | Describing what a system or role is able to do |
| Imperative ("Record the serial") | Procedural action | Inside steps |

Don't upgrade an informal preference into "must".

## 5. Numbering and structure

- Hierarchical: `1.0` phase → `1.1` step → `1.1.1` substep. Don't restart numbering without a reason.
- One principal action per numbered step; related checks or evidence can be substeps.
- Each phase starts with **entry criteria** and ends with **exit criteria**.
- Cross-references use step numbers ("go to 3.4"), and are checked after every edit.
- Put the control at the step where it is performed, with its evidence; then summarize controls in section 13.

## 6. Terminology consistency

- One name per role, system, record, request type, asset class, status, approval and process stage. Pick the source's term and use it everywhere.
- Define every acronym at first use (or in the acronym table if the template requires it).
- Status and state names exactly as in the system of record or the canonical data model; otherwise `[STATE: … — TBD exact name]`.
- Plain language for the stated audience, without dropping technical precision.

## 7. Weak-to-strong rewrites

| Weak | Strong (placeholders where facts are unknown) |
|---|---|
| "Review the request and process it accordingly." | "The Request Analyst compares the requester, request type, approval status and required date with the request form. IF a required field or approval is missing, THEN set the request to [CONFIRMED STATUS], record the missing item in the activity log, and return it to the requester. ELSE go to Step 4." |
| "Make sure the asset is updated in the system." | "The Field Technician sets the asset state to [STATE: In use — TBD exact name], sets Assigned to = the receiving user, and attaches the signed acknowledgement to the asset record in [TBD: ITAM system]." |
| "Collect devices from leavers." | "WHEN the leaver's last working day is recorded, the Asset Coordinator sends the return kit request to [TBD: logistics role] within [TBD: n] business days and sets the recovery task due date to [TBD: rule]." |
| "Dispose of old equipment securely." | "The Disposal Coordinator confirms each device on the collection manifest has a sanitization record or is marked for physical destruction. DO NOT release the shipment until the ITAD vendor's driver signs the chain-of-custody form; attach the signed form to the disposal order." |
| "Escalate if necessary." | "ESCALATE to [TBD: escalation role] when the device is not received [TBD: n] days after the due date; record the escalation in the recovery task." |

Don't copy example status or system names into a real SOP unless the sources confirm them.

## 8. Handoffs and parallel work

- For each handoff to another process or team, state: the related process, the handoff point, the required input, the receiving role, and the return or completion signal.
- When activities run in parallel, say so explicitly ("Steps 3.2 and 3.3 occur concurrently; both must complete before 3.4").
- When the process waits on an external party (carrier, vendor, HR), state the waiting condition and the timeout path.

## 9. Drafting sequence (SKILL Step 3 in full)

1. **Model the process before writing:** trigger → preconditions and access → inputs → normal flow → decision points → approvals → handoffs → controls → evidence created → alternate and exception paths → escalation → failure recovery → final validation → outputs → completion criteria → end state. Introduce every role and system object before it is used.
2. **Decompose each step** with the 12 questions in §1 (who, what, when, where, which system or form, what to check or enter, what validation, what decision, what evidence, what output or status, what if it fails, where next).
3. **Draft into the organization's template,** or the default in `sop-template.md`. One principal action per numbered step; hierarchical numbering (1.0, 1.1, 1.1.1); IF/THEN/ELSE decision logic, never hidden in prose.
4. **Put controls and evidence in the step where they happen,** then summarize them in the control and records sections. Every control has an owner, frequency, evidence and evidence location (or `[TBD]`).
5. **For ITAM processes,** run the checklist in `itam-procedure-checklists.md`: system of record, asset vs. CI record affected, lifecycle state change, custodian, chain of custody, reconciliation, sanitization evidence, exception queue. Don't assume every lifecycle stage is in scope.
6. **Keep reviewer notes out of the procedure.** Assumptions, TBDs, recommendations and source conflicts go in the readiness summary and open-items list.

Source: DocuForge §10–12; AssetForge §35.
