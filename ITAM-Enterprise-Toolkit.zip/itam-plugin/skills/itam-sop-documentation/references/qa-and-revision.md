# QA, validation and revision

Use before releasing any ITAM document, and for REVISE, STANDARDIZE, CONSOLIDATE and VALIDATE requests.

## Contents
1. Internal review passes
2. QA scorecard and release threshold
3. Hallucination check
4. Consistency check
5. Validation report (VALIDATE mode)
6. Revising an existing document (REVISE mode)
7. Standardizing and consolidating
8. Readiness summary, open items, traceability and change-impact tables
9. Output package and variants

## 1. Internal review passes

After drafting, review the document from four angles (condensed from DocuForge §9). These are passes over the same draft, not separate personas.

| Pass | Asks |
|---|---|
| Controls and risk | Are authorization, segregation of duties, approvals, data accuracy, completeness, timeliness, records, retention, security, privacy, exception approval, reconciliation, management review, audit trail and control ownership covered, or flagged as gaps? (Don't invent controls.) |
| End user | Could an authorized employee new to the team execute it using only the SOP, the referenced systems and forms, and the stated access? Flag every step that relies on unstated knowledge. |
| Auditor | Are there unsupported statements, omissions, contradictions, ambiguous responsibilities, missing evidence or weak exception handling? |
| Revision | Fix what the passes found without adding unsupported content; then rescore. |

**Walkthrough test (recommended before approval).** The passes above are desk reviews. Before the owner approves, have someone authorized but unfamiliar with the task follow the document (live, in a test environment, or as a tabletop). Record each point where they hesitate, ask a question or deviate, fix it, and note the test in the revision history. A runbook's run history (`document-type-templates.md` §3) is a good place to record it. `PRACTICE`, adapted from the Operations plugin runbook tips.

## 2. QA scorecard and release threshold

Score each criterion 1–5 (DocuForge §18).

| # | Criterion | 5 means |
|---|---|---|
| 1 | Factual accuracy and source fidelity | Every statement sourced, user-supplied, TBD or labeled recommendation |
| 2 | Completeness | All needed sections and paths present for the stated scope |
| 3 | Procedural executability | A new authorized person could run it end to end |
| 4 | Role and accountability clarity | Every step has a role; one Accountable per activity; RACI matches |
| 5 | Sequence and decision logic | Correct order; every decision shows all paths; step references right |
| 6 | Controls and audit evidence | Controls at the step, with owner and evidence (or flagged gap) |
| 7 | Exception, escalation and recovery handling | Known exceptions have trigger, handler, authority, evidence and resume point |
| 8 | Security and privacy | No sensitive values; data handling explicit where relevant |
| 9 | Language, terminology and consistency | Active, directive, one term per thing; modal verbs used correctly |
| 10 | Maintainability and document control | Control fields, revision history, org-specific values isolated |

Scale: 5 complete and review-ready; 4 strong, minor non-blocking improvements; 3 material gaps or ambiguity; 2 major corrections needed; 1 unusable or unsafe.

**Review-ready threshold:** total ≥ 46/50; no criterion below 4; no unresolved critical contradiction; no unsupported requirement presented as fact; every binding requirement traceable to a source or explicit user instruction; every phase has entry and exit conditions; every decision identifies its paths; every known exception has an owner or is marked unresolved; every control has evidence or says evidence requirements are unconfirmed.

If below threshold: name the failed criteria, revise, rescore; repeat until it passes or an owner decision is required. Don't inflate scores. Note: a draft with many legitimate `[TBD]`s can still be review-ready as a *draft*; it is not approvable until the TBDs close. Say so in the readiness summary.

Scorecard output:

| Criterion | Score | Validation result |
|---|---:|---|
| Factual accuracy and source fidelity | /5 | |
| Completeness | /5 | |
| Procedural executability | /5 | |
| Role and accountability clarity | /5 | |
| Sequence and decision logic | /5 | |
| Controls and audit evidence | /5 | |
| Exception and recovery handling | /5 | |
| Security and privacy | /5 | |
| Language and consistency | /5 | |
| Maintainability and document control | /5 | |
| **Total** | **/50** | |

## 3. Hallucination check

Before release, list every instance of the following in the draft and confirm each is (A) supported by a source, (B) supplied by the user, (C) marked `[TBD]`, or (D) labeled a recommendation (DocuForge §19):

person or role · department · system · field · status or state · form · queue · report · deadline · threshold · approval · control · policy · regulation · retention period · repository · notification · escalation path

Anything that fails all four is removed or converted. This is a ★ release item.

## 4. Consistency check

- [ ] The same role, system, status and record have one name throughout.
- [ ] Step and section cross-references are correct.
- [ ] Defined terms match how they're used.
- [ ] RACI agrees with the procedure.
- [ ] Control matrix agrees with the procedure (each control appears at a step).
- [ ] Exception matrix agrees with the procedure (each exception has an entry point).
- [ ] Records section lists the evidence the steps create, and only that.
- [ ] Process overview agrees with the detailed steps.
- [ ] Stated scope agrees with the procedure.
- [ ] Completion criteria agree with the final steps.
- [ ] Revision history agrees with the change summary.

## 5. Validation report (VALIDATE mode)

Produce the report first; rewrite only if the user asked for a corrected version.

Evaluate: source fidelity, scope clarity, procedural completeness, sequence, role accountability, decision logic, approvals, controls, evidence, exceptions, escalations, records, retention, security, privacy, terminology, usability, template compliance, audit readiness, revision control.

Severity (DocuForge §16):

| Severity | Meaning |
|---|---|
| Critical | Could cause legal, regulatory, security, financial, safety or major control failure |
| High | Could make the process fail or produce materially inconsistent results |
| Medium | Ambiguity, inefficiency, weak evidence or maintainability problems |
| Low | Editorial, formatting or minor usability |
| Observation | Possible improvement not currently a requirement |

Finding format:

| ID | Severity | Section | Existing language or issue | Why it matters | Supporting source | Recommended correction | Owner decision needed |
|---|---|---|---|---|---|---|---|

End with the scorecard (section 2) and a one-line verdict: review-ready / needs revision / blocked pending owner decisions.

## 6. Revising an existing document (REVISE mode)

1. Preserve approved content that is still correct; keep document ID and revision history unless told otherwise.
2. Compare the current document with the authoritative sources; identify outdated steps, terms, systems, roles, controls and references.
3. Correct contradictions; remove duplicate or obsolete instructions.
4. **Do not silently change the underlying process.** Classify every change: process, control, role, system, compliance, editorial clarification, formatting standardization.
5. Produce a change-impact summary (section 8).
6. List downstream updates needed: training, forms, knowledge articles, system configuration, reports, controls, related SOPs.
7. Increment the version and add a revision-history row with change type and reason.

## 7. Standardizing and consolidating

STANDARDIZE (map to the approved template): preserve operational meaning; normalize headings, role names, terms and numbering; remove repetition; convert descriptive paragraphs into executable steps; separate policy statements from procedure; separate normal flow from exceptions; add missing metadata placeholders without inventing values; make control and evidence descriptions consistent.

CONSOLIDATE (merge several procedures): identify where versions conflict and present them rather than merging incorrectly; keep local variations only when they are supported and necessary (for example a regulatory difference by country); propose a single enterprise process plus documented local variants where that fits; record which source each part came from.

## 8. Readiness summary, open items, traceability and change-impact tables

**Document readiness summary**
- Draft status and intended approval route
- Number of unresolved `[TBD]` items
- Number of labeled recommendations
- Material source conflicts
- Owner decisions required before approval

Never say the document is approved, compliant, certified or audit-proof. Say "review-ready" only when the threshold is met, and "aligned with the supplied requirements" rather than "fully compliant".

**Assumptions and open items** — group as: confirmed facts; non-blocking assumptions; TBD items (with owner); recommendations; decisions required before approval.

**Source traceability matrix**

| SOP section or requirement | Source document | Location in source | Authority level | Notes |
|---|---|---|---|---|

Keep source references out of procedural sentences unless the template requires inline references.

**Change-impact summary** (revise / standardize / consolidate)

| Change | Change type | Reason | Operational impact | Required follow-up |
|---|---|---|---|---|

## 9. Output package and variants

When information is sufficient, deliver in order:
- **A. The document** (SOP or other type), publication-ready, with document control and approval record fields (no fabricated names, signatures or dates).
- **B. Document readiness summary:** draft status, number of TBDs and recommendations, source conflicts, owner decisions required before approval.
- **C. QA scorecard** (table, with a one-line validation note per criterion).
- **D. Assumptions and open items:** confirmed facts, non-blocking assumptions, TBDs, recommendations, decisions required.
- **E. Source traceability matrix** (for audit-sensitive procedures, or when the user asks).
- **F. Change-impact summary** (for revised, standardized or consolidated documents).

If the user asks for the document only, give A plus a short list of TBDs. In ASK_FIRST mode with blocking gaps, output only the Clarification Packet.

**Executive variant:** a one-page process summary (`document-type-templates.md` §8) for approvers. **Practitioner variant:** the full SOP, or a step-level work instruction for one role.

Source: DocuForge §9, 14–16, 18–21.
