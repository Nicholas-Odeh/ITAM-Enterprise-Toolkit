---
name: itam-vendor-contract-management
description: Use when reviewing an IT vendor contract or proposal, asking whether a vendor missed an SLA or owes credits, building a scorecard or QBR pack, assessing vendor risk, or preparing a renewal's commercial terms, notice date or negotiation. Covers obligation registers, SLA credits, scorecards, vendor risk, TCO inputs, negotiation points. Not for new-vendor RFPs (use itam-acquisition-procurement), license position or true-up sizing (use itam-software-license-management) or TCO math (use itam-financial-management).
---

# IT Vendor, Contract and SLA Management

Turn contracts, SLA reports and invoices into decisions: what each side owes, whether service levels were met, what credits are due, what risk the vendor carries, and what to do at renewal. For ITAM, vendor management, procurement and service owners.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **The contract text decides obligations.** Cite document and clause for every obligation, threshold and remedy. Never turn an internal target into a supplier commitment, a KPI miss into a breach, or `UNKNOWN` into compliant.
7. **Compute in code, show the formula.** SLA and credit formulas come from the governing document; run `python3 scripts/sla_calc.py`. TCO goes through `itam-financial-management`. A result carries the weakest label of its inputs.
8. **Analysis, not legal advice.** Enforceability, liability, indemnity and dispute strategy go to legal review.

## When to use

- Obligation register: "what do we / they owe under this MSA?"
- "Did they miss the SLA?", credits due or unclaimed, chronic breach.
- Scorecard, QBR pack, vendor tiering, third- or fourth-party risk.
- Vendor review (proposal, renewal, comparison): TCO breakdown, negotiation points.
- Auto-renewal notice dates; renew vs. re-source; exit.

**When not to use:** RFx and new-vendor selection → `itam-acquisition-procurement`; license position and true-up quantities → `itam-software-license-management`; TCO, NPV and lease-vs-buy math → `itam-financial-management`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| Obligations, clause matrix, ITAM triggers | `references/contract-extraction-schema.md` |
| SLA attainment and credits | `references/sla-formulas.md` + `scripts/sla_calc.py` |
| Scorecard, QBR, tiering, vendor risk | `references/scorecard-template.md` |
| Vendor review (new, renewal, comparison) | `references/vendor-review.md` |
| Renewal, negotiation, exit | `references/renewal-checklist.md` |

Method per type: `references/working-method.md` §2.

### Step 2 — Preflight

Use the intake in `vendor-review.md` §1: vendor and context; decision and notice dates; the signed document chain with effective dates; pricing, volumes and current spend; performance data and its source; approved weights and risk method; consequence of error. Ask for missing amendments before declaring an obligation. Rate evidence `SUFFICIENT`, `PARTIALLY SUFFICIENT` or `INSUFFICIENT` and narrow conclusions to match.

### Step 3 — Do the work

Normalize → inventory evidence → extract → validate SLA definitions → calculate with scripts → analyze → options → recommend (`working-method.md` §2). Every material finding becomes an action with owner, date and evidence of completion.

### Step 4 — Verify before release

- ★ Every obligation, threshold, right and remedy traces to a document and clause; unreviewed documents are named.
- ★ Contractual requirements are separated from internal targets; nothing `UNKNOWN` reads as compliant.
- ★ SLA definitions match the contract (exclusions, windows, clock, rounding), and every formula is shown.
- ★ Critical calculations were recomputed in code before release.
- ★ No benchmark, right or framework clause is asserted without a verified source.
- ★ Legal-interpretation questions are flagged for legal review.
- The full 26-mark checklist: `references/quality-checklist.md`.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Availability is just uptime over the month" | Use the contract's formula; near a threshold the formula decides the breach. |
| "They missed our target, so they're in breach" | Only a contractual commitment can be breached. |
| "The credit is about 5% of the fee" | Run `sla_calc.py` with the tier table and cap; numbers by eye are not evidence. |
| "The renewal notice can wait" | Back-calculate the notice deadline now. |

Stop if you are about to: assert an obligation without a clause; send a credit claim or notice without approval; give a legal opinion.

## Common mistakes

| Mistake | Fix |
|---|---|
| Assuming the SOW overrides the MSA | Check the precedence clause. |
| Missing claim deadlines on credits | Track due, claimed, received and deadline per period. |
| Vendor report and own monitoring averaged | Show both and the gap. |
| TCO without exit or switching costs | Include them for every option (`vendor-review.md` §2). |

## If connectors are available

- **~~procurement / ~~document repository:** read contract chain, spend history and renewal dates.
- **~~ITSM:** read incident exports to recalculate SLAs.
- **~~finance:** read invoices for credits received.
- **~~email:** draft credit claims and notices only; nothing sent without approval.

## Output format

1. **Summary:** exposure, breaches, notice deadlines, decision required.
2. **Scope and evidence:** documents with versions and dates, period.
3. **Findings** (obligations, SLAs and credits, scorecard, risk) or the **vendor review** template (`vendor-review.md` §7).
4. **Actions** with owner and date; **items for legal review.**

Variants: `working-method.md` §3.

## Reference files

- `references/contract-extraction-schema.md`: obligations, clause matrix, ITAM triggers.
- `references/sla-formulas.md`: before any SLA, credit or trend calculation.
- `references/scorecard-template.md`: scorecards, QBRs, tiering, vendor risk.
- `references/vendor-review.md`: intake, TCO breakdown, comparison, negotiation points.
- `references/renewal-checklist.md`: renewal timeline, negotiation, decision memo, exit.
- `references/working-method.md`: preflight, method per type, output variants.
- `references/quality-checklist.md`: the 26-mark release checklist.
- `scripts/sla_calc.py`: attainment, breach, tiered credits with caps; `--help` for columns.
