#!/usr/bin/env python3
"""SLA attainment, breach and service-credit calculator.

Computes availability or ticket-attainment percentages from the inputs you supply, compares
them with the contract target, and applies a service-credit tier table with an optional cap.
It does NOT know any contract: every formula choice, exclusion, rounding rule, tier and cap
must come from the governing SLA clause and be recorded in the input files.

Measurement CSV (--input), one row per SLA per period. Header row required.
  sla_id                      e.g. SLA-MSA01-03 (required)
  period                      label such as 2026-09 (required)
  metric                      availability | attainment (required)
  target_pct                  contract target in percent, e.g. 99.9 (required)
  target_rule                 ge (actual must be >= target, default) | gt (must be > target)
  round_dp                    decimal places the contract rounds to BEFORE comparing
                              (blank = compare unrounded; rounding is half-up)
 availability rows:
  pattern                     A = exclusions removed from both sides (agreed service time)
                              B = calendar time, no exclusions
  service_minutes             A: scheduled service minutes; B: calendar minutes (required)
  excluded_maintenance_minutes  A only; blank = 0 (noted as an assumption)
  outage_minutes              total outage minutes in the period (required)
  excluded_outage_minutes     A only; outage minutes excluded by contract; blank = 0 (noted)
 attainment rows (response, resolution, delivery, accuracy ...):
  total_count                 items in the period for this SLA (required)
  excluded_count              items excluded by contract; blank = 0 (noted)
  met_count                   in-scope items that met the target (required)
 credit columns (optional):
  tier_set                    name of a tier set in --tiers; blank = no credit calculated
  fee                         the base the credit applies to (e.g. monthly service fee)
  cap_pct                     cap as percent of fee; blank = none stated
  cap_amount                  cap as an amount; if both caps given, the lower applies

Tier CSV (--tiers): tier_set, below_pct, boundary, credit_pct, credit_amount
  A tier applies when the compared attainment is < below_pct (boundary lt, default) or
  <= below_pct (boundary le). When several tiers apply, the most severe one (lowest
  below_pct) is used. Give credit_pct (percent of fee) or credit_amount (fixed), not both.

Formulas
  availability A = (service - excl_maint - (outage - excl_outage)) / (service - excl_maint)
  availability B = (calendar - outage) / calendar
  attainment     = met / (total - excluded)
  credit         = min(tier credit, caps)

Exit codes: 0 ok; 2 usage error or no valid rows; 3 some rows rejected (listed on stderr).

Examples
  python3 sla_calc.py --input sla.csv
  python3 sla_calc.py --input sla.csv --tiers tiers.csv --format json
  python3 sla_calc.py --input sla.csv --tiers tiers.csv --output results.csv
"""

import argparse
import csv
import json
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, getcontext

getcontext().prec = 34
HUNDRED = Decimal(100)


class RowError(ValueError):
    pass


def dec(row, key, required=False, default=None, notes=None, label=None):
    raw = (row.get(key) or "").strip()
    if raw == "":
        if required:
            raise RowError("missing %s" % key)
        if default is not None and notes is not None:
            notes.append("ASSUMPTION: %s blank, used %s" % (label or key, default))
        return default
    try:
        v = Decimal(raw.replace(",", "").rstrip("%"))
    except InvalidOperation:
        raise RowError("%s is not a number: %r" % (key, raw))
    if v < 0:
        raise RowError("%s is negative" % key)
    return v


def load_tiers(path):
    tiers, errors = {}, []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for n, row in enumerate(csv.DictReader(fh), start=2):
            try:
                name = (row.get("tier_set") or "").strip()
                if not name:
                    raise RowError("missing tier_set")
                below = dec(row, "below_pct", required=True)
                boundary = (row.get("boundary") or "lt").strip().lower()
                if boundary not in ("lt", "le"):
                    raise RowError("boundary must be lt or le")
                pct = dec(row, "credit_pct")
                amt = dec(row, "credit_amount")
                if (pct is None) == (amt is None):
                    raise RowError("give exactly one of credit_pct or credit_amount")
                tiers.setdefault(name, []).append(
                    {"below_pct": below, "boundary": boundary, "credit_pct": pct,
                     "credit_amount": amt})
            except RowError as e:
                errors.append("tiers line %d: %s" % (n, e))
    return tiers, errors


def q(v, dp):
    return v.quantize(Decimal(1).scaleb(-dp), rounding=ROUND_HALF_UP)


def calc_row(row, tiers):
    notes = []
    sla_id = (row.get("sla_id") or "").strip()
    period = (row.get("period") or "").strip()
    if not sla_id or not period:
        raise RowError("sla_id and period are required")
    metric = (row.get("metric") or "").strip().lower()
    target = dec(row, "target_pct", required=True)
    if target > HUNDRED:
        raise RowError("target_pct above 100")
    rule = (row.get("target_rule") or "ge").strip().lower()
    if rule not in ("ge", "gt"):
        raise RowError("target_rule must be ge or gt")
    pattern = ""
    if metric == "availability":
        pattern = (row.get("pattern") or "").strip().upper()
        if pattern not in ("A", "B"):
            raise RowError("availability needs pattern A or B (take it from the SLA clause)")
        service = dec(row, "service_minutes", required=True)
        outage = dec(row, "outage_minutes", required=True)
        if pattern == "A":
            ex_m = dec(row, "excluded_maintenance_minutes", default=Decimal(0), notes=notes)
            ex_o = dec(row, "excluded_outage_minutes", default=Decimal(0), notes=notes)
            if ex_o > outage:
                raise RowError("excluded_outage_minutes exceeds outage_minutes")
            denominator = service - ex_m
            numerator = denominator - (outage - ex_o)
        else:
            for k in ("excluded_maintenance_minutes", "excluded_outage_minutes"):
                if (row.get(k) or "").strip() not in ("", "0"):
                    notes.append("%s ignored under pattern B" % k)
            denominator = service
            numerator = service - outage
        if denominator <= 0:
            raise RowError("agreed service time is zero or negative")
        if numerator < 0:
            raise RowError("counted downtime exceeds agreed service time")
    elif metric == "attainment":
        total = dec(row, "total_count", required=True)
        excluded = dec(row, "excluded_count", default=Decimal(0), notes=notes)
        met = dec(row, "met_count", required=True)
        denominator = total - excluded
        numerator = met
        if denominator <= 0:
            raise RowError("no in-scope items (total_count - excluded_count <= 0)")
        if met > denominator:
            raise RowError("met_count exceeds in-scope items")
    else:
        raise RowError("metric must be availability or attainment")

    actual = numerator / denominator * HUNDRED
    rdp = (row.get("round_dp") or "").strip()
    if rdp:
        try:
            compared = q(actual, int(rdp))
        except ValueError:
            raise RowError("round_dp must be an integer")
    else:
        compared = actual
    breach = compared < target if rule == "ge" else compared <= target

    out = {
        "sla_id": sla_id, "period": period, "metric": metric, "pattern": pattern,
        "numerator": numerator, "denominator": denominator,
        "actual_pct": actual, "compared_pct": compared, "target_pct": target,
        "target_rule": rule, "breach": "Yes" if breach else "No",
        "shortfall_pts": max(Decimal(0), target - compared),
        "tier_set": "", "tier_below_pct": "", "credit_pct": "",
        "credit_before_cap": "", "cap_applied": "", "credit": "", "notes": notes,
    }

    tier_set = (row.get("tier_set") or "").strip()
    if tier_set:
        if tier_set not in tiers:
            raise RowError("tier_set %r not found in --tiers" % tier_set)
        out["tier_set"] = tier_set
        fee = dec(row, "fee")
        applicable = [t for t in tiers[tier_set]
                      if (compared < t["below_pct"] if t["boundary"] == "lt"
                          else compared <= t["below_pct"])]
        if not applicable:
            out["credit_before_cap"] = Decimal(0)
            out["credit"] = Decimal(0)
            out["credit_pct"] = Decimal(0)
        else:
            t = min(applicable, key=lambda x: x["below_pct"])
            out["tier_below_pct"] = t["below_pct"]
            if t["credit_pct"] is not None:
                if fee is None:
                    raise RowError("tier gives credit_pct but fee is blank")
                out["credit_pct"] = t["credit_pct"]
                credit = fee * t["credit_pct"] / HUNDRED
            else:
                credit = t["credit_amount"]
            out["credit_before_cap"] = credit
            caps = []
            cap_pct = dec(row, "cap_pct")
            if cap_pct is not None:
                if fee is None:
                    raise RowError("cap_pct given but fee is blank")
                caps.append(fee * cap_pct / HUNDRED)
            cap_amt = dec(row, "cap_amount")
            if cap_amt is not None:
                caps.append(cap_amt)
            if not caps:
                notes.append("no cap supplied; confirm the contract states none")
            if caps and min(caps) < credit:
                out["cap_applied"] = "Yes"
                credit = min(caps)
            elif caps:
                out["cap_applied"] = "No"
            out["credit"] = credit
        if not breach and out["credit"] not in ("", Decimal(0)):
            notes.append("credit tier applies although target met; check tier table")
    return out


def fmt(v, dp):
    if isinstance(v, Decimal):
        return str(q(v, dp))
    if isinstance(v, list):
        return "; ".join(v)
    return v


def main(argv=None):
    p = argparse.ArgumentParser(
        description=__doc__.split("\n\n")[0],
        epilog="\n\n".join(__doc__.split("\n\n")[1:]),
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", required=True, help="measurement CSV (columns listed below)")
    p.add_argument("--tiers", help="service-credit tier CSV (columns listed below)")
    p.add_argument("--format", choices=["csv", "json"], default="csv")
    p.add_argument("--decimals", type=int, default=4,
                   help="decimal places shown for percentages and amounts (default 4)")
    p.add_argument("--output", help="write to this file instead of stdout")
    a = p.parse_args(argv)

    tiers, errors = {}, []
    if a.tiers:
        try:
            tiers, errors = load_tiers(a.tiers)
        except OSError as e:
            print("error: %s" % e, file=sys.stderr)
            return 2
    try:
        with open(a.input, newline="", encoding="utf-8-sig") as fh:
            rows = list(csv.DictReader(fh))
    except OSError as e:
        print("error: %s" % e, file=sys.stderr)
        return 2

    results = []
    for n, row in enumerate(rows, start=2):
        try:
            results.append(calc_row(row, tiers))
        except RowError as e:
            errors.append("input line %d: %s" % (n, e))
    for e in errors:
        print("rejected: %s" % e, file=sys.stderr)
    if not results:
        print("error: no valid rows", file=sys.stderr)
        return 2

    cols = ["sla_id", "period", "metric", "pattern", "numerator", "denominator",
            "actual_pct", "compared_pct", "target_pct", "target_rule", "breach",
            "shortfall_pts", "tier_set", "tier_below_pct", "credit_pct",
            "credit_before_cap", "cap_applied", "credit", "notes"]
    out = open(a.output, "w", newline="", encoding="utf-8") if a.output else sys.stdout
    try:
        if a.format == "json":
            json.dump({"results": [{c: fmt(r[c], a.decimals) for c in cols} for r in results],
                       "rejected": errors}, out, indent=2)
            out.write("\n")
        else:
            w = csv.writer(out)
            w.writerow(cols)
            for r in results:
                w.writerow([fmt(r[c], a.decimals) for c in cols])
    finally:
        if a.output:
            out.close()
    return 3 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
