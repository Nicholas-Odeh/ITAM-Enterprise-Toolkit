# Renewal, negotiation and exit checklist

Use this file for renewal timelines, renewal assessments, negotiation preparation, the decision memo, and exit or transition planning. Lead times and thresholds shown are `RECOMMENDATION` placeholders; take real values from the contract and the organization's procurement policy (see `templates/company-profile.md` if present).

## 1. Renewal timeline (back-calculate from the contract)

| Item | Source | Value |
|---|---|---|
| Current term end date | clause ___ | |
| Renewal mechanism (automatic / by order / by amendment) | clause ___ | |
| Renewal term length | clause ___ | |
| Non-renewal or termination notice period | clause ___ | |
| How notice must be given (written, address, method, recipient) | clause ___ | |
| Price change on renewal (cap, CPI, list) | clause ___ | |
| **Notice deadline** = term end − notice period | calculated | |
| **Decision date** = notice deadline − approval lead time | policy / `RECOMMENDATION` | |
| **Kick-off date** = decision date − assessment and sourcing lead time | policy / `RECOMMENDATION` | |

**ILLUSTRATIVE:** term ends 2027-06-30; 90-day notice → notice deadline 2027-04-01; with a 120-day internal lead time, kick-off by 2026-12-02. Check how the contract counts days (calendar vs. business days, whether notice must be *received* by the date) and flag the reading for legal review if it is unclear.

Track every renewal in a calendar with alerts at kick-off, decision and notice dates, owned by a named person. A missed notice date on an auto-renewing contract is a common, avoidable loss.

## 2. Renewal evidence pack

Gather before the assessment:
- Signed contract chain and amendments; current obligation register.
- 12–24 months of SLA results, breaches, credits due, claimed and received.
- Scorecard history and open corrective actions.
- Spend history vs. commitment; invoices and disputes; rate-card compliance.
- Utilization (licenses assigned vs. used, devices under support vs. in service, reharvest candidates) from the asset and license records.
- Risk profile, assessment results and open findings; subcontractor changes.
- Product roadmap and end-of-sale / end-of-support notices for products in the estate.
- Market information: quotes, benchmarking rights in the contract, alternatives. **Never present a benchmark without a source.**

CAMP notes that vendor management supplies acquisition with asset performance data and contract information to use in negotiations (CAMP M:37).

## 3. Renewal assessment

| Question | Evidence | Finding | Label |
|---|---|---|---|
| **Performance:** did the vendor meet contractual and operational expectations? | | | |
| **Risk:** are residual risks acceptable? | | | |
| **Commercial:** is pricing competitive and aligned with value delivered? | | | |
| **Dependency:** how hard would replacement be (switching cost, data, skills, integrations)? | | | |
| **Remediation:** are significant issues unresolved? | | | |
| **Strategic fit:** does the vendor still match future needs and architecture? | | | |
| **Market position:** is benchmarking or market testing justified? | | | |
| **Transition:** what are switching costs and operational risks? | | | |
| **Value realization:** did the contract deliver the outcome it was bought for, not just meet SLAs? | | | |

**Options:** renew · renew with conditions · renegotiate · extend temporarily · competitively source · remediate before renewal · reduce scope · dual-source · transition · terminate.

For the recommended option, state the evidence, benefits, risks, trade-offs, assumptions and **the conditions that would change the recommendation**. Don't pick an option only because it looks cheapest. If competitively sourcing, hand the RFx work to itam-acquisition-procurement.

## 4. Negotiation preparation

### Topics to consider
Pricing and rate protection · volume tiers · SLA definitions and targets · service credits and caps · chronic-failure rights · audit rights · security and assurance obligations · reporting · transition assistance · termination for convenience · renewal mechanics and notice periods · benchmarking · subcontractor controls · data portability and return · continuity commitments · liability and remedies (legal review) · governance · innovation commitments.

ITAM-specific asks to consider: serial/ASN and asset-tag data on delivery · warranty start on delivery or install rather than ship date · drive-retention on RMA · take-back and certified disposal · license reassignment and transfer rights · entitlement records delivered to ITAM · price holds for refresh volumes · end-of-life notice periods.

### Position table

| Issue | Current term (clause) | Our objective | Priority (MUST / SHOULD / TRADEABLE / OPTIONAL) | Evidence / leverage | Acceptable fallback | Walk-away | Concession we could offer | Risk of conceding |
|---|---|---|---|---|---|---|---|---|

Also record: the **BATNA** (best alternative if no agreement is reached), walk-away conditions, reciprocal value, sequence of issues, and who has authority to agree what. Do not invent the counterparty's motives; record only what has been observed or stated.

## 5. Decision memo (template)

1. **Decision required** and deadline (notice date).
2. **Recommendation** in one or two sentences.
3. **Evidence summary:** performance, risk, commercials, dependency (with labels).
4. **Options considered** with trade-offs.
5. **Financial impact:** formula and assumptions shown.
6. **Risks and conditions** that would change the recommendation.
7. **Approval required** (role and authority level from policy).

## 6. Exit and transition checklist

A termination clause is not an exit strategy. For critical vendors, check the organization actually has a credible plan:

- Executive sponsor approval and a named project manager; a transfer team formed.
- Termination strategy and transition plan, including the replacement vendor selection and onboarding.
- Notice served per the contract's method, and confirmation received.
- Inventories and consignment stock depleted or returned; open orders cancelled or completed.
- Invoices cleared and credits settled; final reconciliation.
- Users, stakeholders, business units and other strategic vendors informed.
- Data returned in the agreed format, then destruction certified; credentials and access revoked.
- Licenses transitioned, terminated or reharvested; asset records updated with the new vendor, contract and support dates.
- Documentation and knowledge transferred; vendor transactions terminated.

CAMP describes these steps for removing a product or vendor, including assigning a project manager, forming a transfer team, gaining sponsor approval, depleting inventories, clearing invoices, informing users and stakeholders, and assimilating the new vendor (CAMP S:151). It also lists vendor policies an organization may define, including vendor transition, new vendor, risk management, performance rating, negotiation and RFP policies (CAMP S:148).
