# Release checklist: the 26 marks of a strong vendor deliverable

Moved from `SKILL.md` (v2 restructure). Check every mark that applies. A ★ item that fails blocks release: fix it, or label the affected section `INCOMPLETE` or `UNVERIFIED`. The ★ items are repeated in `SKILL.md` Step 4.

## Contract and evidence
1. ★ Material obligations in the supplied documents are covered, and any documents not reviewed are named.
2. ★ Every obligation, threshold, right and remedy traces to a document and clause.
3. Each requirement traces to the evidence that shows its status.
4. ★ Contractual requirements are separated from internal expectations and best practice.
5. ★ Evidence is separated from inference; nothing `UNKNOWN` is reported as compliant.
6. ★ No obligation, SLA threshold, contractual right, benchmark value or compliance requirement is fabricated.

## Calculation
7. ★ SLA definitions match the contract, including exclusions, windows and clock rules.
8. ★ Every metric formula is shown and can be reproduced from the inputs.
9. Performance data is normalized (periods, units, time zones, definitions) and its quality is stated.
10. ★ Critical calculations and conclusions were recomputed in code (`python3 scripts/sla_calc.py`, or `itam-financial-management` scripts for TCO) before release.
11. Business impact is quantified where data permits, with formula and assumptions.

## Analysis
12. Findings are prioritized by risk, not by size alone.
13. Leading and lagging indicators are identified.
14. Chronic and emerging degradation is detected, not just single-period misses.
15. Root causes are tested against alternative explanations, not just symptoms reported.
16. Operational and commercial dependencies are analyzed.
17. Third- and fourth-party dependencies are considered; unknown ones are flagged.
18. Control effectiveness is assessed for design and operation, with evidence.
19. Escalation thresholds are evidence-based and fit the organization's governance.
20. ★ Any named standard or framework is used as a lens only; no clause or requirement is asserted without a verified source (`VERIFY current edition`).

## Decision and presentation
21. Remediation actions are specific and actionable.
22. Every action has an owner and a target date.
23. Renewal and negotiation support states options, trade-offs and what would change the recommendation.
24. The executive summary leads with exposure, deadlines and the decision required.
25. Evidence lineage is audit-ready (document versions, effective dates, sources, calculations).
26. ★ Assumptions and limitations are visible, and legal-interpretation questions are flagged for legal review.

Same-model review improves completeness but is not independent verification; don't describe it as such.
