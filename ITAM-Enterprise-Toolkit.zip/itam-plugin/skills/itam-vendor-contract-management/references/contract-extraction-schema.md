# Contract extraction schema

Use this file to turn contract documents into an obligation register, a requirement-to-evidence matrix and a list of ITAM lifecycle triggers. Field names are a recommended schema (`PRACTICE`); rename them to match the user's contract repository if one exists.

**Contents:** 1. Build the document map first · 2. Obligation register fields · 3. Requirement types · 4. Status values · 5. Clause checklist · 6. ITAM lifecycle trigger list · 7. Requirement-to-evidence matrix · 8. Ambiguity, conflict and legal-review handling · 9. Example row (illustrative only; not from any real contract)

## 1. Build the document map first

Before extracting anything, list every document in the agreement chain:

| Doc ID | Type | Title / reference | Parties | Effective date | Expiry / term | Amends or attaches to | Precedence language (quote clause no.) | Signed copy? |
|---|---|---|---|---|---|---|---|---|

Typical types: MSA, master supply agreement, SOW, work order, order form, PO, SLA or service schedule, pricing schedule, software license agreement, support or maintenance agreement, warranty terms, DPA, security or privacy addendum, amendment, change order, exhibits, and policies incorporated by reference.

Rules:
- Determine precedence **only** from the documents' own order-of-precedence clauses. If none exists, record `Precedence: not stated` and show conflicts side by side.
- An unsigned draft, a vendor web page or a quote is not a governing document unless a signed document incorporates it. Note whether incorporated URLs can change unilaterally (a common risk for online terms; flag for legal review).
- Record which documents you were **not** given. Coverage claims apply only to the documents reviewed.

## 2. Obligation register fields

| Field | What to capture |
|---|---|
| Obligation ID | `OBL-<contract>-<nnn>`; stable across revisions |
| Source document | Doc ID from the map |
| Clause / section | Exact clause number and heading; page if no numbering |
| Requirement | One obligation per row, in plain words; quote only short key phrases |
| Obligor | Party that must act (vendor, customer, both) |
| Beneficiary | Party that receives the benefit |
| Requirement type | See section 3 |
| Trigger | Event that activates it (signature, order, incident, renewal notice, termination) |
| Frequency | One-time, recurring (with period), or event-driven |
| Due date / window | Deadline or response window, with the time zone and business-day rules if stated |
| Metric / threshold | Measurable condition, exactly as defined |
| Evidence required | What would prove fulfilment (report, certificate, ticket, invoice line) |
| Dependency | Related obligations or customer dependencies |
| Exception / exclusion | Carve-outs stated in the text |
| Remedy | Credit, fee, termination right or other remedy, if stated; else `None stated` |
| Current status | See section 4 |
| Risk | Impact if not met (operational, financial, compliance, security) |
| Owner | Accountable person or role on the customer side |
| Confidence | High / Moderate / Low / Unverified, with the reason |
| Label | `FACT` if read from the signed text; `INFERENCE` if derived; `ASSUMPTION` otherwise |

## 3. Requirement types

Classify each row. The distinction is mandatory wherever mixing categories could change a decision.

`CONTRACTUAL` · `SLA` · `REGULATORY` · `POLICY` · `CONTROL` · `OPERATIONAL` · `COMMERCIAL` · `SECURITY` · `PRIVACY` · `FINANCIAL` · `BUSINESS CONTINUITY` · `REPORTING` · `GOVERNANCE` · `INDUSTRY BEST PRACTICE` · `INTERNAL TARGET` · `RECOMMENDED IMPROVEMENT`

Law ≠ contract ≠ policy ≠ standard ≠ best practice, unless a document explicitly links them (for example, a contract clause that requires compliance with a named standard).

## 4. Status values

`COMPLIANT` · `PARTIALLY COMPLIANT` · `NON-COMPLIANT` · `NOT APPLICABLE` · `NOT TESTED` · `INSUFFICIENT EVIDENCE` · `DISPUTED` · `UNKNOWN`

`UNKNOWN` and `INSUFFICIENT EVIDENCE` are never rolled up as compliant. A KPI miss is `NON-COMPLIANT` only when the KPI is a contractual commitment.

## 5. Clause checklist

Walk the documents for each category and record either a row or `Not found in documents reviewed`.

**General:** affirmative obligations · prohibited actions · deliverables and milestones · acceptance criteria · reporting · approvals · notifications (and notice addresses and methods) · documentation · audit rights (who, how often, notice, cost) · subcontracting and flow-down · insurance · warranties · indemnities · limitation of liability · IP and data ownership · confidentiality.

**Commercial:** pricing and rate cards · price holds and escalators (CPI or fixed %) · volume tiers and commitments · minimum purchase or spend · true-up mechanics · invoicing requirements (detail level, timing, disputes) · payment terms · credits and remedies · benchmarking rights · most-favoured terms if any.

**Term and exit:** initial term · renewal mechanism (auto-renew or not) · notice periods and how notice must be given · termination for convenience and for cause · cure periods · chronic-failure termination rights · transition assistance · data return and destruction (format, timing, certificate) · license survival or wind-down.

**Security, privacy, continuity:** security addendum controls · breach notification windows · data location and transfer · BC/DR commitments (RTO/RPO if stated) · assurance reports the vendor must provide (for example SOC reports or certifications, as named in the contract) · right to assess.

**ITAM-specific clauses** (from AssetForge §24 and CAMP DOC/ACQ guidance, M:36, M:43–44):
- Warranty start rule (ship date, delivery date or install date), length, and coverage level.
- RMA and advance-replacement terms; who keeps the failed part or drive (matters for data security).
- Vendor pre-delivery services: asset tagging, imaging or enrollment, serial/ASN data feed to ITAM (CAMP lists the accuracy of vendor-applied tags as an indicator, M:22).
- License grant, metric, permitted use, transfer and reassignment rights, and who receives proof of entitlement.
- Leased vs. owned status, lease return condition, and end-of-lease data handling.
- Disposal, take-back and recycling obligations and their certificates.
- Maintenance and support end dates (end of sale, end of support) if stated in the contract.

## 6. ITAM lifecycle trigger list

Convert dated or event-driven obligations into actions against the asset register and calendar.

| Trigger ID | Obligation ID | Event / date | Lead time | Action | Asset records affected (class, model, contract link) | Owner | System where it is tracked |
|---|---|---|---|---|---|---|---|

Typical triggers: renewal notice deadline · warranty or support expiry for a model or batch · lease return window · true-up or license report due date · audit-right notice received · price-hold expiry · data-return deadline after termination · certificate of destruction due after disposal.

Link the contract ID to each affected asset record (an ownership and contractual fact, so it belongs on the asset record, not the CI).

## 7. Requirement-to-evidence matrix

| ID | Requirement | Source (doc, clause) | Evidence | Status | Gap | Impact | Recommended action | Owner |
|---|---|---|---|---|---|---|---|---|

Chain for audit mode: **source → requirement → evidence → analysis → finding → risk → recommendation → action → verification**.

## 8. Ambiguity, conflict and legal-review handling

- **Ambiguous clause:** record the plausible readings, the evidence that would settle it (definitions section, negotiation history, vendor's written confirmation), and the decision impact of each reading.
- **Conflict between documents:** quote both clause references, the effective dates and any precedence language; mark `Unresolved` if precedence is not stated.
- **Send to legal review** when the decision turns on enforceability, liability caps, indemnity scope, jurisdiction, statutory interpretation or dispute strategy. Do not state a legal conclusion.

## 9. Example row (illustrative only; not from any real contract)

| Field | Value |
|---|---|
| Obligation ID | OBL-ACME-HW-014 |
| Source / clause | DOC-03 Hardware Supply Agreement, cl. 7.2 "Asset Data" |
| Requirement | Vendor provides serial number, model and asset tag for each unit shipped, before delivery |
| Obligor / beneficiary | Vendor / Customer ITAM |
| Type | CONTRACTUAL; REPORTING |
| Trigger / frequency | Each shipment / event-driven |
| Due window | Before delivery (as stated) |
| Evidence required | ASN file per shipment; match to receiving records |
| Remedy | None stated |
| Status | PARTIALLY COMPLIANT: 3 of 12 shipments in the period had no ASN (`FACT`, from the receiving log supplied) |
| Owner | Receiving lead |
| Label / confidence | FACT / High |
