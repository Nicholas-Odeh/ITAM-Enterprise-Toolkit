# Vendor scorecard, segmentation, risk and governance

Templates for vendor performance scorecards, QBR/MBR packs, vendor tiering, third- and fourth-party risk, escalation and governance cadence. Weights, tiers, scales and thresholds shown here are `RECOMMENDATION` placeholders until the organization approves its own. Never present them as policy.

**Contents:** 1. Scorecard dimensions and example measures · 2. Scoring method · 3. Scorecard table (template) · 4. QBR / MBR pack (default agenda) · 5. Vendor segmentation and criticality · 6. Third-party risk profile · 7. Dependency and fourth-party mapping · 8. Escalation levels (adapt to the organization's governance) · 9. Governance cadence (template) · 10. Remediation plan

## 1. Scorecard dimensions and example measures

| Dimension | Example measures (pick those with reliable data) |
|---|---|
| Service performance | SLA attainment, availability, incident response/resolution, repeat incidents, backlog age |
| Delivery | on-time delivery, order accuracy (items, quantity, serials, tags, ASN data), milestone attainment, DOA / defect rate, RMA turnaround |
| Commercial | invoice accuracy, pricing compliance vs. rate card, credit realization, budget variance, cost predictability |
| Risk and compliance | open audit or security findings, overdue remediation, policy exceptions, required assurance reports delivered on time |
| Governance | reporting timeliness, attendance at reviews, action completion rate, escalation response |
| Relationship | responsiveness, proactive improvement, innovation, internal stakeholder satisfaction |

CAMP suggests surveying internal customers about vendors on criteria such as invoice accuracy, order fulfilment time, delivery accuracy, product reliability, technical support responsiveness, sales support, staff product knowledge, return policy, payment terms, negotiation flexibility and price against similar products (CAMP S:149). Use scorecard results, interviews, surveys and actual-vs-promised contract execution as inputs, and keep the scorecard objective, on a standard scale and on a schedule (CAMP S:150). CAMP's Vendor Management indicators include timestamped scorecard reviews, how often a meeting is needed to resolve an issue, how often vendor contact data is updated, the vendor's ability to meet contract obligations, and infractions by vendor staff (CAMP M:24; S:137).

## 2. Scoring method

1. **Define each measure:** formula, source, period, target, and whether the target is contractual or internal.
2. **Normalize to a common 0–100 (or 1–5) scale.** Choose and disclose one:
   - Target-based: `score = min(actual / target, 1) × 100` (for higher-is-better measures).
   - Banded: map ranges to points (for example meets contract = 100, within 1 point = 70, otherwise 30). The bands are a `RECOMMENDATION` unless approved.
   - Survey: mean rating ÷ max rating × 100, with response count shown.
3. **Weights** come from, in order: the user; approved policy; or a labeled proposal. Weights sum to 100%.
4. **Calculate:** `Vendor score = Σ(normalized dimension score × weight)`.
5. **Sensitivity:** recompute with reasonable alternative weights. If the ranking or the rating band changes, say so.
6. **Data-quality qualifier:** if any input failed the data-quality gate, show the score with a qualifier (for example "provisional: delivery data covers 2 of 3 months") or don't score that dimension.

## 3. Scorecard table (template)

| Dimension | Measure | Target (source) | Actual (source, period) | Normalized | Weight | Weighted | Trend | Label |
|---|---|---|---|---|---|---|---|---|
| Service | P1 resolution within SLA | [clause ref] | [ ] | [ ] | [ ]% | [ ] | ↑ ↓ → | FACT / INFERENCE |
| … | | | | | | | | |
| **Total** | | | | | 100% | **[ ]** | | |

Below the table: data limitations, the weight source, and the top three actions.

## 4. QBR / MBR pack (default agenda)

1. Scorecard and trend since last review.
2. SLA results, breaches, credits due, claimed and received.
3. Open issues and escalations, with age.
4. Corrective-action and service-improvement plan status.
5. Risk and compliance items (assurance reports, findings, subcontractor changes).
6. Commercial: spend vs. commitment, invoice disputes, upcoming price changes.
7. Roadmap, demand forecast, end-of-life notices for products in the estate.
8. Decisions and actions (owner, date).

## 5. Vendor segmentation and criticality

Tier on supported criteria, **never spend alone** (a low-spend vendor with privileged access can be critical): business criticality · data sensitivity · service dependency · recovery requirements · substitution difficulty · concentration · integration depth · privileged or physical access · regulatory impact · customer impact · geographic dependency · financial exposure.

Suggested tiers: CRITICAL / HIGH / MODERATE / LOW (`RECOMMENDATION`). CAMP gives an illustrative split for prioritizing vendor attention: strategic, organization-wide vendors (about the top 5%), preferred vendors that add post-sale value (the next 20%), and basic relationships (the remaining 75%) (CAMP S:147). Treat those percentages as a starting point, not a rule.

## 6. Third-party risk profile

Risk categories to consider (pick those relevant): strategic · operational · cybersecurity · privacy · regulatory · financial · concentration · geopolitical · reputational · legal/contractual · business continuity · technology/cloud · data · IP · fraud · supply chain · environmental · subcontractor / fourth party · exit and transition.

| Risk ID | Category | Description | Inherent risk (method) | Controls (design / operating evidence) | Control status | Residual risk | Treatment | Owner | Review date |
|---|---|---|---|---|---|---|---|---|---|

- Use the organization's risk method. If there is none, propose one, label it `RECOMMENDATION`, and keep qualitative judgement where numbers would be false precision. Don't invent a residual-risk formula.
- Control status: EFFECTIVE · PARTIALLY EFFECTIVE · INEFFECTIVE · NOT TESTED · INSUFFICIENT EVIDENCE · NOT APPLICABLE. Operating effectiveness needs evidence of operation (reports, test results), not only a policy document.
- For detailed control testing or audit work, hand off to the risk and audit skill (itam-risk-controls-audit) if it is installed.

## 7. Dependency and fourth-party mapping

Map: **business service → internal owner → supplier → supplier's service → subcontractor → technology / hosting location / data**.

| Fourth party | Function | Criticality | Data or system access | Location | Flow-down obligations (clause) | Notification-of-change right? | Continuity dependency | Known / disclosed? |
|---|---|---|---|---|---|---|---|---|

Mark undisclosed dependencies `UNKNOWN`; don't assume visibility. Look for correlated failure: several vendors sharing one cloud region, carrier, logistics provider or ITAD processor.

Concentration checks: single-source products, one distributor for most hardware, one ITAD vendor for all regions, one hosting provider behind several SaaS tools, scarce specialist skills.

## 8. Escalation levels (adapt to the organization's governance)

| Level | Typical trigger | Forum |
|---|---|---|
| 1 Operational | routine miss, quick fix | service owner + vendor delivery lead |
| 2 Vendor management | persistent or material performance issue | vendor manager + vendor account manager |
| 3 Executive / commercial | significant breach, chronic failure, financial impact, negotiation issue | executive sponsor, procurement |
| 4 Risk / compliance / legal | possible regulatory, legal, security or privacy issue | risk, compliance, legal, security |
| 5 Crisis / continuity | material disruption or enterprise exposure | crisis / BC leadership |

Escalation thresholds must come from evidence and the organization's model; propose and label them if none exist.

## 9. Governance cadence (template)

| Tier | Operational (weekly or as needed) | Tactical (monthly) | Strategic (quarterly) |
|---|---|---|---|
| CRITICAL | incident and issue review | scorecard, SLA, actions | QBR: performance, finance, roadmap, risk, renewal strategy |
| HIGH | as needed | scorecard | semi-annual review |
| MODERATE / LOW | by exception | quarterly scorecard | annual review |

For each forum record participants, decision rights, required reports, action ownership and evidence retention. CAMP describes the vendor manager role as owning communications, performance analysis, scorecard maintenance and vendor crisis management, with a defined communication protocol and a maintained vendor database (CAMP M:48, M:115; S:136, S:146).

## 10. Remediation plan

| Action ID | Finding | Root cause | Action | Priority | Owner | Due date | Dependency | Success measure | Evidence of completion |
|---|---|---|---|---|---|---|---|---|---|

Each action answers: which finding it fixes, what risk it reduces, who owns it, when it's due, how completion is evidenced, how effectiveness is verified, and what happens if it slips. Priority = risk + business impact + urgency + contractual or regulatory significance + dependency, not size alone.
