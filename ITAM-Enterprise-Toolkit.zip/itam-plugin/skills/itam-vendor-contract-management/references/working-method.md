# Working method by request type

Detail moved from `SKILL.md` (v2 restructure). Labels as in the `itam-operating-standard` skill.

## Contents
1. Preflight in full
2. Method per request type
3. Output structure

## 1. Preflight in full

Confirm, or state the assumption for:

- **Objective and decision:** what must be decided, by whom, and by when (renewal date, QBR, audit).
- **Governing documents:** every signed document in the chain (MSA, SOW, order forms, SLA schedule, amendments, DPA and security addenda), with effective dates. Ask for missing amendments before declaring an obligation.
- **Measurement period and data source** for any SLA or KPI, and whether the data is the vendor's report or the organization's own monitoring.
- **Organizational methods:** approved scorecard weights, risk rating method, escalation levels. If none exist, propose them and label them `RECOMMENDATION`.
- **Consequence of error:** LOW / MODERATE / HIGH / CRITICAL. Scale verification to it; a credit claim or termination notice is HIGH or above.

Rate evidence `SUFFICIENT`, `PARTIALLY SUFFICIENT` or `INSUFFICIENT`, and narrow conclusions to match. For a vendor review, use the intake list in `vendor-review.md` §1. If `templates/company-profile.md` exists at the plugin root, read it for vendor tiers, scoring weights, risk method and approval authorities.

## 2. Method per request type

Follow **normalize → inventory evidence → extract → validate → analyze → generate alternatives → recommend → verify → present**.

- **Obligations.** Build the obligation register: one row per obligation, with clause citation, obligor, trigger, due window, metric, evidence required, remedy, status and owner. Classify each by requirement type (contractual, SLA, regulatory, policy, security, commercial, internal target and so on). Flag conflicts between documents, and ambiguous clauses with their plausible readings. Don't assume an SOW overrides an MSA, or that an amendment or PO changes terms, unless a precedence clause says so (`contract-extraction-schema.md`).
- **ITAM triggers.** Mark clauses that must drive an asset-lifecycle or governance action: warranty and support end dates, RMA terms, vendor tagging and serial data on delivery, license and use rights, audit rights, data return and destruction, disposal and take-back, renewal and notice dates, price holds. Record each as a dated action against the contract ID and the affected asset records. Linking contracts and documents to assets is itself a measured ITAM outcome (CAMP M:23; S:100–101).
- **SLAs and credits.** For each SLA, validate numerator, denominator, service hours, exclusions, maintenance windows, time zone, clock start and stop, rounding and data completeness before calculating (`sla-formulas.md` §2). Then compute attainment, breach and credit (with caps and claim deadlines) with `python3 scripts/sla_calc.py`, and compare credits claimed with credits received. Never assume `availability = uptime / calendar time`.
- **Scorecards.** Score agreed dimensions (service, delivery, commercial, risk and compliance, governance, relationship) with disclosed weights: `Vendor score = Σ(normalized dimension score × approved weight)`. Qualify any score built on poor data. CAMP stresses objectivity, a standardized rating scale, scheduled delivery, and comparing actual with promised contract execution (CAMP S:149–150).
- **Risk and dependencies.** Tier vendors on criticality, not spend alone. Describe inherent risk, control design and operating effectiveness, and residual risk, using the organization's method or a labeled proposal. Map business service → supplier → subcontractor → technology, location and data, and mark undisclosed fourth parties as `UNKNOWN`.
- **Vendor review and TCO.** Gather the cost lines (`vendor-review.md` §2) and hand the math to `itam-financial-management`'s `scripts/tco.py`. Produce strengths, concerns, risk table and negotiation points (`vendor-review.md`).
- **Renewal.** Back-calculate the notice deadline and internal decision dates. Assess performance, risk, commercials, dependency, open remediation, strategic fit and market position. Set out options (renew, renew with conditions, renegotiate, extend, re-source, reduce scope, transition, terminate) with their evidence, trade-offs and what would change the call. For negotiation, classify asks as MUST / SHOULD / TRADEABLE / OPTIONAL and state the BATNA and walk-away conditions without inventing the vendor's motives (`renewal-checklist.md`).
- **Actions.** Every material finding becomes a specific action with owner, due date, success measure and evidence of completion. No "improve vendor management."

## 3. Output structure

Pick only the outputs the decision needs. Default structure for a vendor review:

1. **Executive summary:** what happened → why it matters → business impact → decision required → action. Lead with financial exposure, breaches, deadlines (especially notice dates) and unresolved risk.
2. **Scope and evidence:** documents (with versions and effective dates), datasets, period, limitations.
3. **Findings:** contractual position, SLA performance and credits, scorecard, risk and dependencies, commercial findings, as each applies.
4. **Recommendations and remediation plan:** action, owner, date, success measure, evidence.
5. **Assumptions, open questions and items for legal review.**
6. **Traceability appendix** (when an audit trail is needed): source → requirement → evidence → finding → action.

**Executive variant:** one page with the summary, a three-to-five-line scorecard or risk view, the decision and the deadline. Tables in an appendix.
**Practitioner variant:** the full obligation register, SLA calculation worksheet or scorecard table, with formulas and labels inline.
