# SLA calculation, service credits and performance trends

The formulas below are **patterns**, not defaults. Use the formula written in the governing SLA. If the SLA does not define a term, say so, show the readings it could have, and calculate each one rather than picking one silently. All worked examples use made-up numbers and are labeled `ILLUSTRATIVE`.

Compute in code, not mentally. For availability and ticket-attainment SLAs with tiered credits, use `python3 scripts/sla_calc.py` (from this skill's folder; `--help` lists the input columns). It reproduces the Pattern A, Pattern B, attainment and credit examples below exactly, applies contract rounding before comparison when you give `round_dp`, applies the most severe matching credit tier and the lower of any caps, and rejects inconsistent rows (exit code 3). For any formula the script doesn't cover, write a short calculation with the inputs shown.

**Contents:** 1. SLA register fields · 2. Calculation controls (validate all before calculating) · 3. Formula patterns · 4. Service credits · 5. Chronic and emerging degradation · 6. Data quality gate (before any score or credit) · 7. Root cause of a missed SLA · 8. Calculation worksheet (paste into the deliverable)

## 1. SLA register fields

| Field | Description |
|---|---|
| SLA ID | `SLA-<contract>-<nn>` |
| Service | Covered service or product |
| Metric | Availability, response, resolution, delivery, etc. |
| Definition | Contract definition, with clause reference |
| Target | Required level exactly as written (for example "≥ 99.9% per calendar month") |
| Measurement window | Monthly, quarterly, per incident |
| Service hours | 24×7, business hours, with time zone |
| Source system | Vendor report, own monitoring, ITSM tool |
| Calculation | The contract formula, written out |
| Exclusions | Maintenance windows, customer-caused, force majeure, third-party, as stated |
| Actual | Calculated value, with inputs |
| Variance | Actual − target (in the metric's units) |
| Breach | Yes / No / Unknown |
| Breach count and duration | Per window |
| Credit / remedy | Formula and amount, or `None stated` |
| Trend | Improving / stable / declining, with the method used |
| Business impact | What the miss cost or affected, if evidenced |
| Root cause | Known / probable / unknown |
| Action | Recommended treatment |

## 2. Calculation controls (validate all before calculating)

1. Numerator. 2. Denominator. 3. Measurement period boundaries. 4. Service hours. 5. Exclusions and how they are evidenced. 6. Maintenance windows (scheduled, notified on time?). 7. Time zones and daylight-saving changes. 8. Rounding and decimal places (does 99.85% round to 99.9%?). 9. Incident priority and categorization rules (and re-categorization). 10. Clock start and stop rules (pending-customer, on-hold states). 11. Repeated or linked incidents (counted once or each time?). 12. Customer-caused exclusions. 13. Force-majeure exclusions, if applicable. 14. Data completeness: is the incident or monitoring population complete for the period?

If any control can't be validated, the result is `UNVERIFIED` and the reason is stated next to it.

## 3. Formula patterns

### Availability

Pattern A (agreed service time, exclusions removed from both sides):
```
agreed_service_time = scheduled_service_minutes − excluded_maintenance_minutes
counted_downtime    = total_outage_minutes − excluded_outage_minutes
availability        = (agreed_service_time − counted_downtime) / agreed_service_time
```

Pattern B (calendar time, no exclusions):
```
availability = (calendar_minutes − total_outage_minutes) / calendar_minutes
```

Other variants exist (per-service component, per-site, transaction-success rate, minimum-of-components). Use the one the SLA defines.

**ILLUSTRATIVE example.** 30-day month = 43,200 minutes. Scheduled maintenance excluded by contract: 240 minutes. Outages: 95 minutes, of which 20 are documented as customer-caused and excluded by contract. Target: 99.9%.

- Pattern A: agreed service time = 43,200 − 240 = 42,960. Counted downtime = 95 − 20 = 75. Availability = 42,885 / 42,960 = **99.825%** → breach.
- Pattern B: (43,200 − 95) / 43,200 = **99.780%** → breach.

Both breach here, but the result differs by 0.045 points; near a threshold, the choice of formula decides the outcome. Always show which pattern the contract requires.

### Response and resolution attainment

```
in_scope   = tickets_in_period_for_priority − contractually_excluded_tickets
attainment = tickets_meeting_target / in_scope
```
**ILLUSTRATIVE:** 200 P2 incidents, 4 excluded (customer-caused, per contract), 186 acknowledged within target → 186 / 196 = **94.9%**.

State whether the clock pauses in "awaiting customer" states, and whether the target is per ticket (each one must meet it) or aggregate (a percentage must meet it).

### Mean and percentile measures

```
MTTA = Σ(acknowledge_time − open_time) / n
MTTR = Σ(restore_time − open_time) / n      (confirm whether "R" is restore, resolve or repair)
P90  = 90th percentile of the per-ticket durations (state the percentile method)
```
Means hide tail failures; report a percentile alongside the mean when the contract allows.

### Delivery and quality

```
on_time_delivery = orders_delivered_by_committed_date / orders_due_in_period
order_accuracy   = orders_with_correct_items_qty_and_data / orders_delivered
first_time_fix   = incidents_fixed_on_first_visit / incidents_requiring_visit
```
For ITAM, "correct data" can include the serial, asset tag and ASN record (see the contract-extraction ITAM clause list).

## 4. Service credits

Capture from the contract: triggering threshold · credit formula (tiered %, fixed amount, per-hour) · base it applies to (monthly fee for the service, the affected component, total invoice) · maximum or cap (per month, per year) · earn-back provisions · claim procedure and **claim deadline** · whether credits are the sole and exclusive remedy · relation to chronic-failure termination rights · whether credits apply automatically or only on claim.

**ILLUSTRATIVE tier table** (made up; replace with the contract's):

| Monthly availability | Credit (% of monthly service fee) |
|---|---|
| ≥ 99.9% | 0% |
| < 99.9% and ≥ 99.5% | 5% |
| < 99.5% | 10% |
| Cap | 15% of monthly fee |

With the Pattern A result (99.825%) and an illustrative monthly fee of $20,000: credit = 5% × $20,000 = **$1,000**, inside the cap.

### Credit leakage analysis

| Period | SLA ID | Breach? | Credit due (calc) | Claim deadline | Claimed? | Received? (invoice ref) | Unclaimed or unpaid | Label |
|---|---|---|---|---|---|---|---|---|

Never assert an entitlement the contract does not grant. If the claim deadline has passed, report the amount as lost, not recoverable.

## 5. Chronic and emerging degradation

- **Chronic breach:** use the contract's definition (for example "N misses in M periods") if one exists; it may trigger extra rights. If the contract has none, a repeat-miss rule is an internal KRI and must be labeled `RECOMMENDATION`, not a contractual trigger.
- **Trend methods** (use only what the data supports, and say why the method helps): month-over-month and rolling 3-month average · slope of a simple linear fit · median and percentile shifts · coefficient of variation for volatility · control limits (mean ± 3σ on a stable baseline) for outliers and regime changes · Pareto of breach causes.
- **Leading indicators** (KRIs): rising backlog or ticket age, growing unresolved Sev-1/2 count, declining change success, rising remediation age, overdue security findings, account-team turnover. **Lagging indicators** (KPIs): SLA attainment %, credits paid.

## 6. Data quality gate (before any score or credit)

Check completeness, validity, consistency, uniqueness, timeliness and lineage. Look for missing records, duplicates, overlapping periods, inconsistent units, changed definitions, timestamp or time-zone errors, re-categorized tickets and incomplete SLA populations. If the vendor's report and your own monitoring disagree, show both and the size of the gap; don't average them.

## 7. Root cause of a missed SLA

Test competing explanations before converging: vendor staffing or capacity · customer dependency · wrong categorization · integration or monitoring error · data quality · unclear contract definitions · third-party dependency · change failure · process failure. Name the evidence that would tell them apart.

## 8. Calculation worksheet (paste into the deliverable)

```
SLA ID / clause:
Period (start–end, time zone):
Formula (from clause ___):
Inputs (value, source, label):
Exclusions applied (each with evidence):
Result (unrounded → rounded per clause ___):
Target / breach:
Credit formula (clause ___), base, cap:
Credit amount:
Claim deadline / status:
Verification: recomputed by ___ on ___; differences: ___
```

**Script input for the worked examples above** (`ILLUSTRATIVE`):

```
sla_id,period,metric,target_pct,pattern,service_minutes,excluded_maintenance_minutes,outage_minutes,excluded_outage_minutes,total_count,excluded_count,met_count,tier_set,fee,cap_pct
SLA-X-01,2026-09,availability,99.9,A,43200,240,95,20,,,,AVAIL,20000,15
SLA-X-02,2026-09,attainment,95,,,,,,200,4,186,,,
```
with a tier file `tier_set,below_pct,credit_pct` → `AVAIL,99.9,5` and `AVAIL,99.5,10`. Result: 99.8254% (breach, credit 1,000.00) and 94.8980% (breach).
