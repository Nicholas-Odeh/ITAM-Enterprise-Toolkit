# Vendor review: intake, TCO breakdown, risk and negotiation points

A one-vendor review for a new proposal, a renewal decision or a side-by-side comparison, ending in Proceed / Negotiate / Pass. Structure adapted from the Operations plugin's vendor-review skill and brought under this plugin's evidence rules. All numbers in examples are `ILLUSTRATIVE`.

## Contents
1. What I need from you (intake)
2. TCO breakdown
3. Risk assessment
4. Performance
5. Comparison matrix
6. Negotiation points
7. Output template

## 1. What I need from you (intake)

Ask for these in one message; proceed with what arrives and label the gaps.

| Item | Why it matters |
|---|---|
| **Vendor name and product or service** | Scopes the review |
| **Context:** new vendor, renewal, or comparison (and with whom) | Sets the decision and the options |
| **Decision date and, for renewals, the notice date** | Renewal timeline (`renewal-checklist.md` §1) |
| **Documents:** proposal or quote; for renewals the signed contract chain, SLA schedule and amendments | Obligations and terms come only from these |
| **Pricing and volumes:** unit prices, quantities, term, price-change clauses | TCO inputs |
| **Current spend** (renewals): invoices or spend report for 12–24 months | Price change and utilization |
| **Performance data:** SLA reports, own monitoring, ticket exports | SLA attainment and credits |
| **Risk inputs:** security assessment, financial checks, subcontractor list | Risk section |
| **Who decides, and approval limits** | Recommendation audience |

## 2. TCO breakdown

Gather cost lines here; do the math with `itam-financial-management` (its `scripts/tco.py`, if that skill is installed), never by eye.

| Category | Examples | Typical source |
|---|---|---|
| License or subscription | per seat, per device, flat, usage-based | Quote, order form |
| Implementation and migration | professional services, data migration, integration build | SOW, quote |
| Training and onboarding | vendor courses, internal time | Quote, internal estimate (`ASSUMPTION`) |
| Support and maintenance | included or add-on tiers | Quote, contract |
| Hardware or infrastructure | devices, hosting, connectors | Quote |
| Internal labor | administration, vendor management | Internal estimate (`ASSUMPTION`) |
| ITAM-specific | asset tagging and ASN data services, take-back and certified disposal, lease-end charges | Quote, contract |
| Exit costs | data extraction and migration, termination fees, transition assistance, dual running | Contract, estimate |

Rules:
- Every line has an amount, period, source and label. A missing line is "not quoted", not zero.
- Compare options over the same term and units; include exit costs for the incumbent and switching costs for the challenger.
- Build the cash-flow CSV the TCO script expects (`option, period, kind, category, amount`) and run it with Finance's discount rate, plus `--rate 0` for the undiscounted Year-1 and multi-year totals:

```
option,period,kind,category,amount
Renew-3y,0,cost,implementation,0
Renew-3y,1,cost,subscription,120000
Renew-3y,2,cost,subscription,126000
Renew-3y,3,cost,subscription,132300
Switch-3y,0,cost,implementation,45000
Switch-3y,0,cost,exit_incumbent,15000
Switch-3y,1,cost,subscription,100000
Switch-3y,2,cost,subscription,100000
Switch-3y,3,cost,subscription,100000
```
(`ILLUSTRATIVE` numbers.) Example command, from the `itam-financial-management` folder: `python3 scripts/tco.py --input flows.csv --rate 0` then again with the Finance rate.

If `itam-financial-management` isn't installed, show the arithmetic in a short script or spreadsheet with the inputs visible, and say so.

## 3. Risk assessment

Use `scorecard-template.md` §5–7 for tiering, the third-party risk profile and fourth-party mapping. For the review, cover at least:

| Risk area | Evidence to look for |
|---|---|
| Financial stability | Credit or financial reports supplied by the user; never inferred from reputation |
| Security and compliance posture | Assurance reports, assessment results, open findings, data location |
| Concentration | Share of a critical service on this vendor; single-vendor dependency |
| Lock-in and exit terms | Termination rights, data return and format, transition assistance clauses |
| Continuity and disaster recovery | Contracted commitments and tested evidence |

Likelihood and impact use the organization's method; otherwise label ratings `PROVISIONAL`.

## 4. Performance

SLA attainment and credits (`sla-formulas.md`, `python3 scripts/sla_calc.py`), support response, availability, delivery accuracy, feature delivery against roadmap commitments, stakeholder satisfaction (scorecard dimensions in `scorecard-template.md` §1). Only measured values; label survey and anecdote as such.

## 5. Comparison matrix

Side by side, one column per vendor: pricing basis and TCO result · functional fit · integrations (including ITAM data: serials, ASN, entitlements) · security · support model · contract terms (term, renewal, exit) · references. If the comparison is a new selection with scored criteria, use `itam-acquisition-procurement` and its `scripts/rfx_score.py` rather than scoring here.

## 6. Negotiation points

Each point is tied to evidence and classified MUST / SHOULD / TRADEABLE / OPTIONAL (`renewal-checklist.md` §4):

| Point | Evidence (source) | Ask | Class | Fallback |
|---|---|---|---|---|
| Unclaimed service credits | credit-leakage table, months and amounts | Pay or credit outstanding amounts within claim deadlines | MUST | Apply to renewal price |
| Utilization below commitment | license or device utilization report | Reduce committed volume | SHOULD | Flexible true-down |
| Delivery data quality | order-accuracy measure | Serial, ASN and tag data on delivery as a contract term | SHOULD | Credit per non-compliant order |

Leverage is evidence the organization holds (performance, utilization, market quotes with a named source), never assumed vendor motives. State the BATNA and walk-away conditions. Legal terms go to Legal.

## 7. Output template

```markdown
## Vendor review: [Vendor] — [New / Renewal / Comparison]
Date: [date] · Decision by: [role, date] · Notice date: [date or n/a]

### Summary
[Proceed / Negotiate / Pass] — two or three sentences with the main reason and the deadline.

### Cost (TCO)
| Component | Year 1 | Term total | PV (rate [x], Finance) | Source | Label |
|---|---|---|---|---|---|
| ... | | | | | |
Script run: [command]; hand-check: [one figure].

### Risk
| Risk | Likelihood | Impact | Evidence | Mitigation |
|---|---|---|---|---|

### Performance
[SLA attainment, credits due / claimed / received, scorecard trend]

### Strengths / Concerns
- ...

### Negotiation points
| Point | Evidence | Ask | Class | Fallback |
|---|---|---|---|---|

### Assumptions, gaps and items for legal review
- ...
```
