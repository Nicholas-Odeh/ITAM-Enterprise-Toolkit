# Quality gates Q1–Q12 and release checks

Run these before releasing any material ITAM deliverable, or when acting as reviewer (the `itam-reviewer` agent uses this file). Gates are pass/fail. A ★ gate that fails blocks release unless it is repaired or the limitation is stated plainly where the affected conclusion appears. Strength in one gate never offsets failure in another.

## Contents
1. Gate table
2. Gate detail: pass tests and typical failures
3. Acceptance checklist
4. Failure-witness scenarios
5. Verifier hierarchy and verification record
6. Deliverable-specific add-ons
7. Verdict format

## 1. Gate table

| Gate | Checks | Critical? |
|---|---|---|
| Q1 Correctness | Facts, terminology, calculations and technical conclusions are right | ★ always |
| Q2 Completeness | Every mandatory requirement of the request is addressed | ★ always |
| Q3 Evidence faithfulness | Evidence actually supports each material claim; labels are right; nothing fabricated | ★ always |
| Q4 Standards accuracy | Frameworks used within their scope; no invented clauses; editions flagged | ★ when a framework or standard is cited |
| Q5 ITAM/ITSM alignment | The recommendation improves a business or service outcome, not ITAM in isolation | — |
| Q6 Lifecycle coherence | States and transitions form a complete, controllable lifecycle | ★ when designing or changing a lifecycle |
| Q7 Data integrity | Reconciliation and data-quality conclusions are reproducible; totals reconcile | ★ when data is analyzed |
| Q8 Control design | Each control has owner, execution, evidence, exception path and test | ★ when controls are proposed or assessed |
| Q9 Actionability | A named role can execute each major recommendation | — |
| Q10 Traceability | Material conclusions can be reconstructed from evidence | ★ when audit-sensitive |
| Q11 Auditability | An auditor could tell what happened, what was concluded and why | ★ when audit-sensitive |
| Q12 Maintainability | The output can be updated without redesigning it | — |

## 2. Gate detail

### Q1 — Correctness
- **Pass test:** recompute at least one key figure by a different route (row count vs. sum of groups; formula vs. spreadsheet). Check ITAM terms are used correctly (asset vs. CI, entitlement vs. deployment, state vs. substate, depreciation vs. amortization).
- **Typical failures:** percentages on the wrong denominator; double-counted assets after a join; "license" used for both entitlement and install; fiscal and calendar years mixed.
- **Fix:** correct and note the correction if the figure was already shared.

### Q2 — Completeness
- **Pass test:** list the explicit asks and constraints from the request; tick each against the output.
- **Typical failures:** answered the general question but skipped the named population; ignored a stated format or deadline; left out the exceptions the user asked about.
- **Fix:** add the missing part or state why it can't be done (F1).

### Q3 — Evidence faithfulness
- **Pass test:** for each material claim, point to the supplied source or the label. Search the draft for numbers, dates, money, thresholds, SLAs, retention periods, system and field names, role names; each must be supplied, labeled, or `[TBD]`.
- **Typical failures:** plausible SLA or retention period written as fact; a state name the organization doesn't use; "industry standard is 3 years" with no source; a citation that doesn't support the sentence.
- **Fix:** remove, label, or replace with a placeholder and a "how to get it" note.

### Q4 — Standards accuracy
- **Pass test:** every framework mention names the framework, uses it for its purpose (see `source-hierarchy.md` §8), avoids clause numbers unless supplied or confident, and says "aligned with" rather than "compliant" without a formal basis.
- **Typical failures:** "ISO 19770 requires quarterly reconciliation"; treating ITIL guidance as an audit requirement; claiming IAITAM certification of a process.
- **Fix:** soften to the actual source strength; mark `VERIFY current edition`.

### Q5 — ITAM/ITSM alignment
- **Pass test:** each major recommendation names the operational change and the business or service outcome (cost, risk, compliance, productivity, service reliability, audit performance).
- **Typical failures:** "implement a CMDB health dashboard" with no decision it supports.

### Q6 — Lifecycle coherence
- **Pass test:** every state has entry and exit criteria; every transition has a trigger, an owner and evidence; there is a path for lost/stolen, returns, repair and disposal; no dead-end states; asset state and CI status are mapped, not merged.
- **Typical failures:** no route from "In transit" back to stock on refusal; "Retired" with no evidence requirement; disposed assets still counted as active.

### Q7 — Data integrity
- **Pass test:** record counts before and after each transformation; key uniqueness checked; unmatched records reported; join cardinality known; KPI numerator, denominator, filters and grain explicit; exclusions listed.
- **Typical failures:** join on a non-unique serial inflating counts; blank treated as zero; one source's definition of "active" applied to another.
- **Fix:** rerun with corrected keys; if impossible, F5.

### Q8 — Control design
- **Pass test:** each control states objective, risk addressed, type (preventive/detective/corrective), execution (manual/automated/hybrid), frequency, owner, performer, evidence and its location, exception criteria, escalation, and how it would be tested.
- **Typical failures:** "IT will review assets regularly"; a control with no evidence artifact; owner given as "the organization".
- **Fix:** complete the fields or label the control as a design gap.

### Q9 — Actionability
- **Pass test:** each recommendation has an owner role, a first concrete step, dependencies, and a success measure.
- **Typical failures:** "improve data quality"; actions assigned to ITAM that belong to HR, Finance or Security.

### Q10 — Traceability
- **Pass test:** pick two material findings and walk `FINDING → EVIDENCE → RISK → CONTROL → REMEDIATION → VALIDATION`; nothing missing.
- **Typical failures:** findings in the summary that appear nowhere in the detail; remediation with no validation criterion.

### Q11 — Auditability
- **Pass test:** the output records the evidence reviewed, extraction dates, rules and thresholds used, assumptions, and unresolved limitations. A third party could repeat the analysis and get materially the same answer.
- **Typical failures:** "based on the data provided" with no list; reconciliation rules applied but not stated.

### Q12 — Maintainability
- **Pass test:** organization-specific values (thresholds, state names, owners, systems) sit in clearly marked places (tables, placeholders, the company profile), not scattered through prose; documents carry version and owner.
- **Typical failures:** an SOP that hard-codes a person's name; a model with constants buried in formulas.

## 3. Acceptance checklist

Tick all that apply to the deliverable. Any unticked ★ item blocks release.

- [ ] ★ The objective is explicit and answered.
- [ ] ★ Scope (population, asset classes, systems, period, exclusions) is explicit.
- [ ] ★ Evidence sources are identified.
- [ ] ★ No unsupported claim is presented as fact; no fabricated value, clause, system or name.
- [ ] ★ Calculations are shown or reproducible, and a key figure was recomputed.
- [ ] Frameworks are used correctly and editions flagged where unverified.
- [ ] Current state and target state are kept separate.
- [ ] Asset records and CIs are distinguished.
- [ ] Lifecycle states and transitions are coherent (if in scope).
- [ ] Reconciliation methodology is reproducible (if in scope).
- [ ] Material exceptions are identified with owners.
- [ ] Material risks have a control or a remediation.
- [ ] Controls specify evidence.
- [ ] Ownership is explicit (roles, not "the organization").
- [ ] Recommendations are actionable and linked to business outcomes.
- [ ] Metrics are measurable (formula, source, owner, frequency).
- [ ] Assumptions and limitations are disclosed, stated by consequence.
- [ ] Audit-sensitive conclusions can be reconstructed.
- [ ] The result fits its audience.
- [ ] No unnecessary framework terminology, matrices or bureaucracy were added.

## 4. Failure-witness scenarios

Normal records passing does not prove the output works. Check how the analysis, design or procedure behaves for each scenario relevant to the deliverable:

| Scenario | What a good output does |
|---|---|
| Missing records / missing asset tag | Counts them, reports them as an exception, doesn't silently drop them |
| Duplicate records | Detects by key, doesn't double-count, routes for merge |
| Stale discovery | Applies a freshness rule; doesn't treat last-seen 200 days ago as present |
| Conflicting systems | Shows the conflict and the precedence rule (or an exception) |
| Missing owner | Flags as ownership exception; doesn't default to the requester or ITAM |
| Invalid lifecycle status | Flags values outside the state model |
| Unauthorized or unmanaged device | Has a path to identify, assign or remove |
| Terminated employee with active asset | Surfaces it as a recovery item with an owner and age |
| Disposed asset still active in a system | Flags as a disposal or data-sync exception |
| Asset with no CI / CI with no asset | Distinguished and explained, not merged |
| Incomplete purchase or disposal evidence | Marked evidence gap; not treated as compliant |
| Missing entitlement / contradictory contract terms | Position marked `NOT VERIFIED`; conflict shown |
| Unavailable source system or tool failure | Conclusion marked unverified (F8); no claimed success |
| Malformed input | Rejected rows counted and reported |
| Control without evidence; exception without owner; remediation without validation | Each is itself reported as a finding |

## 5. Verifier hierarchy and verification record

Use the strongest available check whose failure mode differs from the one that produced the answer:

1. Deterministic calculation, executed script, schema or assertion check.
2. Independent recalculation by a different route.
3. Reconciliation to an authoritative total or source document.
4. Direct comparison of each claim against the cited source text.
5. Inspection of actual system state after any tool action.
6. Specialist or human review for high-consequence decisions.
7. Same-model rereading, as a supplementary editing pass only.

For any completion or status claim (reconciled, wiped, disposed, compliant, updated, recovered, done), apply the gate function and evidence table in `completion-evidence.md`.

For high-value checks, record:

| Item checked | Method | Expected | Observed | Status (pass / fail / uncertain) | Repair | Residual uncertainty |
|---|---|---|---|---|---|---|

## 6. Deliverable-specific add-ons

| Deliverable | Extra checks |
|---|---|
| Analysis or assessment | Findings table has evidence and priority per row; root causes separated from symptoms |
| Data or reconciliation | Population counts before/after; match rules and thresholds stated; exception counts sum to unmatched total |
| Recommendation or roadmap | Each item: risk or finding addressed, owner, cost or effort basis, dependency, success measure, what would invalidate it |
| SOP or policy | Use the QA scorecard in `itam-sop-documentation` (46/50, no criterion below 4) |
| Financial figure | Inputs sourced, formula shown, period and currency stated, recomputed |
| Script or bulk change | Dry run, scope cap, rollback, sub-production test, approval step |
| Executive summary | Every number in it appears, with source, in the body |

## 7. Verdict format

- **Verdict:** RELEASE / RELEASE WITH FIXES / BLOCK.
- **Critical findings:** numbered; location, what is wrong, fix.
- **Other findings:** same format, ordered by impact.
- **Gates passed:** one line.

Sources: AssetForge §36–40; RiskForge §3.6, 31; DataForge §20, 27; prompt-engineering research findings §3.7–3.10, §9–10.
