# Failure and recovery modes F1–F8

When the preflight gate or a quality gate fails, pick the matching mode below. Each mode says how to recognize it, what to write, what you can still deliver, and what you must not do. The aim is a bounded, honest partial result rather than either a refusal or a confident fabrication.

## Contents
1. Quick selector
2. F1–F8 in detail
3. Sub-cases from data analysis
4. Partial-result template
5. Revalidation triggers after change

## 1. Quick selector

| Symptom | Mode |
|---|---|
| Can't answer because key information or evidence is absent | F1 |
| Two sources give different values or obligations | F2 |
| The organization has no policy or standard for the point | F3 |
| A framework clause, edition or requirement can't be confirmed | F4 |
| Data exists but is too incomplete, inconsistent or duplicated to trust | F5 |
| A control is described but there is no evidence it ran | F6 |
| Asked to declare compliance, but the basis is missing | F7 |
| A system, file, query, script or connector failed or is unavailable | F8 |

## 2. F1–F8 in detail

### F1 — Insufficient evidence
- **Detect:** preflight result `INSUFFICIENT`; a required count, contract term, owner or threshold is missing and can't be retrieved.
- **Write:** `INSUFFICIENT EVIDENCE` plus an exact list of what is missing, who would hold it, and how to obtain it (report name, export filter, document, person).
- **Still deliver:** the method, the structure of the answer with placeholders, and any part supported by evidence (NARROW).
- **Must not:** estimate the missing value and present it as a finding.
- **Example:** "Leaver recovery rate can't be calculated: no HR termination list was supplied. Needed: terminations 2026-07-01 to 2026-09-30 with employee ID and date (HR system). With it, rate = recovered devices ÷ devices assigned to leavers."

### F2 — Conflicting sources
- **Detect:** different values for the same attribute or obligation from two sources.
- **Write:** the conflict record from `source-hierarchy.md` §6; the rule applied, or "unresolved — exception raised".
- **Still deliver:** the analysis under each value if the conclusion differs (ENUMERATE), or under the governing value if a rule exists.
- **Must not:** pick the more plausible or more convenient value silently, or average them.

### F3 — Missing organizational standard
- **Detect:** the user asks what they "must" do, and there is no policy, standard or contract term covering it.
- **Write:** "No organizational requirement was supplied for X. The following is a recommendation based on `PRACTICE` / `STANDARD (named framework)`." Offer it as a draft policy statement for approval.
- **Still deliver:** a labeled recommendation with the options and trade-offs.
- **Must not:** phrase a recommendation as an existing requirement ("policy requires…").

### F4 — Standard cannot be verified
- **Detect:** a clause-level or edition-specific claim is needed and the text isn't available.
- **Write:** `STANDARD VERSION / REQUIREMENT NOT VERIFIED`; describe the framework's purpose and the general expectation in your own words; mark `VERIFY current edition`.
- **Still deliver:** the analysis against the user's own policy or contract, plus a list of clauses to check.
- **Must not:** quote clause numbers or requirement wording from memory as fact.

### F5 — Data quality prevents analysis
- **Detect:** key fields missing above a level that changes the answer; duplicate keys; unknown grain; values outside valid ranges; totals that don't reconcile.
- **Write:** quantify the problem ("18% of in-use records lack serial; 212 duplicate serials"), state its consequence for each affected conclusion, and list the remediation needed before reliable analysis.
- **Still deliver:** the analysis on the clean subset, clearly scoped, plus the data-quality findings themselves (often the most useful output).
- **Must not:** impute, drop or "fix" records without documenting the rule and its effect on totals.

### F6 — Control cannot be tested
- **Detect:** a control is documented, but no execution evidence (logs, tickets, sign-offs, reports) was supplied.
- **Write:** `CONTROL DESIGN REVIEW ONLY — OPERATING EFFECTIVENESS NOT VERIFIED`.
- **Still deliver:** the design assessment and the evidence request list (what artifact, period, sample size if known).
- **Must not:** rate the control effective, or reduce residual risk because the control exists on paper.

### F7 — Compliance cannot be established
- **Detect:** asked "are we compliant?" without complete entitlement, contract, deployment or obligation evidence.
- **Write:** what was tested, against what, with what result; then "Compliance cannot be established because …".
- **Still deliver:** the observed position (for example deployment counts vs. known entitlements), labeled with its gaps and the direction of risk.
- **Must not:** convert "no violation observed" into "compliant", or give an audit-defensible position from partial data.

### F8 — Tool or source failure
- **Detect:** a query errors, a file won't parse, a connector times out, a script fails, or a source is unavailable.
- **Write:** what failed, what it affects, and which conclusions are therefore `NOT VERIFIED`.
- **Still deliver:** results from an authorized fallback source if one exists (labeled as such), otherwise the unaffected parts.
- **Must not:** report the step as complete, retry without limit, or fill the gap with expected output.

## 3. Sub-cases from data analysis

These are common causes of F1, F2, F5 and F8 in ITAM data work, with the specific recovery.

| Sub-case | Parent | Recovery |
|---|---|---|
| Ambiguous KPI definition | F1 | Get or state numerator, denominator, filters, grain and exclusions before calculating |
| Unknown data grain | F5 | Inspect key uniqueness and meaning; don't aggregate or join until grain is known |
| Join multiplication | F5 | Stop; check key cardinality; fix the relationship; rerun and reconcile totals |
| Material missingness | F5 | Quantify the pattern; choose and document a treatment; test whether conclusions change |
| Invalid types or ranges | F5 | Find the source rule; correct only when justified; otherwise flag or exclude with a count |
| Critical metric fails reconciliation | F5 | Don't release as verified; trace source, filters, joins and formulas |
| Small or unrepresentative sample | F1 | Report uncertainty; avoid population claims; recommend more data |
| Causal claim without a causal design | F4-like | Reframe as association, or state what evidence would be needed |
| Result hinges on one assumption | F1 | Show the result under the alternative; lower confidence |
| Chart and table disagree | F5 | Reconcile the chart data to the calculation table; repair the narrative |

## 4. Partial-result template

```
Status: PARTIAL — <mode, e.g. F1 Insufficient evidence>
Answered: <what is supported, with labels>
Not answered: <what is missing and why>
Needed to complete: <specific item> from <source/owner>, e.g. <export, filter, document>
Effect of the gap: <which conclusion or number would change, and in which direction>
Next step: <smallest action to close the gap>
```

## 5. Revalidation triggers after change

A conclusion that was valid can become invalid. Revisit affected outputs (procedures, policies, controls, dashboards, data mappings, training, audit evidence) when any of these change:

- lifecycle model or state names
- asset scope or asset classes
- policy, standard or approval authority
- ownership or roles
- authoritative source for an attribute
- reconciliation rule, threshold or match logic
- CMDB class model or asset-CI mapping
- control design or evidence requirement
- system integration or discovery source
- metric definition
- risk threshold or scoring method
- vendor or contract
- regulatory requirement
- framework edition

When a change invalidates earlier assurance, rerun the affected checks before relying on the earlier conclusion, and record what was revalidated.

Sources: AssetForge §39, 41; DataForge §21, 26; RiskForge §7; prompt-engineering research findings §10.
