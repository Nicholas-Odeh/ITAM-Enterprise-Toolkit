# Output modes A–G and the default output contract

Choose the smallest mode that serves the decision. Combine modes only when the request needs it, and never repeat the same content across sections.

## Contents
1. Mode selector
2. Modes A–G
3. Default output contract (substantial deliverables)
4. Standard formats: findings, recommendations, exceptions, metrics
5. Executive translation rules
6. Audit-trail mode
7. Length and section discipline

## 1. Mode selector

| If the user wants… | Audience | Mode |
|---|---|---|
| A decision, a funding ask, a risk summary for leaders | Executives, steering committee | A |
| A diagnosis of a problem in systems, data or process | ITAM / ITSM / engineering practitioners | B |
| A procedure people will follow | Operators, approvers, auditors | C |
| Who decides, who owns, what the rules are | Program owner, governance board, Internal Audit | D |
| Numbers from data: counts, matches, exceptions, KPIs | Analysts, asset managers | E |
| Where the program should go and how to get there | CIO, program owner, sponsors | F |
| Everything, explicitly requested | Mixed | G |

A quick question gets a direct answer, not a mode. Use a mode when the output is a deliverable.

## 2. Modes A–G

### Mode A — Executive advisory
- **Lead with:** business impact, risk, the decision required, investment, measurable outcome.
- **Structure:** situation (2–3 sentences) → principal finding → business implication → decision required and deadline → options with cost, risk and outcome → recommendation → key uncertainties.
- **Length:** one page; supporting detail in an appendix.
- **Leave out:** platform detail, table names, methodology, unless the decision depends on it.

### Mode B — Technical assessment
- **Lead with:** findings and their evidence.
- **Structure:** scope and evidence reviewed → current state → findings table → root causes → remediation (by owner and priority) → validation method → assumptions and limitations.
- **Include:** queries, field names, match rules, exact counts with extraction dates.

### Mode C — Procedure / SOP
- **Structure:** document control → purpose → scope → definitions → roles → preconditions → procedure → decision points → controls → exceptions → evidence → escalation → metrics → references → revision history.
- **Method:** use the `itam-sop-documentation` skill for the full drafting and QA method.

### Mode D — Governance package
- **Structure:** governance model and forums → decision rights → ownership and RACI → policies and standards → controls → exception and escalation process → reporting and review cadence → evidence.
- **Method:** use the `itam-program-governance` skill for RACI, policy and KPA content.

### Mode E — Data / reconciliation analysis
- **Structure:** data scope (sources, extraction dates, populations) → normalization rules → matching method and thresholds → results (matched / unmatched / exceptions by type) → exception population → risk → root cause → remediation → metrics.
- **Include:** counts that reconcile (in = matched + unmatched + excluded), and the rules applied.

### Mode F — ITAM strategy
- **Structure:** executive summary → strategic context → current state and maturity (evidence-based) → target state → strategic objectives → operating model → governance → data and technology architecture → controls → roadmap (waves) → KPIs → benefits → risks.
- **Method:** use the `itam-program-governance` skill.

### Mode G — Full enterprise package
- Only when explicitly requested. Combine the applicable modes under one executive summary. Cross-reference instead of repeating.

## 3. Default output contract (substantial deliverables)

Use these sections in this order, and drop any that add nothing for this request.

1. **Executive summary** — situation, principal finding, business implication, top actions.
2. **Objective and scope** — objective, population, systems, exclusions, timeframe.
3. **Evidence reviewed** — the sources actually used, with dates.
4. **Assumptions and limitations** — material items only, stated by consequence.
5. **Current-state assessment** — what the evidence shows.
6. **Detailed findings** — findings table (section 4).
7. **Standards / framework alignment** — a short crosswalk where it helps.
8. **Lifecycle assessment** — state and process gaps.
9. **Data / inventory / CMDB analysis** — quantitative results.
10. **Governance and ownership** — accountable roles and gaps.
11. **Controls and audit evidence** — required controls and proof.
12. **Exceptions** — actionable exception records.
13. **Root causes** — separated from symptoms.
14. **Recommendations** — each tied to findings.
15. **Remediation roadmap** — priorities and dependencies.
16. **Metrics** — formula, owner, frequency, decision supported.
17. **Target state** — what success looks like.
18. **Traceability** — `FINDING → EVIDENCE → RISK → CONTROL → REMEDIATION → VALIDATION`.

## 4. Standard formats

**Findings**

| ID | Finding | Evidence (label, source) | Impact | Risk | Priority | Owner |
|---|---|---|---|---|---|---|

**Recommendations** — one line each in the form:
`ITAM capability → measurable operational change → business outcome`, plus owner, first step, dependency, success measure.

**Exceptions** — minimum fields: ID, type, asset or population, date identified, source, expected state, observed state, impact, root cause, owner, priority, remediation, target date, age, status, validation method, closure evidence. Exception types: approved policy exception, data-quality exception, process failure, control failure, integration failure, ownership failure, lifecycle exception, compliance exception, audit finding.

**Metrics**

| Metric | Formula (numerator / denominator) | Source system | Owner | Frequency | Target | Decision it supports |
|---|---|---|---|---|---|---|

Targets come from the organization; if none is supplied, write `[TBD: target — metric owner to set]`, not a number.

**Remediation horizons**

| Horizon | Typical content |
|---|---|
| Immediate / stabilize | Contain exposure, preserve evidence, assign owners, fix critical control failures |
| Short term | Reconcile, correct processes, train, report |
| Medium term | Integrate systems, improve data quality, redesign workflows, add metrics |
| Long term | Target operating model, automation, analytics, sustained improvement |

## 5. Executive translation rules

For executive audiences, lead with (1) business impact, (2) risk, (3) the decision, (4) investment, (5) measurable outcome.

Translate technical findings into operational consequences the evidence supports:

| Technical statement | Executive translation |
|---|---|
| "12% of CI records have no linked asset" | "For about one in eight systems we can't show who owns it or what it costs, which slows incident response and weakens cost reporting." |
| "Leaver devices: 61% recovered within SLA" | "Roughly four in ten departing employees' devices are not returned on time, which creates data-exposure and replacement-cost risk." |
| "ELP shows -140 seats for Product X" | "We are using more licenses than we can prove we own for Product X; this is audit exposure until resolved." |

Only translate into effects the evidence supports; don't add a cost figure that wasn't calculated.

For leadership risk communication, cover in order: decision required, objective affected, material risk, evidence, consequence, current controls, residual exposure, recommended treatment, cost, decision deadline, risk of delay, owner.

## 6. Audit-trail mode

Switch on for audit responses, compliance positions, write-offs, disposal evidence, or anything a regulator or auditor may see. Retain, where available:

- request and version of the deliverable
- source identifiers, timestamps and extraction dates
- normalization and matching rules, thresholds
- assumptions and their owners
- calculations (formula and inputs)
- findings, controls and exceptions
- recommendations and validation results
- unresolved limitations

Keep it proportionate: don't add provenance that nobody will need. The aim is that a reviewer can reach materially the same conclusion from the same inputs.

## 7. Length and section discipline

- Don't include empty template sections to look thorough; don't omit a needed section to look concise.
- Put method detail after the answer, not before it.
- One table is better than three paragraphs when comparing items.
- Executive summaries contain no number that isn't in the body with its source.

Sources: AssetForge §32–34, 38; RiskForge §25–26; prompt-engineering research findings §3.11, §3.16.
