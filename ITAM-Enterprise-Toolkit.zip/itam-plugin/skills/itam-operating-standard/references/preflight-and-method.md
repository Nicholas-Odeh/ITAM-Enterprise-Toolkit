# Preflight sufficiency gate and working method

Detail behind Steps 2 and 3 of `itam-operating-standard`. Read it when a request is substantial, audit-sensitive, or missing something that could change the answer.

## Contents
1. The six sufficiency tests
2. Response ladder when something is insufficient
3. Working method (Step 3 in full)
4. Standing rules carried from version 1

## 1. The six sufficiency tests

Before drafting definitive findings, test each kind of sufficiency and record the result as `SUFFICIENT`, `PARTIALLY SUFFICIENT` or `INSUFFICIENT`.

| Test | Question |
|---|---|
| Objective | Is the decision or question specific enough to know what a good answer looks like, and who will use it? |
| Scope | Are the asset classes, population, locations, systems and time period clear? |
| Evidence | Are the records, documents or data needed actually present, current and in scope? |
| Semantics | Are field meanings, state names, KPI definitions, units and identifiers unambiguous? |
| Authority | Is it known which source governs (contract, policy, system of record) for the point in question? |
| Method and tools | Can the requested conclusion be supported by this evidence and these tools (for example an exact calculation or a causal claim)? |

## 2. Response ladder when something is insufficient

Take the least disruptive response that keeps the answer honest:

1. **RETRIEVE.** Get the evidence yourself if an authorized source or tool is available.
2. **CLARIFY.** Ask one short, specific question when the gap would change scope, accountability, a compliance or financial conclusion, or the recommended action. Never ask what the supplied material already answers.
3. **ASSUME AND LABEL.** Adopt a bounded, low-risk assumption, state it once, and label it `ASSUMPTION` wherever it is relied on.
4. **ENUMERATE.** When two or three interpretations are plausible and cheap to cover, answer each.
5. **NARROW.** Complete only the supported part and say exactly what is left out and why.
6. **ABSTAIN.** Refuse to produce a compliance conclusion, control-effectiveness rating, count, cost or risk score that cannot be supported. Say `INSUFFICIENT EVIDENCE` and list what would be needed.

When the ladder ends in NARROW or ABSTAIN, use the matching recovery mode in `failure-recovery.md`.

## 3. Working method (Step 3 in full)

- **Normalize the request** for substantial jobs: objective, deliverable, audience, scope, evidence available, constraints, decision required, consequence of error. For large or audit-sensitive work, give requirement IDs (`OBJ-01`, `REQ-01`, `DATA-01`, `CTRL-01`) so findings can trace back.
- **Label as you write,** not afterwards. Calculated figures show their formula and inputs (`FACT` inputs, calculated result). See `source-hierarchy.md` for label definitions and status markers (`NOT VERIFIED`, `VERIFY current edition`, `[TBD: ...]`).
- **Handle conflicts explicitly.** State the conflict, name each source, and compare authority, timestamp, collection method, scope and owner. Apply a documented reconciliation rule if one exists; otherwise record an exception. Never pick the more plausible value silently.
- **State confidence only when it helps,** as `HIGH`, `MODERATE`, `LOW` or `NOT VERIFIED`, and base it on evidence quality, not on how fluent the answer is.
- **Describe limitations by their consequence.** Not "some data is missing" but "12% of records lack cost center, so the chargeback totals understate the affected departments".
- **Keep the traceability chain** for material findings: `FINDING → EVIDENCE → RISK → CONTROL → REMEDIATION → VALIDATION`.
- **Connect recommendations to outcomes:** ITAM capability → measurable operational change → business outcome. Don't recommend a process just because a framework contains it.
- **Use the smallest method that works.** Don't produce frameworks, matrices or long reports the decision doesn't need.

## 4. Standing rules carried from version 1

Version 2 moved the plugin-wide rules into a five-rule core block that every skill carries. These version 1 rules still apply and live here so nothing is lost:

| Rule | Where it is detailed |
|---|---|
| Label material statements `FACT`, `STANDARD`, `PRACTICE`, `INFERENCE`, `ASSUMPTION`, `RECOMMENDATION` | `source-hierarchy.md` §3 |
| Source hierarchy: law/regulation > signed contract > approved policy > system of record > operational data > published framework > professional practice > inference > assumption. Show conflicts; don't silently pick | `source-hierarchy.md` §1, §6 |
| Critical failures are non-compensatory: one failed ★ check blocks release | `quality-gates.md` §1, §7 |
| Smallest method that works | §3 above |
| Never upgrade a claim's status (unknown is not fact, missing evidence is not a pass, "no violation observed" is not "compliant") | `source-hierarchy.md` §5 |
| Alignment is not certification: say "aligned with" IAITAM, ISO/IEC 19770, ITIL or NIST unless there is a formal basis for "compliant", "conformant" or "certified" | `source-hierarchy.md` §8 |
| Verification brackets generation: check answerability before drafting and faithfulness after. Rereading your own draft is an editing pass, not independent verification | `quality-gates.md` §5; `completion-evidence.md` |

Sources: AssetForge §4.1, 29–31; RiskForge §3.2; DataForge §2; prompt-engineering research findings §3.2–3.3.
