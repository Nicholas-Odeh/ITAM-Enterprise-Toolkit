# Source hierarchy, evidence labels and citation rules

Use this file to decide which source governs a point, how to label what you say, what to do when sources disagree, and how to cite frameworks without inventing them.

## Contents
1. Source authority order
2. Two questions, two halves of the hierarchy
3. Evidence labels
4. Status markers
5. Never-upgrade list
6. Conflicting sources: procedure and record
7. Confidence scale
8. Framework register and verification rule
9. Citation rules

## 1. Source authority order

| Rank | Source | ITAM examples | What it can establish | What it cannot establish |
|---|---|---|---|---|
| 1 | Law and regulation | data-protection law, e-waste rules, export control, financial-reporting law | Mandatory obligations in a jurisdiction | How the organization actually operates; legal advice (route to Legal) |
| 2 | Signed contract | license agreement, order form, lease, ITAD service agreement, MSA/SOW, SLA schedule | Entitlements, license metrics, SLA thresholds, credits, audit rights, notice periods | Anything not in the signed text; a draft or a vendor's summary is not the contract |
| 3 | Approved organizational policy or standard | ITAM policy, hardware standard, refresh policy, retention schedule, capitalization policy | What the organization requires of itself, who has authority | Whether the policy is followed (needs evidence of operation) |
| 4 | System of record | ServiceNow asset table, ERP fixed-asset register, HR system for employment status, contract repository | The official recorded value for the attribute that system owns | Physical truth; attributes owned by another system |
| 5 | Operational data | discovery, MECM/Intune/Jamf, Entra ID sign-ins, physical count, receiving log, invoice | Observed state at a point in time | Ownership, entitlement or financial facts on its own |
| 6 | Published framework | IAITAM best practice, ISO/IEC 19770, ITIL, NIST, CIS | What good practice or a requirement set says, within its scope | Facts about this environment; a requirement for this organization unless adopted by contract or policy |
| 7 | Professional practice | widely accepted ITAM practice not tied to a named source | A reasonable default | That the organization does or must do it |
| 8 | Inference | a conclusion drawn from the evidence above | A reasoned interpretation, stated as such | A fact |
| 9 | Assumption | a premise adopted because information is missing | A bounded working basis | Anything; it must be stated and revisited |

Notes:
- **System of record is per attribute, not per system.** HR owns employment status, finance owns book value, the ITAM repository owns lifecycle state and assignment, discovery owns last-seen. Name the owner of each attribute before declaring a winner. If the organization has an authoritative-source matrix, it overrides this default.
- **A framework adopted by contract or policy inherits that rank** for the adopted parts. A control framework named in an audit scope letter is rank 2 or 3 for that audit.
- **The user's own statement** about their environment counts as supplied evidence (`FACT`, attributed to the user) unless it conflicts with a higher source; then show the conflict.
- **Organizational hierarchy wins.** If the user's governance documents define a different authority order, use theirs and say so.

## 2. Two questions, two halves of the hierarchy

Most confusion comes from mixing two different questions:

| Question | Governing sources | Example |
|---|---|---|
| "What is required?" | Law → contract → policy → (adopted) framework | "Must we keep certificates of destruction?" Look for a retention schedule, the ITAD contract, applicable law. A framework alone gives `STANDARD` or `PRACTICE`, not an obligation. |
| "What is true here?" | System of record → operational data → user statements | "How many laptops are in use?" The asset repository count is the recorded answer; discovery and the physical count test it. A framework says nothing about this. |

Answer each half from its own sources, then compare them to find gaps ("policy requires X; records show Y").

## 3. Evidence labels

Canonical labels used across the plugin. Put the label in backticks after the claim or at the start of a table cell.

| Label | Meaning | Use when | Example |
|---|---|---|---|
| `FACT` | Directly supported by evidence the user supplied or a system you queried | You can point to the record, document or extract | "312 assets are In use with no assigned user (`FACT`, alm_hardware export 2026-10-14)." |
| `STANDARD` | Stated in a named framework, standard or contract | You can name the source and, where confident, the section | "The license grants 500 named users (`STANDARD`, Order Form §2)." |
| `PRACTICE` | General professional practice, not tied to this organization's evidence | Offering a sensible default | "Cycle counts of high-value stock are commonly monthly (`PRACTICE`)." |
| `INFERENCE` | A conclusion reasoned from evidence | The step from evidence to conclusion is yours | "The 40 stale records likely come from the 2025 depot closure (`INFERENCE` from location and last-seen dates)." |
| `ASSUMPTION` | A premise adopted because information is missing | Proceeding past a non-blocking gap | "Assumes a 4-year laptop refresh (`ASSUMPTION`; confirm in refresh policy)." |
| `RECOMMENDATION` | A proposed action | Anything the user should do | "Add a weekly leaver-device report (`RECOMMENDATION`)." |

Equivalents in the source prompts, for translation when reading older material:

| Forge / research term | Canonical label |
|---|---|
| SOURCE-REPORTED, OBSERVED, DATA-REPORTED, source-confirmed requirement | `FACT` (or `STANDARD` when the source is a contract or framework) |
| COMPUTED RESULT, CALCULATED | `FACT` inputs + calculated result; show the formula |
| INFERRED, reasonable but unconfirmed inference | `INFERENCE` |
| ASSUMED | `ASSUMPTION` |
| INDUSTRY BEST PRACTICE, FRAMEWORK GUIDANCE | `PRACTICE` or `STANDARD` (named) |
| ANALYST RECOMMENDATION, RECOMMENDED — not confirmed | `RECOMMENDATION` |
| UNVERIFIED | status marker `NOT VERIFIED` (below) |

Label material statements only. Material means it affects a number, an obligation, a risk rating, an accountability, or the recommended action. Don't label every sentence.

## 4. Status markers

| Marker | Meaning |
|---|---|
| `NOT VERIFIED` | Plausible but not supported enough to rely on |
| `VERIFY current edition` | A framework or standard is cited but its current edition or exact wording was not checked |
| `INSUFFICIENT EVIDENCE` | The requested conclusion cannot be reached; list what is missing |
| `STANDARD VERSION / REQUIREMENT NOT VERIFIED` | A clause-level claim was requested but cannot be confirmed |
| `CONTROL DESIGN REVIEW ONLY — OPERATING EFFECTIVENESS NOT VERIFIED` | Control evaluated on paper only |
| `NOT ASSESSED` | Maturity, risk or control rating withheld for lack of evidence |
| `[TBD: what is missing — owner to confirm]` | Placeholder in a document for an organization-specific value |

## 5. Never-upgrade list

Never convert:

| From | To |
|---|---|
| Unknown | Fact |
| Missing | Zero |
| Assumption | Verified requirement |
| Control exists | Control is effective |
| Policy intent | Operating effectiveness |
| Planned remediation | Current control |
| Missing evidence | Pass |
| No violation observed | Compliant |
| Tool failure or skipped check | Success |
| Low incident count | Low risk |
| Sample result | Population fact |
| Partial period | Full-period comparison |
| Data error | Legitimate outlier, without investigation |
| Correlation | Causation |
| Populated field | Accurate field |
| Discovery | Ownership |
| Framework alignment | Certification |
| A second opinion from the same model | Independent verification |

## 6. Conflicting sources: procedure and record

When two sources disagree about the same fact:

1. State the conflict in one line (which attribute, which values).
2. Name each source and its rank in section 1.
3. Compare authority for **that attribute** (who owns it).
4. Compare timestamps and expected freshness (a discovery scan from yesterday vs. a register updated last quarter).
5. Compare collection method (automated, manual entry, vendor-reported) and scope (same population, same definition?).
6. Check for a documented reconciliation or precedence rule; apply it if it exists and say so.
7. If no defensible rule exists, do not choose. Record an exception and route it to the attribute owner.
8. Carry the conflict into the deliverable where it affects a conclusion.

Conflict record:

| Field | Content |
|---|---|
| Conflict ID | `CF-01` |
| Attribute / claim | e.g. assigned user for asset tag 100234 |
| Source A (rank, date, value) | ServiceNow (4, 2026-10-01, J. Smith) |
| Source B (rank, date, value) | Intune primary user (5, 2026-10-18, A. Lee) |
| Rule applied | Documented rule / none |
| Resolution | Value adopted and why, or "unresolved — exception EX-14" |
| Impact on conclusions | Which finding or number changes |
| Owner | Attribute owner role |

For contract vs. policy, or law vs. policy, conflicts: show both and flag them for Legal or the policy owner. Don't resolve legal questions yourself.

## 7. Confidence scale

Use only when it helps the reader decide.

| Level | Basis |
|---|---|
| `HIGH` | Direct evidence from the governing source, recent, reconciled or recomputed |
| `MODERATE` | Evidence from a lower-rank source, or governing source with known gaps that don't change the direction |
| `LOW` | Indirect evidence, material gaps, or depends on an unconfirmed assumption |
| `NOT VERIFIED` | No adequate support; don't act on it without checking |

Confidence describes the evidence, not the writing. If a conclusion depends heavily on one assumption, say which one and what happens if it is wrong.

## 8. Framework register and verification rule

Use frameworks to support an analysis, not to replace defining the problem. Before attributing anything to a framework:

1. Prefer the official text supplied by the user, or retrieved from the issuer.
2. Confirm the edition when research is available; otherwise mark `VERIFY current edition`.
3. Don't quote clause numbers or requirement wording from memory unless confident.
4. Distinguish mandatory requirement, organizational requirement, framework guidance, professional practice and recommendation.
5. Show conflicts between frameworks or between a framework and policy.

| Framework | Purpose (what to use it for) | How to cite | Status |
|---|---|---|---|
| IAITAM Best Practice Library / CAMP course material | ITAM program structure: the 12 Key Process Areas, roles, policy and communication practice | Paraphrase; cite `(CAMP M:<page>)` or `(CAMP S:<slide>)`. Proprietary: no long quotes | Source in hand (CAMP manual v2.1.3) |
| ISO/IEC 19770 family | ITAM management-system requirements (part 1), software identification tags, entitlement schema, utilization measurement, vocabulary | Name the part and purpose; no clause numbers unless supplied | `VERIFY current edition` |
| ITIL 4 | IT asset management and service configuration management practices; links to change, service desk, supplier management | Name the practice; describe in your own words | `VERIFY current edition` and any successor version |
| ISO/IEC 20000-1 | Service-management-system requirements | Name only, unless text supplied | `VERIFY current edition` |
| ISO 55000 / 55001 | Asset-management systems for physical assets generally | Name and purpose | `VERIFY current edition` |
| NIST SP 1800-5 | Practice guide for IT asset management (reference build, modular documentation, standards mapping) | Name and purpose | `VERIFY current edition` |
| NIST Cybersecurity Framework 2.0 | Asset Management category in the Identify function | Name the function/category; check subcategory IDs before quoting | `VERIFY` subcategory text |
| CIS Critical Security Controls v8.x | Control 1 (enterprise asset inventory) and Control 2 (software asset inventory) | Name the control; check safeguard numbers before quoting | `VERIFY current version` |
| NIST SP 800-88 | Media sanitization methods and verification | Name and purpose; use the disposition skill for detail | `VERIFY current revision` |
| COBIT (ISACA) | IT governance and management objectives; IT balanced scorecard concepts | Name and purpose | `VERIFY current edition` |

Laws and regulations (for example financial-reporting, privacy or e-waste rules) are named only when the user's context makes them relevant, and their requirements come from Legal or the official text, not from memory.

## 9. Citation rules

- **Supplied documents:** cite the document and location the user gave you (`Order Form §2`, `ITAM Policy v3 p.4`, `export 2026-10-14, row 118`).
- **Data extracts:** cite the system, table or report, and the extraction date. Counts without an extraction date are `NOT VERIFIED` for audit use.
- **CAMP:** `(CAMP M:57-71)` for the manual, `(CAMP S:119-125)` for slides; paraphrase only.
- **Forge-derived method:** no citation needed in user deliverables; the method is the plugin's own.
- **Each citation must support the claim next to it.** Don't cite a source for a stronger statement than it makes, and don't cite what you haven't seen.
- **Time-sensitive facts** (product features, current editions, prices, legal changes) need a fresh authorized source; otherwise mark them `NOT VERIFIED`.

Sources: AssetForge §4.1, 29–31; RiskForge §3.2, 5.1, 6; DataForge §2, 16, 21; prompt-engineering research findings §3.2–3.3, §8.
