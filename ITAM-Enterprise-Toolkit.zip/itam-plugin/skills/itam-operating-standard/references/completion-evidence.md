# Completion evidence: what proves each ITAM claim

Extends the Iron Law in `itam-operating-standard` ("no completion claim without fresh evidence"). The method is adapted from the Superpowers `verification-before-completion` skill and translated to ITAM evidence. Read it before stating that any reconciliation, wipe, disposal, license position, record update, recovery or delegated task is finished.

## Contents
1. What "fresh" means
2. Evidence by claim (full table)
3. Patterns: right and wrong
4. When the gate applies
5. Reporting actual status

## 1. What "fresh" means

Evidence is fresh when it was produced or read **in this conversation**, from the current data, after the last change that could affect it. Not fresh:
- a result from last month's run, a previous chat or a colleague's summary;
- output read before a later edit, re-run, import or write;
- a sample presented as the population;
- a success message from a tool, script, flow, vendor or agent that you did not check against the output itself.

## 2. Evidence by claim

| Claim | Requires | Not sufficient |
|---|---|---|
| Inventory reconciled | Match report: records in per source, matched by tier, unmatched, residual exceptions by code, formulas, as-of date (`itam-inventory-reconciliation`) | "The script ran"; a match rate with no denominator; Tier 3 proposals counted as matched |
| Cycle count complete / stock accurate | Count sheet totals vs. system totals, variance list, approved adjustments | "We counted the room"; adjustments made by the counter |
| Device wiped or sanitized | Per-serial wipe log or certificate naming serial, method and date | MDM wipe command "sent"; lot-level certificate; ITAD invoice |
| Device disposed | Certificate reconciled to serial, plus sanitization evidence and financial-closure reference | Pickup manifest only; "the vendor collected it" |
| License compliant | Effective license position per product and metric: entitlements and consumption, each with source and date | A green tool dashboard; "we bought enough"; no audit letter received |
| Licenses reclaimed | Post-change consumption read showing the seats released | The reclaim ticket closed |
| Asset updated in the ITSM/CMDB | Re-query after the write showing the new values on the named records | API returned success; the import job finished; "the transform map ran" |
| Bulk change done | Before and after counts that differ by exactly the intended scope, plus a sample of changed records | Job log "completed"; no error emails |
| Leaver device recovered | Stockroom receipt with serial scan, record state changed | Carrier shows "delivered"; user says it was posted |
| Device built and ready | Validation checklist passed for that serial, build version recorded | Task sequence finished; ESP completed on one test unit |
| Control effective | Test of operation over the period with sample evidence | Control written in the policy; owner says it runs |
| SOP or policy approved | Approval record with approver, version and date | Draft circulated; no objections received |
| KPI value | Calculation on the supplied data with numerator, denominator, population, as-of date | Number copied from a slide; "about 95%" |
| Worker or agent said done | Inspect the output it produced: file, diff, query result, record | The worker's success report |

## 3. Patterns: right and wrong

**Reconciliation**
- Right: run `python3 scripts/match_tiers.py` → read `summary.json` → "4,812 of 5,030 repository records matched (95.7%; 4,812 / 5,030; as of 2026-10-14); 218 exceptions open, 37 of them severity High."
- Wrong: "Reconciliation complete, looks clean."

**Record writes**
- Right: draft the update → user approves → write → re-query the 40 records → "40 of 40 now show `IN_STOCK/PENDING_INSPECTION`."
- Wrong: "Updated in ServiceNow."

**Disposal**
- Right: compare certificate serials to the pickup manifest → "312 of 315 serials on the certificate; 3 missing, listed below; disposal not complete for those 3."
- Wrong: "The ITAD batch is done."

**Delegated work**
- Right: the worker reports success → open its output → check it against the request → report what is actually there.
- Wrong: forward the worker's summary as the result.

## 4. When the gate applies

Always before:
- any statement or implication of success, completion, compliance or correctness, in any wording ("should be fine now", "looks reconciled", "all set");
- moving a record to a terminal or evidence-gated state (for example `DISPOSED`, `WRITTEN_OFF`, `READY_TO_DEPLOY`);
- closing a ticket, sending a status update, or handing off to the next step or another skill;
- telling a stakeholder or auditor something is finished.

## 5. Reporting actual status

When the evidence does not support the claim, say what is true, with the evidence:
- "Reconciliation run; not yet complete: 218 exceptions open, 14 review-required matches unconfirmed."
- "Wipe command issued to 22 devices; confirmation received for 19; 3 pending (serials listed)."
- "License position calculated for 3 of 5 metrics; Processor-core metric `INSUFFICIENT EVIDENCE` (no host inventory supplied)."

This is not slower than a false "done": it is the next action list.

Sources: Superpowers `verification-before-completion` (adapted); `quality-gates.md` §5 (verifier hierarchy); AssetForge §36–40.
