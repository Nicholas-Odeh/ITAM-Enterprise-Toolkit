---
name: itam-operating-standard
description: Use when an ITAM deliverable must be audit-ready or defensible; when asked how sure a finding is, where a number came from or whether it is verified; when sources conflict or evidence is missing; before saying anything is reconciled, compliant, wiped, disposed or done; or when QA-reviewing a draft. Covers evidence labels, source hierarchy, preflight sufficiency, completion evidence, quality gates Q1–Q12, failure modes F1–F8 and output modes A–G. Not for domain content such as licensing or disposal (use the domain skill).
---

# ITAM Operating Standard

Every ITAM skill in this plugin points here as its required background. Core principle: **a claim is only as good as the evidence in hand now.** It decides what an answer may claim, how sure it may sound, and whether a draft can be released, for practitioners and reviewers whose work must survive an audit.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Never upgrade a claim's status.** Unknown is not fact; "no violation observed" is not "compliant"; a documented control is not an effective one.
7. **Critical failures are non-compensatory.** One failed ★ check blocks release.
8. **Alignment is not certification.** Say "aligned with" IAITAM, ISO/IEC 19770, ITIL or NIST unless a formal basis for "certified" is supplied.

Read `templates/company-profile.md` at the plugin root first if it exists.

## The Iron Law

```
NO COMPLETION CLAIM WITHOUT FRESH EVIDENCE
```

**Gate function**, before any status claim:
1. **Identify** the evidence that would prove the claim.
2. **Obtain** it: run the script, re-query the record, open the certificate.
3. **Read** it fully: counts, exceptions, serials, dates.
4. **State** the claim with its evidence, or state the actual status.

| Claim | Requires | Not sufficient |
|---|---|---|
| "Inventory reconciled" | Match report with counts per source and residual exceptions | "The script ran" |
| "Device wiped" | Certificate or wipe log naming each serial | MDM wipe "sent"; lot-level certificate |
| "License compliant" | ELP per metric with sources and dates | Tool dashboard is green |
| "Asset updated in ~~ITSM" | Re-query after the write | Write returned success |
| "Leaver device recovered" | Stockroom receipt with serial scan | Carrier "delivered" |
| "Worker or agent said done" | Check the output yourself | The success report |

Full table and patterns: `references/completion-evidence.md`.

## When to use

- Audit responses, compliance positions, write-offs, disposal evidence.
- "How sure are you?", "where does 4,312 come from?", "is this verified?"
- Systems disagree, or a contract, policy or export is missing.
- Reviewing a draft before release (also the `itam-reviewer` agent).

**When not to use:** for the domain method itself (load the domain skill alongside); for writing an SOP (`itam-sop-documentation`).

## Workflow

### Step 1 — Classify

| Request | Load |
|---|---|
| Provenance or confidence question | `references/source-hierarchy.md` |
| Conflicting or missing evidence | `references/failure-recovery.md`, then `source-hierarchy.md` |
| Completion or status claim | `references/completion-evidence.md` |
| Release or QA check | `references/quality-gates.md` |
| Deliverable shape; audit-trail mode | `references/output-modes.md` |

### Step 2 — Preflight

Test objective, scope, evidence, semantics, authority and method. If any is insufficient, take the least disruptive response: RETRIEVE, CLARIFY, ASSUME AND LABEL, ENUMERATE, NARROW or ABSTAIN (`references/preflight-and-method.md`).

### Step 3 — Do the work

- Label as you write; calculated figures show formula and inputs.
- Apply the source hierarchy; show conflicts, never silently pick.
- State each limitation by its consequence; keep `FINDING → EVIDENCE → RISK → CONTROL → REMEDIATION → VALIDATION`.

### Step 4 — Verify before release

- ★ Q1 Correctness (figures recomputed), Q2 Completeness, Q3 Evidence faithfulness.
- ★ Every status claim passed the gate function.
- ★ Q4, Q7, Q8, Q10, Q11 when they apply (`references/quality-gates.md`).
- Q5, Q6, Q9, Q12 and the failure-witness check.

Verdict: **RELEASE**, **RELEASE WITH FIXES** or **BLOCK**. State it first, for your own output and for any draft the user asks you to edit or review.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The script ran without errors" | Exit code is not the result. Read the counts. |
| "The vendor confirmed all drives were wiped" | A statement is not a certificate. Check per serial. |
| "It reconciled last month" | Fresh means this data, this conversation. |
| "The agent reported success" | Verify the output independently. |
| "The deadline is today" | Report actual status and what is missing. |
| "It *should* be compliant" | Implying success is claiming it. |
| "They only asked me to polish the wording" | Polishing an unsupported claim publishes it. Give the verdict and name each failing claim before any rewrite. |

Stop if you are about to: write "done", "reconciled", "compliant" or "updated" without evidence read in this conversation; present a sample as the population; use "should", "probably" or "looks" about a status.

## Common mistakes

| Mistake | Fix |
|---|---|
| Picking the more plausible of two conflicting values | Show both sources; apply a rule or log an exception (F2) |
| "No issues found" read as "compliant" | Use the never-upgrade list |
| Rereading your own draft as verification | Recalculate or compare to the source |
| A long report where one table answers it | Pick the smallest output mode |

## If connectors are available

- **Any connector:** record system and read time per figure; re-query after an approved write; a failed tool is F8, never a pass.
- **~~document repository / ~~knowledge base:** read policies and contracts for the authority test; cite file and version.

## Output format

Smallest mode that serves the decision: A executive, B technical, C procedure, D governance, E data, F strategy, G full package. End substantial deliverables with **Assumptions and limitations** and, when audit-sensitive, **Evidence reviewed**.

## Reference files

- `references/source-hierarchy.md`: authority order, labels, never-upgrade list, conflicts, frameworks, citations. Read for provenance questions.
- `references/completion-evidence.md`: evidence per completion claim, patterns, actual-status wording. Read before any status claim.
- `references/preflight-and-method.md`: sufficiency tests, response ladder, full method, carried-over v1 rules. Read for substantial work.
- `references/quality-gates.md`: Q1–Q12, failure witnesses, verifier hierarchy, verdict. Read before release.
- `references/failure-recovery.md`: F1–F8 and partial-result template. Read when a gate fails.
- `references/output-modes.md`: modes A–G, output contract, audit-trail mode. Read when shaping a deliverable.
