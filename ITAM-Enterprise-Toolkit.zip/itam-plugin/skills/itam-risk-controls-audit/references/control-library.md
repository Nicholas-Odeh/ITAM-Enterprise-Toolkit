# ITAM control library

A starting library of ITAM controls, built on the control fields in AssetForge §13 and RiskForge §10. Everything here is `PRACTICE`: frequencies, owners and thresholds are suggestions to be replaced with the organization's approved values. Owners are roles, not people (CAMP M:98). Type: P = preventive, D = detective, C = corrective. Mode: M = manual, A = automated, H = hybrid.

A control is incomplete if no observable evidence shows it operated (AssetForge §13).

## Contents
1. Full control record (fields)
2. Governance
3. Acquisition and receiving
4. Inventory and reconciliation
5. Deployment, joiner-mover-leaver and loss
6. Software and SaaS
7. Disposal
8. Financial
9. ITAM system integrity (ITGC-relevant)
10. Adapting the library

## 1. Full control record (fields)

`control_id | name | objective | risks_addressed | scope | activity | type (P/D/C) | mode (M/A/H) | frequency | trigger | owner | performer | inputs | expected_result | evidence | evidence_location | retention | exception_criteria | escalation | dependencies | test_step | pass_criteria | framework_refs`

The tables below show the core fields; complete the rest when adopting a control.

## 2. Governance

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| GOV-01 | ITAM authority and expectations are defined and current | ITAM policy approved by the designated authority and reviewed on schedule | P / M | Annual review [org] | ITAM program owner | Approved policy with version history and approval record | Inspect approval and last review date; confirm approver has authority per delegation |
| GOV-02 | Exceptions are approved, time-bound and monitored | Exception register reviewed; expired exceptions escalated | D / M | Monthly [org] | ITAM manager | Exception register, review sign-off, escalation records | Sample exceptions; verify approver authority, expiry set, expired items escalated |
| GOV-03 | ITAM performance is visible to management | KPI / KRI pack reviewed by governance forum | D / M | Quarterly [org] | ITAM program owner | Meeting pack, minutes, actions | Inspect two periods' packs and minutes; trace actions to closure |

## 3. Acquisition and receiving

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| ACQ-01 | IT purchases go through the approved channel with authorization | Purchase requests approved before PO; non-standard items reviewed (CAMP M:27–49 non-standard review) | P / H | Per transaction | Procurement manager | Approved request linked to PO | Sample POs; confirm approval precedes PO date and approver is authorized |
| ACQ-02 | Entitlements are captured at purchase | Software purchases create entitlement records with proof of purchase linked | P / H | Per transaction | SAM manager | Entitlement record with contract / invoice link | Sample software POs; trace to entitlement record and document |
| REC-01 | Received assets are recorded promptly and identifiably | Receipt creates asset record with tag and serial within [org: N days] | P / H | Per receipt | Receiving / asset identification lead | Receiving log and asset record timestamps | Sample receipts; compare receipt date to record creation; check tag and serial present |

## 4. Inventory and reconciliation

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| INV-01 | The repository reflects what exists | Discovery-to-repository reconciliation; exceptions ticketed and aged | D / H | Monthly [org] | ITAM analyst | Reconciliation report, exception tickets | Re-perform one period's reconciliation; trace sampled exceptions to resolution |
| INV-02 | Physical stock matches records | Stockroom cycle count; variances investigated and approved | D / M | Quarterly or rolling [org] | Stockroom manager | Signed count sheets, variance report, write-off approvals | Observe a count or inspect signed sheets; sample variances for investigation and approval |
| INV-03 | Unknown devices are addressed | Unknown / unauthorized devices on the network are onboarded, quarantined or removed | D, C / H | Continuous with weekly review [org] | Security operations with ITAM | Alerts, tickets, closure notes | Sample alerts; verify each was resolved within the defined time |
| INV-04 | Records stay complete | Required-field completeness monitored and corrected | D / A | Monthly [org] | ITAM data owner | Data-quality report, correction tickets | Recompute completeness from an extract; compare with reported figure |

## 5. Deployment, joiner-mover-leaver and loss

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| DEP-01 | Custodians accept responsibility | User acknowledges assignment (signed or electronic) | P / H | Per assignment | Service desk lead | Acknowledgement record | Sample assignments; confirm acknowledgement exists and matches serial |
| JML-01 | Leavers' assets are recovered | HR leaver list reconciled to recovery records; unrecovered items escalated | D, C / H | Per leaver, reviewed weekly [org] | ITAM manager with HR | Leaver list, recovery records, escalations | Take the period's leaver list; re-perform matching; check escalations for unrecovered items |
| JML-02 | Leavers' licenses are reclaimed | Licenses and SaaS access removed at departure | C / H | Per leaver | SAM manager / identity team | Deprovisioning records | Sample leavers; verify removal date against termination date |
| LOST-01 | Lost or stolen devices are contained and recorded | Report, remote lock or wipe, record update, security review | C / H | Per event | Security with ITAM | Incident ticket, lock / wipe log, record change | Sample events; verify each step and timing |

## 6. Software and SaaS

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| SW-01 | License position is known for material publishers | ELP produced, reviewed and signed off | D / M | Semi-annual or before renewals [org] | SAM manager | Signed ELP with data sources and date | Inspect latest ELPs; re-perform one product's calculation |
| SW-02 | Unauthorized software is addressed | Discovery compared with approved catalog; unauthorized titles removed or approved | D, C / H | Monthly [org] | SAM manager with Security | Report, tickets, approvals | Sample detections; trace to removal or approval |
| SW-03 | SaaS applications have owners and terms on record | New SaaS found via SSO / spend is registered with owner, renewal date and security review | D / H | Monthly [org] | SAM manager | SaaS register, discovery output | Compare discovery output to register; sample new apps for owner and review |

## 7. Disposal

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| DIS-01 | Only authorized assets are retired | Retirement approved; legal-hold check done | P / M | Per batch | Disposal manager | Approval and hold-check records | Sample disposed assets; confirm approval and hold check precede pickup |
| DIS-02 | Data is removed before assets leave control | Sanitization or destruction recorded and verified per media serial | P / H | Per asset | Disposal manager / ITAD vendor | Per-item sanitization reports or destruction certificate lines | Sample disposed serials; locate the per-serial record and result |
| DIS-03 | Every device handed over is accounted for | Manifest, vendor receipt and certificates reconciled by serial | D / H | Per batch | Disposal manager | Reconciliation record and exception log | Re-perform reconciliation for a sampled batch |
| DIS-04 | ITAD vendor remains qualified | Certifications verified and vendor audited | D / M | Annual [org] | Vendor manager | Registry lookups, audit report | Inspect the latest audit and registry checks |

Detail for disposal controls: the `itam-secure-disposition` skill.

## 8. Financial

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| FIN-01 | Asset records and the fixed-asset ledger agree | Reconcile capitalized assets, additions and disposals between the repository and the ledger | D / M | Quarterly or period-end [org] | Finance asset accountant with ITAM | Signed reconciliation, reconciling items | Re-perform for one period; sample reconciling items for resolution |
| FIN-02 | Invoices match what was received and entitled | Invoice-to-PO-to-receipt (and entitlement) matching | P, D / H | Per invoice | Accounts payable | Match records, exceptions | Sample invoices; confirm three-way match |

## 9. ITAM system integrity (ITGC-relevant)

These matter when ITAM data feeds financial reporting or audit reliance (see `framework-mapping.md`, SOX ITGC).

| ID | Objective | Activity | Type / mode | Suggested frequency | Owner | Evidence | Test step |
|---|---|---|---|---|---|---|---|
| SYS-01 | Only authorized people can change asset records | Role-based access; periodic access review | P, D / H | Quarterly review [org] | ITAM platform owner | Access review sign-off, removals | Inspect the review; sample users against roles and job function |
| SYS-02 | Configuration and integration changes are controlled | Changes to ITAM tool, imports and integrations go through change management | P / H | Per change | ITAM platform owner | Change records with approval and test evidence | Sample changes from the system log; trace each to an approved change |
| SYS-03 | Interfaces deliver complete data | Import / integration job monitoring and failure handling | D / A | Per run, reviewed daily [org] | Integration owner | Job logs, failure tickets | Inspect logs for the period; sample failures for resolution |

## 10. Adapting the library

1. Keep only controls that address a risk in the register; every control maps to at least one risk.
2. Replace bracketed values with approved ones; record who approved them.
3. Name the evidence location in the organization's repository.
4. Add the test step and pass criteria before calling a control "designed".
5. Flag single-control dependencies for material risks and consider a detective backup.
