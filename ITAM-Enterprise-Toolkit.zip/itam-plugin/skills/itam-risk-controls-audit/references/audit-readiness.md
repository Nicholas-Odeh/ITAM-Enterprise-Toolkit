# Audit readiness and response

Labels as in `risk-method.md`. For a software publisher's license audit use the `itam-software-license-management` skill instead; this file covers internal audit, external financial audit, regulatory and certification audits of ITAM.

## Contents
1. Readiness checklist
2. Evidence model
3. Traceability
4. During the audit: requests and walkthroughs
5. Responding to findings
6. Remediation tracking and closure
7. Compliance tracking: control inventory, audit calendar, evidence management, gap analysis
8. Release checks that are not blocking

## 1. Readiness checklist (`PRACTICE`)

- [ ] Scope known: audit type, period, entities, processes, systems, frameworks or criteria.
- [ ] Single point of contact and request log in place.
- [ ] Control descriptions current, each with owner, frequency and evidence location (`control-library.md`).
- [ ] Self-test performed on key controls for the period (`control-testing.md`), with gaps known before the auditor finds them.
- [ ] Prior findings: status of each, with closure evidence.
- [ ] Populations ready to extract with a completeness check (for example all disposals, all leavers, all new hardware in the period).
- [ ] Policies and procedures approved and dated.
- [ ] Exception register current; expired exceptions resolved.
- [ ] Evidence repository organized by control ID and period.
- [ ] Control owners briefed on walkthroughs: describe what they do, show evidence, don't speculate.

## 2. Evidence model

Typical ITAM evidence artifacts (AssetForge §14): approved request, approval record, purchase order, invoice, receiving record, asset tag record, inventory scan, system record, discovery record, user acknowledgement, deployment record, chain-of-custody record, return record, transfer record, retirement approval, data-sanitization evidence, disposition evidence, destruction evidence, vendor record, reconciliation report, exception approval, remediation record, control execution log, management review.

For each artifact know: the control it supports, owner, authoritative repository, retention requirement, integrity requirement, timestamp, reviewer and known exceptions (AssetForge §14). A process that "probably happened" is not evidence.

## 3. Traceability

Requirement → Risk → Control → Test → Evidence → Finding → Remediation → Validation → Closure (RiskForge §29).

For full traceability, give each item an identifier (for example REQ-, RISK-, CTL-, FIND-, ACT-) and keep a matrix:

`id | requirement / risk / control | evidence | analysis | conclusion | verification | status`

## 4. During the audit: requests and walkthroughs

Request log: `request_id | date_received | requested_by | description | control_id | owner | due | date_provided | items_provided | reviewed_by | status | notes`.

- Review every item before it is provided: correct period, complete population, no unrelated sensitive data.
- Provide populations with the query or report used, so completeness can be checked.
- Correct inaccurate statements quickly and in writing.
- Track auditor observations as they arise; agree facts before they become findings.

## 5. Responding to findings

Management response per finding:

| Field | Content |
|---|---|
| Agreement | Agree / partially agree / disagree, with factual basis |
| Root cause | As agreed or as management sees it |
| Action | Specific change to control, process, system or data |
| Owner | Named role accountable for the action |
| Target date | Realistic; tied to dependencies |
| Interim measure | Compensating control or monitoring until the fix is in place |
| Validation | Evidence that will demonstrate closure |

Disagree only on facts or criteria, with evidence. Do not commit to dates or resources without the owner's agreement.

## 6. Remediation tracking and closure

Tracker (RiskForge Output G): `finding_id | risk_id | control_id | gap | severity | action | owner | due | status | evidence_required | validation_status | residual_risk`.

- Report open, overdue and closed items to the governance forum.
- Close only with evidence that the fixed control has operated for at least one cycle (`PRACTICE`; the auditor may require more).
- Track repeat findings: a recurrence means the root cause was not addressed (AssetForge §26.4, audit finding recurrence).
- Planned remediation does not reduce current residual risk until validated.

## 7. Compliance tracking: control inventory, audit calendar, evidence management, gap analysis

Four standing components keep ITAM audit-ready between audits (component structure adapted from the Operations plugin's compliance-tracking skill; field lists `PRACTICE`). Keep them in one workbook or list set, keyed by `control_id` and `obligation_id` so they join.

### 7.1 Control inventory

The risk-control matrix (`control-library.md` §1 fields) plus effectiveness tracking:

`control_id | control | framework_refs (edition, VERIFY) | obligation_ids | risk_ids | owner | frequency | evidence | design_result | operating_result | test_period | test_ref | last_tested | next_test | open_findings`

- `design_result` and `operating_result` use the vocabulary in `control-testing.md` §6. Leave them "Not tested / design only" until a test for the period exists; never write "effective" from the control description alone.
- A control mapped to a framework is "aligned with" it, not certified against it.

### 7.2 Audit calendar (template)

One row per audit, assessment or recurring obligation. Publisher license audits belong to `itam-software-license-management`, but list their dates here so the calendar is complete.

| Field | Content |
|---|---|
| audit_id | `AUD-<yyyy>-<nn>` |
| Audit or assessment | Name, e.g. "External financial audit FY[FILL]", "ISO/IEC 27001 surveillance" (`VERIFY` scope) |
| Type | Internal, external financial, regulatory, certification, customer, publisher |
| Criteria | Framework, regulation or contract, with edition (`VERIFY`) |
| Scope | Entities, processes, systems, asset classes |
| Period under review | Start–end |
| Auditor or assessor | Firm or team; single point of contact |
| Key dates | Planning meeting, PBC list received, PBC due, fieldwork start–end, draft report, management responses due, final report |
| Readiness milestones | Back-calculated from fieldwork start (below) |
| Remediation deadlines | Per finding, linked to the tracker in §6 |
| Owner | Named role accountable for readiness |
| Status | Planned, preparing, in fieldwork, reporting, remediation, closed |

Readiness milestones, back-calculated from fieldwork start. Offsets are `[FILL]` by the organization; the bracketed values are a `PRACTICE` starting point only.

| Milestone | Offset | Done when |
|---|---|---|
| Scope and criteria confirmed | [T−90 days] | Scope letter or engagement memo filed |
| Control inventory refreshed | [T−75] | Owners confirmed; descriptions current |
| Self-test of key controls | [T−60] | Test worksheets for the period (`control-testing.md` §5) |
| Prior findings closure evidence | [T−45] | Each finding closed with validation evidence, or status explained |
| Populations extractable with completeness checks | [T−30] | Query or report saved with each population |
| Evidence repository organized by control and period | [T−21] | Evidence register (§7.3) shows no `MISSING` for in-scope controls |
| Walkthrough briefings | [T−14] | Owners briefed (§1) |
| Fieldwork | T | Request log open (§4) |
| Management responses | [per auditor timetable] | Responses per §5 |

Recurring evidence dates (quarterly access reviews, monthly reconciliations, annual policy approvals) go on the same calendar so that missed cycles show up before the audit does.

### 7.3 Evidence management register

`control_id | evidence_item | period | expected_frequency | repository_location | owner | last_collected | next_due | retention_rule | integrity (who can edit) | status`

- `status`: `CURRENT`, `STALE` (last collected older than the expected frequency), `MISSING`, `CONTRADICTORY`.
- Location is a path or record link, not "SharePoint". For SharePoint repositories see `sharepoint-itam-records`.
- An evidence gap is reported separately from a control failure: missing evidence means "not demonstrated", not "failed".

### 7.4 Gap analysis

`gap_id | requirement (source and citation) | obligation_id | current_state (evidence) | gap | risk_id | severity (organization's method or PROVISIONAL) | remediation_action | owner | target_date | dependencies | validation_evidence | status`

- Prioritize by residual risk and by the nearest audit or legal deadline on the calendar.
- "Timeline to compliance" is a list of dated actions with owners. A gap closes only when validation evidence exists (§6); a target date is not a status.

### 7.5 Compliance status view

Counts by status (vocabulary in `compliance-legislation.md` §6); controls "Not tested" for the current period; evidence `STALE` or `MISSING`; audits and evidence due in the next [FILL: 90] days; open findings by age and severity. Every number in the view comes from the registers above, with the extraction date.

## 8. Release checks that are not blocking

Moved from `SKILL.md`; check them before releasing any risk, control or audit deliverable.

- Risk owner, control owner, performer and remediation owner are distinguished, with roles more specific than "IT" (RiskForge §20).
- Evidence gaps are reported separately from control failures.
- Inventory and reconciliation discrepancies stay visible as populations and counts.
- KRIs have a source, an owner, thresholds (from the organization or marked fill-in) and a response.
- Recommendations name what changes, who does it and how closure will be validated.
- Executive variant: decision required; the three to five most material risks and control weaknesses with business impact; residual exposure versus appetite; recommended treatments with cost and owner; risk of delay (RiskForge §26).
