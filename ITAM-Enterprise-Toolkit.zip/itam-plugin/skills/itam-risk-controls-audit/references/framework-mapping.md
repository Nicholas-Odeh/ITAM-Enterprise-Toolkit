# Framework mapping

**Read this first.** This file describes each framework at the level of **purpose** and shows which ITAM controls usually provide evidence for it. Identifiers, safeguard numbers and section references below are given only to help locate the text and are marked `VERIFY`: confirm them against the current official publication before putting them in an audit document. Mapping a control to a framework shows relevance, not compliance or certification (RiskForge §5.1). Frameworks strengthen ITAM; they do not turn every ITAM analysis into a cybersecurity assessment (AssetForge §5.5).

Control IDs refer to `control-library.md`.

## Contents
1. CIS Critical Security Controls v8
2. NIST Cybersecurity Framework 2.0, ID.AM
3. NIST SP 1800-5, IT Asset Management
4. ISO/IEC 19770-1
5. SOX and IT general controls
6. Other frameworks often asked about
7. Summary matrix
8. Recording a mapping

## 1. CIS Critical Security Controls v8

**Purpose.** A prioritized set of cybersecurity safeguards. The first two controls are about knowing what hardware and software exist, because the rest of the controls depend on it. `VERIFY` whether the organization uses v8 or a later point release (for example v8.1), and its implementation group.

| Control | Purpose | Safeguard themes (`VERIFY` numbering and wording) | ITAM controls |
|---|---|---|---|
| Control 1, Inventory and Control of Enterprise Assets | Know every enterprise asset connected to the infrastructure, so that only authorized assets get access and unauthorized ones are found | Detailed asset inventory maintained; unauthorized assets addressed; active and passive discovery; using network data (for example DHCP logs) to update the inventory | REC-01, INV-01, INV-03, INV-04, DEP-01 |
| Control 2, Inventory and Control of Software Assets | Know all software, so that only authorized and supported software is installed and run | Software inventory maintained; authorized software is supported; unauthorized software addressed; automated software inventory; allowlisting of software, libraries and scripts | SW-02, SW-03, SW-01, ACQ-02 |
| Related: data disposal safeguard under the data protection control | Secure disposal of data | `VERIFY` the safeguard and its wording | DIS-02, DIS-03 |

## 2. NIST Cybersecurity Framework 2.0, Asset Management (ID.AM)

**Purpose.** CSF 2.0 organizes cybersecurity outcomes into functions (Govern, Identify, Protect, Detect, Respond, Recover). The Asset Management category in Identify is about knowing and managing the assets that enable the organization's purpose, consistent with their importance to objectives and risk strategy. `VERIFY` subcategory identifiers and wording against the current CSF 2.0 publication.

| Outcome theme (subcategory IDs `VERIFY`) | ITAM controls |
|---|---|
| Inventories of hardware are maintained | REC-01, INV-01, INV-02, INV-04 |
| Inventories of software, services and systems are maintained | SW-01, SW-02, SW-03 |
| Inventories of services provided by suppliers are maintained | SW-03 (SaaS register); vendor register in `itam-vendor-contract-management` |
| Assets are prioritized by classification, criticality and impact | Asset criticality and data classification fields in the repository |
| Inventories of data and metadata are maintained | Data classification held per device (supports DIS-02) |
| Hardware, software, services and data are managed throughout their life cycles (including disposal) | JML-01, LOST-01, DIS-01 to DIS-04 |

The Govern function (for example supply chain risk management) and Protect function (for example data security, platform security) contain further outcomes that ITAM supports; `VERIFY` before mapping.

## 3. NIST SP 1800-5, IT Asset Management

**Purpose.** A National Cybersecurity Center of Excellence practice guide that shows how an organization (originally framed around the financial services sector) can build an IT asset management capability from commercially available products, with a reference architecture, risk considerations, and mappings to security standards. It presents its build as one possible solution, not the only one (research finding on SP 1800-5). `VERIFY` the volume structure and publication date.

**Use it for:** architecture and integration ideas for discovery, inventory and analytics; demonstrating that asset data supports security monitoring and response; a published example of tying asset management to security controls. It is guidance, not a certifiable requirement.

**ITAM controls typically evidenced:** INV-01, INV-03, INV-04, SYS-03.

## 4. ISO/IEC 19770-1

**Purpose.** The ISO/IEC 19770 family covers IT asset management. Part 1 specifies requirements for an IT asset management *system*, using the common management-system structure (context, leadership, planning, support, operation, performance evaluation, improvement), so an organization can establish, run and improve ITAM and, if it chooses, be assessed against it. Other parts cover topics such as software identification tags, entitlement schemas, resource utilization measurement and vocabulary (`VERIFY` current edition of Part 1 and the numbering and status of other parts).

| Management-system theme | ITAM evidence |
|---|---|
| Scope, policy, roles and authority | GOV-01; RACI from `itam-program-governance` |
| Risk and opportunity planning | Risk register (`risk-method.md`) |
| Operational processes across the asset lifecycle | Lifecycle controls REC-01 to DIS-04 |
| Data and records | INV-04, SYS-01 to SYS-03 |
| Performance evaluation, internal audit and management review | GOV-03; internal audit program (`audit-readiness.md`) |
| Nonconformity and continual improvement | Findings and remediation tracker |

Do not state "conforms to ISO/IEC 19770-1" without a formal assessment against the current text.

## 5. SOX and IT general controls

**Purpose.** The US Sarbanes-Oxley Act requires applicable public companies to maintain, assess and (for some) have auditors attest to internal control over financial reporting (`VERIFY` the sections and filer requirements that apply). The CAMP manual notes that SOX-type legislation dictates financial practices and records retention that ITAM must support (CAMP M:41; S:116, S:118). Many organizations use the COSO internal control framework, and external auditors follow their professional auditing standards (`VERIFY` which apply).

**IT general controls (ITGCs)** are the controls over the systems and data that financial reporting relies on. Commonly grouped (`PRACTICE`; auditors' own structures vary) as access to programs and data, program change management, program development or acquisition, and computer operations.

**When ITAM is in scope:** if the asset repository or SAM tool feeds fixed-asset accounting, depreciation, lease accounting or capitalization decisions, or if its reports are used as evidence in a financial control, that system and its reports can come into ITGC and report-reliability testing. Agree scope with Finance and the auditors; do not assume.

| Area | ITAM controls |
|---|---|
| Fixed-asset existence, completeness and disposals | FIN-01, INV-02, DIS-01, DIS-03 |
| Purchase-to-pay accuracy | ACQ-01, FIN-02 |
| Access to programs and data | SYS-01 |
| Program and configuration change | SYS-02 |
| Computer operations (interfaces, jobs) | SYS-03 |
| Reliability of reports used as evidence | Report logic under change control (SYS-02), population completeness checks (`control-testing.md` §3) |

## 6. Other frameworks often asked about

| Framework | ITAM relevance | Note |
|---|---|---|
| ISO/IEC 27001 and its Annex A controls | Inventory of assets, acceptable use, return of assets, storage media, secure disposal or re-use of equipment | `VERIFY` edition (for example 2022) and control numbers |
| ITIL (service asset and configuration management) | Relationship between asset records and CIs | Asset record is not a CI (core operating rule 3) |
| NIST SP 800-53 (configuration management and media protection families) | Federal and contractor environments | `VERIFY` revision and baseline |
| NIST SP 800-88 | Media sanitization | See the `itam-secure-disposition` skill |

## 7. Summary matrix

| Control | CIS v8 | CSF 2.0 ID.AM | SP 1800-5 | ISO/IEC 19770-1 | SOX ITGC / financial |
|---|---|---|---|---|---|
| REC-01 | 1 | Hardware inventory | ✓ | Operation | Existence |
| INV-01 | 1 | Hardware inventory | ✓ | Operation | Completeness |
| INV-02 | 1 | Hardware inventory | | Operation | Existence |
| INV-03 | 1 | Hardware inventory | ✓ | Operation | |
| INV-04 | 1 | Hardware inventory | ✓ | Data and records | |
| SW-01 | 2 | Software inventory | | Operation | |
| SW-02 | 2 | Software inventory | | Operation | |
| SW-03 | 2 | Software / supplier services | | Operation | |
| JML-01 | 1 | Life cycle | | Operation | Existence |
| DIS-01–04 | Data disposal (`VERIFY`) | Life cycle | | Operation | Disposals |
| FIN-01 | | | | Performance evaluation | Fixed assets |
| SYS-01–03 | | | ✓ (SYS-03) | Data and records | ITGC |
| GOV-01–03 | | | | Leadership, evaluation | |

All cells are `PRACTICE` mappings at theme level. `VERIFY` against the current texts before using them as audit criteria.

## 8. Recording a mapping

`mapping_id | control_id | framework | edition / version | identifier (verified) | requirement summary (from the official text) | relationship (supports / partially supports / evidences) | verified_by | verified_on | source`
