# Control testing and findings

Labels as in `risk-method.md`. Adapted from RiskForge §10, §31, §33, §35. When an external auditor or internal audit function has its own methodology, follow it; this file fills gaps.

## Contents
1. Design versus operating effectiveness
2. Test methods
3. Sampling
4. Evidence grading
5. Test worksheet
6. Result vocabulary
7. Finding format

## 1. Design versus operating effectiveness

**Design test:** would this control, operating as described, address the risk? (RiskForge §10.1)
- Does it address the stated risk, at the right point in the process?
- Is the owner clear, the scope complete and the frequency right for the risk?
- Does it generate evidence? Can exceptions be detected, and is escalation defined?
- Can it be bypassed? Does it hold up under abnormal conditions (peaks, staff absence, system outage)?

**Operating test:** did it actually operate as designed, throughout the period? (RiskForge §10.2)
- Operated at the required frequency, across the intended population.
- Produced reliable evidence; detected and resolved exceptions; followed escalation.

Never conclude operating effectiveness from policy or procedure documents alone. A design failure makes an operating test moot; report the design gap.

## 2. Test methods

| Method | What it is | Strength |
|---|---|---|
| Inquiry | Ask the performer how the control works | Weakest; never sufficient alone (`PRACTICE`) |
| Observation | Watch the control being performed | Shows it at a point in time |
| Inspection | Examine records, approvals, reports, logs | Common for manual controls |
| Re-performance | Independently redo the control (for example re-run a reconciliation) | Strongest for detective controls |

For automated controls, test the configuration and its change control, and confirm the system was the same throughout the period (link to SYS-02 in `control-library.md`).

## 3. Sampling

- Use the organization's or the auditor's sampling methodology. Do not invent sample sizes. If none is supplied, state the sample size used, how items were selected (random, systematic, targeted) and why, and label it `PROVISIONAL`.
- Define the population first (period, frequency, completeness of the list you sampled from). A sample from an incomplete population proves little: record how completeness of the population was confirmed.
- Sample across the whole period, not only recent items.
- Record each sample item's identifier so the test can be re-performed.

## 4. Evidence grading

Classify evidence (RiskForge §10.3): sufficient, partially sufficient, insufficient, stale, contradictory, unavailable. Good evidence is attributable, complete, accurate, retrievable, time-bound, reproducible and appropriate to the control (RiskForge §29). Report evidence gaps separately from control failures: a control can operate and still fail an audit because nothing proves it.

## 5. Test worksheet

`test_id | control_id | period | test_type (design / operating) | method | population_definition | population_size | completeness_check | sample_size | selection_method | sample_ids | attributes_tested | exceptions_found | exception_details | evidence_refs | result | tester | test_date | reviewer`

## 6. Result vocabulary

| Result | Use when |
|---|---|
| Effective | Design adequate; operated without exceptions in the sample |
| Effective with exceptions | Exceptions found but judged isolated, with rationale |
| Ineffective — design | Control would not address the risk even if performed |
| Ineffective — operation | Designed adequately but not performed, or performed incorrectly |
| Not tested / design only | No evidence for the period; residual risk gets no credit |

Severity classifications in financial-reporting audits (for example deficiency, significant deficiency, material weakness) are defined by the applicable auditing standards and decided by management and the auditors. The workflow may describe facts and draft rationale, but must not assign these classifications (`VERIFY` the definitions in use).

## 7. Finding format (RiskForge §33)

**FINDING [ID] — [title]**
- **Condition:** what exists now.
- **Criteria:** the requirement, policy, control or target it falls short of (with source).
- **Evidence:** what was examined, sample IDs, counts.
- **Risk:** consequence if not addressed.
- **Root cause:** people, process, technology, data, governance, ownership, integration, funding (RiskForge §16). Separate direct cause, contributing factor and symptom.
- **Existing controls and assessment:** design and operating effectiveness.
- **Residual risk:** current exposure.
- **Recommendation:** specific change, not "improve governance" (RiskForge §34).
- **Owner, priority, target date.**
- **Validation:** how closure will be proven.
- **Confidence / limitations:** HIGH, MODERATE, LOW or INSUFFICIENT EVIDENCE, with reasons (RiskForge §35).
