# Compliance and legislation tracking

Labels as in `risk-method.md`. **Not legal advice.** Legal counsel decides whether a law applies and what it requires; this file structures how ITAM identifies, records, maps and evidences those obligations.

## Contents
1. Compliance versus legislation
2. Obligation categories
3. Obligation register
4. Tracking process
5. Roles
6. Status vocabulary
7. Indicators

## 1. Compliance versus legislation

The CAMP model separates two related areas (CAMP M:40–41; S:88, S:111–112):

- **Compliance Management** keeps the organization conforming to license terms, contracts, internal standards and applicable rules. It prepares responses to compliance events, runs periodic internal asset discovery, settles non-compliance, manages the internal IT audit process and communicates requirements.
- **Legislation Management** maintains awareness of laws and regulations that affect IT assets, by jurisdiction: it identifies applicable and pending legislation, evaluates its effect before and after it takes effect, gives internal guidance, and feeds changes into policies and processes.

Legislation also shapes other areas: documentation retention periods, financial record-keeping (proof of purchase, invoices, linking financial records to assets), and procurement and disposal requirements (CAMP M:41; M:36).

## 2. Obligation categories

The CAMP material groups the laws that drive ITAM as copyright, security, disposal, financial, privacy and industry-specific (CAMP S:113), and names contracts and license terms as legal documents that bind the organization (CAMP S:114–115). Use these categories, plus contractual obligations:

| Category | Typical ITAM touchpoints |
|---|---|
| Copyright and licensing | Software installation and use; anti-piracy policy; removal of software that cannot be proven legally acquired (CAMP M:69–70) |
| Security | Asset inventory, configuration, lost devices, access to asset data |
| Disposal and environmental | Sanitization, e-waste handling, export (see the `itam-secure-disposition` skill's `standards.md`) |
| Financial | Fixed-asset accuracy, records retention, internal control over financial reporting |
| Privacy | Personal data on devices, in SaaS, in the asset repository itself |
| Industry-specific | Sector rules for health, finance, government, critical infrastructure |
| Contractual | Publisher license terms, lease terms, vendor and customer contract obligations |

The CAMP slides name examples by country (for example Sarbanes-Oxley, US copyright law, HIPAA, Gramm-Leach-Bliley, Canada's PIPEDA, UK copyright and data protection law, Japan's J-SOX) (CAMP S:116–118). Treat these as illustrations only: names, versions and requirements change. `VERIFY` every law's current status and applicability with Legal before recording it as an obligation.

## 3. Obligation register

One row per obligation (adapted from RiskForge §30):

`obligation_id | category | source (law, regulation, contract, policy) | citation (as provided by Legal or the source document) | jurisdiction | applies_to (entities, asset classes, data classes) | requirement (verified interpretation, with who verified it) | effective_date | control_ids | evidence | status | gap | risk_id | owner | last_reviewed | next_review`

Rules:
- The `requirement` field holds Legal's or the source document's wording or a verified interpretation, never a paraphrase from memory.
- Every obligation maps to at least one control, or is recorded as a gap with a risk ID.
- Pending legislation is tracked in the same register with status `PENDING` and an assessment date.

## 4. Tracking process

| Step | Activity | Output |
|---|---|---|
| 1 Identify | Monitor legislative and regulatory sources by jurisdiction, contract changes, and policy changes; Legal, Compliance and industry bodies are typical sources | Candidate list |
| 2 Assess | Legal confirms applicability by entity, jurisdiction and asset class; ITAM assesses the operational effect | Applicability decision |
| 3 Map | Map to existing controls or design new ones (`control-library.md`) | Control mapping |
| 4 Communicate | Tell affected owners what changes, by when; update policy and training | Communication record |
| 5 Implement | Change processes, systems, contracts | Change records |
| 6 Evidence | Define the evidence that demonstrates conformance | Evidence locations |
| 7 Monitor | Periodic review of status; re-assess on change | Register update |

## 5. Roles

The CAMP manual describes a Compliance and Legislation Manager who researches legislation affecting the use, tracking and reporting of assets, follows pending rules, communicates them and drives ITAM compliance across contracts, intellectual property, accounting, privacy, government-access and environmental law, working with the audit response and negotiation teams (CAMP M:112; M:124–125). In most organizations this is a responsibility shared with Legal and Compliance rather than a single job. Record the actual owner for each obligation.

## 6. Status vocabulary (RiskForge §30)

COMPLIANT, PARTIALLY COMPLIANT, NONCOMPLIANT, NOT APPLICABLE, NOT ASSESSED, INSUFFICIENT EVIDENCE, plus PENDING for legislation not yet in force. Never mark COMPLIANT because a control description resembles a requirement; it needs evidence of operation.

## 7. Indicators

CAMP compliance indicators (CAMP S:87; M:23), to be defined with numerator, denominator, source and cadence:

- Share of installed software titles compliant with their license terms.
- Share of hardware assets, by type, disposed of according to local regulations.
- Share of ITAM processes audited for conformance to program requirements.

Add, for the register itself (`PRACTICE`): obligations with a mapped control; obligations reviewed on schedule; pending items with an assessment.
