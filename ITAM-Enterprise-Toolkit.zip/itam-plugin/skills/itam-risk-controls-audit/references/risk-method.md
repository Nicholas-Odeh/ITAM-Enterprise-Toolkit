# ITAM risk method

Labels: `FACT`, `STANDARD`, `PRACTICE`, `INFERENCE`, `ASSUMPTION`, `RECOMMENDATION`, `VERIFY`, `PROVISIONAL`. Adapted from RiskForge §3, §8–9, §18–22.

## Contents
1. Writing a risk
2. Starter ITAM risk catalog
3. Rating: precedence and the provisional scale
4. Inherent, residual and target risk
5. Treatment
6. Risk acceptance and exceptions
7. Key risk indicators
8. Register columns

## 1. Writing a risk

> Because of **[cause / condition]**, **[risk event]** may occur, resulting in **[impact on objective]**.

Attach: business objective, process, asset population or service, cause, event, impact types (financial, operational, compliance, security, service, reputational), risk owner. Avoid generic risks such as "poor data quality"; say what goes wrong for whom.

Develop at least one less-obvious scenario when the obvious one could hide a different failure mode (RiskForge §8.4).

## 2. Starter ITAM risk catalog (`PRACTICE`; adapt, don't copy blindly)

| ID | Cause / condition | Event | Impact |
|---|---|---|---|
| R-INV-01 | Discovery does not cover all networks or device types | Unknown devices operate unmanaged | Unpatched devices exploited; incident scope unknown. Lack of asset identification is described as the top threat to information security (CAMP M:88) |
| R-INV-02 | No reconciliation between discovery, repository and finance | Ghost assets on the books; zombie devices in use | Misstated fixed assets; wasted spend; audit finding |
| R-JML-01 | HR leaver events not linked to asset recovery | Devices not returned | Asset loss; data exposure; license cost continues |
| R-STK-01 | Stockroom access and counts not controlled | Shrinkage or theft from stock | Financial loss; data exposure if used devices are stored |
| R-SW-01 | Installs and SaaS sign-ups bypass the request process | Unlicensed or unauthorized software | Audit settlement; malware; data leakage (CAMP M:90–91) |
| R-SW-02 | Entitlement records lack proof of purchase | Rights cannot be proven in an audit | Paying again for rights already owned |
| R-SAAS-01 | SaaS subscriptions bought on cards, without owners | Orphaned subscriptions and data | Spend leakage; data held by unknown vendors |
| R-DIS-01 | Sanitization not verified per serial | Device leaves with recoverable data | Breach notification, regulatory penalty, reputational harm |
| R-DIS-02 | ITAD vendor not overseen | Illegal export or dumping; unreported loss | Environmental and legal liability (CAMP M:77) |
| R-LIF-01 | End-of-support assets not tracked | Unsupported systems remain in critical services | Outage or security exposure; emergency spend |
| R-FIN-01 | Asset register and fixed-asset ledger diverge | Depreciation and disposals misstated | Financial reporting error; SOX/ITGC deficiency |
| R-GOV-01 | Exceptions approved without expiry | Temporary exceptions become permanent practice | Control erosion (RiskForge §21) |
| R-DATA-01 | ITAM repository access and changes uncontrolled | Records altered without trace | Evidence unreliable; audit reliance withdrawn |
| R-MOB-01 | Mobile and BYOD devices outside management | Corporate data on unmanaged devices | Data leakage (CAMP M:90–91) |

## 3. Rating: precedence and the provisional scale

Precedence (RiskForge §9.1): organization-defined methodology → mandated methodology → approved program methodology → provisional.

If no methodology is supplied, use the scale below, label every rating `PROVISIONAL`, and list what is needed to make it official (approved scale, impact thresholds, appetite, owner sign-off). Avoid arbitrary precision.

**Likelihood (PROVISIONAL)**

| Level | Descriptor | Guide |
|---|---|---|
| 1 | Rare | Not expected in the planning horizon |
| 2 | Unlikely | Could occur; no recent history |
| 3 | Possible | Has occurred in the sector or once internally |
| 4 | Likely | Has occurred internally more than once |
| 5 | Almost certain | Occurring now or expected within the period |

**Impact (PROVISIONAL)**: score each relevant dimension and take the highest. Money thresholds are organization values; do not invent them.

| Level | Financial | Compliance / legal | Security / privacy | Service |
|---|---|---|---|---|
| 1 | < [org] | Minor internal policy breach | No sensitive data | No user-visible effect |
| 2 | [org]–[org] | Reportable internally | Limited internal data | Minor degradation |
| 3 | [org]–[org] | External audit finding | Confidential data, contained | Service degraded for a business unit |
| 4 | [org]–[org] | Regulator or publisher action likely | Regulated data exposed | Critical service outage |
| 5 | > [org] | Penalties, litigation or settlement | Large-scale regulated data breach | Prolonged critical outage |

**Rating bands (PROVISIONAL):** score = likelihood × impact; 1–4 Low, 5–9 Medium, 10–14 High, 15–25 Critical. Show the rationale, not just the number.

## 4. Inherent, residual and target risk

| Term | Meaning | Rule |
|---|---|---|
| Inherent | Risk assuming existing controls are absent or ineffective | Rate before looking at controls |
| Residual | Risk remaining given controls that exist and whose operation is evidenced | Credit only tested or evidenced controls; reflect exceptions and failure history |
| Target | Expected risk once approved treatments are implemented | Never reported as current |

Residual risk is a judgment documented with reasons. Do not reduce inherent scores by a fixed percentage per control unless the organization's method says so. A control rated "not tested" gives no residual credit.

## 5. Treatment

Options: avoid, reduce, transfer / share, accept, monitor, escalate (RiskForge §18). For each treatment: action, rationale, expected risk reduction, owner, cost / effort (estimate labeled), dependencies, target date, success criteria, validation method, risk if delayed. Check proportionality: the cost and complexity of the treatment should fit the risk reduced.

Prioritize with residual risk, appetite breach, regulatory requirement, exposure population, velocity, effort and dependencies. Do not mark everything high (RiskForge §19).

## 6. Risk acceptance and exceptions

Record (RiskForge §21): risk / exception ID, scope, business justification, affected control, residual risk, compensating controls, conditions, owner, approver and their authority, start, expiry, review cadence, monitoring, revocation triggers. Expired exceptions are governance issues. Acceptance must come from someone with authority to accept that level of risk; record the source of that authority (policy or delegation).

## 7. Key risk indicators

For each KRI (RiskForge §22): ID, risk ID, metric with numerator and denominator, data source, owner, frequency, baseline, warning and critical thresholds ([org] unless supplied), direction of concern, escalation trigger, response, audience.

Example KRIs (`PRACTICE`; thresholds are fill-in):

| KRI | Risk |
|---|---|
| Devices seen by discovery but absent from the repository, count and age | R-INV-01 |
| Leaver devices unrecovered after [org: N] days | R-JML-01 |
| Unauthorized software titles detected per period | R-SW-01 |
| Disposed serials without serial-level certificate after [org: N] days | R-DIS-01 |
| Exceptions past expiry | R-GOV-01 |
| Assets past end of support in critical services | R-LIF-01 |

## 8. Register columns

`risk_id | statement | category | objective | asset_or_process | cause | event | impact | inherent_L | inherent_I | inherent_rating | key_controls | control_effectiveness | residual_rating | appetite_status | treatment | target_rating | risk_owner | target_date | status | method (ORG or PROVISIONAL) | last_review`
