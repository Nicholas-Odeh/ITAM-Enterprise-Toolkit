---
name: itam-risk-controls-audit
description: Use when building an ITAM risk register or control library (RCM), testing whether asset controls work, preparing for an internal, SOX/ITGC or certification audit, answering a PBC list or finding, tracking audit dates, evidence or regulatory obligations, or mapping controls to CIS, NIST CSF, ISO/IEC 19770-1 or SOX. Covers risk ratings, controls, testing, audit calendar, evidence, gap analysis. Not for publisher license audits (use itam-software-license-management) change-request impact and rollback (use itam-change-request), or QA of a single draft before release (use itam-operating-standard).
---

# ITAM Risk, Controls and Audit

Turn ITAM weaknesses into risk statements, controls that leave evidence, tests that prove they work, and an audit trail from requirement to closure. For ITAM managers, control owners, auditors and compliance teams. In CAMP, Compliance Management is the focal point for audit response (CAMP M:40–41).

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Inherent, residual and target risk stay separate.** Residual risk credits only controls with evidence of operation; planned remediation changes target risk, never current residual (RiskForge §3.4).
7. **A documented control is not an effective control.** Judge design and operating effectiveness separately; operating effectiveness needs evidence from the period under review (RiskForge §3.2).
8. **The organization's methodology comes first.** Use its risk scale, appetite, sampling and deficiency definitions; otherwise label ratings `PROVISIONAL`. Auditors and management decide deficiency severity; compliance conclusions are not legal advice.

## When to use

- Risk register, rating, acceptance, KRIs.
- Control library, RCM; control testing, findings, management responses.
- Upcoming audit, PBC list, audit calendar, evidence register, gap analysis.
- Obligation register; framework mapping.

**When not to use:** publisher license audits → `itam-software-license-management`; impact, risk and rollback for a specific change → `itam-change-request`; disposal evidence → `itam-secure-disposition`; fixing the process behind a finding → `itam-process-improvement`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| Risk identification, rating, acceptance, KRIs | `references/risk-method.md` |
| Control design, library, RCM | `references/control-library.md` |
| Control testing and findings | `references/control-testing.md` |
| Audit readiness, PBC, responses, remediation | `references/audit-readiness.md` §1–6 |
| Control inventory, audit calendar, evidence register, gap analysis | `references/audit-readiness.md` §7 |
| Obligations and legislation | `references/compliance-legislation.md` |
| Framework mapping | `references/framework-mapping.md` |

Read `templates/company-profile.md` at the plugin root if present.

### Step 2 — Preflight

Confirm or label (RiskForge §7): decision and audience; scope and period; the organization's methodology; existing controls and evidence locations; frameworks with editions. No methodology → labeled provisional scale. No evidence of operation → conclude on design only.

### Step 3 — Do the work

State risks as cause–event–impact → rate inherent, residual, target → define controls with evidence and test steps → test design, then operation → trace Requirement → Risk → Control → Test → Evidence → Finding → Closure, listing uncontrolled risks and single-control dependencies → keep the four compliance-tracking registers current (`audit-readiness.md` §7).

### Step 4 — Verify before release

- ★ Inherent, residual and target risk are distinct; no planned action reduces current residual.
- ★ Every operating-effectiveness conclusion cites evidence from the period, or reads "not tested" / "design only".
- ★ Ratings follow the organization's method or are labeled `PROVISIONAL`.
- ★ No framework clause, legal requirement or compliance status without a source or `VERIFY`.
- ★ Critical control failures stand alone, not averaged into a score.
- Non-blocking checks in `audit-readiness.md` §8 are done.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The policy says it, so the control is effective" | A description is design at most. Effective needs tested evidence for the period. |
| "The fix is planned, so residual risk is lower" | Planned work changes target risk only. |
| "That control resembles the requirement, mark it compliant" | Compliant needs mapped evidence of operation. |
| "The evidence probably exists" | Unlocated evidence is `MISSING`; report the gap. |

Stop if you are about to: call a control effective without period evidence; cite a clause from memory; pick samples to get a clean result; assign deficiency severity yourself.

## Common mistakes

| Mistake | Fix |
|---|---|
| Risks as vague topics ("asset data") | Cause–event–impact form, with an owner. |
| Owner listed as "IT" | Name risk owner, control owner and performer. |
| Evidence gaps reported as control failures | Report "not demonstrated" apart from "failed". |
| Audit dates in someone's head | Audit calendar with back-calculated milestones. |

## If connectors are available

- **~~ITSM / ~~CMDB:** read populations and control execution records; keep the query.
- **~~document repository:** read evidence and dates; draft the evidence register.
- **~~project tracker / ~~email:** draft remediation tasks and evidence requests; nothing sent without approval.

## Output format

Only the parts the request needs:

1. **Summary:** conclusion, confidence, limitations.
2. **Risk register:** ID | statement | inherent | controls | residual | appetite | treatment | owner.
3. **RCM or control inventory** with design and operating results.
4. **Audit calendar, evidence register or gap analysis** (§7 templates).
5. **Findings and remediation tracker; assumptions and evidence gaps.**

Executive variant: `audit-readiness.md` §8.

## Reference files

- `references/risk-method.md`: stating, rating, treating or accepting risks; starter catalog.
- `references/control-library.md`: designing controls or an RCM.
- `references/control-testing.md`: tests, sampling, results, finding format.
- `references/audit-readiness.md`: readiness and response; §7 compliance tracking and audit calendar.
- `references/compliance-legislation.md`: obligation register, new laws.
- `references/framework-mapping.md`: CIS, NIST CSF, SP 1800-5, ISO/IEC 19770-1, SOX ITGC (verify clauses).
