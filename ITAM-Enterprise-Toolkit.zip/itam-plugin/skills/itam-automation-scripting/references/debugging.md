# Debugging scripts and integrations: root cause before fix

Adapted from the Superpowers `systematic-debugging` skill for ITAM scripts, scheduled jobs and integrations (Graph, Intune, ServiceNow, CSV pipelines). The method is general practice (`PRACTICE`); product behavior cited is labeled `DOC` with its source or `VENDOR — VERIFY`.

## Contents
1. The rule
2. Phase 1: investigate
3. Phase 2: compare with what works
4. Phase 3: one hypothesis at a time
5. Phase 4: fix with a failing case first
6. ITAM-specific failure patterns
7. Rationalizations and what to do instead
8. Debug log template

## 1. The rule

**No fix without a root cause and a failing case.** A fix proposed before the investigation is a guess, and a guess that "works" on a data job can still corrupt records silently. This applies most when there is time pressure, when the fix looks obvious, and when a previous fix didn't work.

## 2. Phase 1: investigate

1. **Read the error fully.** The whole message, stack trace, HTTP status and response body (redacted), line numbers, error codes and the record key it failed on. Many errors name the fix.
2. **Reproduce it.** Same input, same identity, same environment, ideally on a small slice (one device, one page, one CSV row). If it doesn't reproduce, collect more data (run log, input file, timestamps) before changing anything.
3. **Check recent changes.** Script version and diff; module or package versions; API version or endpoint changes; permission or consent changes; credential or certificate expiry; source file layout (new columns, renamed headers, encoding, delimiter); platform upgrades; who ran it and from where.
4. **Instrument the boundaries** of a multi-step job before guessing which step fails. For each stage (fetch → land → normalize → match → write), log what goes in and what comes out: row counts, key samples, null counts, page counts. One instrumented run shows which boundary loses or mangles data.
5. **Trace the bad value back to its source.** Where did the wrong serial, duplicate row or empty field first appear? Keep tracing upstream until you reach where it was created, and fix it there, not where it surfaced.

## 3. Phase 2: compare with what works

- Find a working example: last week's successful run, the same call in Graph Explorer or the REST API Explorer, a sibling job that handles a similar source.
- List every difference between working and broken (input, identity, parameters, version, time window, data shape), however small.
- If the job follows a documented pattern (paging, retries, import sets), re-read the pattern completely before adapting it.

## 4. Phase 3: one hypothesis at a time

- Write it down: "I think X is the cause because Y."
- Test it with the smallest change, one variable at a time, on the reproduction slice, read-only where possible.
- Confirmed → Phase 4. Not confirmed → a new hypothesis; don't stack a second change on the first.
- If you don't understand something, say so and say what would settle it.

## 5. Phase 4: fix with a failing case first

1. **Failing case first:** the smallest input that reproduces the defect, as a test (`test-checklist.md` §3) or a one-off script. Show it fails.
2. **One fix** for the identified cause. No bundled refactoring or "while I'm here" changes.
3. **Verify:** the failing case passes, adjacent tests still pass, and a dry run on real-shaped data shows the expected counts. Report `PASS`, `FAIL` or `NOT EXECUTED` honestly.
4. **Keep the failing case** as a permanent regression test.
5. **Three failed fixes → stop.** If each fix reveals a new problem somewhere else, question the design (wrong key, wrong source of truth, wrong pattern) and discuss it with the user before a fourth attempt.

When the cause really is external (a vendor outage, throttling, an upstream data defect you don't own): record what was investigated, add the right handling (retry with backoff, clearer error, quarantine of bad rows), add monitoring, and raise it with the owner.

## 6. ITAM-specific failure patterns

| Symptom | Causes to test first |
|---|---|
| Fewer rows than the console shows | Paging stopped early (next link ignored, `$top` treated as total); filter evaluated in the wrong time zone; throttled page returned empty (`integration-patterns.md` §3) |
| Duplicate devices | Serial not normalized (case, spaces, separators, placeholder serials); hostname used as key; same device from two sources; re-run not idempotent |
| Every record "changed" on each run | Comparing raw vs. normalized values; date/time zone formatting; trailing spaces; field type mismatch |
| 401 / 403 after weeks of working | Certificate or secret expired; consent or permission removed; Conditional Access change (`VENDOR — VERIFY`) |
| 429 or 503 bursts | Throttling; missing `Retry-After` handling; parallel runs overlapping |
| Garbled names or broken columns | Encoding (UTF-8 vs. BOM vs. ANSI), delimiter, quoted commas, Excel reformatting serials as numbers |
| ServiceNow import loads but target fields stay empty | Transform map field mapping or coalesce field; choice values not matching; check each import set row's state and error comment first (`VENDOR — VERIFY` field names; see `servicenow-itam` `references/query-script-patterns.md`) |
| ServiceNow update "succeeds" but related records don't follow | A business rule or flow expected to run didn't, or ran in a different order; check the record's audit history and system log before changing code |

**Never "fix" by bypassing the platform.** In ServiceNow, `GlideRecord.setWorkflow(false)` disables business rules, script engines and audits for that operation (`DOC`: api-reference/server-api-reference/c_GlideRecordScopedAPI.md, brazil branch, as checked 2026-10-20). Rerunning a failing update with it can skip the rules that keep related records consistent (for example asset–CI synchronization, `VENDOR — VERIFY` on your instance) and leaves no audit trail. It is a design decision for the platform owner, never a debugging shortcut.

## 7. Rationalizations and what to do instead

| Thought | Do instead |
|---|---|
| "Quick fix now, investigate later" | Investigate now; the quick fix becomes permanent. |
| "Just rerun it with `setWorkflow(false)`" | Find why the business rule blocks or fails; bypassing it skips rules and audit. |
| "Hard-code the credential to rule out auth" | Never. Test auth separately with the approved identity and a secret store. |
| "Bump the retry count until it passes" | Find what fails; retries hide defects and amplify throttling. |
| "Try a few changes and see" | One hypothesis, one change. |
| "It worked on my sample, ship it" | Prove it on the failing case and on a dry run of real-shaped data. |
| "One more fix" after two failures | Stop and question the design. |

## 8. Debug log template

```
Symptom (exact error, record key, run ID):
Reproduced? (input slice, environment, identity):
Recent changes checked:
Boundary counts (fetch / land / normalize / match / write):
Hypothesis 1: ... Test: ... Result:
Root cause (evidence):
Failing case (test name or script):
Fix (one change):
Verification (commands, results, status):
Regression test kept at:
```
