# Integration patterns for ITAM data

Patterns for getting asset-relevant data in and out of systems reliably: CSV and API ingestion, paging, retries, idempotency, pipeline stages, and Microsoft Graph queries for Intune, Entra ID and Autopilot. Endpoints and permissions listed are ones in common, documented use; anything marked `VERIFY` must be checked against current Microsoft Graph documentation (endpoint version, permission name, property availability) before use. Never invent an endpoint, property or permission; if one is needed and not listed, look it up or ask.

**Contents:** 1. Pipeline stages · 2. CSV and spreadsheet-export ingestion · 3. API ingestion · 4. Microsoft Graph for device and user data · 5. Authentication patterns (choose what the organization approves) · 6. ServiceNow · 7. Scheduling and monitoring

## 1. Pipeline stages

```
extract → land raw (unchanged, timestamped) → validate → normalize → match / reconcile
        → stage proposed changes → review / approve → load (safe-write) → report
```

- **Land raw** data exactly as received, with source, extract time (UTC) and run ID. It's the evidence trail and lets you re-run later stages without re-extracting.
- **Validate** schema and values; quarantine bad rows with a reason code; never drop them silently.
- **Normalize** into a separate table or file (serials, model names, manufacturer aliases, user identifiers, dates).
- **Match** on stable keys (normalized serial + manufacturer; directory object IDs for users), then classify exceptions (see itam-inventory-reconciliation if installed).
- **Stage** the proposed changes as a reviewable file before any write.
- **Load** with the safe-write pattern in `code-standards.md`.

## 2. CSV and spreadsheet-export ingestion

- Confirm encoding (UTF-8 with or without BOM, or a legacy code page), delimiter, quote character, header row, and date and number formats (decimal comma?). Excel exports often add a BOM; read with `utf-8-sig` in Python.
- Map source headers to canonical field names in a configuration table, not in code. Fail if a required header is missing; warn on unexpected extra headers.
- Treat cells as untrusted. When writing CSVs people will open in Excel, neutralize text cells that start with `=`, `+`, `-` or `@` (for example by prefixing `'`) to prevent formula injection; leave genuine numeric fields alone.
- Detect duplicates within the file on the normalized key before loading.
- Record row counts in, accepted, quarantined, and the hash or size of the source file.

## 3. API ingestion

### Paging
| Style | How to page | Stop when |
|---|---|---|
| Next-link (Microsoft Graph `@odata.nextLink`) | request the returned link exactly as given | no next link in the response |
| Offset / limit (for example ServiceNow `sysparm_offset` / `sysparm_limit`) | increase offset by limit | a page returns fewer rows than the limit |
| Cursor / token | pass the returned cursor | cursor empty |
| `Link` header (RFC 8288 style) | follow `rel="next"` | no next relation |

Always set a maximum page count to catch loops. Don't construct next-page URLs yourself when the API gives you one.

### Retries, throttling and timeouts
- Timeout on every request.
- Retry only idempotent requests (GET, or writes protected by an idempotency key) and only on transient errors: 429, 500, 502, 503, 504, connection resets.
- Honour `Retry-After` (Microsoft Graph returns it with 429 throttling responses); otherwise exponential backoff with jitter, capped, with a maximum attempt count.
- Never retry 400, 401 (fix auth), 403 (fix permissions) or 404 blindly.
- Reduce load first: request only needed fields (`$select`, `sysparm_fields`), filter server-side, and avoid per-record calls where a list call works.

### Idempotency and incremental loads
- Upsert on a natural key; re-running a job must not duplicate records.
- Use a watermark (last successful run time or a delta token where the API provides one) for incremental loads, and store it only after the run commits.
- Tag each run with an ID; record what each run changed so it can be reversed.
- Make writes conditional where the target allows it (compare current value with the before-image; skip if someone else changed it).

### Tested Python helper (standard library; tested against a local mock server)

```python
import json
import random
import time
import urllib.error
import urllib.request

RETRYABLE = {429, 500, 502, 503, 504}


def get_json(url: str, token: str, timeout: float = 30, max_retries: int = 5) -> dict:
    """GET a JSON document with a timeout and bounded, backed-off retries."""
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}",
                                               "Accept": "application/json"})
    for attempt in range(max_retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.load(resp)
        except urllib.error.HTTPError as exc:
            if exc.code not in RETRYABLE or attempt == max_retries:
                raise
            retry_after = exc.headers.get("Retry-After", "")
            delay = float(retry_after) if retry_after.isdigit() else min(60, 2 ** attempt)
        except urllib.error.URLError:
            if attempt == max_retries:
                raise
            delay = min(60, 2 ** attempt)
        time.sleep(delay + random.uniform(0, 1))  # jitter spreads out retries
    raise RuntimeError("unreachable")


def get_all(url: str, token: str, max_pages: int = 10_000):
    """Yield every item of a collection, following @odata.nextLink until it is absent."""
    for _ in range(max_pages):
        page = get_json(url, token)
        yield from page.get("value", [])
        url = page.get("@odata.nextLink")
        if not url:
            return
    raise RuntimeError(f"Stopped after {max_pages} pages; check for a paging loop")
```

Use it with a token obtained from an approved method (section 5). Don't log the token or the full request headers.

## 4. Microsoft Graph for device and user data

Base URL `https://graph.microsoft.com/v1.0/`. Prefer `v1.0`; `beta` endpoints can change without notice and should be used only when the user accepts that.

| Data | Request | Typical application permission | Notes |
|---|---|---|---|
| Intune managed devices | `GET /deviceManagement/managedDevices` | `DeviceManagementManagedDevices.Read.All` | Useful properties: `id`, `deviceName`, `serialNumber`, `manufacturer`, `model`, `operatingSystem`, `osVersion`, `userPrincipalName`, `enrolledDateTime`, `lastSyncDateTime`, `complianceState`, `managedDeviceOwnerType`, `azureADDeviceId`. Some properties are returned only when named in `$select` or only in beta: `VERIFY`. Server-side `$filter` support on this collection is limited: `VERIFY` per property, or filter client-side. |
| Entra ID (Azure AD) devices | `GET /devices` | `Device.Read.All` | `id` (directory object ID), `deviceId`, `displayName`, `operatingSystem`, `operatingSystemVersion`, `accountEnabled`, `approximateLastSignInDateTime`, `trustType`, `registrationDateTime`. |
| Users | `GET /users?$select=id,userPrincipalName,displayName,accountEnabled,employeeId,department` | `User.Read.All` | Some filters need advanced query headers (`ConsistencyLevel: eventual` with `$count=true`): `VERIFY` for the filter used. |
| Autopilot device identities | `GET /deviceManagement/windowsAutopilotDeviceIdentities` | `DeviceManagementServiceConfig.Read.All` (`VERIFY`) | `serialNumber`, `model`, `manufacturer`, `groupTag`, `enrollmentState`: `VERIFY` property names and v1.0 availability. |
| Detected (discovered) apps | `GET /deviceManagement/detectedApps` | `DeviceManagementManagedDevices.Read.All` (`VERIFY`) | Inventory signal only; not a license entitlement or an installation count you can audit against without validation. |

**Key joins and gotchas** (`PRACTICE`, based on documented property meanings):
- Intune `managedDevice.azureADDeviceId` matches Entra `device.deviceId`, **not** `device.id`.
- A device can appear in Intune, Entra and Autopilot with different names; join on serial (Intune, Autopilot) and on `deviceId` (Intune ↔ Entra), not on display name.
- Serial numbers can be blank or placeholders for some platforms and virtual machines; normalize and quarantine (see `code-standards.md`).
- Stale-device logic (for example "no sync in N days") uses an N the organization approves; don't invent one.
- Remote actions (wipe, retire, delete, sync) are writes with real impact: they follow the safe-write rules and need named approval, and are out of scope for reporting jobs.

**PowerShell (Microsoft Graph PowerShell SDK; VERIFY module version, v2 assumed):**

```powershell
# App-only sign-in with a certificate; values come from configuration, not literals in code
Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -CertificateThumbprint $Thumbprint -NoWelcome

$props = 'id','deviceName','serialNumber','manufacturer','model','operatingSystem','osVersion',
         'userPrincipalName','lastSyncDateTime','complianceState','azureADDeviceId'
$devices = Get-MgDeviceManagementManagedDevice -All -Property $props | Select-Object $props
$devices | Export-Csv -Path $OutFile -NoTypeInformation -Encoding utf8

# Raw request alternative: single quotes stop PowerShell expanding $select
$page = Invoke-MgGraphRequest -Method GET -Uri 'https://graph.microsoft.com/v1.0/devices?$select=id,deviceId,displayName,approximateLastSignInDateTime' -OutputType PSObject
```

The `-All` switch makes the SDK follow next-links for you. With `Invoke-MgGraphRequest`, follow `@odata.nextLink` yourself.

**Python:** obtain an app-only token with Microsoft's MSAL library (`msal.ConfidentialClientApplication(...).acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])`, certificate credential preferred; `msal` is a third-party package: confirm it is approved), or with a managed identity where the job runs in Azure. Then page with the helper above.

## 5. Authentication patterns (choose what the organization approves)

| Pattern | When | Notes |
|---|---|---|
| Managed / workload identity | job runs on a cloud platform that supports it | no stored secret; preferred where available |
| App registration with certificate | scheduled job on a server | certificate in a protected store; record expiry and rotate |
| App registration with client secret | only if the above aren't possible | secret in a vault; short expiry; never in code |
| Delegated (interactive) sign-in | ad-hoc analyst queries | runs with the user's own rights; not for unattended jobs |

Request only the permissions the job needs (read-only for reporting), and get admin consent through the organization's process. Permission names change occasionally: `VERIFY` in Microsoft Graph documentation.

## 6. ServiceNow

For Table API paging, encoded queries, GlideRecord / GlideAggregate, import sets, transform maps and the ServiceNow safe-write pattern, load the servicenow-itam skill's `references/query-script-patterns.md`. Its rules (read-only by default, bounded queries, no hard-coded sys_ids or choice values, import sets rather than direct inserts) apply alongside this file.

## 7. Scheduling and monitoring

- Run under a dedicated service identity, not a person's account.
- Log run ID, start, end, counts and exit code; alert on non-zero exit, on zero rows where rows are expected, and on counts that move more than an agreed percentage from the last run (threshold set by the owner).
- Keep run outputs per the retention rule; delete raw personal data when it's no longer needed.
- Document the job: owner, schedule, source, target, permissions, rollback, and where its outputs go.
