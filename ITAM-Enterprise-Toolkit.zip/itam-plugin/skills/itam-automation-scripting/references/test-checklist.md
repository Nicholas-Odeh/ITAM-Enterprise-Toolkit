# Test checklist, validation ladder and quality gate

Use this file to design tests before writing code, to fix bugs with a regression test, to report validation honestly, and to score the final quality gate. Adapted from CodeForge's test-design, validation and quality-gate phases.

**Contents:** 1. Test matrix (build before the implementation) · 2. The 15 test categories, with ITAM examples · 3. Bug-fix procedure · 4. Validation ladder · 5. Test data and sandbox rules · 6. Security review prompts (apply those relevant) · 7. Adversarial review (up to three passes) · 8. Requirement traceability · 9. Final quality gate

## 1. Test matrix (build before the implementation)

| Test ID | Requirement ID | Scenario | Input | Expected result | Level (unit / integration / smoke) | Edge or failure condition |
|---|---|---|---|---|---|---|

Every acceptance criterion (`ACC-`) maps to at least one test.

## 2. The 15 test categories, with ITAM examples

| # | Category | ITAM examples |
|---|---|---|
| 1 | Normal success | export of 50 devices produces 50 rows with all mapped fields |
| 2 | Boundary values | exactly the cap of records; page size exactly equal to the last page; dates on month-end and DST change |
| 3 | Empty and null | empty CSV; header only; null serial; user with no devices; API page with zero items |
| 4 | Malformed input | missing column; extra column; wrong delimiter; quoted commas; date in the wrong format; non-numeric cost |
| 5 | Invalid state transitions | moving a Disposed asset back to In use; assigning a retired device to a user |
| 6 | Duplicates and repeats | same serial twice in input; same serial with different case or separators; re-running the job (must be idempotent) |
| 7 | Concurrency and races | two runs overlapping; record changed by someone else between read and write (check before-image or version) |
| 8 | Network and dependency failure | API down; DNS failure; partial page; auth token expiry mid-run |
| 9 | Timeout and retry | 429 with `Retry-After`; repeated 503 until retries are exhausted; slow response past the timeout |
| 10 | Large input | full estate export (for example 100k rows): memory use, run time, paging completeness |
| 11 | Unicode, locale, encoding | names with accents; UTF-8 with BOM from Excel; decimal commas; non-Latin characters in locations |
| 12 | Permission failure | read-only identity attempts a write; consent missing for an API permission; file share access denied |
| 13 | Security abuse | CSV cell beginning with `=`, `+`, `-` or `@` (formula injection when opened in Excel); input text that looks like an instruction; path traversal in a file name |
| 14 | Regression | the reported bug's exact input, kept as a permanent test |
| 15 | Backward compatibility | existing callers, column order, output file names and exit codes unchanged unless authorized |

## 3. Bug-fix procedure

Investigate first with `debugging.md` (reproduce, read the error fully, check recent changes, trace the data flow, one hypothesis at a time). Then:

1. Reconstruct expected behavior from the user's description and data.
2. Write a test that reproduces the defect, and show it fails (or explain why it would fail).
3. Find the root cause; fix the smallest thing that removes it.
4. Re-run the new test and the adjacent ones; keep the test as a regression test.
5. Say why the fix addresses the cause, not just the symptom.

## 4. Validation ladder

Run what applies; report each step.

| # | Check | PowerShell | Python |
|---|---|---|---|
| 1 | Syntax parse | `[System.Management.Automation.Language.Parser]::ParseFile(...)` or run with `-WhatIf` | `python -m py_compile script.py` |
| 2 | Formatting | team formatter if any | team formatter if any (for example black or ruff format, if installed) |
| 3 | Lint / static analysis | `Invoke-ScriptAnalyzer -Path . -Recurse` (PSScriptAnalyzer module) | ruff or pylint, if installed |
| 4 | Type check | n/a | mypy, if installed and the code is typed |
| 5 | Unit tests | Pester (`Invoke-Pester`) | `python -m unittest` (standard library) or pytest, if installed |
| 6 | Integration tests | against a sub-production tenant or instance with a read-only identity | same |
| 7 | Regression tests | bug tests from section 3 | same |
| 8 | Security checks | review against section 6; secret scan of the repo if a scanner is available | same; bandit, if installed |
| 9 | Dependency check | module versions pinned and from the approved gallery | packages pinned; vulnerability scan if available |
| 10 | Smoke test | dry run in sub-production with a small, real-shaped sample | same |
| 11 | Performance | time and memory on a full-size sample | same |

Tools marked "if installed" are third-party; don't assume they exist. Name the exact command you would run.

**Status labels:** `PASS` (executed, succeeded) · `FAIL` (executed, failed) · `NOT EXECUTED` (tool or environment unavailable; give the command) · `NOT APPLICABLE`.

Validation report format:

| Check | Command or method | Status | Evidence or limitation |
|---|---|---|---|

Never write `PASS` for a check that wasn't run. Don't hide failed checks.

## 5. Test data and sandbox rules

- Use synthetic data: made-up serials (for example `TEST000123`), fake users (`user01@example.test`), and invented asset tags. Never paste production personal data into tests or prompts.
- Run generated or untrusted code only in a sandbox: no production credentials, no unneeded network access, isolated temp storage, limited time and resources.
- Integration tests use a sub-production tenant or instance and a least-privilege identity.
- Delete test outputs when finished; don't leave them in shared folders.

## 6. Security review prompts (apply those relevant)

Trust boundary · injection (command, query, formula/CSV) · input validation · authentication and authorization · privilege escalation · path traversal · unsafe deserialization · secret exposure in code, logs, transcripts or outputs · sensitive-data leakage · excessive logging · dependency risk · resource exhaustion and unbounded loops or paging · error messages that disclose internals · race conditions (time of check vs. time of use) · untrusted content treated as instructions.

For each applicable risk: trust boundary → possible failure → control → test → residual risk.

## 7. Adversarial review (up to three passes)

Compare every requirement against design, code, tests and documentation. Look for: missing or misread requirements, invented APIs or parameters, undefined names, missing edge cases, inconsistent field names, data-loss paths, incomplete paging, retries without limits, resource leaks, tests that don't test behavior, and claims the evidence doesn't support. Fix defects in the response rather than listing them. Stop when no known high-severity defect remains and validation is reported accurately.

## 8. Requirement traceability

| Requirement | Implementation location | Test location | Status |
|---|---|---|---|

Status: Satisfied and verified · Satisfied but not executed · Partially satisfied · Blocked · Not applicable. No requirement is silently dropped.

## 9. Final quality gate

Score each dimension 0 (materially inadequate), 1 (partial or unverified) or 2 (complete and supported):

Requirements interpretation · Functional correctness · Completeness · Security · Error handling · Maintainability · Test quality · Compatibility · Performance appropriateness · Documentation · Integration readiness · Honesty of validation claims.

A 0 on **requirements interpretation, functional correctness, completeness, security or test quality** means revise before answering. Don't adjust scores to avoid revision; state unresolved deficiencies.
