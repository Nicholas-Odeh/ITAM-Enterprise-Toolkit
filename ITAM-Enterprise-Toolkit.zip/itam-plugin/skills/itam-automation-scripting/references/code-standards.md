# Code standards for ITAM automation

Rules and patterns for PowerShell and Python that touch asset, device, license or user data. They are `PRACTICE` unless stated. Version-specific behavior is noted; confirm against the user's runtime.

**Contents:** 1. Rules for both languages · 2. PowerShell · 3. Python · 4. Safe-write pattern · 5. Secrets and identity · 6. Serial normalization helper (Python, tested)

## 1. Rules for both languages

- **Structure:** a parameterized entry point; small functions with one job; configuration (tenant, URLs, paths, field maps, caps) in parameters or a config file, never scattered literals.
- **Inputs:** validate at the boundary (required columns, types, allowed values, file exists). Reject or quarantine bad rows with a reason rather than guessing.
- **Errors:** fail fast on setup errors (auth, missing config); record and continue on per-record errors, then exit non-zero if any failed. Don't swallow exceptions. Don't print stack traces or raw API error bodies that may contain tokens or personal data.
- **External calls:** timeouts on every call; bounded retries with exponential backoff and jitter on 429 and 5xx; honour `Retry-After`; complete paging (see `integration-patterns.md`).
- **Logging:** structured lines with run ID, step, counts and record keys; no secrets, tokens or full personal records. Log serials and asset tags, not names and emails, unless the user needs them.
- **Outputs:** a data file (CSV, UTF-8, header row) and a summary (JSON or a final line) with counts read, written, rejected, changed and failed.
- **Exit codes:** 0 success; 1 completed with record failures; 2 input or configuration error; other non-zero for setup failure.
- **No dynamic execution** of data: no `Invoke-Expression`, `eval`, `exec`, `shell=True` or string-built commands from input. Use parameterized queries and API filters built with proper encoding.
- **Files:** write to a run folder; never overwrite the input; create temporary files with the language's secure temp APIs.
- **Dependencies:** standard library or modules already approved in the environment. Name any addition and why.

## 2. PowerShell

- Declare the version: `#Requires -Version 5.1` or `7.x`, and modules with `#Requires -Modules`. Behavior differs between Windows PowerShell 5.1 and PowerShell 7 (for example default file encodings), so test on the version that will run it.
- Start scripts with `Set-StrictMode -Version Latest` and `$ErrorActionPreference = 'Stop'`.
- Use `[CmdletBinding(SupportsShouldProcess)]` so `-WhatIf` and `-Confirm` work, and an explicit `-Apply` switch so the default is a dry run.
- Validate parameters with `[ValidateNotNullOrEmpty()]`, `[ValidateSet()]`, `[ValidateRange()]`, `[ValidateScript()]`.
- Use approved verbs (`Get-Verb`) for functions; emit objects, not formatted text; keep `Write-Host` for interactive messages only.
- Wrap collections with `@()` so `.Count` works for zero or one item.
- `Export-Csv -NoTypeInformation`; set `-Encoding` explicitly (`utf8` in 7.x is UTF-8 without BOM; in 5.1 it writes a BOM).
- Use `try { } catch { } finally { }` and `$_.Exception.Message`; rethrow with `throw` when the caller must stop.
- Don't use `Start-Transcript` on jobs that handle tokens or secrets unless the transcript location is protected; it records console output.

## 3. Python

- State the version (for example 3.10+) and use `argparse`, `logging`, `pathlib`, `csv`, `json`, `datetime` with time zones.
- Read CSVs with `newline=""` and `encoding="utf-8-sig"` (handles Excel's BOM); write with `newline=""`.
- Type hints and docstrings on public functions; `if __name__ == "__main__": sys.exit(main())`.
- HTTP with the standard library (`urllib.request`) or an approved package (for example `requests`); always pass a timeout.
- `subprocess.run([...], check=True)` with an argument list, never `shell=True` with input data.
- Use `datetime.now(timezone.utc)`; store ISO 8601 in UTC.

## 4. Safe-write pattern

Every job that changes records follows this shape: **dry run by default → cap → before-image → apply with per-record log → summary → rollback from the before-image**. Run it against sub-production first, then in production with the approved change reference. The two adapter functions are the only system-specific parts; replace them with the target system's read and write calls (for ServiceNow see the servicenow-itam skill's safe-write pattern).

### Python (tested with stubbed adapters on Python 3.13)

```python
#!/usr/bin/env python3
"""Apply one field update per CSV row, with dry run by default, a change cap,
a before-image for rollback, and a per-row change log.

Pattern: replace read_current() and apply_change() with the target system's
read and write calls. Everything else is generic.
"""
import argparse
import csv
import datetime as dt
import json
import logging
import sys
import uuid
from pathlib import Path

REQUIRED_COLUMNS = ("serial_number", "new_value")
log = logging.getLogger("safe_update")


def read_current(key: str) -> dict:
    """Return the record's current values for the fields this job changes."""
    raise NotImplementedError("Adapter: read the record from the target system")


def apply_change(key: str, value: str) -> None:
    """Write one change to the target system; raise on failure."""
    raise NotImplementedError("Adapter: write the change to the target system")


def write_csv(path: Path, rows: list) -> None:
    fields = []
    for row in rows:
        fields += [k for k in row if k not in fields]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input_csv", type=Path, help="CSV with serial_number,new_value")
    p.add_argument("--apply", action="store_true", help="make changes (default: dry run)")
    p.add_argument("--max-changes", type=int, default=200, help="abort if more rows than this")
    p.add_argument("--change-ref", required=True, help="approved change or ticket ID")
    p.add_argument("--out-dir", type=Path, default=Path("runs"))
    args = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    with args.input_csv.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            log.error("Input is missing columns: %s", ", ".join(missing))
            return 2
        rows = list(reader)
    if len(rows) > args.max_changes:
        log.error("%d rows exceeds cap of %d; narrow the input", len(rows), args.max_changes)
        return 2

    run_id = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    for r in rows:
        r["serial_number"], r["new_value"] = r["serial_number"].strip(), r["new_value"].strip()
    before = [{"serial_number": r["serial_number"], **read_current(r["serial_number"])} for r in rows]
    write_csv(args.out_dir / f"{run_id}-before.csv", before)

    results = []
    for r in rows:
        key, value = r["serial_number"], r["new_value"]
        if not args.apply:
            status = "dry-run"
        else:
            try:
                apply_change(key, value)
                status = "changed"
            except Exception as exc:  # system boundary: record the failure, continue
                status = f"failed: {type(exc).__name__}"
                log.warning("Change failed for %s: %s", key, type(exc).__name__)
        results.append({"run_id": run_id, "serial_number": key, "new_value": value,
                        "status": status, "change_ref": args.change_ref,
                        "utc": dt.datetime.now(dt.timezone.utc).isoformat()})
    write_csv(args.out_dir / f"{run_id}-changes.csv", results)

    summary = {"run_id": run_id, "mode": "apply" if args.apply else "dry-run",
               "rows": len(rows),
               "changed": sum(r["status"] == "changed" for r in results),
               "failed": sum(r["status"].startswith("failed") for r in results)}
    print(json.dumps(summary))
    return 1 if summary["failed"] else 0


if __name__ == "__main__":
    sys.exit(main())
```

Rollback: review the `*-before.csv` file, rename its changed column to `new_value`, and run the same script with `--apply` and a new change reference.

### PowerShell (pattern; NOT EXECUTED here, run Pester and PSScriptAnalyzer before use)

```powershell
#Requires -Version 7.2
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][ValidateScript({ Test-Path $_ -PathType Leaf })][string]$InputCsv,
    [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$ChangeReference,
    [ValidateRange(1, 5000)][int]$MaxChanges = 200,
    [string]$OutputDir = (Join-Path -Path $PWD -ChildPath 'runs'),
    [switch]$Apply
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-CurrentRecord { param([string]$Key) throw 'Adapter: read the record from the target system' }
function Set-RecordValue  { param([string]$Key, [string]$Value) throw 'Adapter: write the change' }

$rows = @(Import-Csv -Path $InputCsv)
foreach ($col in 'serial_number', 'new_value') {
    if ($rows.Count -gt 0 -and -not ($rows[0].PSObject.Properties.Name -contains $col)) {
        throw "Input is missing column '$col'."
    }
}
if ($rows.Count -eq 0) { Write-Warning 'Input has no rows; nothing to do.'; exit 0 }
if ($rows.Count -gt $MaxChanges) { throw "Input has $($rows.Count) rows; cap is $MaxChanges. Narrow the input." }

$runId = '{0}-{1}' -f (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ'), ([guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

$before = foreach ($r in $rows) { Get-CurrentRecord -Key $r.serial_number.Trim() }
$before | Export-Csv -Path (Join-Path $OutputDir "$runId-before.csv") -NoTypeInformation -Encoding utf8

$results = foreach ($r in $rows) {
    $key = $r.serial_number.Trim(); $value = $r.new_value.Trim()
    $status = 'dry-run'
    if ($Apply -and $PSCmdlet.ShouldProcess($key, "Set value to '$value'")) {
        try   { Set-RecordValue -Key $key -Value $value; $status = 'changed' }
        catch { $status = 'failed: ' + $_.Exception.GetType().Name }
    }
    [pscustomobject]@{
        run_id = $runId; serial_number = $key; new_value = $value; status = $status
        change_ref = $ChangeReference; utc = (Get-Date).ToUniversalTime().ToString('o')
    }
}
$results | Export-Csv -Path (Join-Path $OutputDir "$runId-changes.csv") -NoTypeInformation -Encoding utf8

$failed = @($results | Where-Object status -like 'failed*').Count
[pscustomobject]@{ run_id = $runId; mode = $(if ($Apply) { 'apply' } else { 'dry-run' })
    rows = $rows.Count; changed = @($results | Where-Object status -eq 'changed').Count; failed = $failed } |
    ConvertTo-Json -Compress
if ($failed) { exit 1 }
```

### Safe-write checklist
- Dry run is the default and its output shows exactly what would change.
- Hard cap, sized to the approved change; above it the job stops rather than truncating silently.
- Before-image saved before the first write; rollback steps written down.
- Change reference (ticket or approval ID) recorded on every changed row and, where the target supports it, in the record's audit or work notes.
- Business rules, workflows and sync stay on unless the user approves bypassing them with a stated reason.
- Large changes run in batches with a pause and a check between batches.
- Destructive device actions (wipe, retire, delete) require named approval per run and are never looped over a list without it.

## 5. Secrets and identity

- **Where secrets live:** a secret store (for example a cloud key vault, the PowerShell SecretManagement module with an approved vault, or the scheduler's credential store), or a managed identity / workload identity so no secret exists at all. Environment variables injected by the scheduler are acceptable when nothing better is available. VERIFY which options the organization has approved.
- **Prefer certificates or managed identities** over client secrets for app-only API access; rotate whatever is used, and record the expiry.
- **Never** put secrets in code, config files committed to source control, command-line arguments (visible in process lists and logs), CSV outputs, transcripts or chat prompts.
- **Least privilege:** read-only permissions for reporting jobs; separate identities for read and write jobs; scope to the smallest set of resources the platform allows.
- **Personal data:** select only the fields the job needs; mask or drop personal fields in logs; keep output files in access-controlled locations and delete them per retention rules.

## 6. Serial normalization helper (Python, tested)

```python
import re
PLACEHOLDER_SERIALS = {"", "0", "NONE", "NA", "N/A", "DEFAULTSTRING", "TOBEFILLEDBYOEM",
                       "SYSTEMSERIALNUMBER"}

def normalize_serial(raw):
    """Return a comparable serial, or None if it is missing or a known placeholder."""
    if raw is None:
        return None
    s = re.sub(r"[\s\-_.]", "", str(raw)).upper()
    if s in PLACEHOLDER_SERIALS or set(s) <= {"0"}:
        return None
    return s
```

Removing separators is a choice: keep the raw value alongside the normalized one, and check whether any manufacturer in the estate uses hyphens meaningfully before applying it. Extend the placeholder list from values actually seen in the user's discovery data.
