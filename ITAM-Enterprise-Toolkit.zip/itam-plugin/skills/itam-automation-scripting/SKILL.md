---
name: itam-automation-scripting
description: Use when someone asks for a PowerShell or Python script, scheduled job, bulk update, API query or data pipeline for asset, device, license or user data (Graph, Intune, Entra ID, Autopilot, CSV, REST), pastes a script that fails or returns duplicates, or wants code reviewed before production. Covers safe writes, secrets, paging, retries, idempotency, tests, debugging. Not for ServiceNow GlideRecord, Table API or import-set specifics (use servicenow-itam) matching rules and exception codes (use itam-inventory-reconciliation), or SharePoint list and library how-to (use sharepoint-itam-records).
---

# ITAM Automation and Scripting

Correct, secure, testable automation for IT asset data: reads, normalizing pipelines and tightly controlled write-backs. For the engineers who run the code and the reviewers who approve it. Default posture: read-only.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Writes ship gated.** Dry run is the default; hard cap on records changed; before-image for rollback; sub-production test; approval step. Wipe, retire and delete are never automated without named human approval per run.
7. **No secrets anywhere visible.** None in code, tests, logs, examples, command lines, CSVs or prompts. Least-privilege identity and a secret store.
8. **Root cause before fix.** Debug by reproducing, reading the error fully and testing one hypothesis at a time; no fix without a failing case (`references/debugging.md`).

## When to use

- "Pull all Intune devices to CSV", nightly imports, scheduled reports.
- Graph, Entra ID, Autopilot or REST queries; paging and throttling.
- Bulk state, owner or location updates; record retirement.
- "This script fails / times out / returns duplicates."
- Code or security review; test plans.

**When not to use:** ServiceNow GlideRecord, encoded queries, Table API, import sets → `servicenow-itam` (this skill's safe-write and test rules still apply); matching logic and exception codes → `itam-inventory-reconciliation`; change records for a production write → `itam-change-request`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| New script or pipeline | `references/code-standards.md` + `references/integration-patterns.md` |
| API or source integration | `references/integration-patterns.md` |
| Bulk update or write-back | `references/code-standards.md` §4 (safe-write pattern) |
| Bug, failure, unexpected output | `references/debugging.md`, then `references/test-checklist.md` §3 |
| Code or security review; test plan | `references/code-standards.md` + `references/test-checklist.md` |

### Step 2 — Preflight

Specification snapshot (`working-method.md` §1): acceptance criteria, runtime, systems, identity, volumes, sub-production, personal data. Label facts `CONFIRMED`, `ASSUMED`, `UNKNOWN` or `BLOCKING`; ask only about blocking ones (five at most).

### Step 3 — Do the work

Hard rules and method: `working-method.md` §2–4 (no invented APIs, complete code, tests first, key on normalized serial, UTC, idempotent upserts).

**Debugging scripts and integrations.** Before proposing any fix: reproduce on a small slice; read the whole error; check recent changes (versions, permissions, certificates, source layout); instrument each stage boundary; trace the bad value to its source; test one hypothesis at a time; write the failing case, then make one fix. Three failed fixes → stop and question the design (`debugging.md`).

### Step 4 — Verify before release

- ★ Every endpoint, cmdlet, field and permission is from supplied material, known with confidence, or marked `VERIFY`.
- ★ No secret, token or credential appears anywhere in the output.
- ★ Every write path has dry-run default, cap, rollback, sub-production note and approval step.
- ★ Nothing is reported as passing that wasn't executed (`PASS`, `FAIL`, `NOT EXECUTED`).
- ★ A bug fix names its root cause and has a failing case that now passes.
- Non-blocking checks: `working-method.md` §5.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Quick fix now, investigate later" | Find the cause first; quick fixes on data jobs corrupt records quietly. |
| "Just rerun it with `setWorkflow(false)`" | That disables business rules, script engines and audit (`debugging.md` §6). Never a debugging shortcut. |
| "Hard-code the token just to test" | Credentials never go in code, even temporarily. |
| "Small update, skip the dry run" | Every write gets a dry run and a cap. |
| "It worked on 10 rows; it should work" | A sample isn't the run. Unexecuted is `NOT EXECUTED`; dry-run the full set first. |

Stop if you are about to: write without a dry run; trigger a wipe, retire or delete without named approval; stack a second fix on an unconfirmed one.

## Common mistakes

| Mistake | Fix |
|---|---|
| Keying devices on hostname | Normalized serial plus manufacturer. |
| Stopping at the first API page | Follow next links to the end; check totals. |
| Retrying 429s immediately | Honour `Retry-After`, back off with jitter. |
| Editing raw extracts in place | Land raw, normalize in a separate stage. |

## If connectors are available

- **~~endpoint management / ~~CMDB / ~~ITSM:** read sample records to confirm field names; writes are drafted as a dry-run diff for approval.
- **~~document repository / ~~project tracker:** read the job's runbook; draft updates and tasks.

## Output format

1. **Specification snapshot and short design.**
2. **Complete code and tests.**
3. **Run commands,** dry run first.
4. **Validation report:** check · command · status.
5. **Security, residual risk, assumptions.**

For a bug: the debug log, failing case, fix and verification. Full structure and reviewer variant: `working-method.md` §6.

## Reference files

- `references/working-method.md`: specification, hard rules, ITAM data idioms, deliverables.
- `references/code-standards.md`: before writing or reviewing code; safe-write pattern, secrets.
- `references/integration-patterns.md`: ingestion, paging, retries, Graph, auth, scheduling.
- `references/test-checklist.md`: test matrix, bug-fix procedure, validation, quality gate.
- `references/debugging.md`: any failing script or integration.
