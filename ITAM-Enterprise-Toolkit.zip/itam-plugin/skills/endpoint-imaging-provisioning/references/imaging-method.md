# Imaging and provisioning: preflight and working method

Detail behind Steps 2 and 3 of `endpoint-imaging-provisioning`. Read it for any build standard, method decision, handoff design or bench measurement that others will use. Content is `PRACTICE` unless cited; product behavior is `VENDOR — VERIFY` except the Graph names confirmed in `provisioning-methods.md` §11.

## Contents
1. Preflight checklist
2. Build standards
3. Method selection
4. Model and baseline control
5. Enrollment registration hygiene
6. Asset record handoff
7. Reimage on redeploy
8. Bench throughput
9. Output variants

## 1. Preflight checklist

Read `templates/company-profile.md` at the plugin root if present, and `asset-data-model.md` (shared copy; canonical lifecycle states). Then confirm, or assume and label:
- **Tooling:** Autopilot + Intune, MECM, co-management, Jamf or another Mac MDM, Android Enterprise mode, any OEM factory provisioning service. This changes almost everything; if unknown, ask.
- **Join and identity model:** Entra ID joined or hybrid joined; Mac directory binding or none.
- **Platforms, models and volumes:** the supported model list (from the profile or an asset export), not a guessed one.
- **Registration path:** who registers hardware hashes or ABM device assignments (OEM, reseller, internal), and when.
- **Where versions live:** the image or build register, the change process, and who approves a new build.
- **Lifecycle mapping:** which asset state and substate means "configured/ready" in their system (ServiceNow details: `servicenow-itam`).
- **Bench context:** locations, technicians, network (PXE, bandwidth, content caching), shifts, and current volumes if metrics are wanted.

## 2. Build standards

One build per platform and persona, defined as layers: OS edition and version, baseline configuration and security policy, security agents, core apps, language and region, drivers and firmware. Give each build an ID and version (scheme in `build-standard.md`), an owner, a status (pilot, current, sustaining, retired) and an effective date. Changes go through change control and a pilot ring before becoming current. A pre-approved standard configuration is an asset standard in IAITAM terms (CAMP M:119; CAMP S:69), so the build catalog and the hardware catalog should reference each other.

## 3. Method selection

Compare options on: device ownership path (new from OEM vs. recovered), network location (office, home, remote site), time-to-desk, technician touch, offline or air-gapped needs, app payload size, hybrid-join dependency, and regulatory or line-of-business constraints. Present the trade-off, not a verdict, unless the user's constraints decide it. Per-method prerequisites to verify: `provisioning-methods.md`.

## 4. Model and baseline control

Every supported model has a row in the model-driver matrix: approved BIOS/UEFI and firmware versions, the driver source and update method, settings (Secure Boot, TPM, BIOS password), known issues and status. A model without a row is not ready to deploy. Onboarding a new model is a mini change: pilot units, validation pass, row added, catalog updated (`model-driver-matrix.md`).

## 5. Enrollment registration hygiene

The serials registered in Autopilot, ABM/ASM or zero-touch portals should reconcile to ITAM records. Registered serials with no asset record, and active assets with no registration, are both exceptions. Hand bulk matching to `itam-inventory-reconciliation`; the Graph resources that expose registered serials are listed in `provisioning-methods.md` §11. Deregistration is a step in disposal, sale, lease return and some RMA swaps (SKILL rule 8).

## 6. Asset record handoff

Imaging is where ITAM data is most often lost. At build start, the asset is already received and tagged (`itam-logistics-warehouse`). At a validation pass, record against the asset: build ID and version, validation result and checklist version, technician, date, and the ticket or order. Then move the asset to the state and substate that means configured/ready (the canonical `IN_STOCK/READY_TO_DEPLOY`, transition T05a in `asset-data-model.md`, mapped to the user's system; `VERIFY` the mapping). A failed build moves it to a defective or rework substate with the failure reason, never back to plain available stock.

## 7. Reimage on redeploy

Use the decision table in `build-standard.md` §8. Rule of thumb: a device changing hands internally is rebuilt to the current build, not handed over as-is; a device leaving control goes to `itam-secure-disposition`; a device kept by the same user after repair is validated, not necessarily rebuilt. Reimaging with volume-license media can depend on reimaging rights in the license agreement (CAMP M:149); confirm with `itam-software-license-management`.

## 8. Bench throughput

Measure, don't assume: builds completed per technician per shift, build cycle time, first-pass yield, rework rate, failure reasons, queue age, and time from receipt to ready. Definitions: `validation-checklist.md` §8. Targets come from the user (`[FILL]`); never invent them. Forecasting how many technicians, benches or shifts future volumes need belongs to `itam-capacity-planning`, which uses these measures as inputs.

## 9. Output variants

**Default:** answer (two to five sentences); the standard, procedure, checklist, matrix rows or method comparison, labeled; assumptions and VERIFY list (each vendor fact and where to confirm it; each `[FILL]` value and its owner); risks (data loss, devices stuck in tenant registration, unlicensed reimaging, unmanaged devices reaching users, ITAM records drifting from reality).

**Executive variant:** lead with time-to-ready, technician hours, rework cost and security exposure; technical detail in an appendix.

**Practitioner variant:** checklists and numbered steps a technician can follow at the bench.
