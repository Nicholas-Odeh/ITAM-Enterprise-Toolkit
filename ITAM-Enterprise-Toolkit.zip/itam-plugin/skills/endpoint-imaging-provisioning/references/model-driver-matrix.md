# Model, driver and firmware matrix (template)

Content is `PRACTICE`. Every version, model string and tool name below must come from the organization or the OEM. Leave `[FILL]` visible rather than guessing. OEM tool names given as examples are `VENDOR — VERIFY`.

## Contents
1. Matrix columns
2. Matrix (template rows)
3. Model identification strings
4. New-model onboarding procedure
5. Baseline update cadence
6. Drift detection
7. End of support

## 1. Matrix columns

| Column | Meaning |
|---|---|
| Model ID | Internal key; matches the hardware model record in the ITAM system |
| Manufacturer / marketing name | As the OEM sells it |
| Model string (system) | Exactly what the device reports (see section 3); used for driver mapping and discovery normalization |
| Platform family | Windows laptop, Windows desktop, Mac, tablet, phone, rugged |
| Status | Pilot · Supported (orderable) · Sustaining (in service, not orderable) · Retired |
| Supported builds | Build IDs from `build-standard.md` |
| Supported OS releases | [FILL — VERIFY with OEM support matrix] |
| BIOS/UEFI baseline | Approved version |
| Firmware baselines | Dock, Thunderbolt/USB-C controller, SSD, TPM, embedded controller, as relevant |
| BIOS/UEFI settings | Secure Boot, TPM state, boot order, BIOS admin password set, virtualization, wake settings |
| Driver source | OEM driver pack, Windows Update, MECM package, MDM-managed |
| Driver update method | OEM tool, Windows Update for Business driver policies, MECM, none |
| Known issues | With ticket references |
| Validation evidence | Ring 0 result, date |
| Onboarded / end of sale / end of support | Dates [FILL] |
| Owner | EUC engineer accountable for the row |

## 2. Matrix (template rows)

| Model ID | Mfr / name | Model string | Family | Status | Builds | OS releases | BIOS baseline | Firmware baselines | Settings profile | Driver source | Update method | Known issues | Evidence | Onboarded | EoS | Owner |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| [FILL] | [FILL] | [FILL] | Windows laptop | Supported | WIN-STD | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| [FILL] | [FILL] | [FILL] | Mac | Supported | MAC-STD | [FILL] | n/a (OS-managed) | n/a | n/a | OS-managed | MDM OS updates | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |

Keep the matrix where the build register lives [FILL]. The ITAM hardware model record should carry the same Model ID so the asset, the catalog and the driver mapping agree.

## 3. Model identification strings

Driver mapping and discovery normalization fail most often on model strings. Capture, for each model, what the device actually reports:

- **Windows:** the `Model` and `Manufacturer` properties of `Win32_ComputerSystem`, and `Name`/`Version` of `Win32_ComputerSystemProduct`. Some OEMs put a machine-type code in one field and the friendly name in another (`VENDOR — VERIFY` per OEM). Some also expose a system SKU or baseboard product code that is more stable for mapping.
- **macOS:** the model identifier reported by the system (for example in System Information); marketing names are not unique enough.
- **Mobile:** model and manufacturer as reported to MDM; IMEI/serial for the asset itself.

Record the exact strings in the matrix and reuse them in task sequence conditions, MDM filters and ITAM normalization rules (`servicenow-itam` for model normalization in ServiceNow).

## 4. New-model onboarding procedure

| Step | Action | Evidence | Gate |
|---|---|---|---|
| 1 | Model approved for the hardware catalog (`itam-acquisition-procurement`) | Catalog decision | ★ Not approved → stop |
| 2 | Obtain pilot units; tag and receive as normal assets | Asset records | — |
| 3 | Capture model strings; create matrix row in Pilot status | Matrix row | — |
| 4 | Set BIOS/UEFI and firmware to the chosen baseline; record versions | Matrix row | — |
| 5 | Build with each supported build; run the full validation checklist | Validation results | ★ Any ★ failure → fix or stop |
| 6 | Confirm registration path (OEM/reseller registers hashes or ABM assignment for this SKU) | Test order or vendor confirmation | ★ Unconfirmed → flag; bench must register manually |
| 7 | Confirm discovery and the ITAM model record normalize the model correctly | Discovery record matches model | — |
| 8 | Approve: status → Supported; communicate to bench and procurement | Change record | — |

## 5. Baseline update cadence

| Item | Cadence [FILL] | Trigger for out-of-cycle update |
|---|---|---|
| BIOS/UEFI | [FILL] | Security advisory rated [FILL] or above; known defect |
| Firmware (dock, SSD, etc.) | [FILL] | Same |
| Drivers | [FILL] | Same; new OS release |

Each update follows the ring model in `build-standard.md` §6 and adds a matrix change note. Security advisory severity thresholds come from the security team's policy; don't invent them.

## 6. Drift detection

- Report installed BIOS/UEFI version by model from inventory (MECM, Intune or the OEM tool) and compare with the matrix baseline. `VENDOR — VERIFY` which tool reports which property.
- Count devices below baseline, by model and age. Devices that cannot reach baseline are refresh candidates (`itam-hardware-lifecycle`).
- Treat a model string seen in discovery but missing from the matrix as an exception: either an unapproved purchase or a normalization gap.

## 7. End of support

When the OEM ends support for a model, or the model can't run the target OS release, set status to Sustaining or Retired, record the date, and feed the list to refresh planning. OEM dates are `VENDOR — VERIFY`; never state them from memory.
