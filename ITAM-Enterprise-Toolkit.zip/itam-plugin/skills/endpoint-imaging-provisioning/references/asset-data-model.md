# Canonical asset data model (field dictionary + lifecycle state machine)

**Shared file.** This is the single canonical definition of hardware asset fields and lifecycle states for the ITAM plugin. Other skills keep a copy in their own `references/`, refreshed from this file by `scripts-sync-shared.sh` at the plugin root. Change it here only, then run the script; don't write competing versions.

**Basis:** `PRACTICE`, derived from Nicholas's AssetForge method (asset vs. CI distinction, lifecycle model, audit-evidence model) and the CAMP description of asset identification: a unique identifier per asset, receiving and acceptance, tagging, discovery, reconciliation, movements, RMAs and status changes from entry into inventory through retirement (CAMP M:38-39; S:73-76). It is a vendor-neutral model, not a product schema. For ServiceNow tables and fields, use the `servicenow-itam` skill and map to this model.

## How to use it

1. Fill the **Org field** and **Org state / substate** columns from the user's system (or from `templates/company-profile.md`). A blank cell means "unknown", never "not needed".
2. Keep the canonical names. Translate them to the organization's names in the output, but don't rename them here.
3. "Required from" codes mean the field must be populated on entry to that state and stay populated afterwards unless noted:
   `OO+` from On order onward · `IS+` from first receipt into stock onward · `IU` while In use · `MS` while Missing · `RT+` from Retired onward · `DP` on entry to Disposed · `opt` optional · `cond` conditional (the rule says when).
4. Validation rules marked `[FILL]` need an organizational value (format, list, threshold). Don't invent one.

## Contents
1. What gets an asset record
2. Field dictionary
3. Attribute authority and conflict rules
4. Lifecycle state machine (states, transitions, entry/exit criteria, evidence)
5. Organization mapping worksheet

## 1. What gets an asset record

An asset record holds ownership, financial, contractual and lifecycle facts. A CI holds operational and dependency facts. They link when both exist; neither replaces the other (`PRACTICE`; AssetForge §7).

| Object | Asset record | CI | Notes |
|---|---|---|---|
| Laptop, desktop, workstation | Yes | Yes (if the CMDB scope includes end-user devices) | Most JML and refresh activity is here. |
| Monitor, dock, headset, peripheral | Yes if at or above the tracking threshold `[FILL]`, otherwise consumable | Usually no | CAMP notes non-managed items such as peripherals are cheap to track by tagging and often over-ordered (CAMP M:92). |
| Corporate-owned smartphone / tablet | Yes | Optional | Track IMEI and the carrier line separately; the line/SIM is a service, not the device. |
| BYOD (personal) device | **No** | No (MDM enrollment record only) | The organization doesn't own it. Track the enrollment, policy acceptance and corporate data, not the hardware. |
| Server, network, storage hardware | Yes | Yes | CI holds relationships; asset holds contract, cost and lifecycle. |
| Virtual machine / cloud instance | No (no physical asset) | Yes | Cost belongs to cloud/FinOps tracking, not hardware assets. |
| Leased or device-as-a-service unit | Yes (`ownership_type` Leased / Vendor-owned) | As above | Lease end drives return, not disposal. |
| Loaner pool device | Yes (`ownership_type` Owned, pool flagged) | As above | Loans are assignments with a due date. |

## 2. Field dictionary

Record column: `A` = asset record, `CI` = configuration item / discovery record, `A+CI` = held on both and kept in sync, with the authoritative side named in section 3.

### 2.1 Identity

| Field | Definition | Record | Required from | Authoritative source | Validation rule | Org field |
|---|---|---|---|---|---|---|
| `asset_id` | Repository's internal, immutable unique key for the record. | A | OO+ | ITAM repository | Unique; never reused; never edited. | `[FILL]` |
| `asset_tag` | Organization's physical label identifier affixed to the device. | A | IS+ (cond: classes exempt from tagging `[FILL]`) | Receiving/tagging step | Unique across all records including disposed ones; matches tag format `[FILL regex]`; never reassigned to another device. | `[FILL]` |
| `serial_number` | Manufacturer serial (service tag) of the unit. | A+CI | IS+ | Device label / receiving scan, corroborated by vendor ASN and discovery | Uppercase alphanumeric after normalization; not a placeholder (e.g. "To be filled by O.E.M.", "0", "N/A"); ≥ 4 characters; unique per manufacturer. | `[FILL]` |
| `manufacturer` | Normalized manufacturer name. | A+CI | OO+ | Model catalog | Value from the approved manufacturer list. | `[FILL]` |
| `model` | Normalized model, tied to a catalog entry. | A+CI | OO+ | Model catalog / procurement | Value from the model catalog; not free text. | `[FILL]` |
| `asset_class` | Category that drives tracking rules (laptop, desktop, monitor, smartphone, tablet, server, network, peripheral ...). | A | OO+ | Model catalog | Value from the class list `[FILL]`; determines whether a CI is expected. | `[FILL]` |
| `hostname` | Device name on the network. | CI | IU (cond: managed endpoints) | Endpoint management / discovery | Follows naming standard `[FILL]`; unique among active devices. | `[FILL]` |
| `hardware_uuid` | SMBIOS/system UUID reported by the device. | CI | opt | Discovery / endpoint management | 32 hex digits; not all-zero or all-F. | `[FILL]` |
| `mac_address` | Network adapter MAC address(es). | CI | opt | Discovery | 12 hex digits. **Not a primary match key**: docks and USB adapters move between devices. | `[FILL]` |
| `mdm_device_id` | Device ID in the MDM / endpoint management tool. | CI | cond: managed devices, IU | MDM | Exists in MDM; one active ID per device. | `[FILL]` |
| `imei` | Cellular device identity. | A+CI | cond: cellular devices, IS+ | Receiving scan / carrier | 15 digits with a valid check digit. | `[FILL]` |

### 2.2 Ownership, assignment and location

| Field | Definition | Record | Required from | Authoritative source | Validation rule | Org field |
|---|---|---|---|---|---|---|
| `ownership_type` | Owned, Leased, Rented, Vendor-owned (device-as-a-service). BYOD is excluded (no asset record). | A | OO+ | Procurement / contract | From list; Leased or Vendor-owned requires `lease_contract_id`. | `[FILL]` |
| `cost_center` | Cost-bearing organizational unit (financial owner). | A | IS+ | Finance cost-center master | Active cost center. | `[FILL]` |
| `managed_by` | Team accountable for the record and physical custody while unassigned (stockroom, site IT). | A | IS+ | ITAM repository | Active group. | `[FILL]` |
| `assigned_to` | Person the device is assigned to. | A | IU (cond: assignment type Individual or Loan) | Assignment transaction in ITAM; identity status from HR / identity provider | Active identity in HR/IdP; empty when not In use. | `[FILL]` |
| `assignment_type` | Individual, Shared, Location (kiosk, lab, meeting room), Loan. | A | IU | ITAM repository | From list; Shared/Location requires a named custodian. | `[FILL]` |
| `custodian` | Named accountable person for shared or location devices. | A | cond: Shared/Location | ITAM repository | Active identity. | `[FILL]` |
| `assigned_date` | Date the current assignment started. | A | IU | Assignment transaction | ≤ today; ≥ `received_date`. | `[FILL]` |
| `acknowledgement_ref` | Reference to the user's receipt/acceptable-use acknowledgement. | A | cond: required by policy `[FILL]`, IU | Assignment workflow / e-signature | Reference resolves to a stored document. | `[FILL]` |
| `loan_due_date` | Date a loaned device must return. | A | cond: assignment type Loan | Loan request | > `assigned_date`. | `[FILL]` |
| `department` | Organizational unit of the assigned user. | A | IU | HR (derived) | Matches HR for `assigned_to`. | `[FILL]` |
| `location` | Site / building / room, or "Remote" convention `[FILL]` for home workers. | A | IS+ | Stockroom transactions (in stock); assignment (in use) | Value from the location master. Network-derived location is `INFERENCE`, not authority. | `[FILL]` |
| `stockroom` | Controlled storage location holding the device. | A | cond: In stock | ITAM repository | Active stockroom; empty when not In stock. | `[FILL]` |

### 2.3 Lifecycle

| Field | Definition | Record | Required from | Authoritative source | Validation rule | Org field |
|---|---|---|---|---|---|---|
| `state` / `substate` | Canonical lifecycle state and substate (section 4). | A | OO+ | ITAM repository | Pair is valid in section 4.1; last change is an allowed transition (4.2). | `[FILL]` |
| `state_changed_at` / `state_changed_by` | When and by whom (or which integration) the state last changed. | A | OO+ | ITAM audit history | Not later than now; not backdated without an approval note. | `[FILL]` |
| `state_change_ref` | Ticket, order or workflow reference that authorized the change. | A | OO+ (cond: controlled transitions in 4.2) | ITSM / workflow | Resolves to a record. | `[FILL]` |
| `order_date` | Date the PO was issued. | A | OO+ | Procurement / ERP | ≤ `received_date`. | `[FILL]` |
| `received_date` | Date the unit was physically received and accepted. | A | IS+ | Receiving record | ≥ `order_date`; ≤ today. | `[FILL]` |
| `in_service_date` | Date first deployed (used for age and refresh). | A | IU | Assignment transaction | ≥ `received_date`. | `[FILL]` |
| `last_verified_date` | Last physical verification (cycle count, audit scan, user attestation). | A | IS+ | Cycle count / attestation | Within verification cadence `[FILL]`. | `[FILL]` |
| `last_discovered_date` / `discovery_source` | Last time a discovery or MDM source saw the device, and which one. | CI | IU (cond: discoverable classes) | Discovery / MDM | Within active window `[FILL days]`. | `[FILL]` |
| `planned_refresh_date` | Date the device becomes eligible for refresh. | A | IU | Calculated: `in_service_date` (or `purchase_date`, per policy) + refresh cycle in `refresh-policy.md` | Calculated, never typed. | `[FILL]` |
| `retired_date` / `retirement_reason` | When and why it was removed from service (end of life, beyond economic repair, lease end, lost, stolen, obsolete). | A | RT+ | Retirement approval | Reason from list. | `[FILL]` |
| `disposal_date` / `disposal_method` | When and how the organization's custody ended (recycled, destroyed, resold, donated, returned to lessor, vendor trade-in, written off). | A | DP | ITAD certificate / lessor receipt / write-off approval | Method from list; date ≥ `retired_date`. | `[FILL]` |

### 2.4 Financial and contractual

| Field | Definition | Record | Required from | Authoritative source | Validation rule | Org field |
|---|---|---|---|---|---|---|
| `po_number` | Purchase order reference. | A | OO+ (cond: purchased) | Procurement / ERP | Exists in ERP. | `[FILL]` |
| `vendor` | Supplier the unit was bought or leased from. | A | OO+ | Procurement / vendor master | Active vendor. | `[FILL]` |
| `invoice_number` | Supplier invoice reference. | A | IS+ (cond: within `[FILL]` days of receipt) | Accounts payable / ERP | Exists in ERP; matches PO. | `[FILL]` |
| `purchase_cost` / `currency` | Acquisition cost per unit and its currency. | A | IS+ | Invoice (PO price is provisional until invoiced) | > 0; ISO 4217 currency code. | `[FILL]` |
| `capitalized` / `fixed_asset_id` | Whether the unit is on the fixed-asset register, and its register ID. | A | cond: cost ≥ capitalization threshold `[FILL]`, IS+ | Finance fixed-asset register | Register ID exists; capitalized units appear in the register. | `[FILL]` |
| `lease_contract_id` / `lease_end_date` | Lease or device-as-a-service contract and its end date. | A | cond: Leased / Vendor-owned, OO+ | Contract repository | End date ≥ start; return planned before end. | `[FILL]` |
| `warranty_end` / `warranty_ref` | End of manufacturer or extended warranty, and the entitlement reference. | A | IS+ | Manufacturer entitlement lookup / contract | ≥ `received_date`. | `[FILL]` |
| `support_contract_ref` | Maintenance or support contract covering the unit. | A | opt | Contract repository | Contract active for In use units that require it. | `[FILL]` |

### 2.5 Recovery, security events and disposition evidence

| Field | Definition | Record | Required from | Authoritative source | Validation rule | Org field |
|---|---|---|---|---|---|---|
| `incident_ref` | Security incident / loss report for a missing device; police report reference where policy requires. | A | MS (cond: Lost, Stolen) | ITSM / security incident tool | Resolves to an incident. | `[FILL]` |
| `remote_action_ref` | Evidence of remote lock / wipe / credential revocation. | A | MS (cond: managed device) | MDM / security | Timestamped; device identity matches. | `[FILL]` |
| `retirement_approval_ref` | Approval to remove from service. | A | RT+ | ITAM workflow | Approver holds delegated authority `[FILL]`. | `[FILL]` |
| `license_reclaim_ref` | Evidence that assigned software/subscriptions were reclaimed. | A | RT+ (cond: licensed software assigned) | SAM tool / workflow | Present before Disposed. | `[FILL]` |
| `sanitization_method` | Method applied to storage (for example clear, purge, destroy as defined by the adopted standard `[FILL]`; NIST SP 800-88 is the common US reference, `VERIFY current edition`). | A | DP (cond: device has storage) | Sanitization tool log / ITAD report | From the adopted standard's list. | `[FILL]` |
| `sanitization_evidence_ref` | Per-serial wipe/destruction log or report. | A | DP (cond: storage) | Wipe tool / ITAD vendor | Lists this serial; date ≤ `disposal_date`. | `[FILL]` |
| `chain_of_custody_ref` | Handover manifest listing serials, signatures and dates when the device left the organization's custody. | A | DP (cond: left custody) | Logistics / ITAD pickup manifest | Lists this serial. | `[FILL]` |
| `itad_vendor` | Disposition vendor. | A | DP (cond: ITAD used) | Vendor master | Approved ITAD vendor `[FILL]`. | `[FILL]` |
| `certificate_ref` | Certificate of destruction / recycling / data erasure, or lessor return receipt. | A | DP | ITAD vendor / lessor | Certificate lists this serial (serial-level, not lot-level, unless policy accepts lot-level `[FILL]`). | `[FILL]` |
| `write_off_approval_ref` | Finance approval to write off a lost/stolen or unrecoverable device. | A | DP (cond: method Written off) | Finance | Approver holds authority `[FILL]`. | `[FILL]` |
| `disposal_proceeds` | Resale, donation value or trade-in credit received. | A | opt | ITAD settlement / finance | ≥ 0; currency stated. | `[FILL]` |
| `financial_closure_date` | Date the fixed-asset entry was retired. | A | DP (cond: capitalized) | Finance fixed-asset register | ≥ `disposal_date` or documented exception. | `[FILL]` |
| `ci_ref` / `ci_retired_date` | Linked CI and the date it was retired. | A | IU (cond: class has a CI) / DP | ITAM-CMDB link | CI retired when asset Disposed. | `[FILL]` |

## 3. Attribute authority and conflict rules

When sources disagree, the authoritative source wins only for its own attributes. Preserve the conflict as an exception (reconciliation skill) instead of silently overwriting. Basis: `PRACTICE` (AssetForge §11.2 attribute-authority pattern).

| Attribute | Authoritative | Secondary | Conflict rule |
|---|---|---|---|
| Serial number | Physical device label / receiving scan | Discovery, vendor ASN | A serial that differs from discovery after a board replacement is an RMA event: update with the RMA reference, don't overwrite blindly. |
| Asset tag | Tagging record | Physical count | Never infer a tag from another source. |
| Model / manufacturer | Model catalog (normalized) | Discovery | Map discovery strings to catalog values with a lookup table. |
| User assignment | ITAM assignment transaction | MDM primary user, discovery last logon | Disagreement is an exception to investigate; last logon is `INFERENCE`. |
| User status (active/leaver) | HR / identity provider | — | HR wins; ITAM never decides employment status. |
| Location | ITAM (stockroom transactions, assignment) | Discovery network location | Network location is a lead, not a fact. |
| Last seen / health | Discovery / MDM | — | ITAM never edits these. |
| Cost, capitalization | ERP invoice / fixed-asset register | PO | Invoice beats PO; register beats ITAM for capitalization. |
| Warranty | Manufacturer entitlement / contract | Model default | Record the lookup date. |
| State | ITAM repository | Discovery activity (as evidence) | Activity that contradicts the state (retired device checking in) is an exception, never an automatic state change. |

## 4. Lifecycle state machine

**States** describe the record at a point in time. **Stages** (in `lifecycle-state-model.md`) describe the process work that moves a record between states. Rules (`PRACTICE`):
- A record holds exactly one state + substate pair. The pair is the true status.
- Use substates for process nuance; don't add states. New states break reporting and asset-CI mappings.
- Every state change happens through a transaction that carries `state_change_ref`, except automated changes that log their integration as `state_changed_by`.
- `DISPOSED` and `CANCELLED` are terminal. Corrections to a terminal record need an approved data-correction note, not a transition.

### 4.1 States and substates

| Canonical state | Meaning | Canonical substates | Counts as inventory on hand | Expected CI status | Org state / substate |
|---|---|---|---|---|---|
| `ON_ORDER` | Ordered, not yet received. | — | No | No CI yet (or planned) | `[FILL]` |
| `IN_TRANSIT` | Moving between custody points. | `TO_STOCKROOM`, `TO_USER`, `RETURN_TO_STOCK`, `TO_VENDOR` (RMA/lessor), `TO_ITAD` | No (tracked separately) | Unchanged / non-operational | `[FILL]` |
| `IN_STOCK` | In a controlled stockroom, not assigned. | `RECEIVING` (received, not yet tagged/recorded), `AVAILABLE`, `RESERVED` (allocated to a request), `IN_BUILD` (imaging/configuration), `READY_TO_DEPLOY` (built and validated; see endpoint-imaging-provisioning), `PENDING_INSPECTION` (returned, awaiting triage and wipe), `PENDING_REPAIR`, `DEFECTIVE`, `LOANER_POOL`, `PENDING_RETIREMENT` | Yes | Non-operational | `[FILL]` |
| `IN_USE` | Deployed and assigned. | `INDIVIDUAL`, `SHARED`, `LOCATION`, `ON_LOAN` | No (deployed) | Operational | `[FILL]` |
| `IN_MAINTENANCE` | Out of service for repair. | `ONSITE_REPAIR`, `DEPOT_OR_RMA` | No | Non-operational / repair | `[FILL]` |
| `MISSING` | Cannot be located. | `UNDER_SEARCH`, `LOST`, `STOLEN`, `NOT_RETURNED` (leaver or loan not recovered) | No | Non-operational; access revoked | `[FILL]` |
| `RETIRED` | Removed from service, still in the organization's custody. | `AWAITING_SANITIZATION`, `SANITIZED`, `AWAITING_PICKUP` | No | Retired / pending | `[FILL]` |
| `DISPOSED` | Custody ended; record closed after closure checks. Terminal. | `RECYCLED`, `DESTROYED`, `RESOLD`, `DONATED`, `RETURNED_TO_LESSOR`, `VENDOR_TRADE_IN`, `RMA_REPLACED` (unit swapped by vendor), `WRITTEN_OFF` (lost/stolen) | No | Retired | `[FILL]` |
| `CANCELLED` | Order cancelled before receipt. Terminal. | — | No | None | `[FILL]` |

### 4.2 Allowed transitions

Any transition not listed is prohibited and should surface as a lifecycle exception. "Evidence" is what must exist **before** the change is recorded. Moves between `IN_STOCK` substates that are not listed (for example `AVAILABLE` ↔ `LOANER_POOL`, `RESERVED` → `IN_BUILD`, `PENDING_INSPECTION` → `PENDING_REPAIR`) are allowed when they carry a `state_change_ref`; they don't change custody.

| # | From | To | Trigger | Guard (entry criteria) | Required evidence |
|---|---|---|---|---|---|
| T01 | — | `ON_ORDER` | PO issued | Approved request; catalog model | PO, approval record |
| T02 | `ON_ORDER` | `CANCELLED` | Order cancelled | Nothing received | Cancellation from vendor/procurement |
| T03 | `ON_ORDER` | `IN_STOCK/RECEIVING` | Delivery accepted | Quantity and serials checked against PO/ASN | Receiving record, packing slip |
| T04 | `IN_STOCK/RECEIVING` | `IN_STOCK/AVAILABLE` | Identification complete | Tag affixed; all `IS+` fields populated | Tag record; complete record |
| T05 | `IN_STOCK/AVAILABLE` | `IN_STOCK/RESERVED` or `IN_BUILD` | Allocated to a request / build | Request reference | Request or build ticket |
| T05a | `IN_STOCK/IN_BUILD` | `IN_STOCK/READY_TO_DEPLOY` (pass) or `IN_STOCK/DEFECTIVE` (fail) | Build validated or failed | Validation checklist complete | Build record with build ID/version, checklist version, technician, date |
| T06 | `IN_STOCK/*` (deployable) | `IN_TRANSIT/TO_USER` | Shipped to a user or site | Build validated (if required) | Shipment record with tracking number |
| T06a | `IN_STOCK/*` | `IN_TRANSIT/TO_STOCKROOM` | Transfer between stockrooms or to a depot | Transfer order or manifest listing serials; destination stockroom set | Transfer record; tracking or signed manifest |
| T06b | `IN_TRANSIT/TO_STOCKROOM` | `IN_STOCK/*` (same substate as before the transfer, or `PENDING_INSPECTION` if condition is in doubt) | Received at the destination | Serial confirmed on receipt | Destination stockroom receipt |
| T07 | `IN_STOCK/*` or `IN_TRANSIT/TO_USER` | `IN_USE` | Handover or proof of delivery | `assigned_to` (or custodian) set; active identity | Delivery/handover record; acknowledgement if policy requires |
| T08 | `IN_USE` | `IN_USE` (new assignee) | Mover / reassignment | Old and new assignee recorded; device reimaged if policy requires `[FILL]` | Transfer ticket |
| T09 | `IN_USE` | `IN_TRANSIT/RETURN_TO_STOCK` | Leaver, refresh, return | Recovery ticket | Return kit tracking or handover receipt |
| T10 | `IN_USE` or `IN_TRANSIT/RETURN_TO_STOCK` | `IN_STOCK/PENDING_INSPECTION` | Received back into stock | Serial confirmed on receipt | Stockroom receipt |
| T11 | `IN_STOCK/PENDING_INSPECTION` | `IN_STOCK/AVAILABLE` | Passed triage, wiped/reimaged | Meets redeploy standard `[FILL]` | Wipe/reimage record |
| T12 | `IN_STOCK/PENDING_INSPECTION` or `DEFECTIVE` | `IN_STOCK/PENDING_RETIREMENT` | Not redeployable | Reason recorded | Triage note |
| T13 | `IN_USE` or `IN_STOCK` | `IN_MAINTENANCE` | Fault reported | Incident reference | Incident; RMA number if vendor repair |
| T14 | `IN_MAINTENANCE` | `IN_USE` or `IN_STOCK` | Repaired | Serial unchanged, or serial change recorded | Repair record |
| T15 | `IN_MAINTENANCE` | `DISPOSED/RMA_REPLACED` | Vendor replaced the unit | Replacement unit received as a new record (T03) | RMA record linking old and new serial; drive retention or sanitization evidence |
| T16 | `IN_USE`, `IN_STOCK`, `IN_TRANSIT` | `MISSING/UNDER_SEARCH` | Cannot be located (count, user report, leaver not returned) | Search opened | Ticket; for `LOST`/`STOLEN`, security incident and remote lock/wipe evidence |
| T17 | `MISSING/*` | `IN_STOCK/PENDING_INSPECTION` | Found / recovered | Physically received | Stockroom receipt; incident updated |
| T18 | `MISSING/*` | `DISPOSED/WRITTEN_OFF` | Search period `[FILL days]` expired | Write-off approved | Write-off approval; incident; insurance/police reference where applicable |
| T19 | `IN_STOCK/PENDING_RETIREMENT` | `RETIRED/AWAITING_SANITIZATION` | Retirement approved | Licenses reclaimed; data needs assessed; legal hold checked | Retirement approval |
| T20 | `RETIRED/AWAITING_SANITIZATION` | `RETIRED/SANITIZED` | Sanitization done in-house | Method per adopted standard | Per-serial sanitization record |
| T21 | `RETIRED/*` | `IN_TRANSIT/TO_ITAD` | Handed to ITAD vendor | Custody manifest prepared | Signed manifest listing serials |
| T22 | `IN_TRANSIT/TO_ITAD` or `RETIRED/*` | `DISPOSED/*` | Disposition confirmed | Certificate reconciled to serial; sanitization evidence present | Certificate; sanitization evidence; financial closure started |
| T23 | `IN_USE` or `IN_STOCK` (leased) | `IN_TRANSIT/TO_VENDOR` → `DISPOSED/RETURNED_TO_LESSOR` | Lease end | Data sanitized per lease terms `[FILL]` | Lessor return receipt listing serial |

### 4.3 Prohibited transitions (always raise an exception)

- `ON_ORDER` → `IN_USE` (skips receiving and identification).
- `IN_USE` → `DISPOSED` or `RETIRED` → `DISPOSED` without sanitization and certificate evidence (skips custody and sanitization).
- `MISSING` → `DISPOSED` without write-off approval.
- `RETIRED` → `IN_USE` without passing through `IN_STOCK/PENDING_INSPECTION` and a documented un-retire approval.
- Any transition out of `DISPOSED` or `CANCELLED`.
- `IN_USE` with an inactive `assigned_to` for longer than the leaver recovery SLA `[FILL]` (a dwell violation rather than a transition, but treat it the same way).

### 4.4 Entry and exit criteria per state

| State | Entry criteria | Exit criteria | Evidence held while in state | Max dwell `[FILL]` |
|---|---|---|---|---|
| `ON_ORDER` | Approved request; PO | Received (T03) or cancelled (T02) | PO | Lead time + `[FILL]` days |
| `IN_STOCK` | Received and accepted; stockroom set | Allocated and shipped/handed over, sent to repair, or retirement approved | Stockroom record; last cycle count | Stock aging threshold, e.g. `[FILL]` days in `AVAILABLE` |
| `IN_TRANSIT` | Shipment or transfer created with tracking | Proof of delivery or receipt | Tracking number, carrier, chain of custody | `[FILL]` days per route |
| `IN_USE` | Handover/POD; active assignee or custodian | Return, repair, missing, or reassignment | Assignment record; discovery activity | Refresh age `[FILL]` |
| `IN_MAINTENANCE` | Incident / RMA | Repaired, replaced, or retired | Repair/RMA record | Repair SLA `[FILL]` |
| `MISSING` | Search opened; incident for lost/stolen | Found (T17) or written off (T18) | Incident; remote action evidence | Search period `[FILL]` |
| `RETIRED` | Retirement approval; licenses reclaimed | Disposed (T22, T23) | Approval; sanitization record | Retire-to-dispose target `[FILL]` |
| `DISPOSED` | Certificate reconciled; sanitization evidence | Terminal | Certificate; financial and CI closure | — |

## 5. Organization mapping worksheet

Fill one row per organizational state/substate pair. Every canonical state should be reached by at least one row; every organizational pair should map to exactly one canonical pair.

| Org state | Org substate | Canonical state | Canonical substate | Gap or note |
|---|---|---|---|---|
| `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` |
| `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` |

Typical gaps to look for: no state for "returned, awaiting wipe" (records jump straight to Available); "Missing" used for both lost and not-yet-returned leaver devices; no distinction between Retired and Disposed; custom states that the asset-CI sync doesn't map; loaners tracked outside the repository.
