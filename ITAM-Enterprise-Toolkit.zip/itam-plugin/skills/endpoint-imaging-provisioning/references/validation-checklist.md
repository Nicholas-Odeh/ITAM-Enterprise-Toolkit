# Build validation checklist, handoff and bench metrics

Content is `PRACTICE`. Product-specific checks are `VENDOR — VERIFY`: confirm the exact setting or report name in the user's tooling. ★ marks a critical check: one ★ failure means the device is not `READY_TO_DEPLOY`, regardless of the rest. Adapt the list; record the checklist version used on every build.

Checklist version: [FILL] · Owner: [FILL] · Approved: [FILL]

## Contents
1. Pre-build checks
2. Post-build checks: Windows
3. Post-build checks: macOS
4. Post-build checks: iOS/iPadOS and Android
5. Physical QA and kit
6. Handoff record
7. Failure handling
8. Bench throughput metrics

## 1. Pre-build checks

- ★ Asset record exists, with asset tag and serial matching the device (the device was received and tagged; see `itam-logistics-warehouse`).
- ★ Model has a Supported (or Pilot, for pilot builds) row in `model-driver-matrix.md`.
- Registration present where the method needs it (Autopilot hash, ABM assignment, zero-touch/KME) and the serial matches the asset record.
- BIOS/UEFI and firmware at baseline, or the build will update them.
- For a rebuild: the previous user's data handling is complete per the recovery procedure, and the asset is not on legal hold or under a security investigation [FILL — how the bench checks this].
- Correct build ID and version selected (current, not sustaining or retired).

## 2. Post-build checks: Windows

- ★ Device is joined/registered as the build specifies (Entra joined or hybrid joined) and enrolled in management (Intune and/or MECM client healthy).
- ★ Disk encryption on (for example BitLocker), and the recovery key escrowed to the approved location (`VENDOR — VERIFY` where your tenant escrows it).
- ★ Security agents installed and reporting (EDR/AV, plus any required VPN/ZTNA or DLP agent).
- ★ Device reports compliant, or the only non-compliant items are ones expected to clear on first user sign-in [FILL list].
- Required apps installed at the expected versions; no failed installs in the management console.
- Update ring/servicing assignment correct; OS release and patch level as the build specifies.
- No unknown devices or driver errors (Device Manager or the OEM tool).
- BIOS/UEFI version at baseline; Secure Boot on; TPM present and ready; BIOS admin password set if the standard requires it.
- Build ID/version stamped where the standard says (registry, WMI, group tag, device category) [FILL].
- Local admin handling as the standard specifies (for example, a managed local admin password solution in place) [FILL].
- Device name follows the naming standard [FILL].

## 3. Post-build checks: macOS

- ★ Enrolled through ADE into the correct MDM server; MDM profile non-removable if the standard requires it.
- ★ FileVault on, and the recovery key escrowed to MDM.
- ★ Security agents installed and reporting.
- Activation Lock state as the standard requires (bypass code escrowed if MDM-managed) (`VENDOR — VERIFY`).
- Required configuration profiles and apps installed; OS version as the build specifies.
- Local account model as the standard specifies [FILL].

## 4. Post-build checks: iOS/iPadOS and Android

- ★ Enrolled in MDM in the correct mode (supervised for corporate iOS/iPadOS; the specified Android Enterprise mode).
- ★ Passcode/encryption policy applied; device reports compliant.
- Required apps and configuration installed.
- IMEI/serial and, where tracked, SIM/line recorded on the asset.
- Activation Lock (iOS) or Factory Reset Protection (Android) managed as the standard specifies (`VENDOR — VERIFY`).

## 5. Physical QA and kit

- No physical damage; screen, keyboard, ports, camera, battery health acceptable [FILL — battery health threshold, if any].
- ★ Asset tag present, legible and scannable; matches the record.
- Accessories per kit list (charger, dock, case) [FILL — kit list per build]; see kitting in `itam-logistics-warehouse`.
- Device cleaned; previous user labels removed.

## 6. Handoff record

Write to the asset record (or the build log linked to it) at validation pass:

| Field | Value |
|---|---|
| Asset tag / serial | — |
| Build ID + version | — |
| Checklist version | — |
| Result | Pass · Fail (with reason code) |
| Technician or service | — |
| Date/time | — |
| Ticket / order / request | — |
| New state/substate | `IN_STOCK/READY_TO_DEPLOY` (canonical) → [FILL — mapped value in the ITAM system; ServiceNow: `servicenow-itam`] |
| Location / stockroom bin | — |

★ The state change happens only after a pass is recorded. A device that is "built" but not recorded is not ready.

## 7. Failure handling

| Outcome | Action | State |
|---|---|---|
| Fails a ★ check, fixable at bench | Fix, then re-run the full checklist (not just the failed item) | Remains in build/rework substate |
| Hardware fault | Raise warranty/repair; RMA shipping per `itam-logistics-warehouse` | Defective / Pending repair |
| Repeated failure on one model | Open a problem record; consider pausing the model in the matrix | — |
| Registration problem (wrong tenant, missing hash) | Escalate to the registration owner; do not bypass enrollment | On hold |

Record a reason code for every failure [FILL — code list, for example DRV, APP, ENR, ENC, HW, REG, NET, OTH].

## 8. Bench throughput metrics

Targets are the organization's to set ([FILL]); never invent them. Each metric: numerator, denominator, source, frequency, owner.

| Metric | Definition | Source |
|---|---|---|
| Builds completed | Validation passes recorded in the period, by bench, technician, model, build | Handoff records |
| Builds per technician-shift | Builds completed ÷ technician shifts worked | Handoff records + roster |
| Build cycle time | Median and 90th percentile of (validation pass time − build start time) | Bench log |
| Receipt-to-ready time | Median of (READY_TO_DEPLOY time − received time); relates to CAMP's receiving-to-inventory staging-time indicator (CAMP M:22) | Asset state history |
| First-pass yield | Devices passing on the first attempt ÷ devices attempted | Handoff records |
| Rework rate | Devices needing more than one attempt ÷ devices attempted; split by reason code | Handoff records |
| Queue age | Count and age of devices waiting for build, by days waiting | Asset state + substate |
| Ready stock vs. demand | `READY_TO_DEPLOY` devices by model ÷ forecast demand for the next [FILL] days | Asset records + request forecast |
| Registration exceptions | Registered serials without an asset + assets without a registration | Reconciliation (`itam-inventory-reconciliation`) |
| Direct-ship success | Direct-ship devices reaching compliant state without bench touch ÷ direct-ship devices | MDM + tickets |

These metrics measure the bench as it runs. Forecasting the technicians, benches or shifts that future volumes need (capacity sizing or staffing) belongs to `itam-capacity-planning`, which takes these measures as inputs.

Interpretation notes (PRACTICE): a high rework rate concentrated in one reason code usually points to a build or model defect, not technician performance. Low first-pass yield on direct-ship devices usually points to app payload size, network conditions or registration timing.
