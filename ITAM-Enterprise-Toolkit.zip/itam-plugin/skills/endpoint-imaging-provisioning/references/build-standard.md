# Build standard and image/version register (template)

All content is `PRACTICE` unless labeled otherwise. Replace every `[FILL]` with the organization's value; leave it visible if unknown. Never fill a version number, OS release or date from memory.

## Contents
1. Document control
2. Build catalog
3. Build layers
4. Image/build version register
5. Versioning scheme
6. Change control and release rings
7. OS version and servicing policy
8. Reimage-on-redeploy decision table
9. Records

## 1. Document control

| Field | Value |
|---|---|
| Document ID | [FILL] |
| Owner (role) | [FILL — e.g., EUC engineering lead] |
| Approver (role) | [FILL — e.g., change advisory board / EUC manager] |
| Version / status | [FILL] / Draft · Approved · Superseded |
| Effective date / next review | [FILL] / [FILL] |
| Related | Hardware catalog [FILL]; model-driver matrix; validation checklist [version]; security baseline [FILL] |

## 2. Build catalog

One row per build. A build is the combination a technician or a provisioning service produces; persona builds differ only where they must.

| Build ID | Platform | Persona / use | OS edition | OS version / release [VERIFY] | Method | Join / enrollment | Config profile set | Security agents | Core apps | Region / language | Owner | Status | Effective |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| WIN-STD | Windows | Knowledge worker | [FILL] | [FILL] | Autopilot user-driven | Entra joined [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | Current | [FILL] |
| WIN-KIOSK | Windows | Shared / kiosk | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| MAC-STD | macOS | Knowledge worker | — | [FILL] | ADE + [MDM] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| IOS-CORP | iOS/iPadOS | Corporate-owned | — | [FILL] | ADE + [MDM], supervised | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |
| AND-CORP | Android | Corporate-owned | — | [FILL] | [zero-touch / KME / QR] | [fully managed / COPE] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |

Status values: **Pilot** (ring 0–1 only), **Current** (default for new builds), **Sustaining** (allowed on existing devices, not for new builds), **Retired** (rebuild at next touch).

## 3. Build layers

Define each layer once and reference it from the catalog so a change touches one place.

| Layer | Content | Source of truth | Change owner |
|---|---|---|---|
| OS | Edition, release, language base | [FILL — e.g., Intune feature update policy, MECM OS image] | [FILL] |
| Firmware & drivers | Per model | `model-driver-matrix.md` | [FILL] |
| Baseline configuration | Security baseline, encryption, update rings, compliance | [FILL — policy names] | [FILL] |
| Security agents | EDR/AV, VPN/ZTNA, DLP | [FILL] | [FILL] |
| Core applications | Required apps for every user | [FILL] | [FILL] |
| Persona applications | Department or role apps | [FILL] | [FILL] |
| Personalization | Region, keyboard, wallpaper, Start/Dock layout | [FILL] | [FILL] |

Modern provisioning (Autopilot, ADE) has no single "image file"; the build is the set of assigned policies and apps at a point in time. Record the build version against that set the same way you would against a WIM.

## 4. Image/build version register

Append-only. One row per released version. Never edit a released row; add a new one.

| Build ID | Version | Release date | Change summary | Change record | Base OS release [VERIFY] | Captured image / task sequence / policy set reference | Validation checklist version | Pilot result (devices, pass rate) | Approved by | Status | Superseded by |
|---|---|---|---|---|---|---|---|---|---|---|---|
| WIN-STD | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] | [FILL] |

Where the register lives: [FILL — e.g., SharePoint list (see `sharepoint-itam-records`), ServiceNow table, Git repo]. The asset record stores the build ID + version applied at each build (see `validation-checklist.md`).

## 5. Versioning scheme

Recommended (RECOMMENDATION): `<BuildID>-<YYYY.MM>-<rev>`, for example `WIN-STD-2026.10-1`.
- New month/period of the base OS or security baseline → new `YYYY.MM`.
- App, driver or setting change within the period → increment `rev`.
- Emergency security change → increment `rev`, record the change as emergency, back-fill pilot evidence.

## 6. Change control and release rings

| Ring | Devices | Entry criterion | Exit criterion |
|---|---|---|---|
| 0 — Lab | Bench test units, one per supported model | Change approved for test | Validation checklist passes on every model [FILL] |
| 1 — IT pilot | [FILL] IT staff devices | Ring 0 passed | [FILL] days without blocking defect |
| 2 — Business pilot | [FILL] representative users | Ring 1 passed | [FILL] |
| 3 — Broad | All new builds and rebuilds | Ring 2 passed, approval recorded | — |

Every release records: change record, approver, ring results, rollback approach (previous version stays available until the new one reaches ring 3).

## 7. OS version and servicing policy

| Item | Value |
|---|---|
| Supported OS releases for new builds | [FILL — VERIFY against vendor lifecycle pages] |
| Supported OS releases in service | [FILL] |
| Minimum version for compliance | [FILL] |
| Upgrade trigger | [FILL — e.g., N-1 policy, end-of-support date minus X months] |
| Hardware that cannot run the target release | List from model-driver matrix; feeds the refresh plan (`itam-hardware-lifecycle`) |

Vendor end-of-support dates are `VENDOR — VERIFY`; never state them from memory.

## 8. Reimage-on-redeploy decision table

| Situation | Action | Asset state path (canonical; map to your system) | Evidence | Route to |
|---|---|---|---|---|
| Returned by leaver, will be reissued internally | Wipe/reset per standard, rebuild to Current build, full validation | Returned → `IN_STOCK/PENDING_INSPECTION` → `IN_BUILD` → `READY_TO_DEPLOY` | Build record, validation pass | This skill |
| Mover keeps device, role changes | Reassign user/group targeting; rebuild only if persona build changes | In use (no change) or → rebuild path | Assignment change record | This skill / `itam-hardware-lifecycle` |
| Repaired, same user | Validate; rebuild only if the drive or board was replaced or integrity is in doubt | In repair → In use | Repair record, validation | This skill |
| Loaner returned | Wipe/reset and rebuild to loaner build | Returned → `IN_STOCK/LOANER_POOL` | Build record | This skill |
| Build on Sustaining/Retired version | Rebuild at next touch | — | Build record | This skill |
| Leaving control (sale, donation, ITAD, lease return) | **Not a reimage.** Sanitize per policy, deregister (Autopilot/ABM/zero-touch), release Activation Lock / FRP | → Pending disposal | Sanitization certificate, deregistration record | `itam-secure-disposition` |
| Warranty swap where the vendor takes the drive | Treat as leaving control unless the contract has a keep-your-drive option [VERIFY contract] | → In transit (RMA) | Sanitization or drive-retention record | `itam-secure-disposition`, `itam-logistics-warehouse` |
| Lost/stolen then recovered | Security review first; rebuild before reuse | → In stock (Quarantine) | Incident record | `itam-hardware-lifecycle` |

## 9. Records

| Record | Created by | Stored in | Retention |
|---|---|---|---|
| Build register row | Build owner | [FILL] | [FILL — set by records policy; never infer] |
| Build record per asset | Technician / automation | Asset record [FILL] | [FILL] |
| Pilot/validation evidence | EUC engineering | [FILL] | [FILL] |
| Change record | Change owner | ITSM [FILL] | [FILL] |
