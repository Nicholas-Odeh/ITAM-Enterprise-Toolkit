# Provisioning methods

Method descriptions are `PRACTICE`. Microsoft Graph resource and property names in §11 are `DOC` (checked against the Microsoft Graph docs repository). Anything else about product features, prerequisites, supported versions, limits or licensing is `VENDOR — VERIFY`: confirm it in current vendor documentation and the user's admin console before it goes into a standard. Product names change (for example Azure AD → Entra ID, DEP → ADE); use the user's terms when they differ.

## Contents
1. Golden image vs. modern provisioning
2. Windows: Autopilot modes
3. Windows: hardware hash registration
4. Windows: MECM/ConfigMgr OSD and co-management
5. macOS
6. iOS/iPadOS
7. Android
8. BYOD (not provisioned)
9. ITAM touchpoints for every method
10. Common failure modes at the bench
11. Microsoft Graph resources for registration reconciliation (DOC)

## 1. Golden image vs. modern provisioning

| Factor | Golden (monolithic) image | Thin image + task sequence | Modern provisioning (Autopilot / ADE / zero-touch) |
|---|---|---|---|
| What is deployed | A captured disk image with apps baked in | A near-stock OS image; apps and settings layered at build | The OEM's factory OS; policies and apps delivered by MDM |
| Technician touch | High (bench) | Medium (bench or PXE) | Low; can ship direct to the user |
| Network need | Local (PXE/media) | Local or distribution points | Internet; content size drives time-to-ready |
| Update effort | Re-capture for each change | Update the layer that changed | Update policies/apps; no image to maintain |
| Drift risk | High; images go stale | Medium | Low if policy is the source of truth |
| Hardware coverage | Per-model driver work | Driver packs per model | Depends on OEM factory image and update tooling |
| Good fit | Air-gapped, lab, kiosk, specialized hardware | Existing ConfigMgr estates, complex app stacks | Remote/hybrid workforce, direct-ship, cloud-managed estates |
| ITAM risk | Builds untracked; unlicensed reimaging | Task sequence version not recorded | Registration not reconciled to assets; devices skip the bench so tagging and receipt must happen upstream |

Notes:
- Apple no longer supports traditional monolithic imaging on current Mac hardware; provisioning is MDM-based (`VENDOR — VERIFY` for the user's models).
- Reimaging with volume-license media can depend on reimaging rights in the license agreement (CAMP M:149). Check with `itam-software-license-management`.
- Direct-ship models move receiving, tagging and the asset record creation to the OEM, reseller or depot. Confirm the vendor applies tags correctly; CAMP lists vendor pre-delivery accuracy as an indicator (CAMP M:22).

## 2. Windows: Autopilot modes

| Mode | Summary | Typical use | Verify before standardizing |
|---|---|---|---|
| User-driven | User signs in on first boot; device joins and enrolls; Enrollment Status Page (ESP) tracks policy/app install | Standard knowledge-worker laptops, direct-ship | Join type supported (Entra vs. hybrid); ESP blocking apps and timeout; app types allowed in ESP |
| Pre-provisioning (formerly "white glove") | Technician or OEM/partner runs the device phase in advance; user completes the user phase later | Large app payloads, slow user networks, white-glove service | Hardware prerequisites (TPM attestation, physical device, network); OEM/partner offering; reseal step |
| Self-deploying | No user affinity; device enrolls on its own | Kiosks, shared devices, meeting rooms | Hardware prerequisites (TPM attestation); supported join types |
| Autopilot device preparation (newer experience) | Different enrollment model; check whether hash registration is needed and which features are supported | New cloud-only deployments | Feature parity with classic Autopilot; coexistence rules |
| Autopilot reset | Returns device to a business-ready state keeping registration | Internal redeploy | What is kept vs. removed; not sanitization (SKILL rule 7) |

Profile assignment is usually by device group, often built from a group tag or order ID. Group tags are an ITAM opportunity: set them to a value that ties the device to its build or persona [FILL].

## 3. Windows: hardware hash registration

Paths (`VENDOR — VERIFY` which your OEM/reseller supports):
- **OEM or reseller registration** at purchase, tied to the order. Preferred for new devices: no bench touch. Contract it in the purchase terms (`itam-acquisition-procurement`).
- **Partner/CSP registration** through the partner relationship in the tenant.
- **Manual**: collect the hash on the device (for example with a PowerShell script during OOBE or from a running OS) and import a CSV in Intune. Used for existing devices and recoveries.
- **MECM/Intune existing devices**: collect hashes from managed devices via policy or reports.

ITAM controls (PRACTICE):
- Serial in the registration = serial on the asset record = serial on the tag. Reconcile on a schedule.
- Record the registration date and source on the asset.
- Deregister before sale, donation, lease return or ITAD, and when a motherboard swap changes the hash (re-register after repair). Approval per SKILL rule 8.

## 4. Windows: MECM/ConfigMgr OSD and co-management

- **Scenarios:** bare metal (new or wiped device via PXE or boot media), refresh (same device, wipe and load, user state optionally captured), replace (old → new device with user state migration), in-place upgrade.
- **Building blocks:** boot image, OS image or upgrade package, driver packages per model, application and package installs, task sequence steps, collections and deployments. Version the task sequence and record it in the build register.
- **Co-management:** workloads split between MECM and Intune. Record which tool owns which workload in the build standard, because the owner of "device configuration" or "apps" decides where a build change is made (`VENDOR — VERIFY` workload names).
- **Bench ITAM:** a task sequence step can write build ID/version and date to the registry or WMI so inventory reports it back; discovery then confirms the build on the asset (INFERENCE that the user's discovery picks it up; verify).

## 5. macOS

- **Automated Device Enrollment (ADE)** through Apple Business Manager (ABM) or Apple School Manager: devices bought through an enrolled reseller or Apple appear in ABM and are assigned to an MDM server (Jamf, Intune or another). First boot enrolls the Mac into MDM with a non-removable profile if configured (`VENDOR — VERIFY` per MDM).
- **Devices not bought through linked channels** can sometimes be added to ABM manually (for example with Apple Configurator), with conditions such as a provisional period during which the user can remove enrollment (`VENDOR — VERIFY`).
- **Setup:** prestage/enrollment profile (setup screens skipped, account creation, FileVault), configuration profiles, apps (VPP/Apps and Books licensing), scripts/policies.
- **ITAM controls:** ABM reseller ID and order number on the asset; serial reconciliation ABM ↔ MDM ↔ asset record; Activation Lock managed by MDM (bypass code escrow) and cleared before the device leaves; release from ABM at disposal (rule 8).

## 6. iOS/iPadOS

- Corporate devices via ADE, **supervised**, assigned to MDM; apps via Apps and Books licenses.
- Shared iPad or single-app (kiosk) modes for shared use (`VENDOR — VERIFY` per MDM).
- ITAM: IMEI and serial on the asset record, carrier line/SIM linked where tracked, Activation Lock handling as for macOS.

## 7. Android

- **Android Enterprise** modes: fully managed (corporate-owned), corporate-owned with work profile (COPE), dedicated device (kiosk), work profile on personal devices (BYOD).
- **Enrollment paths:** zero-touch enrollment (reseller-registered), Samsung Knox Mobile Enrollment, QR code, NFC, or token (`VENDOR — VERIFY` per device and MDM).
- ITAM: IMEI/serial reconciliation between the zero-touch/KME portal, MDM and asset record; remove from the portal at disposal; Factory Reset Protection must be cleared or managed before the device leaves (`VENDOR — VERIFY`).

## 8. BYOD (not provisioned)

Personal devices are registered, not built: app protection or work profile only, no device wipe of personal data. They are not organization assets but may need a registration record (CAMP S:76 lists registration of employee-owned devices as an asset identification function). Policy content belongs to the mobile device policy (CAMP M:71) and `itam-program-governance`.

## 9. ITAM touchpoints for every method

| Point | Record on the asset | Typical source |
|---|---|---|
| Registration | Registration portal, date, source (OEM/reseller/manual) | Autopilot / ABM / zero-touch |
| Build start | Build ID + version, technician or service, date | Bench log / task sequence / MDM |
| Validation pass | Checklist version, result, date | `validation-checklist.md` |
| State change | `IN_STOCK/READY_TO_DEPLOY` (mapped) | ITAM system |
| Assignment | User, date, acknowledgment | ITSM / ITAM |
| Deregistration | Portal, date, approver | At disposal or exit |

## 10. Common failure modes at the bench

| Symptom | Likely causes to check (PRACTICE; confirm in logs) |
|---|---|
| Device not recognized as Autopilot/ADE | Hash/serial not registered or registered to another tenant; profile not assigned yet; group membership delay; motherboard replaced |
| ESP hangs or times out | Blocking app fails or is too large; app type mix; certificate or network/proxy issue; timeout too short |
| Pre-provisioning fails | Hardware prerequisites not met (`VENDOR — VERIFY`); network; device-targeted app failures |
| Hybrid join fails | Connector, domain line-of-sight or VPN timing (`VENDOR — VERIFY`) |
| Task sequence fails at drivers | Model not in matrix; wrong driver package mapping (model string mismatch) |
| Mac skips enrollment | Device not assigned to MDM server in ABM; enrollment profile not assigned; network blocks Apple services |
| Duplicate device objects | Rebuild without cleanup; re-enrollment creates new objects. Clean up per rule 8 and reconcile |

Record every failure reason in the bench log; the reasons feed rework-rate analysis (`validation-checklist.md`).

## 11. Microsoft Graph resources for registration reconciliation (DOC)

Checked 2026-10-20 against `github.com/microsoftgraph/microsoft-graph-docs-contrib` (main branch, commit a7edbd4), v1.0 API reference. These confirm resource, endpoint and property **names** only; they don't confirm product behavior, licensing or limits, which stay `VENDOR — VERIFY`. The docs note that the Graph API for Intune requires an active Intune license for the tenant. Automation code belongs to `itam-automation-scripting`.

| Need | Resource and endpoint (v1.0) | Properties useful to ITAM | Source file |
|---|---|---|---|
| List Autopilot-registered devices | `windowsAutopilotDeviceIdentity`; `GET /deviceManagement/windowsAutopilotDeviceIdentities` | `serialNumber`, `manufacturer`, `model`, `groupTag`, `purchaseOrderIdentifier`, `enrollmentState` (`unknown`, `enrolled`, `pendingReset`, `failed`, `notContacted`), `lastContactedDateTime`, `managedDeviceId`, `userPrincipalName` | `api-reference/v1.0/resources/intune-enrollment-windowsautopilotdeviceidentity.md`; `api-reference/v1.0/api/intune-enrollment-windowsautopilotdeviceidentity-list.md` |
| Deregister an Autopilot device (destructive; rule 8) | `DELETE /deviceManagement/windowsAutopilotDeviceIdentities/{id}` | — | `api-reference/v1.0/api/intune-enrollment-windowsautopilotdeviceidentity-delete.md` |
| Imported hashes not yet processed | `importedWindowsAutopilotDeviceIdentity` | `serialNumber`, `groupTag`, `importId`, `state`, `assignedUserPrincipalName` | `api-reference/v1.0/resources/intune-enrollment-importedwindowsautopilotdeviceidentity.md` |
| List Intune-managed devices | `managedDevice`; `GET /deviceManagement/managedDevices` | `serialNumber`, `deviceName`, `manufacturer`, `model`, `imei`, `meid`, `userPrincipalName`, `managedDeviceOwnerType` (`unknown`, `company`, `personal`), `enrolledDateTime`, `lastSyncDateTime`, `complianceState`, `isEncrypted`, `azureADDeviceId`, `deviceEnrollmentType`, `managementAgent` | `api-reference/v1.0/resources/intune-devices-manageddevice.md`; `api-reference/v1.0/api/intune-devices-manageddevice-list.md` |
| Remote actions (destructive; Security decides) | `POST /deviceManagement/managedDevices/{id}/retire`, `.../wipe` (the wipe body includes `keepEnrollmentData` and `keepUserData` options) | — | `api-reference/v1.0/api/intune-devices-manageddevice-retire.md`; `api-reference/v1.0/api/intune-devices-manageddevice-wipe.md` |

How ITAM uses them (`PRACTICE`):
- **Registration hygiene:** match `windowsAutopilotDeviceIdentity.serialNumber` to the asset record's serial with `itam-inventory-reconciliation`. Registered serials with no asset record, and Windows assets with no registration, are both exceptions.
- **Group tag and order ID:** `groupTag` and `purchaseOrderIdentifier` can carry the build or persona and the PO; check them against the asset record's `po_number` (§2 above).
- **Ownership:** `managedDeviceOwnerType` = `personal` on a device that has an asset record, or `company` on a device with none, is a data-quality exception.
- **Activity:** `lastSyncDateTime` (managed device) and `lastContactedDateTime` (Autopilot) are discovery evidence for `last_discovered_date`; they show activity, not custody or location.
- **Wipe or retire is not sanitization evidence** for a device leaving the organization's control (SKILL rule 7).
