---
name: endpoint-imaging-provisioning
description: Use when planning, standardizing or troubleshooting device builds: Windows Autopilot and Intune, hash registration, MECM task sequences, golden image vs. modern provisioning, Apple ADE, Android Enterprise, build standards and version registers, driver and BIOS baselines, build validation, ESP or enrollment failures, reimage on redeploy, bench KPIs. Not for proving a wipe (use itam-secure-disposition), Graph code (itam-automation-scripting), or capacity sizing or staffing forecasts (use itam-capacity-planning).
---

# Endpoint Imaging and Provisioning

How a received, tagged device becomes a validated device ready to deploy, and how a recovered device is rebuilt. Core principle: **a device is ready only when its validation evidence is recorded against the asset.** For ITAM managers, EUC engineers and bench technicians. Content is `PRACTICE` unless labeled.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Vendor behavior is `VENDOR — VERIFY`.** Features, prerequisites, versions, limits and licensing change often; never state them from memory. Graph names confirmed in `references/provisioning-methods.md` §11 are `DOC`.
7. **Provisioning is not sanitization.** Reimage, Autopilot reset or MDM wipe prepares internal reuse; devices leaving control go through `itam-secure-disposition`.
8. **Destructive device actions need a serial list and approval.** Wipe, retire, delete, deregister, ABM release or bulk profile changes: list serials, get approval, note recovery. Forgetting to deregister also fails: the next owner can't enroll.

## When to use

- "Write our Windows build standard", "track image versions".
- Golden image or Autopilot? Mac ADE, Android zero-touch.
- New model, driver packs, BIOS baselines; "is this build ready?", rework rate.
- ESP stuck, "device not registered", task sequence fails.
- A returned laptop for a new hire: reimage or not?

**When not to use:** proof of wipe (`itam-secure-disposition`); automation code (`itam-automation-scripting`); receiving and tagging (`itam-logistics-warehouse`); capacity sizing or staffing forecasts for the bench (`itam-capacity-planning`, which uses this skill's throughput metrics).

## Workflow

### Step 1 — Classify

| Request | Load |
|---|---|
| Build standard, version register, reimage rules | `references/build-standard.md` |
| Method choice, troubleshooting, Graph registration data | `references/provisioning-methods.md` |
| Model, driver, BIOS, firmware | `references/model-driver-matrix.md` |
| Validation, handoff, bench metrics | `references/validation-checklist.md` |

### Step 2 — Preflight

Confirm or assume: tooling (ask if unknown); join model; supported models; who registers devices; where build versions live; which substate means ready (`references/imaging-method.md` §1).

### Step 3 — Do the work

- **Build standards:** one build per platform and persona, versioned, owned, piloted through change control.
- **Method choice:** show trade-offs, not a verdict. A model without a matrix row is not ready to deploy.
- **Registration hygiene:** reconcile registered serials to asset records.
- **Handoff:** on a validation pass, record build ID and version, checklist version, technician and date, then move the asset to the mapped `IN_STOCK/READY_TO_DEPLOY`; a failed build goes to a defective substate with its reason.
- **Bench throughput:** measure cycle time, yield and rework; targets come from the user.

Full method: `references/imaging-method.md` §2–8.

### Step 4 — Verify before release

- ★ No product limit, prerequisite, version or licensing statement as fact without evidence or a `VENDOR — VERIFY` label.
- ★ Every destructive action has a scoped serial list, approval step and recovery note.
- ★ No reimage, reset or MDM wipe offered as sanitization evidence.
- ★ No device called ready without a passed validation checklist recorded against its serial.
- Handoff steps name the state change and the evidence recorded.
- Models, versions, targets and owners come from the user or are `[FILL]`.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "ESP finished on the test unit; mark the batch ready" | Each serial needs its own passed validation record. |
| "It was Autopilot-reset, so it's clean for resale" | Reset is not sanitization. Route to `itam-secure-disposition`. |
| "Delete the stale Autopilot objects in bulk" | Serial list, approval and recovery note first. |
| "Pre-provisioning needs TPM 2.0, everyone knows that" | Product prerequisites are `VENDOR — VERIFY`. |

Stop if you are about to: move an asset to ready without its validation record; delete or deregister devices without an approved list.

## Common mistakes

| Mistake | Fix |
|---|---|
| Failed build returned to available stock | Defective or rework substate with the failure reason |
| Motherboard swap without re-registration | Deregister and re-register; record the RMA reference |
| Device handed to a new user as-is | Rebuild to the current build (decision table) |
| Build changes made directly in production | Pilot ring and change record first |

## If connectors are available

- **~~endpoint management:** read Autopilot registrations and managed devices (serial, enrollment state, last sync, ownership type; `references/provisioning-methods.md` §11) for reconciliation and bench troubleshooting. Wipe, retire, delete and deregister are drafted only, per rule 8.
- **~~ITSM:** draft the handoff update (build version, validation result, state); re-query after approval.
- **~~knowledge base:** draft the build standard or checklist for approval.

## Output format

1. **Answer** in two to five sentences.
2. **Standard, procedure or table**, labeled.
3. **Assumptions and VERIFY list:** each vendor fact and where to confirm it; each `[FILL]` and its owner.
4. **Risks:** data loss, stuck registrations, unlicensed reimaging, unmanaged devices reaching users, record drift.

Executive and practitioner variants: `references/imaging-method.md` §9.

## Reference files

- `references/imaging-method.md`: preflight, full method, output variants. Read for substantial work.
- `references/build-standard.md`: build catalog, versions, reimage decision table. Read for builds.
- `references/provisioning-methods.md`: methods per platform, failure modes, Graph resources (DOC). Read for method choice or troubleshooting.
- `references/model-driver-matrix.md`: driver, BIOS, firmware baselines. Read for model work.
- `references/validation-checklist.md`: build checks, handoff record, bench metrics. Read for QA or handoff.
- `references/asset-data-model.md`: shared canonical states and fields (source: `itam-hardware-lifecycle`). Read for state mapping.
