---
name: itam-data-analysis-reporting
description: Use when defining or choosing ITAM KPIs or KRIs, asking what a metric means or how to calculate it, assessing the quality of an asset, CMDB, discovery or MDM export, explaining why a number changed, finding trends or anomalies, analyzing an asset spreadsheet, or designing an ITAM dashboard or scorecard. Owns the metrics catalog. Not for matching records (use itam-inventory-reconciliation), status reports (itam-status-report), capacity forecasts (itam-capacity-planning), vendor scorecards (itam-vendor-contract-management) or cost models (itam-financial-management).
---

# ITAM Data Analysis and Reporting

Turns ITAM data into decisions: define measures, check the data can support them, analyze movements, and present them so the audience acts. Core principle: **no number without its definition, population, as-of date and source.** One catalog (`references/metrics-catalog.md`) keeps every skill's metric names consistent. For ITAM managers, analysts and sponsors.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **No metric without its definition.** Every number shows numerator, denominator (or statistic), population, as-of date and source. Never compute a KPI from its name alone.
7. **Targets are organizational.** Use approved targets only; otherwise report against trend and say "no approved target". A benchmark is not the user's target.
8. **Compute, don't estimate.** Calculate with code or formulas and keep them with the result; association is not causation.

## When to use

- "What KPIs should ITAM report?", "define inventory accuracy", a KPI/KRI set.
- "How good is this export?", completeness, duplicates, stale records.
- "Why did leaver recovery drop?", trends, anomalies, counts by state and site.
- An executive ITAM dashboard or scorecard design.

**When not to use:** matching records across systems (`itam-inventory-reconciliation`, then report its output here); a periodic status report with RAG, progress and asks (`itam-status-report`); stockroom, bench or staff capacity forecasts (`itam-capacity-planning`); cost models (`itam-financial-management`); building the workbook (`itam-spreadsheet-models`).

## Workflow

### Step 1 — Classify

| Request | Load |
|---|---|
| Define or choose metrics | `references/metrics-catalog.md` |
| Assess data quality | `references/data-quality-assessment.md` |
| Analyze data, KPI movement, trend, anomaly, forecast | `references/kpi-trend-anomaly-methods.md` + catalog |
| Dashboard or scorecard | `references/dashboard-design.md` + catalog |
| Field or state meaning | `references/asset-data-model.md` |

### Step 2 — Preflight

Confirm or assume: decision and audience; extracts, extract time and grain; catalog definitions and population; approved targets; period and baseline. Ask if a definition choice changes the result (`references/working-method.md` §1).

### Step 3 — Do the work

1. Profile and assess the data before computing; log defects and transformations.
2. Fill a definition card per metric; compute with code; reconcile totals to source row counts.
3. Use the smallest method: descriptive first, decomposition for movements, robust thresholds for anomalies.
4. Label explanations `INFERENCE`; present tiles with numerator and denominator and a lineage footer.

Full method: `references/working-method.md` §2.

### Step 4 — Verify before release

- ★ Every number traces to a retained query, script or formula on supplied data; nothing estimated.
- ★ Every metric shows its catalog ID or card, numerator, denominator, population and as-of date.
- ★ Joins preserve grain; totals reconcile to source row counts; failed calculations aren't reported as results.
- ★ Charts match their tables and don't distort (zero-based bars, labeled units).
- ★ No causal claim without a supporting design; no unapproved target.
- Material data-quality defects and their effect are disclosed; personal data aggregated for the audience.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The sponsor needs a number by noon; ~95% is fine" | An estimate presented as a KPI is fabrication. Compute it or label it. |
| "Industry target is 98%, use that" | Not approved here. Say "no approved target". |
| "The new process caused the improvement" | Association unless the design supports cause. |
| "The total is off by a few rows; ignore it" | Unreconciled totals mean a broken join or filter. Find it. |

Stop if you are about to: report a figure with no denominator; color a tile red or green against an invented target; publish a chart whose table you haven't checked.

## Common mistakes

| Mistake | Fix |
|---|---|
| Retired devices silently in the denominator | State population and exclusions on the card |
| Join on a non-unique key inflates counts | Check key uniqueness before joining |
| Definition changed mid-series, no note | Annotate the break; restate history if possible |
| Status only shown by color | Write status in words too |

## If connectors are available

- **~~ITSM / ~~CMDB / ~~endpoint management:** pull extracts with filter, grain and read time; cite them in the lineage footer.
- **~~finance:** read book values for financial measures.
- **~~office suite / ~~chat / ~~email:** draft the workbook or message; sharing needs approval.

## Output format

1. **Headline.**
2. **Data scope.**
3. **Data quality.**
4. **Results:** metrics table with ID, value, numerator, denominator, target status, trend.
5. **Findings and recommendations** with owner and success measure.
6. **Assumptions, limitations and validation.**

Executive and dashboard variants: `references/working-method.md` §3.

## Reference files

- `references/working-method.md`: preflight, method, output variants. Read for analysis others will act on.
- `references/metrics-catalog.md`: every KPI/KRI with definition, numerator, denominator, source; definition card; target register. Read whenever a metric is named.
- `references/data-quality-assessment.md`: profiling, dimensions, join rules. Read before analyzing an export.
- `references/kpi-trend-anomaly-methods.md`: decomposition, trends, anomalies, forecasts. Read for analysis.
- `references/dashboard-design.md`: layouts, tiles, charts, integrity rules. Read for dashboards.
- `references/asset-data-model.md`: shared canonical fields and states (source: `itam-hardware-lifecycle`). Read for state or field meaning.
