# ITAM metrics catalog (KPIs and KRIs)

The plugin's catalog of ITAM measures. Each entry gives the definition, numerator and denominator (or the statistic for time and count measures), the data source, a target placeholder, a default cadence and a suggested owner role. Other skills (governance, reconciliation) refer to these IDs.

**Basis:** formulas for inventory, data-quality, lifecycle, governance, financial and CMDB measures adapt Nicholas's AssetForge §26 metrics engine and DataForge §13 (KPI definition standard). Entries marked **(CAMP)** paraphrase an example KPA indicator from the CAMP manual (M:22-24); CAMP presents these as examples to choose from, not a mandatory set. Logistics and imaging throughput measures are `PRACTICE`. **Targets are always organizational** (`[FILL]`); cadences and owners are suggested defaults to adjust.

## How to use this catalog

- **KPI** measures performance toward a goal; **KRI** signals exposure that should stay low. Some measures are both depending on the audience.
- Don't calculate a metric from its name alone (DataForge §13). Before reporting, fill a definition card (below) for the population, exclusions and as-of date actually used.
- Every reported value shows: numerator, denominator, unit, population/filter, as-of date or period, source and extract time.
- Choose a handful per audience. Don't create vanity metrics: each one should support a decision or trigger an action (AssetForge §26).
- Field names refer to the shared `asset-data-model.md`; reconciliation codes refer to the reconciliation skill's `exception-codes.md`.

### Definition card (fill per metric before first use)

`ID` · `Name` · `Business question` · `Numerator` · `Denominator` · `Unit` · `Inclusion rules` · `Exclusion rules` · `Time grain` · `Aggregation rule` (sum, median, period-end snapshot) · `Segmentation` · `Target / threshold` (green/amber/red) · `Source fields` · `Owner` · `Interpretation notes` · `Known data-quality caveats`

## 1. Inventory (M-INV)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-INV-01 | Inventory accuracy rate | KPI | Tested records whose existence and key attributes (tag, serial, location, state) are physically confirmed | Records verified accurate | Records tested (random sample) | % | Physical verification sample vs. ITAM | `[FILL]` | Quarterly | Hardware asset manager |
| M-INV-02 | Reconciliation match rate | KPI | Repository records linked by tier 1 or 2 to at least one other source | Repository records linked (T1/T2) | Repository records in scope | % | `match_tiers.py` summary | `[FILL]` | Monthly | ITAM analyst |
| M-INV-03 | Discovery coverage | KPI | In-use discoverable assets seen by approved discovery/MDM within the active window | In-use discoverable assets seen within window | In-use discoverable assets | % | ITAM + discovery/MDM | `[FILL]` | Monthly | Endpoint / discovery owner |
| M-INV-04 | Unrecorded active devices | KRI | Active discovery/MDM devices with no repository record (PR-01, active) | Count of such devices | — (also per 1,000 managed devices) | count | Reconciliation output | `[FILL]` max | Monthly | Hardware asset manager |
| M-INV-05 | Physical verification currency | KPI | In-stock and in-use assets verified (count, scan, attestation) within the verification cadence | Assets with `last_verified_date` within cadence | Assets in `IN_STOCK` + `IN_USE` | % | ITAM | `[FILL]` | Quarterly | Hardware asset manager |
| M-INV-06 | Stockroom count variance | KPI/KRI | Difference between counted and recorded stock | Σ abs(counted − recorded) units (and value) | Recorded units | % and count | Cycle count + ITAM | `[FILL]` | Per count | Stockroom custodian |
| M-INV-07 | Recorded-not-found rate | KRI | In-scope records not found after the search period (PR-02/PR-04 confirmed) | Records confirmed not found | In-scope records | % | Reconciliation + search outcome | `[FILL]` max | Quarterly | Hardware asset manager |
| M-INV-08 | Reconciliation errors by source pair **(CAMP)** | KRI | Mismatches between inventory and electronic discovery, and between inventory and physical results (CAMP M:22) | Exceptions per source pair | — | count per run | Reconciliation output | `[FILL]` | Per run | ITAM analyst |

## 2. Data quality (M-DQ)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-DQ-01 | Required field completeness | KPI | Required fields populated, given each record's state (asset-data-model "Required from" rules) | Required field values populated | Required field values expected (Σ records × fields required for their state) | % | ITAM | `[FILL]` | Monthly | ITAM data owner |
| M-DQ-02 | Ownership completeness | KPI | In-scope assets with a valid owner: active assignee or custodian when In use; cost center from `IS+` | Assets with valid owner | In-scope assets | % | ITAM + HR | `[FILL]` | Monthly | Hardware asset manager |
| M-DQ-03 | Serial validity rate | KPI | Records whose serial normalizes as valid (not empty, placeholder, too short, mangled) | Records with valid serial | Records requiring a serial | % | `normalize_serials.py` summary | `[FILL]` | Monthly | ITAM data owner |
| M-DQ-04 | Duplicate record rate | KRI | Records sharing a strong key (serial, tag) with another record in the same source | Records in duplicate groups | Records | % | Reconciliation DQ-03 | `[FILL]` max | Monthly | ITAM data owner |
| M-DQ-05 | State validity rate | KPI | Records with a mapped state that no evidence contradicts (no ST-01/02/04/07) | Records without state exceptions | Records | % | Reconciliation output | `[FILL]` | Monthly | Hardware asset manager |
| M-DQ-06 | Location validity | KPI | Records whose location is in the location master | Records with valid location | Records requiring location | % | ITAM + location master | `[FILL]` | Monthly | ITAM data owner |
| M-DQ-07 | Transaction latency | KPI | Time from a physical event (delivery, return, move) to the record update | — | — | median and 90th percentile hours | Event timestamps (POD, receipt) vs. `state_changed_at` | `[FILL]` | Monthly | Hardware asset manager |
| M-DQ-08 | Cross-source attribute agreement | KPI | Linked clusters where a compared attribute agrees across sources (per field: user, hostname, model, location) | Clusters with no AT-01 for the field | Multi-source clusters with the field present in ≥ 2 sources | % per field | Reconciliation output | `[FILL]` | Monthly | ITAM analyst |
| M-DQ-09 | Open exceptions per 1,000 assets | KRI | Open reconciliation exceptions normalized by population | Open exceptions × 1,000 | In-scope assets | per 1,000 | Exception register | `[FILL]` max | Monthly | ITAM analyst |

## 3. Lifecycle (M-LC)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-LC-01 | Request-to-deploy cycle time | KPI | Approved request to device `IN_USE` | — | — | median, P90 business days | ITSM request + ITAM | `[FILL]` | Monthly | Deployment lead |
| M-LC-02 | Receiving-to-ready (staging) time **(CAMP)** | KPI | Physical receipt to `IN_STOCK/AVAILABLE` (CAMP AID indicator, M:22) | — | — | median, P90 hours | Receiving log + ITAM | `[FILL]` | Monthly | Receiving lead |
| M-LC-03 | Deployment cycle time | KPI | `AVAILABLE`/`RESERVED` to `IN_USE` | — | — | median, P90 days | ITAM history | `[FILL]` | Monthly | Deployment lead |
| M-LC-04 | Leaver recovery rate | KPI | Leaver devices received within the recovery SLA `[FILL days]` after last day | Leaver devices received within SLA | Leaver devices due in period | % | HR + ITAM | `[FILL]` | Monthly | Hardware asset manager |
| M-LC-05 | Leaver recovery time | KPI | Last working day to device received | — | — | median, P90 days | HR + ITAM | `[FILL]` | Monthly | Hardware asset manager |
| M-LC-06 | Unrecovered leaver devices | KRI | Devices `MISSING/NOT_RETURNED`, or `IN_USE` with inactive assignee past SLA | Count (and value on a stated basis `[FILL]`) | — | count, currency | ITAM + HR | `[FILL]` max | Monthly | Hardware asset manager |
| M-LC-07 | Refresh compliance | KPI | In-use devices within refresh eligibility or with an approved deferral | Compliant devices | In-use devices in refresh scope | % | ITAM + refresh policy | `[FILL]` | Quarterly | IT finance / HAM |
| M-LC-08 | Refresh backlog | KRI | In-use devices past eligibility without deferral | Count | — | count | ITAM | `[FILL]` max | Quarterly | HAM |
| M-LC-09 | Stock aging | KRI | `AVAILABLE` devices in stock longer than the aging threshold `[FILL]` | Aged devices | Devices in `AVAILABLE` | count, % | ITAM | `[FILL]` max | Monthly | Stockroom custodian |
| M-LC-10 | Redeployment rate | KPI | Returned devices triaged as redeployable and redeployed | Devices redeployed | Returned devices triaged in period | % | ITAM history | `[FILL]` | Quarterly | HAM |
| M-LC-11 | Lifecycle exception rate | KRI | Prohibited transitions (LC-01) in state history | Prohibited transitions | State transitions in period | % | ITAM audit history | `[FILL]` max | Monthly | HAM |
| M-LC-12 | Lost/stolen rate | KRI | Devices entering `MISSING/LOST` or `STOLEN` | Devices lost or stolen × 1,000 | Average devices in use (annualized) | per 1,000 per year | ITAM + incidents | `[FILL]` max | Quarterly | Security / HAM |
| M-LC-13 | RMAs by vendor and model **(CAMP)** | KRI | Return-merchandise authorizations (CAMP AID indicator, M:22) | RMAs | Units in service of that model (per 100) | count, per 100 units | RMA log + ITAM | `[FILL]` | Quarterly | Vendor manager / HAM |
| M-LC-14 | Repair turnaround | KPI | Time in `IN_MAINTENANCE` | — | — | median, P90 days | ITAM history | `[FILL]` | Monthly | Service desk lead |
| M-LC-15 | Loaner overdue rate | KRI | Active loans past `loan_due_date` | Overdue loans | Active loans | % | ITAM | `[FILL]` max | Monthly | Service desk lead |
| M-LC-16 | In-use past warranty | KRI | In-use devices with `warranty_end` before as-of date | Devices past warranty | In-use devices | % | ITAM | `[FILL]` | Quarterly | HAM |

## 4. Governance (M-GOV)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-GOV-01 | Control execution rate | KPI | Scheduled ITAM controls executed on time with evidence | Executions on time with evidence | Scheduled executions | % | Control log | `[FILL]` | Monthly | ITAM program owner |
| M-GOV-02 | Exception aging | KRI | Open exceptions older than their resolution SLA | Open exceptions past SLA | Open exceptions | %, plus counts by age band | Exception register | `[FILL]` max | Monthly | ITAM program owner |
| M-GOV-03 | Remediation on-time closure | KPI | Remediation actions closed by target date with closure evidence | Closed on time | Actions due in period | % | Remediation tracker | `[FILL]` | Monthly | ITAM program owner |
| M-GOV-04 | Audit finding recurrence | KRI | Findings repeating a prior finding | Repeat findings | Findings in period | % | Audit reports | `[FILL]` max | Per audit | ITAM program owner |
| M-GOV-05 | Evidence completeness | KPI | Sampled lifecycle transitions with all required evidence (asset-data-model 4.2) | Complete samples | Transitions sampled | % | Evidence sample | `[FILL]` | Quarterly | Internal control owner |
| M-GOV-06 | Policy review currency **(CAMP)** | KPI | ITAM policies reviewed within their review cycle (CAMP POL indicator, M:24) | Policies reviewed in cycle | ITAM policies | % | Policy register | `[FILL]` | Semi-annual | Policy owner |
| M-GOV-07 | ITAM training coverage **(CAMP)** | KPI | Target groups (new hires, IT staff, software administrators, on-site vendors) trained on ITAM policy (CAMP C&E indicators, M:23) | People trained | People in target group | % per group | LMS / HR | `[FILL]` | Quarterly | C&E owner |
| M-GOV-08 | Ticket-linked changes **(CAMP)** | KPI | Asset/configuration changes tied to a service-desk ticket (CAMP PRG indicator, M:24) | Changes with ticket reference | Changes | % | ITAM audit history + ITSM | `[FILL]` | Monthly | Service desk / HAM |
| M-GOV-09 | Standard catalog conformance **(CAMP)** | KPI | Deployed assets that are standard models (CAMP PRG indicator, M:24) | Deployed standard-model assets | Deployed assets | % | ITAM + catalog | `[FILL]` | Quarterly | ITAM program owner |
| M-GOV-10 | Non-standard request rate and approval time **(CAMP)** | KPI | Share of requests that are non-standard, and time to decide them (CAMP ACQ indicators, M:22) | Non-standard requests | All requests | %, median days to decision | ITSM | `[FILL]` | Quarterly | Acquisition manager |

## 5. Financial (M-FIN)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-FIN-01 | Cost per managed asset | KPI | Defined hardware lifecycle cost (components `[FILL]`) per managed asset | Total defined cost in period | Average managed assets | currency | ERP + ITAM | `[FILL]` | Annual | IT finance |
| M-FIN-02 | Redeployment cost avoidance | KPI | Purchases avoided by redeploying returned devices; report as avoidance, not savings | Devices redeployed × standard replacement price `[FILL]` | — | currency | ITAM + catalog price | `[FILL]` | Quarterly | IT finance / HAM |
| M-FIN-03 | Disposition value recovered | KPI | Resale, trade-in and donation value received | Σ `disposal_proceeds` | — (also per disposed unit) | currency | ITAD settlements | `[FILL]` | Quarterly | HAM / finance |
| M-FIN-04 | Invoice reconciliation rate **(CAMP)** | KPI | Invoices reconciled for charge accuracy (CAMP FIN indicator, M:24) | Invoices reconciled | Invoices received | % | AP / ERP | `[FILL]` | Monthly | IT finance |
| M-FIN-05 | Unrecovered asset loss | KRI | Value of written-off, lost, stolen and unrecovered devices on a stated basis (net book or replacement `[FILL]`) | Σ value | — | currency | ITAM + finance | `[FILL]` max | Quarterly | IT finance |
| M-FIN-06 | Refresh forecast variance | KPI | Difference between forecast and actual refresh spend or units | Actual − forecast | Forecast | % | Forecast + ERP | `[FILL]` | Quarterly | IT finance |
| M-FIN-07 | Warranty recovery rate | KPI | Repairs of in-warranty devices claimed under warranty rather than paid | Repairs claimed under warranty | Repairs on in-warranty devices | % | Repair log + warranty data | `[FILL]` | Quarterly | Service desk lead |
| M-FIN-08 | TCO/ROI coverage **(CAMP)** | KPI | Managed asset types monitored for TCO/ROI where appropriate (CAMP FIN indicator, M:24) | Asset types monitored | Managed asset types | % | ITAM finance model | `[FILL]` | Annual | IT finance |
| M-FIN-09 | Leased assets past lease end | KRI | Leased devices not returned by `lease_end_date` | Count (and estimated charges, if contract states them) | — | count, currency | ITAM + lease contracts | `[FILL]` max | Monthly | HAM |
| M-FIN-10 | Contracts reviewed for financial terms **(CAMP)** | KPI | Contracts reviewed for financial terms before signature (CAMP FIN indicator, M:24) | Contracts reviewed | Contracts signed | % | Contract repository | `[FILL]` | Quarterly | Vendor / finance |

## 6. CMDB (M-CMDB)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-CMDB-01 | CI completeness | KPI | CIs with all required attributes for their class | Complete CIs | CIs in scope | % | CMDB | `[FILL]` | Monthly | Configuration manager |
| M-CMDB-02 | Duplicate CI rate | KRI | CIs in duplicate groups (same identifying attributes) | Duplicate CIs | CIs | % | CMDB | `[FILL]` max | Monthly | Configuration manager |
| M-CMDB-03 | Orphan CI rate | KRI | CIs missing required relationships | Orphan CIs | CIs requiring relationships | % | CMDB | `[FILL]` max | Monthly | Configuration manager |
| M-CMDB-04 | Stale CI rate | KRI | Discoverable CIs not updated by discovery within the window | Stale CIs | Discoverable CIs | % | CMDB | `[FILL]` max | Monthly | Configuration manager |
| M-CMDB-05 | Asset-CI sync rate | KPI | Linked asset-CI pairs whose states agree under the state mapping | Pairs in agreement | Linked pairs | % | ITAM + CMDB | `[FILL]` | Monthly | Config manager / HAM |
| M-CMDB-06 | Relationship completeness | KPI | CIs with the relationships their class requires (e.g. to a service) | CIs with required relationships | CIs requiring relationships | % | CMDB | `[FILL]` | Monthly | Configuration manager |
| M-CMDB-07 | Asset-without-CI rate | KRI | Assets of CI-expected classes with no CI (PR-08) | Assets without CI | Assets of CI-expected classes | % | Reconciliation | `[FILL]` max | Monthly | Config manager / HAM |
| M-CMDB-08 | CI-without-asset rate | KRI | CIs of asset-expected classes with no asset record (PR-07) | CIs without asset | CIs of those classes | % | Reconciliation | `[FILL]` max | Monthly | Config manager / HAM |

Never infer CMDB health from the existence of populated records alone (AssetForge §11.4).

## 7. Software license (M-LIC)

Summary measures for dashboards. License position calculation and publisher rules belong to the software license management skill.

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-LIC-01 | License compliance rate **(CAMP)** | KPI/KRI | Software titles whose entitlement covers consumption under the contract metric (CAMP CMP indicator, M:23) | Compliant titles | Titles in scope | % | SAM tool / ELP | `[FILL]` | Quarterly | Software asset manager |
| M-LIC-02 | Unused license rate | KPI | Assigned licenses with no use in `[FILL]` days | Unused assigned licenses | Assigned licenses | % | SAM / SaaS usage | `[FILL]` | Monthly | SAM |
| M-LIC-03 | Reharvest rate | KPI | Licenses identified for reclaim that were reclaimed and reassigned or removed | Reclaimed | Identified for reclaim | % | SAM workflow | `[FILL]` | Monthly | SAM |
| M-LIC-04 | Software harvested at disposal **(CAMP)** | KPI | Disposed devices whose software/licenses were reclaimed where applicable (CAMP DIS indicator, M:23) | Disposed devices with reclaim recorded | Disposed devices with licensed software | % | ITAM + SAM | `[FILL]` | Quarterly | SAM / HAM |
| M-LIC-05 | Unused SaaS subscription cost | KRI | Cost of SaaS seats unused for `[FILL]` days | Σ cost of unused seats | — | currency | SaaS management | `[FILL]` max | Monthly | SAM |
| M-LIC-06 | License agreements managed by ITAM **(CAMP)** | KPI | Known license agreements held in the managed repository (CAMP DOC indicator, M:23) | Agreements managed | Known agreements | % | Contract repository | `[FILL]` | Quarterly | SAM / documentation owner |
| M-LIC-07 | Documents linked to assets **(CAMP)** | KPI | Agreements, proofs of purchase and warranties linkable to their asset or entitlement record (CAMP DOC indicator, M:23) | Documents linked | Documents | % | Repository + ITAM | `[FILL]` | Quarterly | Documentation owner |

## 8. Disposal (M-DIS)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-DIS-01 | Formal disposal coverage **(CAMP)** | KPI | Assets leaving custody through the formal disposal process (CAMP DIS indicator, M:23) | Assets disposed via formal process | Assets leaving custody (recycled, destroyed, sold, donated, returned) | % | ITAM | `[FILL]` | Quarterly | HAM |
| M-DIS-02 | Sanitization evidence rate **(CAMP)** | KPI/KRI | Storage-bearing devices with per-serial evidence that data was secured before transfer of ownership (CAMP DIS indicator, M:23) | Devices with evidence | Storage-bearing devices disposed | % | ITAM + wipe/ITAD reports | `[FILL]` | Monthly | Information security / HAM |
| M-DIS-03 | Certificate reconciliation rate | KPI | Serials handed to the ITAD vendor that appear on a certificate | Serials on certificate | Serials handed over | % | Manifest + certificate | `[FILL]` | Per lot | HAM |
| M-DIS-04 | Retire-to-dispose cycle time | KPI | `RETIRED` to `DISPOSED` | — | — | median, P90 days | ITAM history | `[FILL]` | Monthly | HAM |
| M-DIS-05 | Chain-of-custody breaks | KRI | Serials on a pickup manifest missing from the vendor receipt or certificate, or the reverse | Count | — | count | Manifest + vendor reports | 0 / `[FILL]` | Per lot | HAM |
| M-DIS-06 | Disposal per applicable rules **(CAMP)** | KPI | Disposed hardware, by asset type, handled per the rules that apply locally (CAMP CMP indicator, M:23) | Conforming disposals | Disposals | % | ITAD reports + compliance review | `[FILL]` | Quarterly | Compliance / HAM |
| M-DIS-07 | Disposal backlog | KRI | `RETIRED` records older than the retire-to-dispose target | Count | — | count | ITAM | `[FILL]` max | Monthly | HAM |

## 9. Logistics and imaging throughput (M-OPS)

| ID | Metric | Type | Definition | Numerator | Denominator | Unit | Data source | Target | Cadence | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| M-OPS-01 | Receiving throughput | KPI | Units received and fully recorded per receiving day | Units recorded | Receiving days | units/day | Receiving log + ITAM | `[FILL]` | Weekly | Receiving lead |
| M-OPS-02 | Pick and kit accuracy | KPI | Orders shipped with the correct device and accessories | Correct orders | Orders shipped | % | Logistics log + complaints | `[FILL]` | Monthly | Logistics lead |
| M-OPS-03 | Imaging throughput | KPI | Devices built and passing validation per bench-day | Devices passing validation | Bench-days | devices/bench-day | Imaging/MDM logs | `[FILL]` | Weekly | Imaging lead |
| M-OPS-04 | Build first-pass yield | KPI | Builds passing validation on the first attempt | First-pass builds | Builds attempted | % | Build validation records | `[FILL]` | Weekly | Imaging lead |
| M-OPS-05 | Build cycle time | KPI | `IN_BUILD` to validated | — | — | median, P90 hours | Build records / ITAM history | `[FILL]` | Weekly | Imaging lead |
| M-OPS-06 | Joiner on-time delivery | KPI | Joiner devices delivered (proof of delivery) before the start date | On-time deliveries | Joiner devices due | % | HR start dates + carrier POD | `[FILL]` | Monthly | Deployment lead |
| M-OPS-07 | Return-kit return rate | KPI | Return kits sent to leavers/remote users that came back with the device, measured after `[FILL]` days | Kits returned with device | Kits sent (aged ≥ `[FILL]` days) | % | Logistics + ITAM | `[FILL]` | Monthly | Logistics lead |
| M-OPS-08 | In-transit loss and damage rate | KRI | Shipments lost or damaged | Lost or damaged shipments | Shipments | % | Carrier claims | `[FILL]` max | Monthly | Logistics lead |
| M-OPS-09 | Stock availability | KPI | Model-days at or above the minimum stock level | Model-days at/above minimum | Model-days in period | % | ITAM stock levels | `[FILL]` | Weekly | Stockroom custodian |
| M-OPS-10 | Shipping cost per device | KPI | Outbound and return shipping cost per device moved | Shipping cost | Devices shipped | currency | Carrier invoices | `[FILL]` | Monthly | Logistics lead |
| M-OPS-11 | In-transit dwell exceeded | KRI | Shipments in `IN_TRANSIT` beyond the route's expected time | Count | — | count | ITAM + carrier tracking | `[FILL]` max | Weekly | Logistics lead |
| M-OPS-12 | Vendor pre-delivery accuracy **(CAMP)** | KPI | Vendor-delivered units with services applied correctly before delivery (tag, imaging, registration) (CAMP AID indicator, M:22) | Correct units | Units received with pre-delivery services | % | Receiving inspection | `[FILL]` | Monthly | Vendor manager |

## 10. CAMP KPA indicator crosswalk

CAMP lists example indicators per KPA (M:22-24; S:56, 62, 75, 79, 87, 94, 100, 107, 122, 129, 137). This catalog covers them as follows; indicators not listed (legislation review cadence, project on-time delivery, vendor scorecards) belong to the governance, vendor and project skills.

| KPA | Catalog IDs |
|---|---|
| Acquisition (ACQ) | M-GOV-10, M-LC-01 |
| Asset identification (AID) | M-LC-02, M-LC-13, M-INV-08, M-OPS-12 |
| Communication & education (C&E) | M-GOV-07 |
| Compliance (CMP) | M-LIC-01, M-DIS-06 |
| Disposal (DIS) | M-DIS-01, M-DIS-02, M-LIC-04 |
| Documentation (DOC) | M-LIC-06, M-LIC-07 |
| Financial (FIN) | M-FIN-04, M-FIN-08, M-FIN-10 |
| Policy (POL) | M-GOV-06 |
| Program (PRG) | M-GOV-08, M-GOV-09 |

## 11. Target register (fill once, review `[FILL]`)

| ID | Green | Amber | Red | Basis for target (policy, contract, baseline, benchmark) | Approved by | Review date |
|---|---|---|---|---|---|---|
| `[ID]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` |

If no target is approved, report the value against its own trend and say "no approved target"; don't invent one.
