# Methods: KPI movement, trends, anomalies, forecasts and findings

Use this file when working with an asset export or a metric series: explaining why a KPI moved, finding anomalies, describing trends, forecasting, or writing findings. Basis: condensed from Nicholas's DataForge §5–7 (preflight and task classification), §10–14 (exploration, statistics, time series, KPI and anomaly standards), §16–17 (interpretation, causal and forecasting controls) and §25 (recommendations). Methods are `PRACTICE`.

## 1. Classify the task, then use the smallest method

| Task | Typical ITAM question | Default method |
|---|---|---|
| Descriptive | "How many laptops by state and site?" | Counts and percentages by segment, with totals that reconcile |
| Data-quality assessment | "Can we trust this export?" | `data-quality-assessment.md` |
| Reconciliation | "What's in Intune but not ServiceNow?" | Hand to the reconciliation skill (scripts) |
| KPI movement | "Why did leaver recovery drop?" | Section 3 decomposition |
| Trend | "Is inventory accuracy improving?" | Section 4 |
| Anomaly / exception | "Anything odd in last month's disposals?" | Section 5 |
| Forecast | "How many laptops will need refresh next year?" | Section 6; refresh method in the hardware lifecycle skill |
| Causal | "Did the new return kit improve returns?" | Section 7; usually reframe as association |

Default to descriptive work when it answers the question. Escalate only when the question needs it.

## 2. Preflight (answerability)

Check five kinds of sufficiency before substantive work (DataForge §5): objective (what decision?), data (required records, fields and periods present?), semantics (grain, field meanings, KPI definitions, state meanings clear?), method (can the design support the conclusion asked for?), tools (can the numbers be computed exactly here?). For a material gap, choose the least disruptive response: retrieve the missing data, ask the one question that changes the outcome, list the plausible interpretations, assume-and-label a low-risk assumption, narrow to the supported subset, or decline unsupported precision.

## 3. Explaining a KPI movement

1. Confirm the definition card (metrics catalog) and that numerator and denominator were computed the same way in both periods.
2. Check **denominator integrity**: did the population change (new site onboarded, new discovery source, bulk clean-up)?
3. Decompose: `TOTAL CHANGE → VOLUME EFFECT → RATE / MIX EFFECT → SEGMENT CONTRIBUTION → EXCEPTIONS`. Illustration (hypothetical numbers): leaver recovery falls from 92% to 84% → leaver volume doubled after a reorganization (volume) → remote leavers rose from 30% to 60% of the mix and recover at a lower rate (mix) → one region contributes most of the gap (segment) → a block of devices sits with involuntary leavers awaiting HR (exceptions).
4. Report each component with numbers. Don't attribute the change to a cause just because a suspected driver moved in the same direction.

## 4. Trends

- Compare full periods with full periods; flag partial periods.
- Show enough history to see normal variation; mark definition changes and data-source changes on the chart.
- Use counts and rates together; a falling exception rate with a rising population can still mean more exceptions.
- For noisy weekly operational series, a rolling median or control-chart view separates signal from noise better than week-over-week percentages.

## 5. Anomalies

An anomaly is a departure from an expected pattern, not automatically an error, fraud or root cause (DataForge §14). Methods, simplest first: business-rule thresholds (a user with more than `[FILL]` active laptops; disposal lots where certificate counts ≠ manifest counts), percentile/IQR rules, robust z-scores, rolling baselines, peer-group comparison (a site vs. similar sites). For each anomaly report: entity and period, observed value, expected value and its basis, deviation size, method, likely explanations, evidence needed to confirm, and follow-up. Calibrate thresholds to the team's capacity to investigate; a rule that fires thousands of times a week will be ignored.

ITAM patterns worth testing: bulk state changes on one day by one account; assets disposed shortly after purchase; devices repeatedly lost by the same person or route; stock appearing without receipts; costs heaped on a round number.

## 6. Forecasts

- State the method, horizon, assumptions and what would make it wrong.
- Prefer transparent methods (cohort aging from purchase dates, policy-driven eligibility, run rate × known volume changes) over opaque models for budgeting.
- Show a range (low / expected / high) driven by the uncertain assumptions (deferrals, headcount, redeploy rate), not false precision.
- Label forecast values clearly and keep them visually distinct from actuals.

## 7. Causal claims

Most ITAM questions of the form "did X cause Y?" can only be answered as association from operational data. Say so, then state what design would support a causal claim (a pilot with a comparison group, a before/after with a stable control site, a phased rollout). Don't present correlation as cause (DataForge §17, AC-09).

## 8. Writing findings

For each finding answer (DataForge §16): what is the finding; what evidence supports it; how large is it; what population and period; what uncertainty remains; what alternative explanation is plausible; why it matters; what decision it supports. Label `FACT` for computed values, `INFERENCE` for explanations, `ASSUMPTION` for anything assumed.

Recommendations follow from verified findings, name an owner role, say what they'd change and how success will be measured (a catalog metric), and state what could invalidate them. Don't let a recommendation exceed the strength of its evidence.

## 9. Computation and reproducibility

- Compute with code or spreadsheet formulas, not mental arithmetic; keep the query, script or formula with the result.
- Recalculate material numbers by a second route (independent recount, reconcile to source totals).
- Never report a result from a tool run that failed or wasn't run; give a bounded partial result instead.
- Protect personal data: user names and identifiers in asset exports are personal data; aggregate for broad audiences and share record-level detail only with people who need it.
