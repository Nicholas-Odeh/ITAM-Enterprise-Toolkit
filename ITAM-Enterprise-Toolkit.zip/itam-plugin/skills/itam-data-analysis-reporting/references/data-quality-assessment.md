# ITAM data-quality assessment

Use this file to assess an asset export (ITAM repository, CMDB, discovery, MDM, finance register) before analysis or reporting, or when the user asks "how good is our asset data?". The aim is to know what the data can and can't support before any KPI or chart is built on it.

**Basis:** dimensions and the defect report format adapt Nicholas's DataForge §8 (data-quality standard), §9 (cleaning and transformation log), §26 (failure modes) and §27 (acceptance criteria); ITAM dimensions such as ownership, lifecycle integrity and traceability come from ProcessForge §12 and AssetForge §26.2. Field rules refer to the shared `asset-data-model.md`. Checks are `PRACTICE`; thresholds are `[FILL]`.

## 1. Profile before judging

For each extract, record before anything else:
- source system, extract time, filter used, who pulled it;
- **grain** (one row per asset? per asset per user? per NIC?) and the key that proves it (`asset_id` or serial unique?);
- row count, column list, data types, and the population it claims to cover (all assets, one region, active only?).

Don't aggregate, join or compute KPIs until the grain is established (DataForge F02).

## 2. Dimensions and ITAM checks

| Dimension | Question | ITAM checks (examples) |
|---|---|---|
| Completeness | Does the expected population and its required data exist? | Null rate per field; required fields by state per `asset-data-model.md`; whole sites, classes or months missing; records expected from another source but absent |
| Validity | Do values follow formats, lists and ranges? | Serial and tag formats; placeholder serials (`normalize_serials.py` flags); state/substate pairs in the canonical list; dates not in the future; cost > 0; cost center, location, model from master lists |
| Consistency | Do fields and systems agree? | `IN_USE` with empty assignee; `IN_STOCK` with an assignee; `DISPOSED` without `disposal_date`; `received_date` before `order_date`; same device with different user or model across sources |
| Uniqueness | Is each real asset recorded once? | Duplicate serials, tags, hostnames among active records; near-duplicates differing only in case or punctuation |
| Integrity | Do references resolve? | `assigned_to` exists in HR/IdP; `ci_ref` resolves; `po_number` exists in ERP; model in catalog |
| Timeliness | Is the data current? | Discovery `last_seen` age distribution; `last_verified_date` within cadence; lag between physical events and record updates |
| Ownership | Does every controlled asset have accountable ownership? | Assignee or custodian for In use; cost center from `IS+`; `managed_by` for stock |
| Lifecycle integrity | Are statuses logically possible? | State history contains only allowed transitions; dwell times plausible; no record active after disposal |
| Traceability | Can an asset be followed from acquisition to disposition? | PO → receipt → record → assignment → retirement → certificate links present for a sample |
| Plausibility / distribution | Do values look real? | Spikes on one date (bulk import), heaping on round costs, one user with 40 laptops, sudden category explosion in model names |

Report defects in this format (DataForge §8):

| Issue | Affected field / population | Severity | Evidence (count, %, example IDs) | Analytical impact | Recommended treatment | Residual risk |
|---|---|---|---|---|---|---|

Severity guide (`PRACTICE`): **Critical** = invalidates a KPI or conclusion the user asked for (for example, no usable key to join sources); **High** = biases a result materially; **Medium** = limits a segment; **Low** = cosmetic.

## 3. Treatment and the transformation log

- Treat the raw extract as immutable. Work on a copy or add columns.
- Don't repair defects silently, and don't impute missing values just to make the data look complete. Separate *detected defect*, *proposed remediation*, *applied remediation*, *excluded data* and *unresolved uncertainty*.
- Flag outliers before removing them; never remove values because they weaken the expected result.
- For every material transformation record:

| ID | Input | Rule | Rationale | Rows/fields affected | Before | After | Validation | Reversible? |
|---|---|---|---|---|---|---|---|---|

Common ITAM transformations: identifier normalization (serials, tags, hostnames, users), state mapping to canonical states, model value maps, date parsing with explicit formats, deduplication to one row per device, exclusion of virtual serials from hardware counts.

## 4. Joins between asset sources

Before joining: confirm the grain of both sides, check key uniqueness, state the expected relationship (1:1, 1:many) and count keys that won't match. After joining: compare row counts, test for duplicate multiplication, and reconcile totals (DataForge §9). For matching devices across systems, use the reconciliation skill's tiered matcher instead of a single-key join.

## 5. Scorecard

Summarize as a short scorecard the user can track over time:

| Dimension | Measure (metrics catalog ID) | Value | Population | As of | Status vs. target |
|---|---|---|---|---|---|
| Completeness | M-DQ-01 | | | | |
| Ownership | M-DQ-02 | | | | |
| Validity | M-DQ-03, M-DQ-06 | | | | |
| Uniqueness | M-DQ-04 | | | | |
| Consistency / lifecycle | M-DQ-05, M-DQ-08 | | | | |
| Timeliness | M-DQ-07, M-INV-03 | | | | |

Don't compute a single blended "data-quality score" unless the user asks and agrees the weights; a blended score hides which dimension failed.

## 6. Failure modes to watch

| Code | Failure | Recovery |
|---|---|---|
| F01 | KPI name used without a definition | Get or derive numerator, denominator, filters, grain and exclusions first |
| F02 | Unknown grain | Inspect uniqueness; don't aggregate or join until known |
| F03 | Join multiplication | Stop; inspect key cardinality; fix the relationship; rerun |
| F04 | Material missingness | Quantify the pattern; check whether it's concentrated (one site, one source); choose and disclose treatment |
| F06 | Conflicting sources | Keep the conflict; compare authority (attribute authority table), definitions and dates; narrow the claim |
| F09 | Tool or script failure | Don't claim success; fix and rerun, or return a bounded partial result |
| F11 | Critical metric doesn't reconcile to source totals | Don't release as verified; trace filters, joins and formulas |
| F12 | Small or unrepresentative sample | Report uncertainty; avoid generalizing |

(Codes follow DataForge §26.)
