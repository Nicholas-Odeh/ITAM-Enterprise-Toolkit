# Data analysis and reporting: preflight, method and output variants

Detail behind Steps 2, 3 and the output format of `itam-data-analysis-reporting`. Read it for any analysis or report that someone else will act on.

## Contents
1. Preflight checklist
2. Working method
3. Output variants

## 1. Preflight checklist

Confirm, or state as assumptions:
- **The decision and audience** the analysis or report serves.
- **Data supplied:** which extracts, from which systems, extract time, filters, grain, and whether personal data is included.
- **Definitions:** which catalog metrics apply; population, inclusions and exclusions; state mapping to canonical states; the active window for discovery; the value basis for money (net book, replacement, purchase).
- **Targets and thresholds:** approved, or absent.
- **Period and comparison:** as-of date, reporting period, prior period or baseline.
- **Output:** dashboard (which tool), report, slide, table, or a quick answer.

Read `templates/company-profile.md` if present. If a definition choice would change the result materially (for example, whether retired devices are in the denominator), ask; otherwise proceed and label the choice `ASSUMPTION`. The answerability tests in `kpi-trend-anomaly-methods.md` §2 apply.

## 2. Working method

1. **Profile and assess** the data before computing anything: grain, keys, completeness, validity, duplicates, freshness. Record defects and every transformation (`data-quality-assessment.md`).
2. **Fill a definition card** for each metric used (`metrics-catalog.md`) and compute it with code or formulas; reconcile totals to the source row counts.
3. **Analyze** with the smallest method: descriptive breakdowns first; decomposition for KPI movements; thresholds or robust statistics for anomalies; transparent forecasts with ranges (`kpi-trend-anomaly-methods.md`).
4. **Interpret** each finding: size, population, uncertainty, alternative explanation, decision supported. Label explanations `INFERENCE`. Association is not causation.
5. **Present** for the audience: KPI tiles with numerator and denominator, target status in words as well as color, trend, honest charts, annotations for definition or source changes, lineage footer (`dashboard-design.md`). Use a dashboard or visualization skill or artifact type, if available, for the mechanics.

## 3. Output variants

**Practitioner report (default):**
1. **Headline:** two to four sentences: the answer and why it matters.
2. **Data scope:** sources, extract times, population, grain, exclusions.
3. **Data quality:** material defects and treatments (or "fit for purpose" with evidence).
4. **Results:** metrics table (ID, value, numerator, denominator, target status, trend) and supporting breakdowns or charts.
5. **Findings and recommendations:** each finding with evidence, size, uncertainty, and the action, owner and success measure.
6. **Assumptions, limitations and validation:** what was assumed, what wasn't evaluated, how numbers were checked.

**Executive variant:** one page: headline, four to six KPI tiles, top three risks with owners, decisions requested; detail in an appendix.

**Dashboard variant:** the layout in `dashboard-design.md` for the named audience, plus the definition list and lineage footer.

**Status report:** when the user wants a periodic program or project status update (RAG, progress, risks, asks), hand the metrics produced here to `itam-status-report`.

Sources: DataForge §5–7, 10–17, 25.
