# ITAM dashboard and report design

Use this file when building an ITAM dashboard, scorecard or recurring report (in a BI tool, a spreadsheet, a slide or an HTML page), or reviewing one. If a charting or dashboard skill is available (for example a data-visualization skill or a dashboard artifact type), use it for the mechanics and use this file for ITAM content and integrity rules.

**Basis:** visual integrity rules condense Nicholas's DataForge §15 (visualization standard) and §16 (interpretation); KPI tile content follows DataForge §13. Audience layouts are `PRACTICE`.

## 1. Start from decisions, not data

For each dashboard write down, before choosing charts:
1. **Audience** (executive sponsor, ITAM manager, stockroom/service-desk lead, auditor).
2. **Decisions or actions** the page supports (fund refresh, chase leaver devices, fix a data feed, accept audit evidence).
3. **Three to eight measures** from `metrics-catalog.md` that inform those decisions, each with an approved target or "no approved target".
4. **Refresh cadence** and the source extracts behind each measure.

A measure nobody acts on doesn't belong on the page.

## 2. Layouts by audience

| Audience | Purpose | Typical content | Avoid |
|---|---|---|---|
| Executive (monthly/quarterly) | Exposure, value, direction | 4–6 KPI tiles (inventory accuracy, unrecovered leaver devices and value, refresh backlog, unrecorded active devices, disposal evidence rate, cost avoidance); one trend per tile; top 3 risks with owners | Record-level tables, tool jargon, more than one page |
| ITAM manager (weekly/monthly) | Run the program | KPIs vs. target with trend; exception counts by code and age; lifecycle cycle times; breakdown by site/class/source | Unranked long tables without filters |
| Operations lead (daily/weekly) | Work the queue | Open exceptions by owner and age; leaver recoveries due; stock levels vs. minimum; builds in progress; shipments overdue | Ratios without the underlying counts |
| Auditor / control owner (per period) | Evidence that controls ran | Control execution log; population counts with as-of date; reconciliation results; exception register with closure evidence | Charts without the data table behind them |

## 3. KPI tile specification

Each tile shows: **name** (catalog ID in small text) · **current value** with unit · **target** and status (only if an approved target exists) · **trend** (sparkline or prior period) · **numerator / denominator** (for example "1,212 / 1,300") · **population and as-of date**. Status must not rely on color alone: add a word or symbol (On target / Watch / Off target).

## 4. Choosing the chart

| Question | Use | ITAM example |
|---|---|---|
| Compare categories | Sorted bar chart or dot plot | Exceptions by code; recovery rate by site |
| Trend over time | Line chart | Inventory accuracy by quarter; unrecorded devices by month |
| Distribution | Histogram or box plot | Device age; days to recover leaver devices; stock aging |
| Part-to-whole (few parts) | Stacked bar (100% only when shares matter) | Fleet by lifecycle state; exceptions by severity |
| Deviation from target | Bar vs. reference line, variance bars | Refresh forecast vs. actual |
| Flow between states | Table of transition counts, or a simple stage funnel | Received → recorded → deployed |
| Exact lookup | Table | Exception register; devices assigned to leavers |
| Location | Map only if location drives the decision | Stock by depot when shipping cost depends on region |

## 5. Integrity rules (non-negotiable)

- Label units and time periods; show the as-of date and source on every page.
- Bar charts start at zero. Don't truncate axes in ways that exaggerate differences.
- No 3D, no decorative effects, no dual axes unless justified and clearly labeled.
- Show denominators or sample sizes where interpretation depends on them; a 100% recovery rate from 2 leavers is not the same as from 200.
- Distinguish actuals, estimates, targets and forecasts visually and in the legend.
- Annotate definition changes, new data sources, migrations and bulk clean-ups that cause discontinuities. A jump in "unrecorded devices" after onboarding a new discovery source is a coverage change, not a deterioration.
- Titles state the message or question ("Leaver recovery fell below target in Q3"), not just field names.
- Every chart must reconcile to the table or calculation behind it (DataForge §15 data-to-visual check).
- Don't imply causation from co-movement (DataForge §13, §17).

## 6. Recurring report skeleton

This skeleton is the metrics content of a recurring report. A program or project status report (RAG status, progress against plan, risks, asks, next steps) belongs to `itam-status-report`, which takes its figures and definitions from here.

1. **Headline** — two to four sentences: what changed, why it matters, what is being done.
2. **Scorecard** — KPI tiles or table with targets and trend.
3. **Exposure** — KRIs and the top exceptions by value or risk, with owners.
4. **Drivers** — breakdowns that explain the movement (site, class, source, root-cause category).
5. **Actions** — open remediation items with owners and due dates; status of last period's actions.
6. **Data notes** — sources, as-of dates, definition changes, known data-quality limits, measures not reported and why.

## 7. Data lineage footer

Put on every dashboard page or report: sources with extract times, filters, metric definitions version (catalog IDs), refresh schedule, owner, and a contact for questions. Without it, the numbers can't be audited.
