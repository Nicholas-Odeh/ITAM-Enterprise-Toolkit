# ITAM change record template

Copy this template for every ITAM change. Leave no section blank: write "N/A, because …" when a section doesn't apply. Organization values (change classes, CAB cadence, approvers, freeze windows) come from the organization's change policy or `templates/company-profile.md`; until then they are `[FILL]`.

**Basis:** the section order and the assess-plan-execute-sustain framing adapt the Operations plugin's `change-request` skill. The ITAM sections (dry-run evidence, side effects, audit trail, snapshot) and the risk rubric are `PRACTICE`. ServiceNow behavior is cited to the official docs (`DOC`, ServiceNowDocs brazil branch, as checked 2026-10-20) or marked `VERIFY`.

## Contents
1. Template
2. Risk rubric (`PRACTICE`)
3. Change class guidance
4. Snapshot and audit-trail specification
5. Readiness gate

## 1. Template

```markdown
## Change Request: [Title]
**Change ID:** [ITSM number or PENDING] | **Class:** [Standard / Normal / Emergency — per org policy [FILL]]
**Requester:** [Name/role] | **Change owner:** [Name/role] | **Implementer:** [Name/role]
**Date raised:** [Date] | **Priority:** [Critical/High/Medium/Low]
**Status:** Draft | Not ready (dry run pending) | Pending approval | Approved | In progress | Complete | Rolled back
**Change window:** [Start–end, time zone] | **Freeze calendar checked:** [Yes, source / No]
**Catalog type:** [C1–C7 from itam-change-catalog.md]

### 1. Description
[What is changing, in one paragraph. Name the systems, tables or record types, and the environment.]

### 2. Business justification
[Why: audit finding, data-quality KPI breach, cost, compliance, process change. Cite the finding, KPI ID or ticket.]

### 3. Scope and dry-run evidence
| Item | Value | Source / as-of |
|---|---|---|
| Selection criteria (filter, query, file) | [Exact filter or file name] | [System, extract time] |
| Records in scope | [N from dry run] or `[PENDING DRY RUN]` | [Dry run ID / time] |
| Breakdown | [N per class / state / site / source] | [Dry run] |
| Records excluded and why | [N, reason] | [Dry run] |
| Linked CIs affected | [N] | [Query] |
| Scope cap (abort above) | [N] | Set by change owner |
| Before/after sample | [Attached: N records, strata listed] | [File] |

**Sample strata (minimum):** a typical record, blank or placeholder serial, record with a linked CI, retired or disposed record, duplicate-group member, record owned by a leaver. Show the field values before and the predicted values after.

### 4. Impact analysis
| Area | Impact (H/M/L/None) | Details |
|---|---|---|
| Users / requesters | | [Who, how many, what they notice] |
| ITAM staff and process | | [Workflows, queues, stockroom tasks] |
| Asset records | | [N records, fields changed] |
| Linked CIs and CMDB | | [N CIs; which fields sync; relationships] |
| License position (SAM) | | [Publishers/products whose position may move; when reconciliation runs] |
| Finance / fixed assets | | [Cost centers, depreciation, fixed-asset register links] |
| Reports and KPIs | | [Metric IDs whose baseline shifts] |
| Integrations and scheduled jobs | | [Discovery, MDM, imports, ERP/HR feeds] |
| Security / compliance | | [Audit evidence, data retention, legal hold] |
| Cost | | [Effort, tooling, shipping] |

### 5. Risk assessment
| # | Risk | Likelihood (H/M/L) | Impact (H/M/L) | Rating | Mitigation | Owner |
|---|---|---|---|---|---|---|
| R1 | [Risk] | | | [From rubric] | [How] | [Who] |

### 6. Implementation plan
| Step | Phase (assess/plan/execute/sustain) | Action | Owner | When | Depends on | Checkpoint / evidence |
|---|---|---|---|---|---|---|
| 1 | Plan | Take snapshot of before values (§4 below) | | | Dry run | Snapshot file, row count = scope count |
| 2 | Plan | Test in sub-production: [instance] | | | Snapshot | Test result, count match |
| 3 | Execute | Pause conflicting jobs: [list] | | | Approval | Job status screenshot/log |
| 4 | Execute | Run batch 1 of [k] ([N] records) | | | Step 3 | Count updated = batch size; spot check |
| … | | | | | | |
| n | Sustain | Post-implementation verification | | | Last batch | §8 evidence |

**Stop criteria (trigger rollback):** [e.g. updated count ≠ batch size; any record outside the filter changed; sync errors > [FILL]; unexpected CI state changes; license reconciliation errors].
**Point of no return:** [The step after which rollback is no longer full, e.g. records disposed in an external system, notices sent, devices shipped. Or "none".]

### 7. Communication plan
| Audience | Count | Message | Channel | Timing | Sender | Approved by |
|---|---|---|---|---|---|---|
| [Who] | [N] | [Template from communication-templates.md] | [Channel] | [When] | [Who] | [Who] |

### 8. Rollback plan
- **Trigger:** [Stop criteria above, or the change owner's call; who decides]
- **Steps:** [1. Stop remaining batches. 2. Restore before values from snapshot [file] for records changed (by sys_id or record key). 3. Re-link or re-sync CIs if affected. 4. Resume paused jobs. 5. Notify per comms plan.]
- **Verification:** [Restored count = changed count; sample of N restored records matches snapshot; KPIs back to baseline; no orphaned CIs]
- **Time to roll back:** [Estimate, from the sub-production test]

### 9. Post-implementation verification and sustain
| Check | Expected | Actual | Evidence |
|---|---|---|---|
| Records changed | [Dry-run N] | | [Query, time] |
| Records outside scope changed | 0 | | [Query] |
| Linked CI fields in sync | [N] | | [Query] |
| License position delta (if applicable) | [Predicted] | | [Reconciliation run, time] |
| KPI watch | [Metric IDs, expected direction] | | [Report] |

Lessons learned: [What to change in the catalog or template]. Closure: the change closes only when this table is filled with evidence.

### 10. Approvals required
| Approver | Role | Basis (policy clause / delegation) | Status | Evidence |
|---|---|---|---|---|
| [Name] | [Change owner / data owner / CAB / finance / security] | [FILL] | Pending | |

### 11. Open items and assumptions
- [ASSUMPTION / VERIFY items, each with how to resolve]
```

## 2. Risk rubric (`PRACTICE`)

Use the organization's risk method if one is set in `templates/company-profile.md`. Otherwise use this provisional rubric and say so.

| | Impact Low | Impact Medium | Impact High |
|---|---|---|---|
| **Likelihood High** | Medium | High | High |
| **Likelihood Medium** | Low | Medium | High |
| **Likelihood Low** | Low | Low | Medium |

Impact guide: **High** means production records of record, audit evidence, license position or finance postings change, or more than `[FILL]` users notice. **Medium** means records change but are reversible from snapshot within the window. **Low** means reporting-only or sub-production.

Any change touching more than the scope cap, deleting records, or crossing a point of no return is at least **High** impact.

## 3. Change class guidance

Change classes belong to the organization's change policy `[FILL]`. Typical mapping (`PRACTICE`):
- **Standard** (pre-approved): a repeatable change with a tested template, a fixed scope cap and a proven rollback, for example a monthly location correction under N records. It is standard only if a pre-approved template exists; otherwise it is normal.
- **Normal:** anything else, assessed and approved per the policy (CAB or delegated).
- **Emergency:** only to stop active harm (for example an integration overwriting records). Retrospective review still required; the snapshot is still taken first if at all possible.

## 4. Snapshot and audit-trail specification

**Snapshot (before values).** Export, for every record in scope: the record key (for ServiceNow, `sys_id`), every field the change writes, the linked CI key, and the extract time. Store it in the agreed location `[FILL]` with access control, and record the file name and row count in §3. The row count must equal the scope count.

**Audit trail.** Decide and record:
- Which account executes (named implementer or approved integration account `[FILL]`), so history shows who changed what.
- How the change number is traced: in the update source, a work note, or a field the organization uses `[FILL]`. Check that field history auditing is on for the fields being changed; in ServiceNow, confirm against the instance's audit settings (`VERIFY`).
- Whether the update method fires business rules. In ServiceNow, asset-CI sync runs through two business rules, "Update CI fields on change" on `alm_asset` and "Update Asset fields on change" on `cmdb_ci` (DOC: `it-asset-management/asset-management/c_ManagingAssets.md`). A script or import that suppresses business rules would therefore skip that sync (`INFERENCE`; test in sub-production).

## 5. Readiness gate

The record may go to approval only when:
- ★ §3 has dry-run counts with source and time (no `[PENDING DRY RUN]`).
- ★ The snapshot is specified and the scope cap is set.
- ★ §8 has trigger, steps and verification.
- ★ Every impact row is filled, including "None, because …".
- ★ No approval in §10 shows "Approved" without evidence.
