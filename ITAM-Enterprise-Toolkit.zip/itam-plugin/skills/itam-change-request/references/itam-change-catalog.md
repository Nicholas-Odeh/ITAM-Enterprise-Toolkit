# ITAM change catalog

Common ITAM change types, each with typical risks, pre-checks, the dry-run evidence to attach, side effects to state, a rollback approach, the audiences to inform and the KPIs to watch. Use it after classifying a change in `SKILL.md` Step 1, then fill `change-template.md`.

**Basis:** risks, pre-checks and rollback approaches are `PRACTICE` unless marked. ServiceNow statements marked `DOC` cite the ServiceNowDocs repository, brazil branch, under `markdown/it-asset-management/` (as checked 2026-10-20); confirm against the instance's release. KPI IDs refer to `itam-data-analysis-reporting/references/metrics-catalog.md`. For ServiceNow design detail (tables, properties, IRE), use the `servicenow-itam` skill; for the update script itself, `itam-automation-scripting`.

## Contents
- C1 Bulk asset or CI data correction
- C2 Lifecycle state model or asset-CI mapping change
- C3 ServiceNow HAM/SAM configuration change
- C4 Discovery, MDM, import or integration change
- C5 Stockroom move or consolidation
- C6 Refresh or redeployment wave
- C7 Policy or process rollout
- Cross-cutting: ServiceNow facts to cite

---

## C1 Bulk asset or CI data correction

**Examples:** correcting locations or cost centers after a reorganization; setting state/substate on records found by reconciliation; merging or retiring duplicates; fixing model or serial values; reassigning devices from leavers.

| Aspect | Guidance |
|---|---|
| Typical risks | Filter catches more than intended; overwritten values were correct; duplicates merged the wrong way round; sync pushes bad values to linked CIs; an integration overwrites the fix on its next run. |
| Pre-checks | Exception list and root cause from `itam-inventory-reconciliation`; confirm which source is authoritative for each field; check whether an integration owns the field (it will revert the fix); identify linked CIs. |
| Dry-run evidence | Count by state, class and site; before/after sample across the template's strata; list of records the filter excludes and why. |
| Side effects | **CI:** asset-CI sync applies to linked pairs (see cross-cutting facts). **License:** changes to state, assigned user or installed-on device can move user- or device-based positions at the next reconciliation. **Finance:** cost-center or state changes may need a matching fixed-asset update in `~~finance`. |
| Rollback | Restore before values from snapshot by record key; for merges, keep the losing record (retired, with a pointer) rather than deleting it until verification passes. |
| Never | Delete records to "clean up" unless they are created in error: in ServiceNow, deleting a linked asset or CI deletes the other, and retirement is the documented way to manage an asset no longer in use (DOC: `asset-management/t_DeletingAssets.md`). |
| Audiences | Data owners; service desk (if users see changed assignments); finance (cost centers). |
| KPI watch | M-DQ-01, M-DQ-04, M-DQ-05, M-DQ-08, M-CMDB-05, M-INV-02. |

## C2 Lifecycle state model or asset-CI mapping change

**Examples:** adding or renaming substates; retiring an unused state; changing the asset state ↔ CI install or hardware status mapping; adding a state to support a new process (loaners, quarantine).

| Aspect | Guidance |
|---|---|
| Typical risks | Existing records left on a removed value; reports, workflows, flows and integrations keyed on the old value break; CI status flips on mass for mapped pairs; KPI history becomes non-comparable. |
| Pre-checks | Inventory every consumer of the state field (reports, dashboards, flows, business rules, integrations, SAM rules); count records per current value; confirm the canonical mapping in `itam-hardware-lifecycle` (`asset-data-model.md`). In ServiceNow, the docs advise against modifying state values and allow substates to be adapted to the process (DOC: `asset-management/t_SettingAssetStatesAndSubstates.md`). |
| Dry-run evidence | Count of records per old value → new value; count of linked CIs whose install or hardware status would change under the new mapping. |
| Side effects | **CI:** state maps to CI install status and hardware status through mapping records; the docs say not to use the CI Substatus field for hardware CIs (DOC: `asset-management/work-with-asset-ci.md`). **License:** states used to include or exclude devices from reconciliation change the position. **Reporting:** state-based metrics need a restated baseline. |
| Rollback | Keep old choice values inactive (not deleted) until verification passes; restore mapping records from export; restore record values from snapshot. |
| Audiences | Report owners, service desk, stockroom, finance, SAM. |
| KPI watch | M-DQ-05, M-LC-11, M-CMDB-05, and every metric that filters on state. |

## C3 ServiceNow HAM/SAM configuration change

**Examples:** changing system properties for asset or CI creation; model category changes; normalization or software model changes; reconciliation scope or grouping; stock rules; workflows for transfer orders or retirement.

| Aspect | Guidance |
|---|---|
| Typical risks | Property changes alter behavior for all future records; model changes move installs between software models and shift positions; scheduled jobs pick up the change unattended. |
| Pre-checks | Read current property and record values before changing them (export); confirm the documented effect for the instance's release with `servicenow-itam`; identify scheduled jobs affected. SAM reconciliation runs as a scheduled job, weekly by default, and can be run on demand (DOC: `software-asset-management/t_RunReconciliation.md`, `software-asset-management/run-recon-workspace.md`). |
| Dry-run evidence | Sub-production result; for license-affecting changes, the position before and after a reconciliation run in sub-production, per affected publisher. |
| Side effects | **License:** the next scheduled reconciliation recalculates positions; warn SAM owners before it runs. **Asset/CI creation:** property changes affect records created after the change, not existing ones, unless a fix script runs (`INFERENCE`; verify per property). |
| Rollback | Re-apply exported values; re-run reconciliation for affected publishers; compare positions to the pre-change export. |
| Audiences | SAM and HAM teams, platform owner, procurement if stock rules change. |
| KPI watch | M-LIC-01, M-LIC-02, M-CMDB-05, M-OPS-09 (stock rules). |

## C4 Discovery, MDM, import or integration change

**Examples:** new discovery source or schedule; MDM connector change; new or changed import set and transform; HR or ERP feed changes; identification rule changes.

| Aspect | Guidance |
|---|---|
| Typical risks | Duplicate records or CIs; field ownership conflicts (two sources overwrite each other); last-seen dates jump and distort coverage metrics; leaver feed errors trigger mass reclamation. |
| Pre-checks | Source precedence and field ownership agreed; identification keys (serial, tag) normalized; test load into sub-production; baseline counts from `~~CMDB` and `~~endpoint management`. |
| Dry-run evidence | Insert vs. update vs. ignore counts from the test load; duplicate-candidate count; sample of updated records with before/after. |
| Side effects | **CI:** new CIs may create assets (and the reverse) depending on model category and properties; check with `servicenow-itam`. **License:** new install data changes positions. **Metrics:** coverage and staleness metrics move for reasons unrelated to the estate. |
| Rollback | Disable the schedule or data source first; remove or retire records created by the run (identified by source and run time); restore overwritten fields from snapshot. |
| Audiences | Configuration manager, endpoint team, SAM, report owners. |
| KPI watch | M-INV-03, M-INV-04, M-DQ-04, M-CMDB-02, M-CMDB-04. |

## C5 Stockroom move or consolidation

**Examples:** relocating a depot; merging two stockrooms; closing a site stockroom and shipping stock to a hub.

| Aspect | Guidance |
|---|---|
| Typical risks | Devices lost in transit; records still point at the old stockroom; stock rules fire against the wrong stockroom; service gap for joiners during the move. |
| Pre-checks | Full count of the source stockroom (`itam-logistics-warehouse` cycle-count procedure) and reconciliation of variances before the move; manifest by serial; stock rules and catalog fulfillment groups that reference the stockroom. In ServiceNow, transfer orders and transfer order lines track movement between stockrooms, and transfer order line tasks can be bulk-updated (DOC: `asset-management/create-bulk-transfer.md`); stock rules can trigger transfers or orders when a threshold is reached (DOC: `asset-management/c_StockRules.md`). |
| Dry-run evidence | Count by model and state in the source stockroom; manifest matched to records; list of open requests that will be filled from the moved stock. |
| Side effects | **Records:** location and stockroom change; in-transit state during the move. **Capacity:** reduced fulfillment capacity during the window (see `itam-capacity-planning`). **Finance:** location changes may need fixed-asset location updates. |
| Rollback | Physical moves can't be undone quickly; the rollback is for records (restore stockroom values) and for service (temporary fulfillment from another site). State this point of no return. |
| Audiences | Stockroom staff, logistics, service desk, site leads, requesters with open orders. |
| KPI watch | M-INV-06, M-OPS-08, M-OPS-11, M-OPS-09, M-LC-01. |

## C6 Refresh or redeployment wave

**Examples:** quarterly laptop refresh for a business unit; replacing an end-of-support model; mass redeployment of returned stock.

| Aspect | Guidance |
|---|---|
| Typical risks | Old devices not recovered (users keep both); data migration failures; bench or stock capacity exceeded; license reassignment missed; old devices disposed before sanitization evidence. |
| Pre-checks | Eligible population from `itam-hardware-lifecycle` refresh rules; capacity check with `itam-capacity-planning` (bench, stock, logistics, staff); user scheduling; recovery process for old devices. |
| Dry-run evidence | Eligible list with counts per site and model; exclusions (legal hold, deferrals) with counts; capacity plan showing the wave fits. |
| Side effects | **Records:** two devices per user during overlap; old device moves through recovery states. **License:** device-based licenses need reassignment; reclaim on old device. **Finance:** purchase and retirement postings. |
| Rollback | Per-user: keep the old device until the new one is confirmed working; wave-level: pause remaining batches. |
| Audiences | Affected users and managers, service desk, site leads, finance. |
| KPI watch | M-LC-07, M-LC-08, M-LC-04, M-OPS-03, M-OPS-06, M-FIN-06. |

## C7 Policy or process rollout

**Examples:** new leaver-recovery escalation; new loaner policy; mandatory acknowledgement on assignment; new disposal approval step.

| Aspect | Guidance |
|---|---|
| Typical risks | People don't know or follow the change; the system isn't configured to support it; old and new process run in parallel with conflicting records. |
| Pre-checks | Approved policy text (`itam-program-governance`); SOP updated (`itam-sop-documentation`); system support in place (C2/C3 change if needed); training plan. |
| Dry-run evidence | For process changes, a pilot with a named group and its results stand in for a data dry run. |
| Side effects | New evidence requirements for audit; KPI definitions may change. |
| Rollback | Revert to prior SOP version; communicate the reversal; records created under the new process stay and are flagged. |
| Audiences | Everyone who performs or is affected by the process, with counts; their managers. |
| KPI watch | The metric the policy targets (for example M-LC-04 for leaver recovery) and M-GOV-07 for training coverage. |

Assess-plan-execute-sustain applies most fully to C7: explain the why before the what, train and support, monitor adoption, reinforce, and record lessons (adapted from the Operations `change-request` framework).

---

## Cross-cutting: ServiceNow facts to cite

| Fact | Source |
|---|---|
| Asset and CI updates sync only when the asset and CI point to each other; two business rules perform the sync ("Update CI fields on change" on `alm_asset`, "Update Asset fields on change" on `cmdb_ci`). | DOC: `asset-management/c_ManagingAssets.md` |
| Asset and CI field mappings sync both ways; state/substate maps to CI install status and to CI hardware status; don't use the CI Substatus field for hardware CIs. | DOC: `asset-management/work-with-asset-ci.md` |
| Deleting a linked asset or CI deletes the other; delete only to clean up errors, retire otherwise. | DOC: `asset-management/t_DeletingAssets.md` |
| Avoid modifying state values; substates may be adapted. | DOC: `asset-management/t_SettingAssetStatesAndSubstates.md` |
| SAM reconciliation is a scheduled job (weekly by default) and can be run on demand. | DOC: `software-asset-management/t_RunReconciliation.md` |
| Stock rules and the daily Stock Rule Runner job create tasks, transfer orders or purchase orders at a threshold. | DOC: `asset-management/c_StockRules.md` |
| Whether a given bulk-update method fires business rules (and therefore sync and audit history). | `VENDOR — VERIFY` in sub-production |
