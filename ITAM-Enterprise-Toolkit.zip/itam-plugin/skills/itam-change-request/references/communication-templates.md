# Change communication templates

Draft notices for ITAM changes. Every notice is a draft until the change owner approves it; with `~~chat` or `~~email` connected, draft only, and send only on explicit approval of that message.

**Basis:** the principles adapt the Operations plugin's `change-request` communication guidance (explain the why before the what; communicate early; use more than one channel; acknowledge what people lose, not only what they gain; give a clear route for questions). The templates are `PRACTICE`. Personal data: name individuals only where the message needs it.

## Contents
1. Choosing notices
2. Pre-change notice (affected users or teams)
3. CAB summary (one paragraph)
4. Go / no-go message
5. Completion notice
6. Rollback notice
7. Report-owner notice (KPI baseline shift)

## 1. Choosing notices

| Change type | Pre-change | CAB summary | Go/no-go | Completion | Report-owner |
|---|---|---|---|---|---|
| C1 bulk data correction | If users see changed assignments | Yes | Yes | Yes | If KPIs move |
| C2 state model / mapping | Service desk, stockroom, SAM | Yes | Yes | Yes | Yes |
| C3 HAM/SAM configuration | SAM/HAM teams | Yes | Yes | Yes | If positions move |
| C4 discovery / integration | Config manager, endpoint team | Yes | Yes | Yes | Yes |
| C5 stockroom move | Site, service desk, requesters | Yes | Yes | Yes | Optional |
| C6 refresh wave | Users and managers, in waves | Yes | Per batch | Per batch | Optional |
| C7 policy / process | Everyone in scope | Yes | Pilot then go-live | Yes | If definitions change |

Rollback notices go to everyone who received a pre-change or completion notice.

## 2. Pre-change notice

```text
Subject: [Planned change] [What] on [date, window, time zone]

Why: [One sentence on the reason: the audit finding, data problem or business need.]
What changes: [What people will see differently, in their terms.]
Who is affected: [Group, about N people/records.]
When: [Window]. During the window: [what is unavailable or slower, or "no interruption expected"].
What you need to do: [Action, or "nothing"].
What stays the same / what goes away: [Be honest about anything lost.]
Questions: [Channel or contact]. Change reference: [ID].
```

## 3. CAB summary

```text
[Change ID] [Title]. [Class]. Scope: [N] records ([breakdown]) selected by [filter], dry run [time].
Side effects: CIs [N/none], license position [publishers/none], finance [yes/no].
Risk: [rating] — main risk [R1], mitigated by [..]. Rollback: snapshot [file], [time to roll back], point of no return [step/none].
Tested in [sub-production instance] on [date]: [result]. Window [..]. Approvals sought: [..].
```

## 4. Go / no-go message

```text
[Change ID] go/no-go at [time].
Pre-checks: snapshot taken ([rows] = scope [N]) [✓/✗]; conflicting jobs paused [✓/✗]; implementer and approver present [✓/✗]; freeze calendar clear [✓/✗].
Decision: GO / NO-GO by [change owner]. Next checkpoint: after batch 1 ([N] records) at [time].
```

## 5. Completion notice

```text
[Change ID] [Title] complete at [time].
Verified: [N] records changed (expected [N]); 0 records outside scope changed (query [ref]); linked CIs in sync [N]; [license reconciliation run at [time]: position change [..] / not applicable].
What's different now: [..]. Report owners: [metric IDs] will show a step change from [date].
Issues: [none / list with owner]. Questions: [contact].
```

Never send a completion notice before the post-implementation verification table is filled with evidence.

## 6. Rollback notice

```text
[Change ID] was rolled back at [time] because [trigger].
Current state: [N] records restored from snapshot; verification [result, query ref]. [Anything not restored and why.]
Impact on you: [..]. Next step: [re-plan date / investigation owner].
```

## 7. Report-owner notice

```text
Heads-up: [Change ID] on [date] changes [what] for [N] records. Expect [metric IDs] to move by about [predicted delta, from dry run] for reasons of data correction, not operational performance. Please annotate [dashboard/report] from [date]. Contact [owner].
```
