---
name: itam-change-request
description: Use when an ITAM change needs a change record, CAB submission, impact analysis or rollback plan, such as bulk asset or CMDB data corrections, lifecycle state or substate changes, ServiceNow HAM/SAM configuration, discovery or integration changes, stockroom moves, refresh waves or ITAM policy rollouts. Covers dry-run evidence, asset-CI and license side effects, audit trail and communications. Not for writing the update script (use itam-automation-scripting) or a standing procedure (use itam-sop-documentation).
---

# ITAM Change Request

An ITAM change is ready for approval only when the approver can see which records move, what moves with them (CIs, license positions, finance, reports) and how it all gets put back. This skill drafts change records for a CAB or change owner, adapting the Operations assess-plan-execute-sustain structure to asset data, for asset managers, ServiceNow administrators and ITAM leads.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Dry-run numbers or no approval.** Counts, filter and before/after sample come from a real dry run; until then write `[PENDING DRY RUN]` and mark the record not ready.
7. **Name every side effect** on CIs, license positions, finance and audit trail, even "none, because …".
8. **Rollback restores data.** Snapshot before values first; stopping the job is not a rollback.

## When to use

- Bulk asset or CI corrections; state model or asset-CI mapping changes; HAM/SAM configuration; discovery or integration changes.
- Stockroom moves, refresh waves, policy or process rollouts.
- A CAB pack, rollback plan or change communications.

**When not to use:** the script itself (`itam-automation-scripting`); ServiceNow configuration design (`servicenow-itam`); a standing procedure or runbook (`itam-sop-documentation`); process redesign (`itam-process-improvement`).

## Workflow

### Step 1: Classify

| Change type | Catalog entry in `references/itam-change-catalog.md` |
|---|---|
| Bulk asset or CI data correction | C1 |
| Lifecycle state model or asset-CI mapping | C2 |
| ServiceNow HAM/SAM configuration | C3 |
| Discovery, MDM, import or integration | C4 |
| Stockroom move or consolidation | C5 |
| Refresh or redeployment wave | C6 |
| Policy or process rollout | C7 |

Always load `references/change-template.md`; add `references/communication-templates.md` when others are affected.

### Step 2: Preflight

Read `templates/company-profile.md` if present. Establish the change and its reason, systems and environment, selection criteria, affected teams, change classes and freeze windows `[FILL]`, and scheduled jobs on the same data (discovery, SAM reconciliation, imports). If population or production impact is unknown, ask that one question.

### Step 3: Draft

1. **Assess:** impact table with ITAM rows (records, CIs, license, finance, KPIs, integrations); risks rated by the template's `PRACTICE` rubric or the organization's.
2. **Plan:** owned steps, catalog pre-checks, sub-production test, window, communications.
3. **Execute:** batches, checkpoints, scope cap, stop criteria that trigger rollback.
4. **Sustain:** post-change counts against the prediction, KPI watch by metric ID, closure evidence.

### Step 4: Verify before release

- ★ Counts, filter and as-of time come from a dry run, not an estimate.
- ★ The before/after sample covers edge cases: blank serial, linked CI, retired, duplicate.
- ★ The scope cap is a number, and the job aborts above it.
- ★ Snapshot location, rollback trigger, steps, verification and point of no return are written.
- ★ Asset-CI, license, finance and audit-trail effects are stated.
- ★ No approval is shown as obtained without evidence.
- Sub-production result attached, or the reason there is none; audiences named with counts.
- Material changes: the `itam-reviewer` agent has checked the draft.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "It's only a data fix" | A bulk update to a system of record is a change; auditors ask who approved it. |
| "About 3,000 records" | An estimate is not a dry run. Run the filter. |
| "We can restore from backup" | Platform restores rarely target single records. Snapshot first. |
| "The CIs will follow" | Sync covers linked, mapped pairs only. Count them. |
| "License numbers won't move" | State, install and model changes feed reconciliation. Compare before and after. |

Stop if you are about to: run in production before a dry run; write "restore backup" as the whole rollback; widen scope mid-window; mark an approval given; send notices unapproved.

## Common mistakes

| Mistake | Fix |
|---|---|
| Sample shows only clean records | Sample each edge-case stratum. |
| Window collides with discovery or reconciliation | Pause or avoid those jobs. |
| KPI baselines shift silently | Name affected metric IDs; warn report owners. |
| Closed on "job finished" | Close when post-change counts match the prediction. |

## If connectors are available

- `~~ITSM`: read change calendar, freeze windows, related incidents; draft (never submit) the record.
- `~~CMDB`: read linked CI counts and relationships.
- `~~endpoint management`: baseline device counts for discovery changes.
- `~~project tracker`: draft implementation tasks.
- `~~chat`, `~~email`: draft notices; send only after approval.

## Output format

1. Header (title, class, requester, priority, status, window), description and justification.
2. Scope and dry-run evidence: filter, counts, as-of time, sample, scope cap.
3. Impact table, then risk table.
4. Implementation and communication plans.
5. Rollback plan: trigger, steps, verification.
6. Post-implementation verification; approvals; open items and assumptions.

## Reference files

- `references/change-template.md`: full record template and risk rubric; read for every change.
- `references/itam-change-catalog.md`: risks, pre-checks, side effects and rollback by change type; read after classifying.
- `references/communication-templates.md`: pre-change, go/no-go, completion and rollback notices; read when others are affected.
