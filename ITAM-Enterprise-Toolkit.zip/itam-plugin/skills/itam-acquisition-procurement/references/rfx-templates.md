# RFx templates (RFI, RFQ/RFB, RFP)

Templates and rules for drafting requests to vendors. Everything in square brackets is a fill-in. Legal terms and conditions, confidentiality terms and procurement-law requirements come from the organization's Legal and Procurement teams; never write them as final.

## 1. Choosing the route

CAMP defines the RFx types roughly as follows (paraphrased, CAMP M:150): an **RFI** asks vendors for information about a product or service under consideration; an **RFB** (also called **RFQ**) fixes the terms and specification, makes price a main criterion, and doesn't negotiate responses; an **RFP** asks vendors how their offering meets specific requirements and is expected to end in a selection. CAMP's Acquisition Manager role uses a formal selection process, from a simple RFQ to a rigorous RFP, for non-standard items and exceptions (CAMP M:111).

| Situation | Route | Label |
|---|---|---|
| Item is in the standard catalog and covered by a contract | Order from the catalog; no RFx | PRACTICE |
| Specification is fixed and comparable; price and delivery decide | RFQ / RFB | CAMP M:150 |
| Solutions differ; capability, service, risk and price must be weighed | RFP | CAMP M:150 |
| Market, options or requirements are unclear | RFI first, then RFQ or RFP | CAMP M:150 |
| Policy threshold requires competition, or sole source must be justified | Follow the organization's policy: [threshold / sole-source rule] | fill-in |

## 2. Requirement-writing rules

- One requirement per row, with an ID (`REQ-<area>-<nn>`), a priority, and the evaluation method.
- **Priority:** `M` mandatory (pass/fail; failing it disqualifies), `S` scored, `I` information only. Keep mandatory items genuinely essential; every extra one shrinks the field.
- Write outcomes and measurable conditions, not a single vendor's product features. Avoid brand names unless compatibility requires them, and then allow "or equivalent" where policy requires it.
- Say how the vendor must evidence the answer (document, demo, reference, test).
- Mark requirements that will become contract terms (SLA, data, delivery), so they carry into negotiation.

| ID | Requirement | Priority (M/S/I) | Evidence requested | Evaluation method | Becomes contract term? |
|---|---|---|---|---|---|

## 3. ITAM requirement bank (adapt; all `PRACTICE` unless your policy says otherwise)

**Asset data and identification**
- Provide serial number, model, part number, MAC address(es) where relevant, and ship date per unit, electronically before or with delivery (for example an ASN file in [format]).
- Apply the organization's asset tag to [location on device] before shipment, following [tag standard]. CAMP tracks the accuracy of vendor-applied tags as an asset identification indicator (CAMP M:22).
- Register devices for [enrollment / zero-touch provisioning service, if used: VERIFY which one] before shipment and confirm by file.

**Warranty, support and RMA**
- State warranty start rule (ship, delivery or install date), length and service level per model.
- Describe RMA process, advance replacement, turnaround and whether failed storage media can be retained by the customer.
- Provide end-of-sale and end-of-support notice periods for offered models.

**Software and licensing**
- Deliver proof of entitlement and license records to [ITAM contact / system] at purchase. CAMP tracks whether licensing information for downloaded software reaches ITAM (CAMP M:22).
- State the license metric, transfer and reassignment rights, and audit terms (send to Legal and to the license-management owner).

**Commercial and invoicing**
- Price per unit with validity period, price hold for [period/volume], volume tiers, and escalation basis.
- Invoice at line level with PO number, part number and serial numbers, to support invoice reconciliation.

**End of life and sustainability**
- Describe take-back, recycling and data-sanitization services, certificates provided, and chain-of-custody controls. Certification or standard names must be verified against current editions before they are made mandatory.

**Security and privacy**
- [Security questionnaire / assurance evidence required, per security team.]
- [Data-processing terms, per Legal.]

## 4. RFI template

1. **Purpose:** what the organization is exploring and that this is not a commitment to buy.
2. **Background:** organization context, current state and volumes (only what vendors need; no confidential detail).
3. **Questions:** capabilities, delivery model, typical pricing structure (not binding quotes), integration options, references, roadmap.
4. **Response format and length.**
5. **Timeline:** questions deadline, response deadline, next steps.
6. **Contact and confidentiality:** [single point of contact]; [confidentiality terms from Legal].

## 5. RFQ / RFB template

1. **Introduction and instructions:** single point of contact, deadlines, submission method, validity period of quotes.
2. **Specification:** exact items, quantities, configurations, delivery locations, delivery windows. Allow "or equivalent" per policy.
3. **Mandatory requirements** (pass/fail) including the ITAM data, tagging and warranty items above.
4. **Pricing schedule:** a fixed template every bidder completes (unit price, extended price, taxes, shipping, price hold).
5. **Award basis:** lowest compliant price, or best value per stated criteria. State it up front.
6. **Terms and conditions:** [from Legal / standard purchasing terms].

## 6. RFP template

1. **Introduction:** purpose, organization overview, single point of contact, rules of engagement (no contact with other staff).
2. **Timeline:** issue date · intent-to-respond · questions deadline · answers published to all · response deadline · shortlist · presentations / demos / POC · selection · contract target date.
3. **Background and scope:** current state, volumes, sites, in-scope and out-of-scope services.
4. **Requirements:** functional, technical, service levels, ITAM data, security, privacy, implementation, support, exit. Use the requirement table in section 2.
5. **Commercial response:** pricing template, assumptions, term options, price hold and escalation.
6. **Vendor information:** company profile, financial standing evidence, subcontractors and where they operate, references.
7. **Evaluation approach:** stages (compliance check → mandatory gate → scored evaluation → shortlist → demo / POC → final), the criteria groups, and whether weights are disclosed (per policy).
8. **Response format:** structure, page limits, file formats, and a compliance matrix the vendor completes against each requirement ID.
9. **Terms:** [draft contract or key terms from Legal], confidentiality, no obligation to award, response costs borne by the vendor.

## 7. Q&A and fairness

- One point of contact; all questions in writing by the deadline.
- Answers published to all participants, anonymized.
- Material changes go out as a numbered addendum with a deadline extension if needed.
- Late responses handled per policy: [rule].
- Keep the record: issued document, addenda, Q&A log, responses, evaluation sheets, and the selection memo. CAMP expects acquisition artifacts such as evaluation notes, negotiation notes, contracts and price lists to be passed to documentation management (CAMP M:36).

## 8. Before issuing (checklist)

- Requirements have IDs, priorities and evaluation methods.
- Evaluation criteria, weights and scale are approved and recorded (see `evaluation-matrix.md`).
- Security, Legal and Procurement have reviewed their sections.
- No confidential, personal or internal-only data is included beyond need.
- Timeline is achievable and leaves time for POC and negotiation before the need date.
