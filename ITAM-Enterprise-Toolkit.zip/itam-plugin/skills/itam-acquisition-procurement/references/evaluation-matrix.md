# Evaluation matrix, POC testing and selection memo

Method for scoring vendor responses fairly and reproducibly. Weights, scales and examples here are `RECOMMENDATION` or `ILLUSTRATIVE` until the organization approves its own. Compute scores in code or a spreadsheet, never by eye.

**Calculator:** `python3 scripts/rfx_score.py` (from this skill's folder; `--help` lists the inputs). It applies the mandatory gate, normalizes price against the lowest *qualified* price, computes weighted totals, runs ±N-point and named-scenario sensitivity with proportional rebalancing, and flags near-ties. It reproduces the §3 worked example exactly (84.44 / 82.63 / 67.00; scenarios 85.81 / 81.29 / 71.00 and 83.06 / 83.98 / 63.00). It does not set weights or anchors: those come from the approved plan.

## 1. Set up before any response is opened

1. **Criteria groups** with definitions (for example functional fit, price, service and support, vendor risk, ITAM data and integration, implementation, sustainability).
2. **Mandatory gate:** the `M` requirements from the RFx. A failure disqualifies, or goes to a documented clarification if policy allows.
3. **Weights** summing to 100%, approved by [role]. Record who approved them and when.
4. **Scoring scale with anchors**, so different evaluators mean the same thing:

| Score | Anchor |
|---|---|
| 5 | Fully meets and exceeds in ways that matter to us, with strong evidence |
| 4 | Fully meets, with evidence |
| 3 | Mostly meets; minor gaps with a credible plan |
| 2 | Partly meets; material gaps |
| 1 | Barely addresses the requirement |
| 0 | Not addressed, or no evidence |

5. **Price method:** choose and record one. A common one is `price score = lowest compliant price ÷ bidder's price × max score`. Compare prices on the same basis (same term, quantity, inclusions; use a TCO figure from itam-financial-management if lifecycle costs differ).
6. **Evaluators:** named, independent, with conflict-of-interest declarations. Price is often scored separately from the technical panel so it can't bias technical scores (`PRACTICE`).

## 2. Scoring sheet

| Req / criterion ID | Criterion | Weight | Vendor A score (0–5) | Rationale and evidence ref | Vendor B score | Rationale | … |
|---|---|---|---|---|---|---|---|

**Weighted total** (points out of 100) = `Σ (score ÷ max score × weight)`.

Use **consensus scoring**: evaluators score independently, then meet to agree a score with written rationale. Keep the individual sheets. Large unexplained gaps between evaluators are a sign that the anchor or the requirement is unclear.

## 3. ILLUSTRATIVE worked example (made-up vendors and numbers)

Weights: functional fit 35%, price 25%, service and support 15%, vendor risk 10%, ITAM data and integration 15%.
Prices: A $480,000, B $520,000, C $450,000 (lowest). Price scores: A = 450/480 × 5 = 4.69; B = 450/520 × 5 = 4.33; C = 5.00.

| Criterion | Weight | A | B | C |
|---|---|---|---|---|
| Functional fit | 35 | 4 | 5 | 3 |
| Price | 25 | 4.69 | 4.33 | 5.00 |
| Service and support | 15 | 4 | 3 | 3 |
| Vendor risk | 10 | 3 | 4 | 3 |
| ITAM data and integration | 15 | 5 | 3 | 2 |
| **Weighted total (of 100)** | | **84.44** | **82.63** | **67.00** |

Check for A: 4/5×35 + 4.6875/5×25 + 4/5×15 + 3/5×10 + 5/5×15 = 28 + 23.44 + 12 + 6 + 15 = 84.44.

**Sensitivity:**
- Price 35% / fit 25%: A 85.81, B 81.29, C 71.00. A still leads.
- Fit 45% / price 15%: A 83.06, B 83.98, C 63.00. **B leads.**

Script inputs for this example: `criteria.csv` (`criterion_id,criterion,weight,type` with `PRICE` as type `price`), `scores.csv` (`vendor,criterion_id,score`, consensus scores), `prices.csv` (`vendor,price`). Command: `python3 scripts/rfx_score.py --criteria criteria.csv --scores scores.csv --prices prices.csv --scenario "price-heavy:FIT=25,PRICE=35" --scenario "fit-heavy:FIT=45,PRICE=15" --tie-margin 3 --report sensitivity`.

So the A-vs-B result depends on how much functional fit is worth compared with price. The memo must say so and let the approver confirm the weights; it should not present A as a clear winner.

## 4. Sensitivity and tie-breaks

- Recompute with each major weight moved by a reasonable amount (for example ±10 points, rebalanced across the rest). Report any rank change.
- If the top two are within a margin you can't defend (state it, for example under 3 points), treat it as a tie and decide on pre-stated tie-breakers: POC results, risk, total cost, or reference checks.
- Never change weights after seeing scores to reach a preferred answer. If weights must change, record why and who approved it, and rescore everyone.

## 5. Proof of concept / pilot test plan

| Test ID | Requirement ID | Scenario | Acceptance criterion (measurable) | Environment | Result (pass/fail, evidence) | Tester |
|---|---|---|---|---|---|---|

ITAM-relevant tests to consider: device arrives with correct tag and serial data matching the ASN; enrollment or imaging works end to end; discovery and the asset register show the device correctly; warranty lookup works by serial; license or entitlement data loads into the license tool; invoice lines match the PO and serials.

A failed test sends the vendor back to the shortlist decision, not straight to purchase (CAMP S:66).

## 6. Selection memo (template)

1. **Decision required** and by whom.
2. **Need and scope** (from the request and RFx).
3. **Process followed:** route, vendors invited and responding, disqualifications with reasons, evaluators.
4. **Results:** weighted scores, sensitivity results, POC outcome, reference checks.
5. **Recommendation:** vendor and option, with the main reasons and the main risks.
6. **Commercial summary:** price basis, term, price hold, and TCO if lifecycle costs differ (sourced).
7. **Conditions for award:** items to secure in negotiation (handed to itam-vendor-contract-management), Legal and Security sign-offs.
8. **Approval:** [role / authority level per policy].
9. **Record:** where the evaluation file is stored (scoring sheets, Q&A, addenda, memo).

## 7. Debrief and records

Offer unsuccessful bidders a factual debrief per policy, limited to their own scores and reasons. Keep the full evaluation file per the organization's retention schedule.
