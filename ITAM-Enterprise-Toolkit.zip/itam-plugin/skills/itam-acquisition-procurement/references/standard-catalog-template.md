# Standard catalog template

A standard catalog lists the pre-approved hardware, software and accessories that can be requested through the simple, fast path. CAMP describes asset standards as a catalog of pre-approved equipment and software, possibly including configuration, versions and approved vendors; often bundled with a standard image for all staff or a group; maintained by an asset selection committee with business-unit representation; and expected to change over time. The request process for standard items should stay simple (CAMP S:69). CAMP's Program Management indicators include the share of deployed assets that are part of the IT standard (CAMP M:24).

Values in square brackets are fill-ins. Model names, prices and lifecycles must come from the organization's contracts and data, never from memory.

## 1. Governance

| Item | Value |
|---|---|
| Catalog owner | [role] |
| Asset selection committee members | [IT standards, security, end-user computing, finance, procurement, business-unit reps] |
| Review cadence | [for example quarterly, plus on vendor end-of-sale notices] |
| Decision record location | [repository / site] |
| Change process | proposal → evaluation (and POC if needed) → committee approval → catalog update → communication |
| Exception path | non-standard request flow (see `request-approval-flow.md`) |

## 2. Personas or entitlement groups

| Persona | Description | Default bundle | Approver for upgrades |
|---|---|---|---|
| [Standard knowledge worker] | | [laptop model A, dock, headset] | [line manager] |
| [Power user / developer] | | | |
| [Field / frontline] | | | |
| [Executive] | | | |
| [Contractor] | | | |

Keep personas few; every extra persona adds stock, images and support cost.

## 3. Catalog entry fields

| Field | Notes |
|---|---|
| Catalog ID | stable ID used in the request system |
| Category | laptop, desktop, monitor, mobile phone, tablet, peripheral, software title, accessory |
| Manufacturer / model / part number | exact orderable part numbers |
| Configuration | CPU / RAM / storage / OS edition or software edition and version |
| Personas eligible | from section 2 |
| Approved vendor(s) and contract ID | links to the contract register |
| Unit price and price validity | from contract or current quote; date it |
| Lead time | from vendor data |
| Standard image / build | [image name and version, if applicable] |
| Warranty and support level | from contract |
| Expected refresh cycle | from refresh policy (itam-hardware-lifecycle) |
| License type and metric (software) | from contract; check with license owner |
| Lifecycle status | Proposed · Active · Sunset (no new orders; existing supported) · Retired |
| Sunset / end-of-sale date | vendor notice + internal plan |
| Replacement catalog ID | the successor item |
| Security approval reference | |
| Accessibility notes | |
| Asset tracked? | Yes / No per tracking threshold [value] |

## 4. Catalog item lifecycle

1. **Proposed:** need identified; options evaluated (RFQ/RFP if required); POC against acceptance criteria.
2. **Active:** orderable through the standard path; stock and image maintained.
3. **Sunset:** triggered by end-of-sale notice, price change or a better option; no new orders after [date]; successor named.
4. **Retired:** removed from the catalog; existing units follow the refresh and disposal policy.

Publish changes to requesters and the service desk before they take effect.

## 5. Design rules (`PRACTICE`)

- Fewer models mean simpler imaging, spares, support and repair; prefer one or two models per category per persona.
- Align catalog refresh with vendor product cycles and contract price holds.
- Bundle peripherals and software by persona so one request covers the common case.
- Every standard software title has a known license source and someone who owns its entitlement.
- Track the share of requests fulfilled from the catalog and the share of deployed assets that are standard; a rising non-standard rate is a signal the catalog no longer fits the business.

## 6. Catalog health metrics

| Metric | Formula | Source |
|---|---|---|
| Standard request share | standard requests ÷ all requests | request system |
| Deployed-standard share | in-use assets that match an active or sunset catalog item ÷ in-use assets | asset register |
| Non-standard approval rate | approved non-standard ÷ non-standard requests | request system |
| Catalog fulfilment time | median request-to-delivery for standard items | request system |
| Items past end-of-sale still Active | count | catalog + vendor notices |
