# Working method: preflight, the acquisition flow and deliverables

Detail moved from `SKILL.md` (v2 restructure). Labels as in the `itam-operating-standard` skill. CAMP describes acquisition as the gatekeeper that applies ITAM policy, standards and lifecycle rules before money is spent, and that creates the first records for an asset (CAMP M:35; S:59).

## Contents
1. Preflight in full
2. The acquisition flow
3. Release checks that are not blocking
4. Deliverables

## 1. Preflight in full

Confirm, or state the assumption for:

- **The need:** business outcome, users or personas affected, quantity, timing, and whether it replaces something.
- **Policy constraints:** approval authorities and limits, competitive-bid thresholds, preferred or mandated vendors and frameworks, sector rules (for example public-sector procurement). If unknown, leave a labeled placeholder.
- **Existing options:** current standard catalog, stock on hand, redeployable assets, existing contracts or volume agreements that already cover the need.
- **Stakeholders:** requester, budget owner, IT standards, security, finance, procurement, legal, and who signs off.
- **Deliverable and audience:** a workflow design, a draft RFx, a scoring model or a recommendation memo.

If the purchase is above the organization's competitive threshold or involves sensitive data, treat the consequence as HIGH and include security and legal review. If `templates/company-profile.md` exists at the plugin root, read it for approval limits, catalog, approved vendors and procurement system.

## 2. The acquisition flow

Follows the CAMP acquisition flow (CAMP S:66–68; M:35–37), adapted to the request:

1. **Need and needs assessment.** State the business requirement, objectives and constraints. Justify with TCO or ROI where policy requires it; hand TCO, lease-vs-buy and depreciation to `itam-financial-management` and use its output.
2. **Reuse before buy.** Check stock, redeployable assets and existing entitlements first. CAMP lists reuse of existing inventory as an acquisition function (CAMP S:63).
3. **Standard or non-standard.** A catalog item follows the simple standard path. Anything else follows the non-standard path with justification and wider review (security, standards, deployment, finance) (CAMP S:65, S:69–70).
4. **Choose the sourcing route.** Existing contract or catalog order → RFQ/RFB when the specification is fixed and price leads → RFP when solutions differ and must be evaluated → RFI first when the market or requirements are unclear (CAMP M:150 defines these; see `rfx-templates.md`).
5. **Write requirements** with IDs, priority (mandatory or scored) and how each will be evaluated. Include the ITAM requirements most RFx documents forget: serial and asset-tag data on delivery, warranty start rules, entitlement records, RMA and drive retention, take-back and certified disposal, and invoice detail.
6. **Evaluate.** Apply mandatory pass/fail gates, then score with the pre-approved weights; normalize price; run a sensitivity check (`python3 scripts/rfx_score.py`, `evaluation-matrix.md` §2–4); test shortlisted options (POC or pilot) against written acceptance criteria. Failed testing goes back to the shortlist (CAMP S:66).
7. **Select and negotiate.** Write a selection memo. Contract terms, SLAs and negotiation positions move to `itam-vendor-contract-management`; legal terms go to Legal.
8. **Purchase and hand off.** The PO carries the data receiving and ITAM need; receipt creates or updates the asset record, links the PO, invoice, contract and proof of purchase, and moves the asset into the lifecycle (CAMP M:36: acquisition passes purchase, agreement and order information to asset identification, and artifacts to documentation). Physical receiving, inspection and tagging SOPs belong to `itam-logistics-warehouse`; invoice-to-PO-to-asset matching belongs to `itam-financial-management`. This skill defines the data that must flow between them (`request-approval-flow.md` §7).
9. **Measure.** Track request volume and approval or rejection rates (standard vs. non-standard, by department and asset type), approval cycle times, negotiation duration and RFx response quality (CAMP M:22; S:62), plus receiving-to-record time (`request-approval-flow.md` §8).

## 3. Release checks that are not blocking

- Every requirement has an ID, a priority and an evaluation method; mandatory items are genuinely mandatory.
- The reuse-before-buy check is recorded.
- Sensitivity analysis shows whether the recommendation holds under reasonable alternative weights.
- Evaluator independence and conflicts of interest are addressed.
- The PO-to-receipt handoff lists every field the asset record and documentation need, with an owner.
- Recommendations name the decision-maker and the approval required.

## 4. Deliverables

Unless the user asks for something else:

1. **Answer or recommendation** in two to five sentences (the route to take, the vendor recommended, or the workflow proposed).
2. **The work product:** draft RFx, scoring matrix, catalog, approval flow or handoff specification, with labels on material statements and placeholders for organization-specific values.
3. **Assumptions and open decisions** for the user to confirm (policy limits, weights, approvers).
4. **Risks and next steps:** what has to happen, who owns it, and which other skill takes over (vendor contract, finance, hardware lifecycle).

**Executive variant:** a one-page decision memo with the need, options, recommendation, cost range (sourced), risks and approval required.
**Practitioner variant:** full templates, requirement tables and the scoring workbook layout.
