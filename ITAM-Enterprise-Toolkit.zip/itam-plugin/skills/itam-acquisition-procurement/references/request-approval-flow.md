# Request, approval and PO-to-receipt handoff

How requests for IT assets enter, get approved or rejected, get sourced, and arrive in the asset register. Approval limits, roles and systems are fill-ins; take them from the organization's policy (see `templates/company-profile.md` if present).

**Contents:** 1. Request intake fields · 2. Standard vs. non-standard · 3. Flow · 4. Approval matrix (fill-in) · 5. Justification document (non-standard) · 6. Exceptions to design for · 7. PO-to-receipt-to-asset-record handoff · 8. Acquisition metrics

## 1. Request intake fields

| Field | Why it matters |
|---|---|
| Requester, recipient, cost center | ownership and chargeback |
| Business need (in the requester's words) | justification and needs assessment |
| Catalog ID, or "non-standard" with description | routes the request |
| Quantity and need-by date | sourcing route and lead time |
| Replacement or new? Asset tag being replaced | refresh and recovery link |
| Data sensitivity / security requirements | non-standard review |
| Budget owner | approval |

## 2. Standard vs. non-standard

- **Standard:** an active catalog item for the requester's persona. Approval is minimal: [line manager] or automatic. CAMP's request and approval guidance includes defining what is standard vs. non-standard, keeping approval levels to a minimum, setting specific approval levels for non-standard requests, and not requiring officer-level approval for standard requests (CAMP S:65).
- **Non-standard:** anything else. CAMP says the non-standard path should be more rigorous; the acquisition manager works with the requester, department manager, finance, IT deployment, IT standards and security to decide how to acquire the item or whether to approve it, and an approved request carries a justification document recording the reasoning (CAMP S:70).

## 3. Flow

```
Request submitted
  → Reuse check: stock on hand / redeployable asset / existing entitlement? ── yes → fulfil from stock
  → Standard catalog item?
       yes → standard approval [role] → order under existing contract → PO
       no  → non-standard review (standards, security, deployment, finance)
              → justification document
              → approval per matrix (section 4)
              → rejected: reason recorded, alternative offered (catalog item)
              → approved: sourcing route (existing contract / RFQ / RFP per policy threshold)
  → PO issued → vendor ships (ASN with serials) → receipt → asset record → stock / configure → deploy
```

The "reuse check" step reflects CAMP's acquisition function of reusing existing inventory (CAMP S:63). CAMP also notes acquisition should tell disposal, at purchase time, whether an asset is leased or owned, whether it will hold sensitive data, and whether software is harvestable (CAMP M:36); capture these on the request or PO.

## 4. Approval matrix (fill-in)

| Request type | Value band | Approvers (in order) | Target turnaround |
|---|---|---|---|
| Standard catalog item | any | [line manager / auto] | [ ] |
| Non-standard hardware | ≤ [amount] | [manager, IT standards, security] | [ ] |
| Non-standard hardware | > [amount] | [+ finance, + director] | [ ] |
| New software title | any | [license owner, security, architecture] | [ ] |
| SaaS / cloud subscription | any | [+ security and privacy review, + Legal for terms] | [ ] |
| Above competitive threshold | > [amount] | [procurement-led RFQ/RFP per policy] | [ ] |

Never fill these amounts from general practice; leave the placeholder until the organization supplies them.

## 5. Justification document (non-standard)

1. Business need and outcome; who benefits.
2. Why no catalog item meets the need (specific gaps).
3. Options considered, including reuse and catalog alternatives.
4. Cost: purchase plus lifecycle (support, licensing, accessories, disposal); TCO from itam-financial-management if material.
5. Risks: security, support, compatibility, licensing, data.
6. Support model: who images, supports, patches and repairs it.
7. Approvals with dates. Attach to the request and keep with the asset's documents.

## 6. Exceptions to design for

- **Emergency purchase:** allowed by [role], with retrospective approval within [days] and the same handoff data.
- **Purchasing card or expense purchases:** route through intake or catch them in invoice and expense review; they bypass the asset record otherwise.
- **Free, trial and promotional software:** still needs license-terms review and an owner; CAMP lists trial-use, promotional and donated software among policy topics (CAMP M:71; see itam-software-license-management).
- **Vendor-provided or bundled hardware** (for example with a service contract): ownership and return obligations go on the asset record.
- **Shadow purchases found later:** record them, link them to an owner, and bring them into the standard path.

## 7. PO-to-receipt-to-asset-record handoff

### What the PO should carry
PO number and lines · catalog ID / part number · quantity · ship-to location · requester and recipient · cost center · contract ID · leased or owned · expected warranty terms · data-sensitivity flag · request number · whether the vendor will tag or pre-register devices.

### What the vendor sends
ASN or packing data per unit: serial, model, part number, PO line, ship date, and any tag numbers applied.

### Receiving checks (`PRACTICE`; CAMP's Receiver role inspects for damage, rejects or accepts, and notifies the right parties, CAMP M:115; detailed receiving and tagging SOPs are in itam-logistics-warehouse)
1. Shipment matches PO and ASN (quantity, part numbers, serials).
2. Physical condition; damage → reject or RMA per contract.
3. Tag applied (or apply it now) and recorded against the serial.
4. Discrepancies logged with the vendor within [days per contract].

### Asset record created or updated at receipt
Asset tag · serial · model · category · state = [your received / in-stock state] · location and stockroom · PO number and line · vendor · contract ID · purchase cost · purchase and receipt dates · warranty start and end (per contract rule) · leased/owned and lease end · cost center · request number. Use the canonical field names in `references/asset-data-model.md` if that file has been packaged with this skill.

Documents linked to the record: PO, ASN, invoice, contract or order form, proof of purchase, license entitlement records. CAMP expects acquisition to pass contracts, negotiation notes and other documents to documentation management before the asset is distributed (CAMP M:36), and measures how many documents can be linked to their asset (CAMP M:23).

### Invoice match
Three-way match of PO, receipt and invoice (quantity, price, serials where invoiced) before payment (`PRACTICE`). CAMP lists invoice reconciliation as a financial management indicator (CAMP M:24). The matching method belongs to itam-financial-management; hand mismatches and credits to finance and, for repeated issues, to the vendor scorecard (itam-vendor-contract-management).

## 8. Acquisition metrics

| Metric | Source |
|---|---|
| Requests by department, asset type, standard vs. non-standard | request system (CAMP M:22) |
| Approvals and rejections, by the same splits | request system (CAMP M:22) |
| Time to approve or reject, standard and non-standard | request system (CAMP M:22; S:62) |
| Contract negotiation time, start to close | procurement records (CAMP M:22) |
| Quality of RFQ/RFB/RFP responses | evaluation records (CAMP M:22) |
| Receipt-to-asset-record time | receiving log + asset register (CAMP M:22 lists receiving-to-inventory staging time under Asset Identification) |
| Purchases without an asset record (by invoice) | invoices vs. asset register |
