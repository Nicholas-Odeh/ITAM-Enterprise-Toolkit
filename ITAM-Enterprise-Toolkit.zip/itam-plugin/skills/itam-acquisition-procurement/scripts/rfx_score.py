#!/usr/bin/env python3
"""RFx weighted-score calculator with mandatory gate, price normalization and sensitivity.

Scores vendor responses against criteria and weights that were approved BEFORE responses
were opened. It does not choose weights, anchors or the price method for you: those come
from the approved evaluation plan and are passed in as files and options.

Criteria CSV (--criteria): criterion_id, criterion, weight, type
  weight   points; all weights must sum to 100 (use --normalize-weights to rescale)
  type     scored (evaluator score 0..max) | price (computed from --prices)

Scores CSV (--scores): vendor, criterion_id, score
  One row per vendor per scored criterion: the consensus score on the 0..--max-score scale.
  Every qualified vendor needs a score for every scored criterion.

Prices CSV (--prices, needed when a criterion has type price): vendor, price
  Compare prices on the same basis (term, quantity, inclusions) or use a TCO figure.
  Price score = lowest qualified price / vendor price x max score (lower price is better).

Mandatory CSV (--mandatory, optional): vendor, requirement_id, result
  result pass | fail. A vendor with any fail is DISQUALIFIED: it is not ranked and its price
  does not set the lowest price.

Weighted total (out of 100) = sum over criteria of (score / max score x weight).

Sensitivity
  --shift N      move each criterion's weight up and down by N points, rescaling the
                 other criteria proportionally so the total stays 100; reports rank changes
  --scenario S   named weight set, e.g. "fit-heavy:FIT=45,PRICE=15". Unlisted criteria are
                 rescaled proportionally to fill the rest of 100. Repeatable.
  --tie-margin M flag when the top two qualified vendors are within M points

Reports (--report): summary (default) | detail (points per criterion) | sensitivity
Exit codes: 0 ok; 2 usage error or no valid vendors; 3 some rows rejected (stderr).

Examples
  python3 rfx_score.py --criteria criteria.csv --scores scores.csv --prices prices.csv
  python3 rfx_score.py --criteria c.csv --scores s.csv --prices p.csv --shift 10 \\
      --scenario "fit-heavy:FIT=45,PRICE=15" --report sensitivity
  python3 rfx_score.py --criteria c.csv --scores s.csv --prices p.csv --format json
"""

import argparse
import csv
import json
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, getcontext

getcontext().prec = 34
HUNDRED = Decimal(100)


class UsageError(Exception):
    pass


def num(text, what):
    try:
        return Decimal(str(text).strip().replace(",", "").lstrip("$"))
    except InvalidOperation:
        raise ValueError("%s is not a number: %r" % (what, text))


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def load_criteria(path, normalize):
    crit, order = {}, []
    for n, row in enumerate(read_csv(path), start=2):
        cid = (row.get("criterion_id") or "").strip()
        if not cid:
            raise UsageError("criteria line %d: missing criterion_id" % n)
        if cid in crit:
            raise UsageError("criteria line %d: duplicate criterion_id %s" % (n, cid))
        try:
            w = num(row.get("weight", ""), "weight")
        except ValueError as e:
            raise UsageError("criteria line %d: %s" % (n, e))
        if w < 0:
            raise UsageError("criteria line %d: negative weight" % n)
        ctype = (row.get("type") or "scored").strip().lower()
        if ctype not in ("scored", "price"):
            raise UsageError("criteria line %d: type must be scored or price" % n)
        crit[cid] = {"name": (row.get("criterion") or cid).strip(), "weight": w, "type": ctype}
        order.append(cid)
    if not crit:
        raise UsageError("no criteria")
    total = sum(c["weight"] for c in crit.values())
    if total != HUNDRED:
        if not normalize:
            raise UsageError("weights sum to %s, not 100 (fix the plan or pass "
                             "--normalize-weights)" % total)
        for c in crit.values():
            c["weight"] = c["weight"] / total * HUNDRED
    if sum(1 for c in crit.values() if c["type"] == "price") > 1:
        raise UsageError("only one price criterion is supported")
    return crit, order


def rebalance(weights, fixed):
    """Set fixed criteria to given weights; rescale the rest proportionally to fill 100."""
    for k, v in fixed.items():
        if k not in weights:
            raise UsageError("unknown criterion in scenario: %s" % k)
        if v < 0 or v > HUNDRED:
            raise UsageError("scenario weight out of range for %s" % k)
    rest = [k for k in weights if k not in fixed]
    remaining = HUNDRED - sum(fixed.values())
    if remaining < 0:
        raise UsageError("scenario weights exceed 100")
    rest_total = sum(weights[k] for k in rest)
    new = dict(weights)
    new.update(fixed)
    for k in rest:
        if rest_total == 0:
            new[k] = remaining / len(rest)
        else:
            new[k] = weights[k] / rest_total * remaining
    if not rest and remaining != 0:
        raise UsageError("scenario lists every criterion but does not sum to 100")
    return new


def totals(points_basis, weights):
    """points_basis: vendor -> {cid: fraction 0..1}; returns vendor -> total out of 100."""
    return {v: sum(f[c] * weights[c] for c in weights) for v, f in points_basis.items()}


def rank(tot):
    ordered = sorted(tot.items(), key=lambda kv: (-kv[1], kv[0]))
    return {v: i + 1 for i, (v, _) in enumerate(ordered)}, [v for v, _ in ordered]


def q(v, dp):
    return str(v.quantize(Decimal(1).scaleb(-dp), rounding=ROUND_HALF_UP))


def main(argv=None):
    p = argparse.ArgumentParser(
        description=__doc__.split("\n\n")[0],
        epilog="\n\n".join(__doc__.split("\n\n")[1:]),
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--criteria", required=True)
    p.add_argument("--scores", required=True)
    p.add_argument("--prices")
    p.add_argument("--mandatory")
    p.add_argument("--max-score", default="5", help="top of the scoring scale (default 5)")
    p.add_argument("--normalize-weights", action="store_true")
    p.add_argument("--shift", help="sensitivity: move each weight by +/- this many points")
    p.add_argument("--scenario", action="append", default=[],
                   help='named weight set "name:CRIT=w,CRIT=w" (repeatable)')
    p.add_argument("--tie-margin", default="0", help="flag top two within this many points")
    p.add_argument("--report", choices=["summary", "detail", "sensitivity"],
                   default="summary")
    p.add_argument("--format", choices=["csv", "json"], default="csv")
    p.add_argument("--decimals", type=int, default=2)
    p.add_argument("--output")
    a = p.parse_args(argv)

    errors = []
    try:
        max_score = num(a.max_score, "--max-score")
        if max_score <= 0:
            raise UsageError("--max-score must be positive")
        tie_margin = num(a.tie_margin, "--tie-margin")
        crit, order = load_criteria(a.criteria, a.normalize_weights)
        price_cid = next((c for c in order if crit[c]["type"] == "price"), None)

        vendors = []
        scores = {}
        for n, row in enumerate(read_csv(a.scores), start=2):
            v = (row.get("vendor") or "").strip()
            cid = (row.get("criterion_id") or "").strip()
            try:
                if not v or cid not in crit:
                    raise ValueError("unknown or missing vendor/criterion_id")
                if crit[cid]["type"] != "scored":
                    raise ValueError("%s is a price criterion; put prices in --prices" % cid)
                s = num(row.get("score", ""), "score")
                if s < 0 or s > max_score:
                    raise ValueError("score %s outside 0..%s" % (s, max_score))
                if (v, cid) in scores:
                    raise ValueError("duplicate score for %s / %s" % (v, cid))
                scores[(v, cid)] = s
                if v not in vendors:
                    vendors.append(v)
            except ValueError as e:
                errors.append("scores line %d: %s" % (n, e))

        prices = {}
        if price_cid:
            if not a.prices:
                raise UsageError("criteria include a price criterion; pass --prices")
            for n, row in enumerate(read_csv(a.prices), start=2):
                v = (row.get("vendor") or "").strip()
                try:
                    pr = num(row.get("price", ""), "price")
                    if not v or pr <= 0:
                        raise ValueError("vendor missing or price not positive")
                    prices[v] = pr
                    if v not in vendors:
                        vendors.append(v)
                except ValueError as e:
                    errors.append("prices line %d: %s" % (n, e))

        failed = {}
        if a.mandatory:
            for n, row in enumerate(read_csv(a.mandatory), start=2):
                v = (row.get("vendor") or "").strip()
                res = (row.get("result") or "").strip().lower()
                if res not in ("pass", "fail") or not v:
                    errors.append("mandatory line %d: result must be pass or fail" % n)
                    continue
                if res == "fail":
                    failed.setdefault(v, []).append((row.get("requirement_id") or "").strip())
                if v not in vendors:
                    vendors.append(v)

        status, basis = {}, {}
        qualified = [v for v in vendors if v not in failed]
        for v in vendors:
            if v in failed:
                status[v] = "DISQUALIFIED (mandatory fail: %s)" % ", ".join(failed[v])
        incomplete = []
        for v in qualified:
            missing = [c for c in order if crit[c]["type"] == "scored" and (v, c) not in scores]
            if price_cid and v not in prices:
                missing.append(price_cid + " (price)")
            if missing:
                incomplete.append(v)
                status[v] = "INCOMPLETE (missing: %s)" % ", ".join(missing)
                errors.append("vendor %s not ranked; missing %s" % (v, ", ".join(missing)))
        ranked = [v for v in qualified if v not in incomplete]
        if not ranked:
            raise UsageError("no vendor has a complete, qualified set of scores")

        lowest = min(prices[v] for v in ranked) if price_cid else None
        price_score = {}
        for v in ranked:
            f = {}
            for c in order:
                if crit[c]["type"] == "price":
                    price_score[v] = lowest / prices[v] * max_score
                    f[c] = price_score[v] / max_score
                else:
                    f[c] = scores[(v, c)] / max_score
            basis[v] = f
            status[v] = "QUALIFIED"

        base_w = {c: crit[c]["weight"] for c in order}
        base_tot = totals(basis, base_w)
        base_rank, base_order = rank(base_tot)

        sens = []

        def add_case(label, weights):
            t = totals(basis, weights)
            r, o = rank(t)
            sens.append({"case": label,
                         "weights": {c: weights[c] for c in order},
                         "totals": t, "ranks": r, "leader": o[0],
                         "rank_change": "Yes" if o != base_order else "No"})

        add_case("base", base_w)
        if a.shift:
            sh = num(a.shift, "--shift")
            for c in order:
                for sign, tag in ((1, "+"), (-1, "-")):
                    nw = base_w[c] + sign * sh
                    if nw < 0 or nw > HUNDRED:
                        continue
                    add_case("%s %s%s" % (c, tag, a.shift), rebalance(base_w, {c: nw}))
        for spec in a.scenario:
            if ":" not in spec:
                raise UsageError('scenario must look like "name:CRIT=w,CRIT=w"')
            name, body = spec.split(":", 1)
            fixed = {}
            for part in body.split(","):
                k, _, val = part.partition("=")
                fixed[k.strip()] = num(val, "scenario weight")
            add_case(name.strip(), rebalance(base_w, fixed))
    except UsageError as e:
        for x in errors:
            print("rejected: %s" % x, file=sys.stderr)
        print("error: %s" % e, file=sys.stderr)
        return 2
    except (OSError, ValueError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 2

    for x in errors:
        print("rejected: %s" % x, file=sys.stderr)

    tie_note = ""
    if len(base_order) > 1:
        gap = base_tot[base_order[0]] - base_tot[base_order[1]]
        if gap <= tie_margin:
            tie_note = ("TIE: %s and %s within %s points (gap %s); apply the pre-stated "
                        "tie-breakers" % (base_order[0], base_order[1], a.tie_margin,
                                          q(gap, a.decimals)))
            print(tie_note, file=sys.stderr)

    dp = a.decimals
    summary = []
    for v in vendors:
        summary.append({
            "vendor": v, "status": status.get(v, ""),
            "price": q(prices[v], dp) if v in prices else "",
            "price_score": q(price_score[v], dp) if v in price_score else "",
            "weighted_total": q(base_tot[v], dp) if v in base_tot else "",
            "rank": base_rank.get(v, ""),
        })
    summary.sort(key=lambda r: (r["rank"] == "", r["rank"] if r["rank"] != "" else 0))
    detail = []
    for v in base_order:
        for c in order:
            detail.append({"vendor": v, "criterion_id": c, "criterion": crit[c]["name"],
                           "weight": q(base_w[c], dp),
                           "score": q(basis[v][c] * max_score, dp),
                           "points": q(basis[v][c] * base_w[c], dp)})
    sens_rows = []
    for s in sens:
        for v in base_order:
            sens_rows.append({"case": s["case"], "vendor": v,
                              "weighted_total": q(s["totals"][v], dp),
                              "rank": s["ranks"][v], "leader": s["leader"],
                              "rank_change_vs_base": s["rank_change"],
                              "weights": "; ".join("%s=%s" % (c, q(s["weights"][c], dp))
                                                   for c in order)})

    out = open(a.output, "w", newline="", encoding="utf-8") if a.output else sys.stdout
    try:
        if a.format == "json":
            json.dump({"summary": summary, "detail": detail, "sensitivity": sens_rows,
                       "tie": tie_note, "rejected": errors,
                       "max_score": str(max_score),
                       "lowest_qualified_price": q(lowest, dp) if lowest else ""},
                      out, indent=2)
            out.write("\n")
        else:
            rows = {"summary": summary, "detail": detail, "sensitivity": sens_rows}[a.report]
            w = csv.DictWriter(out, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    finally:
        if a.output:
            out.close()
    return 3 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
