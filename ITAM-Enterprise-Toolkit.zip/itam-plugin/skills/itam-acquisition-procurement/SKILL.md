---
name: itam-acquisition-procurement
description: Use when someone asks to "write an RFP" or RFQ, score vendor responses, design a request and approval workflow, build or prune a standard device catalog, justify a non-standard purchase, check reuse before buying, or define what the PO must pass to receiving and the asset register. Covers catalogs, approval matrices, RFx, weighted evaluation, POCs, selection memos, PO-to-receipt handoff. Not for existing contracts, SLAs or renewals (use itam-vendor-contract-management) or TCO and lease-vs-buy math (use itam-financial-management).
---

# IT Acquisition and Procurement

Decide whether something should be bought at all, route standard and non-standard requests, run a fair RFx and selection, and make sure every purchase arrives in the asset register with the data and documents it needs. For ITAM, procurement, IT standards and service owners. CAMP treats acquisition as the gatekeeper that applies ITAM policy before money is spent (CAMP M:35).

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Policy and law govern the process.** Approval limits, bid thresholds, sole-source rules and public-sector procurement law come from the organization's policy and counsel. Use labeled placeholders; never invent them.
7. **Fix the evaluation before opening responses.** Mandatory criteria, weights and scales are approved first; any later change is documented with reason and approver, and everyone is rescored.
8. **Draft, don't commit.** Prepare RFx drafts, scoring sheets and memos only. Do not issue RFx, contact vendors, accept terms or raise POs.

## When to use

- Request intake, approval matrix, non-standard justification.
- Standard catalog design or sunsetting.
- RFI vs. RFQ vs. RFP; drafting; requirement lists; vendor Q&A.
- Scoring, price normalization, sensitivity, POC, selection memo.
- What the PO and receipt must carry to create the asset record.

**When not to use:** existing contracts, SLAs, scorecards, renewals → `itam-vendor-contract-management`; TCO, lease vs. buy → `itam-financial-management`; receiving and tagging SOPs → `itam-logistics-warehouse`.

## Workflow

### Step 1 — Classify the request

| Request | Load |
|---|---|
| Intake, approvals, justification | `references/request-approval-flow.md` |
| Standard catalog | `references/standard-catalog-template.md` |
| RFx drafting | `references/rfx-templates.md` |
| Evaluation and selection | `references/evaluation-matrix.md` + `scripts/rfx_score.py` |
| PO-to-receipt handoff | `references/request-approval-flow.md` §7 |
| End-to-end acquisition | `references/working-method.md`, then the above in order |

### Step 2 — Preflight

Confirm or label (`working-method.md` §1): the need, users, quantity and timing; policy limits and thresholds; existing stock, redeployable assets and contracts; stakeholders and sign-off; the deliverable. Above the competitive threshold or with sensitive data, treat the consequence as HIGH and include security and legal review.

### Step 3 — Do the work

Need → reuse before buy → standard or non-standard → sourcing route → requirements with IDs and ITAM data requirements → evaluate (mandatory gate, pre-approved weights, `python3 scripts/rfx_score.py` with sensitivity, POC) → selection memo → PO and receipt handoff → measure (`working-method.md` §2).

### Step 4 — Verify before release

- ★ No approval limit, bid threshold, legal requirement, price or vendor fact is invented; placeholders are labeled.
- ★ Criteria, weights and scales were fixed before scoring; any change is documented.
- ★ Scores and price normalization come from a script run that can be reproduced, with the command shown.
- ★ The RFx holds no confidential or personal data beyond need, and no draft is presented as issued.
- ★ Legal terms, liability and data-protection clauses are routed to Legal.
- Non-blocking checks: `working-method.md` §3.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Vendor A is clearly ahead" | Run sensitivity; a weight shift can flip the rank. |
| "I'll tally the scores quickly" | Numbers by eye are not evidence. Run `rfx_score.py`. |
| "Let's adjust the weights now we've seen the bids" | That biases the outcome. Document, approve, rescore everyone. |
| "Send the RFP to the shortlist" | Draft only; procurement issues it. |

Stop if you are about to: score before weights are approved; let a disqualified bid set the lowest price; email a vendor.

## Common mistakes

| Mistake | Fix |
|---|---|
| RFx without ITAM data requirements | Add serial, ASN, tag, warranty-start and take-back requirements. |
| Comparing prices on different terms | Same term, quantity and inclusions, or a TCO figure. |
| Skipping the reuse check | Record stock and redeployable assets first. |
| Everything "mandatory" | Keep mandatory items truly pass/fail; score the rest. |

## If connectors are available

- **~~procurement:** read existing contracts, catalogs, approval limits and spend; draft requisitions only.
- **~~ITSM / ~~CMDB:** read stock on hand and redeployable assets for the reuse check.
- **~~document repository:** read RFx templates and file the evaluation record.
- **~~email:** draft vendor Q&A responses; procurement sends.

## Output format

1. **Recommendation** in two to five sentences.
2. **Work product:** RFx draft, scoring results with the script command, catalog, approval flow or handoff spec.
3. **Assumptions and open decisions** (limits, weights, approvers).
4. **Risks and next steps,** naming the skill that takes over.

Variants: `working-method.md` §4.

## Reference files

- `references/request-approval-flow.md`: intake, routing, approval matrix, justification, PO-to-receipt handoff, metrics.
- `references/standard-catalog-template.md`: designing or retiring catalog items.
- `references/rfx-templates.md`: choosing and drafting RFI, RFQ/RFB or RFP; requirement bank.
- `references/evaluation-matrix.md`: criteria, weights, scoring, sensitivity, POC, selection memo.
- `references/working-method.md`: preflight, the nine-step flow, deliverables.
- `references/asset-data-model.md`: shared copy of the canonical data model (source `itam-hardware-lifecycle`); don't edit.
- `scripts/rfx_score.py`: mandatory gate, price normalization, weighted totals, sensitivity; `--help` for inputs.
