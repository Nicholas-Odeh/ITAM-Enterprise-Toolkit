---
name: itam-logistics-warehouse
description: Use when receiving, tagging, storing, shipping or getting back IT equipment: receiving against PO or ASN, tag standards, stockroom or depot setup, running a physical cycle count, new-hire and remote kits, leaver return kits, lost or damaged shipments, RMA shipping, in-transit chain of custody, shipping abroad. Not for matching datasets or variance analysis (use itam-inventory-reconciliation), ITAD custody (itam-secure-disposition), stock-level, capacity sizing or staffing forecasts (use itam-capacity-planning), or a failing recovery rate (use itam-process-improvement).
---

# ITAM Logistics and Warehouse

The physical movement and storage of IT assets: receiving, tagging, storage, kitting, shipping, returns, counts and claims. Core principle: **every handoff of a serialized asset leaves a custody record.** For ITAM managers, stockroom and depot staff, and service desk teams that ship to remote users. Content is `PRACTICE` unless cited; organization values are `[FILL]`.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Regulated shipping is awareness, not advice.** Never state a dangerous-goods limit, customs or export classification, sanctions position, carrier liability term, claim deadline or pay-deduction permission from memory: label it `VERIFY` and name who confirms it.
7. **Custody is continuous.** Every handoff (dock, stockroom, technician, courier, user, depot, vendor) records who, which serials, when, condition, and seal or tracking number. A gap is an exception to investigate.
8. **Count, then investigate, then adjust.** A count never silently overwrites the record; adjustments are approved by someone other than the counter.

## When to use

- "Write our receiving SOP", "where do tags go", damaged delivery, PO mismatch.
- Stockroom layout and controls; planning and running a physical cycle count.
- New-hire shipping, leaver return kits, "the carrier lost a laptop", RMA shipments.
- Shipping abroad; a swollen battery; dock-to-stock or transit-loss metrics.

**When not to use:** matching the count file or other datasets and analyzing variance (`itam-inventory-reconciliation`); lifecycle state design and the leaver trigger (`itam-hardware-lifecycle`); ITAD chain of custody (`itam-secure-disposition`); forecasting stock levels, stockroom space or staffing (`itam-capacity-planning`).

## Workflow

### Step 1 — Classify

| Request | Load |
|---|---|
| Receiving, inspection, tagging, put-away | `references/receiving-sop.md` |
| Shipping, kits, returns, claims, RMA, international, batteries | `references/remote-shipping-playbook.md` |
| Stockroom controls, cycle counts, peripheral tracking tiers | `references/cycle-count-procedure.md` |
| Metrics and SLAs | `references/logistics-metrics.md` |

### Step 2 — Preflight

Confirm or assume: sites and countries; system of record for stock; what is tracked individually; carriers and contract terms (never assumed); return policies. Ask if international or 3PL scope is unknown (`references/logistics-method.md` §1).

### Step 3 — Do the work

- **Receiving:** match to PO/ASN → inspect → accept or reject → capture serials → tag → record → put away → notify (CAMP M:38, M:115).
- **Tags** are unique and meaningless outside the organization (CAMP M:38). **Zones** match record statuses.
- **Outbound:** HR-sourced address, serial and photo at pack, tracking; In transit → In use only on confirmed delivery.
- **Returns:** returned means a stockroom receipt with a serial scan.
- **Claims:** build the evidence packet at pack time; a lost data-bearing device is a security event.

Full method: `references/logistics-method.md` §2–9.

### Step 4 — Verify before release

- ★ No dangerous-goods, customs, export, sanctions, carrier liability, claim deadline or pay-deduction point stated as fact; each `VERIFY` with an owner.
- ★ Every handoff produces a custody record; gaps are flagged as exception paths.
- ★ No count variance adjusted without investigation and independent approval.
- ★ No device recorded as delivered or returned without proof of delivery or a receipt scan.
- ★ Home addresses and personal data minimized and kept out of shared trackers.
- SLAs, thresholds, kits and carriers come from the user or are `[FILL]`; each custody step names the state change.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The count is 5 short; adjust and move on" | Recount, investigate, then an independent approver adjusts. |
| "Tracking says delivered, so mark it returned" | Returned means a receipt scan in the stockroom. |
| "Laptops ship fine by air; just send it" | Battery and export rules are `VERIFY` with the carrier and trade compliance. |
| "We'll deduct it from final pay" | HR and Legal decide that. |

Stop if you are about to: adjust a record to match a count; skip a custody record for an internal move; state a carrier claim deadline from memory.

## Common mistakes

| Mistake | Fix |
|---|---|
| Untagged items tagged on the spot during a count | Record them; receive formally first |
| Pending-disposal devices in the general stockroom | Separate, access-logged zone |
| Claim evidence gathered after the loss | Serial and photo at pack time |
| Shipping address copied from a ticket | Use the HR or authoritative address |

## If connectors are available

- **~~ITSM:** read stockroom and asset records; draft receipts, transfers and state changes for approval, then re-query.
- **~~procurement / ~~HR:** read POs and ASNs; leaver dates and addresses (minimum personal data).
- **~~email:** draft return reminders and claim messages; never send.

## Output format

1. **Answer** in two to five sentences.
2. **Procedure, checklist or design:** steps with role, system action, evidence and exception path.
3. **Assumptions and VERIFY list** with who confirms each item.
4. **Risks.**

Executive and practitioner variants: `references/logistics-method.md` §10.

## Reference files

- `references/logistics-method.md`: preflight, method per area, output variants. Read for substantial work.
- `references/receiving-sop.md`: receiving, inspection, tagging. Read for inbound work.
- `references/remote-shipping-playbook.md`: kits, shipping, returns, custody, claims, international. Read for outbound or returns.
- `references/cycle-count-procedure.md`: stockroom controls, count procedure, variance, tracking tiers. Read for counts.
- `references/logistics-metrics.md`: metric definitions and dashboard layout. Read when measuring performance.
- `references/asset-data-model.md`: shared canonical states (source: `itam-hardware-lifecycle`). Read for state mapping.
