# Remote shipping, returns, claims and international playbook

Content is `PRACTICE`. Every carrier term, dangerous-goods rule, customs or export-control point and HR/legal question is `VERIFY` with the named owner. Organization values are `[FILL]`.

## Contents
1. Kitting
2. Outbound: new hire, replacement, loaner
3. Leaver and replacement returns
4. In-transit chain of custody
5. Carrier tracking and exceptions
6. Loss and damage claims
7. RMA and warranty shipping
8. International shipping
9. Lithium battery awareness
10. Depot or 3PL partner oversight

## 1. Kitting

| Kit ID | For build / persona | Contents | Packaging | Owner |
|---|---|---|---|---|
| [FILL] | WIN-STD laptop | Device, charger, [dock?], [headset?], quick-start card, return instructions | [FILL] | [FILL] |
| [FILL] | Leaver return kit | Box sized for device + charger, padding, prepaid label, tamper-evident seal, instructions, packing checklist | [FILL] | [FILL] |

Kitted devices sit in a reserved/kitted zone and substate, linked to the request they serve, so they don't count as available stock.

## 2. Outbound: new hire, replacement, loaner

| # | Step | Evidence |
|---|---|---|
| 1 | Trigger: approved request linked to a JML event or ticket (`itam-hardware-lifecycle`) | Request |
| 2 | Get the delivery address from the authoritative source [FILL — HR system], not from free-text email; confirm with the user if it differs | Address source noted (not copied into broad trackers) |
| 3 | Allocate a Configured/Ready device (`endpoint-imaging-provisioning`) and reserve it to the request | Asset reserved |
| 4 | Pack: scan tag and serial; photograph serial, contents and sealed box; record seal number if used | Pack record + photos |
| 5 | Choose service level per policy [FILL]: tracking always; signature required for [FILL — e.g., data-bearing devices or above a value]; declared value/insurance per carrier contract [VERIFY] | Label + tracking number |
| 6 | Update record: state In transit; tracking number, carrier, ship date, ship-to type (home/office) | Asset record |
| 7 | Track to delivery (section 5) | Tracking history |
| 8 | User confirms receipt and accepts the device and acceptable use terms | Acknowledgment |
| 9 | Update record: In use, assigned to user, location type remote | Asset record |

Direct-ship from OEM or depot follows the same record steps; the depot or OEM supplies the pack evidence.

## 3. Leaver and replacement returns

| # | Step | Owner |
|---|---|---|
| 1 | Trigger from HR leaver event or replacement delivery; list assets assigned to the person | ITAM |
| 2 | Send return kit or prepaid label within [FILL] days of trigger; replacement returns ship with the new device | Shipping desk |
| 3 | Instructions: what to return (device, charger, accessories), how to pack, don't remove tags, sign out of personal accounts [FILL per platform], where to drop off | Shipping desk |
| 4 | Reminder cadence: [FILL — e.g., day X, day Y]; escalation to manager then HR at [FILL] | ITAM / service desk |
| 5 | Security action if not returned by [FILL]: remote lock or wipe **per security policy** | Security |
| 6 | Receipt at depot: check seal, scan serial, inspect, photograph condition, compare with assigned list | Receiver |
| 7 | Update record: returned / In stock (quarantine or pending rebuild); close the retrieval task | ITAM |
| 8 | Route: rebuild (`endpoint-imaging-provisioning`) or disposition (`itam-secure-disposition`) | ITAM |
| 9 | Unrecovered after [FILL]: write-off decision by [FILL role]; any recovery from final pay or legal action is an **HR/legal decision** and may be restricted by local law [VERIFY] | HR / Legal / Finance |

Return rate and time-to-recover are tracked in `logistics-metrics.md`.

## 4. In-transit chain of custody

Minimum custody record at every handoff (SKILL rule 7): asset tag, serial, from (person/site), to (person/site/carrier), date/time, condition, seal number, tracking number, signature or system confirmation. Handoffs to cover: stockroom → shipping desk → carrier → recipient; recipient → carrier → depot → stockroom; depot ↔ vendor (RMA). Bulk moves between sites use a manifest (one line per serial) signed at both ends; in ServiceNow this maps to transfer orders (`servicenow-itam`); in the canonical model it is transitions T06a and T06b (`asset-data-model.md` §4.2). Custody to an ITAD vendor belongs to `itam-secure-disposition`.

## 5. Carrier tracking and exceptions

| Tracking status | Action | When |
|---|---|---|
| No first scan within [FILL] | Confirm pickup with carrier; check the package didn't stay on the dock | [FILL] |
| Delivery exception / address issue | Contact recipient using the authoritative contact; correct with carrier | Same day [FILL] |
| Delivered, user says not received | Ask carrier for proof of delivery; check neighbors/reception; start claim clock | [FILL] |
| No movement for [FILL] days | Open carrier trace; mark asset In transit — investigation | [FILL] |
| Returned to sender | Receive as a return; re-ship or cancel | — |

Keep a daily exceptions list for open shipments past expected delivery.

## 6. Loss and damage claims

Claim deadlines, liability limits and evidence rules are in the carrier contract or tariff [VERIFY]; never assume them.

Evidence packet (build it at pack time): tracking number, ship date, declared value and service, pack photos (serial, contents, sealed box), weight, invoice or asset cost, delivery photos/POD, damage photos, recipient statement.

| Step | Action |
|---|---|
| 1 | Confirm loss or damage; record the date discovered |
| 2 | **If data-bearing:** open a security incident; confirm encryption status from MDM; remote lock/wipe per policy; record the decision (`itam-hardware-lifecycle` covers lost/stolen state handling) |
| 3 | File the carrier claim within the contractual window [VERIFY] |
| 4 | Asset state: lost/in-transit investigation → final state per lifecycle model (e.g., Missing/Stolen) once the carrier confirms loss |
| 5 | Record claim outcome and recovered amount; finance handles write-off (`itam-financial-management`) |

## 7. RMA and warranty shipping

- Get the vendor RMA number before shipping; record it on the asset with the fault description.
- **Storage media decision before the device leaves:** remove and retain the drive, use a keep-your-drive contract option, or confirm encryption and the vendor's handling terms [VERIFY contract; policy decision via `itam-secure-disposition`].
- Remove the device from your management portals only if the vendor is replacing the unit and the replacement will be registered (`endpoint-imaging-provisioning`).
- Record serial out, and serial back in. A replacement unit with a new serial needs a new asset record or a documented serial swap per the data model; never silently overwrite the serial.
- Count RMAs by vendor and asset type (CAMP M:22).

## 8. International shipping (general awareness only — VERIFY with trade compliance)

Questions to settle with trade compliance and the carrier or broker before the first shipment to a country:
- **Who is importer of record (IOR) and exporter of record**, and on what Incoterms the shipment moves. Shipping to an individual's home in another country can create import obligations the person can't fulfil.
- **Customs documents:** commercial or pro-forma invoice, value declaration (used equipment still needs a value), product classification codes, country of origin.
- **Export controls on encryption:** laptops and phones contain encryption. Export rules of the shipping country (for example the US EAR, or EU dual-use rules) and import or use restrictions of the destination country may apply; sanctioned or embargoed destinations may be prohibited. Classification and licensing are trade-compliance decisions [VERIFY]; this skill never assigns a classification.
- **Returns from abroad** are exports from that country and imports into yours; plan both directions.
- **Taxes and duties:** who pays and how they're recovered.
- **Alternatives:** in-country procurement or a regional depot/3PL often beats cross-border shipping for recurring volume (RECOMMENDATION, depending on volume and cost data).
- **Travel with devices** (employees carrying laptops) is a policy question for trade compliance and security, not a shipping process.

## 9. Lithium battery awareness (VERIFY with carrier and a trained shipper)

- Laptops, phones and tablets contain lithium batteries. Shipping them is regulated as dangerous goods under air and ground rules (for example IATA rules for air) and each carrier's own acceptance rules. Batteries installed in equipment, packed with equipment, and shipped alone are treated differently [VERIFY current edition and carrier rules].
- Spare or standalone batteries are more restricted than batteries installed in a device [VERIFY].
- **Damaged, defective, swollen or recalled batteries** face special restrictions and are generally not accepted through normal air services [VERIFY]. Isolate them and use the carrier's or a hazmat specialist's process.
- Some shipments require staff with dangerous-goods training to prepare and sign them [VERIFY]. Record who in the organization is trained [FILL].
- Return kit instructions should tell users not to ship a visibly swollen device and to contact the service desk instead.

## 10. Depot or 3PL partner oversight

If a depot or 3PL performs any of this: put receiving, tagging, kitting, custody records, count access, claims handling and data-bearing device handling in the contract and SLA [VERIFY with `itam-vendor-contract-management`]; get their records into your system of record (not just their portal); audit them with periodic counts and evidence sampling.
