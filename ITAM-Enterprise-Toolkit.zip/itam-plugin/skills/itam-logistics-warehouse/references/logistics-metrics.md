# Logistics and warehouse metrics

Definitions are `PRACTICE` unless a CAMP citation is given. Targets are the organization's to set: always `[FILL]`, never invented. For each metric state the numerator, denominator, source, frequency and owner. For a full ITAM metrics catalog and dashboard design, see `itam-data-analysis-reporting`.

## Contents
1. Inbound and receiving
2. Stockroom and inventory
3. Outbound and delivery
4. Returns and recovery
5. Transit loss, damage and claims
6. RMA
7. Cost
8. Dashboard layout
9. Data quality notes

## 1. Inbound and receiving

| Metric | Formula | Source | Note |
|---|---|---|---|
| Receiving-to-inventory (staging) time | Median and 90th percentile of (placed-into-inventory time − received time) | Asset state history | CAMP indicator (CAMP M:22; S:75) |
| Receipt accuracy | Receipts matching PO/ASN on model, quantity and serial ÷ receipts | Receiving log | — |
| Vendor pre-delivery accuracy | Vendor-tagged or vendor-registered units correct ÷ units received from that vendor | Receiving exceptions | CAMP indicator: did the vendor apply the asset tag appropriately (CAMP M:22) |
| Receiving exceptions rate | Receipts with any exception ÷ receipts, by reason | Receiving log | — |
| Inventory increases/decreases with who, how and when | Count of adjustments by type and actor | Asset history | CAMP lists how, who and when inventory changed (CAMP M:22) |

## 2. Stockroom and inventory

| Metric | Formula | Source |
|---|---|---|
| Inventory record accuracy | Locations (or serials) where record = count ÷ locations (or serials) counted | Cycle counts |
| Physical-vs-record reconciliation errors | Count of variances per count, by cause | Count records; CAMP indicator (CAMP M:22) |
| Stock aging | Days in current In stock substate, by model and zone (buckets [FILL]) | Asset state history |
| Ready stock coverage | Configured/Ready units ÷ forecast demand for next [FILL] days | Assets + demand forecast |
| Stockouts | Requests that waited because no stock was available | Requests |
| Pending-disposal backlog | Units and age in pending-disposal zone | Asset records |

Ready stock coverage reports today's position against a demand forecast supplied by the user or by `itam-capacity-planning`; building that forecast, and sizing stockroom space or staff, is that skill's job.

## 3. Outbound and delivery

| Metric | Formula | Source |
|---|---|---|
| Request-to-ship time | Median of (ship time − approved request time) | Requests + shipments |
| On-time delivery | Delivered by the promised date ÷ delivered | Carrier tracking |
| First-time delivery success | Delivered on first attempt ÷ shipments | Carrier tracking |
| Delivery-to-acceptance time | Median of (user acknowledgment − delivery time) | Acknowledgments |
| Unacknowledged deliveries | Delivered > [FILL] days without user acknowledgment | Acknowledgments |

## 4. Returns and recovery

| Metric | Formula | Source |
|---|---|---|
| Leaver return rate at N days | Leaver assets received within N days of leave date ÷ leaver assets due (N = [FILL], e.g., report at 2–3 cut-offs) | JML + receipts |
| Time to recover | Median of (receipt at depot − leave date) | JML + receipts |
| Replacement return rate | Old devices returned within [FILL] days of replacement delivery ÷ replacements | Shipments + receipts |
| Unrecovered value | Sum of [FILL — book or replacement value] of unrecovered assets past final deadline | Assets + finance |
| Return condition | Returns graded damaged ÷ returns | Receiving inspection |

## 5. Transit loss, damage and claims

| Metric | Formula | Source |
|---|---|---|
| Transit loss rate | Shipments confirmed lost ÷ shipments, by carrier and lane | Claims |
| Transit damage rate | Shipments arriving damaged ÷ shipments, by carrier | Receiving + user reports |
| Claim filing timeliness | Claims filed within contract window ÷ claims | Claims log |
| Claim recovery | Amount recovered ÷ amount claimed | Claims log |
| Custody exceptions | Handoffs missing a custody record ÷ handoffs sampled | Custody audit sample |
| Lost data-bearing devices with confirmed encryption | Lost devices with encryption confirmed ÷ lost data-bearing devices | Security + MDM |

## 6. RMA

| Metric | Formula | Source |
|---|---|---|
| RMAs by vendor and asset type | Count, by vendor, model, reason | RMA log; CAMP indicator (CAMP M:22) |
| RMA turnaround | Median of (replacement received − RMA opened) | RMA log |
| RMA open aging | Open RMAs by age bucket | RMA log |

## 7. Cost

| Metric | Formula | Source |
|---|---|---|
| Cost per outbound shipment | Carrier + packaging + labor [FILL whether labor is included] ÷ shipments | Invoices |
| Cost per recovered device | Return kit + label + handling ÷ devices recovered | Invoices |
| International landed cost | Shipping + duties + taxes + broker fees ÷ shipments, by country | Invoices + broker |

## 8. Dashboard layout (suggested)

1. **Top row (executive):** leaver return rate at N days, unrecovered value, transit loss rate, inventory record accuracy, staging time.
2. **Inbound:** staging time trend, receiving exceptions by vendor, vendor pre-delivery accuracy.
3. **Stock:** ready stock coverage by model, stock aging buckets, pending-disposal backlog.
4. **Outbound/returns:** on-time delivery by carrier, return rate funnel (due → kit sent → in transit → received), open shipment exceptions.
5. **Claims and RMA:** open claims and RMAs by age, recovery rate.

## 9. Data quality notes

- Metrics are only as good as the timestamps. Check that receipt, state change and shipment times are captured at the event, not batch-entered later (INFERENCE when they cluster at day end).
- Carrier data joins to assets via tracking number; a shipment without a tracking number on the asset record can't be measured.
- Report the denominator with every rate; small denominators (for example a country with five shipments) need the count shown, not just the percentage.
