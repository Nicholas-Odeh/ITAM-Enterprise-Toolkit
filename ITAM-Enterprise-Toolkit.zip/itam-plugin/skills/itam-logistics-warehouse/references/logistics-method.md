# Logistics and warehouse: preflight and working method

Detail behind Steps 2 and 3 of `itam-logistics-warehouse`. Read it for any receiving, tagging, stockroom, shipping, returns or claims design that others will follow. The supplied sources cover the receiving role, tagging and asset identification at concept level (CAMP M:38–40, 92, 111–115; CAMP S:72–76); everything else is `PRACTICE`, and organization values (SLAs, thresholds, carriers, addresses) are `[FILL]`.

## Contents
1. Preflight checklist
2. Receiving
3. Tagging standard
4. Stockroom and depot controls
5. Kitting and outbound shipping
6. Returns and leavers
7. Claims, RMA and international
8. Peripherals and consumables
9. Metrics
10. Output variants

## 1. Preflight checklist

Read `templates/company-profile.md` if present, and `asset-data-model.md` (shared copy; canonical lifecycle states). Then confirm, or assume and label:
- **Sites and flows:** central depot, regional stockrooms, third-party logistics (3PL) or depot partner, OEM direct-ship; countries involved.
- **System of record for stock and movements:** ServiceNow (stockrooms, transfer orders; see `servicenow-itam`), another ITAM tool, or a spreadsheet.
- **What is tracked:** asset classes tracked individually vs. by quantity; the tracking threshold if one exists.
- **Carriers and contracts:** carriers, service levels, declared-value or insurance terms, claim process. Never assume these.
- **Policies that govern returns:** leaver policy, remote-lock policy, any deduction rules (HR/legal).
- **Volumes and current metrics** if the user wants performance analysis. Sizing future stock, space or staff is `itam-capacity-planning`.

Ask one question if a missing item would change the design (for example international scope, or 3PL vs. in-house).

## 2. Receiving

The Receiver inspects packages for damage, rejects or accepts, and notifies the right parties; asset identification personnel assign the identifier, tag and record the asset (CAMP M:38, M:111–112, M:115; S:74). Make the flow explicit: match to PO/ASN → inspect → accept or reject → capture serials → tag → create or update the asset record → put away in a status-matched location → notify procurement and finance. Receipt-to-inventory staging time is a named CAMP indicator (CAMP M:22). Detail and exception rules: `receiving-sop.md`.

## 3. Tagging standard

The tag carries a unique identifier that has no meaning outside the organization (CAMP M:38). Barcodes and QR codes let anyone with a scanner or phone pull up the record (CAMP M:92). Decide symbology, material (durable, tamper-evident where theft matters), placement per device type, and who applies tags (vendor pre-tagging needs an accuracy check; CAMP M:22). Never place tags on removable parts, vents or battery doors.

## 4. Stockroom and depot controls

Physical zones match record statuses: receiving/quarantine, available, reserved/kitted, build/rework, defective/RMA, pending disposal (secure, separately controlled). Access is restricted and logged; data-bearing devices pending disposal are the highest-risk zone. Bin locations are recorded so a count can find what the record says is there. Transfers between stockrooms use a manifest and canonical transitions T06a/T06b. Detail: `cycle-count-procedure.md`.

## 5. Kitting and outbound shipping

Kits are defined per build or persona (device, charger, peripherals, documentation). Outbound shipments carry: a verified address from the authoritative source (normally HR), serial capture and photo at pack, tracking, signature where the risk justifies it, and user acknowledgment at receipt. The asset moves In transit → In use only on confirmed delivery and acceptance. Detail: `remote-shipping-playbook.md`.

## 6. Returns and leavers

Return kits go out on a trigger from the leaver or replacement process (`itam-hardware-lifecycle` owns the joiner-mover-leaver trigger). Use prepaid labels, clear instructions, a reminder cadence and an escalation path. A device counts as returned only on a stockroom receipt with a serial scan. Unrecovered devices go through the security path (remote lock per policy) and a write-off decision; deductions from pay are an HR and Legal question (SKILL rule 6).

## 7. Claims, RMA and international

Build the claim evidence packet at pack time, not after the loss. A lost data-bearing device is also a security event. RMA shipments need a vendor RMA number and a decision on the storage drive (`itam-secure-disposition`). International shipments raise customs, importer-of-record, export-control (encryption) and battery questions that are always `VERIFY` with trade compliance and the carrier. Detail: `remote-shipping-playbook.md`.

## 8. Peripherals and consumables

Decide per class whether it is tracked individually (serialized and tagged), tracked by quantity (min/max), or expensed and untracked. Cost is one criterion; data-bearing capability, theft attractiveness and warranty value are others. CAMP notes that simple non-managed items (screens, keyboards, mice) are often over-ordered and easy to track once tagged (CAMP M:92). Thresholds are `[FILL]`.

## 9. Metrics

Use `logistics-metrics.md`; every metric gets a definition, source and owner, and targets come from the organization.

## 10. Output variants

**Default:** answer (two to five sentences); procedure, checklist or design with role, system action, evidence and exception path per step, labeled; assumptions and VERIFY list, each with who confirms it (carrier, trade compliance, legal, HR, security); risks (loss, data exposure, unrecovered devices, record drift, regulatory exposure).

**Executive variant:** lead with recovery rate, loss and damage cost, staging time and audit exposure.

**Practitioner variant:** SOP-style steps and checklists for the dock, stockroom or shipping desk. For a controlled SOP document, use `itam-sop-documentation` with this procedure as input.
