# Stockroom controls and cycle count procedure

Content is `PRACTICE` unless cited. Organization values are `[FILL]`. This file covers the physical count and stockroom controls. Matching count results to discovery, ServiceNow or finance data and classifying the exceptions belongs to `itam-inventory-reconciliation`; ServiceNow stockroom and transfer order mechanics belong to `servicenow-itam`.

## Contents
1. Stockroom and depot layout
2. Physical and access controls
3. Tracking tiers for peripherals and consumables
4. Count types and frequency
5. Count procedure
6. Variance tolerance, investigation and adjustment
7. Records and evidence

## 1. Stockroom and depot layout

Physical zones should mirror record statuses so that "where it is" and "what the record says" can be checked at a glance.

| Zone | Holds | Record state/substate (canonical; map to yours) | Control level |
|---|---|---|---|
| Receiving / quarantine | Arrived, not yet accepted or tagged; unknown shipments | Received / In stock – quarantine | Restricted |
| Available | Tagged, ready or awaiting build | In stock – available | Restricted |
| Build / rework | On the imaging bench | In stock – pending install / rework | Restricted |
| Configured / kitted | Built and reserved to a request | Configured/Ready – reserved | Restricted |
| Defective / RMA | Awaiting repair or vendor return | In stock – defective / pending repair | Restricted |
| Returned / pending rebuild | Recovered from users | In stock – returned | Restricted |
| Pending disposal | Awaiting sanitization or ITAD pickup | In stock / Retired – pending disposal | **High**: separate locked cage, named access, custody log (`itam-secure-disposition`) |
| Consumables | Quantity-tracked items | Quantity on hand | Standard |

Bin/location codes: [FILL — e.g., SITE-ZONE-RACK-SHELF]. Every individually tracked asset in a stockroom has a bin on its record.

## 2. Physical and access controls

- Access restricted to named roles [FILL]; badge or key log reviewed [FILL frequency].
- Visitors and couriers escorted; no unattended dock.
- CCTV where policy and law allow [VERIFY with security/legal].
- Segregation of duties: people who can adjust records are not the only people who count, and requesters don't fulfil their own requests.
- Moves between zones update the record at the time of the move, not at the end of the day.
- Data-bearing devices awaiting disposal are never stored with available stock.

## 3. Tracking tiers for peripherals and consumables

Decide per item class. Thresholds are the organization's; leave `[FILL]` if unknown. CAMP notes that inexpensive non-managed items are often over-ordered and that tagging makes them easy to track (CAMP M:92).

| Tier | Tracked how | Criteria (any one is enough) | Examples to classify [FILL] |
|---|---|---|---|
| 1 — Individually tracked | Serial + asset tag, full lifecycle record | Can store data; unit cost ≥ [FILL]; theft-attractive; under warranty worth claiming; needed for compliance | Laptops, desktops, phones, tablets, external storage [decide], high-end monitors [decide] |
| 2 — Quantity tracked | Count by SKU and location; min/max reorder | Below tier 1 threshold but issued in volume or worth controlling | Docks [decide], headsets, keyboards, mice, cables, adapters |
| 3 — Expensed, untracked | No record; budget only | Low cost, consumed | Batteries (non-lithium packs), cleaning supplies |

Rule (PRACTICE): anything that can store organizational data is tier 1 regardless of cost, because its disposal needs evidence.

Min/max for tier 2: min = [FILL] (lead time × usage rate + safety stock), max = [FILL]. Record usage rate from issue data, not estimates. Forecasting future stock levels, stockroom space or staffing for expected demand belongs to `itam-capacity-planning`; this file only sets reorder points from current usage.

## 4. Count types and frequency

| Count type | When | Scope |
|---|---|---|
| Full (wall-to-wall) | [FILL — e.g., annually or before audit/year end] | Everything in every zone |
| Cycle count | [FILL] | A rotating subset so every location is covered within [FILL] |
| Risk-weighted (ABC) | A: high value / data-bearing → [FILL frequency]; B → [FILL]; C → [FILL] | By item class or zone |
| Trigger count | After a variance, a theft report, staff change, system migration, or before handing a stockroom to a new owner | Affected zone/SKU |
| Pending-disposal count | Before every ITAD pickup | Pending disposal cage |

## 5. Count procedure

| # | Step | Note |
|---|---|---|
| 1 | Schedule; generate count sheet by location from the system (tier 1: serial list; tier 2: SKU list) | **Blind count recommended:** counters see locations, not expected quantities or serials |
| 2 | Freeze movements in the counted zone, or record a cutoff time and log in-flight moves | Prevents false variances |
| 3 | Count: scan every tag in every bin; tier 2 counted by SKU | Scan, don't type |
| 4 | Record items found that aren't on the sheet (unknown tags, untagged devices) | Never discard |
| 5 | Compare count with record (by serial for tier 1, by quantity for tier 2) | Data matching at scale: `itam-inventory-reconciliation` |
| 6 | Recount variances by a different person | Confirms the variance before investigation |
| 7 | Investigate (section 6) | — |
| 8 | Approve and post adjustments; release freeze | Approver independent of counter |
| 9 | Report accuracy and variance causes | `logistics-metrics.md` |

## 6. Variance tolerance, investigation and adjustment

Tolerance: tier 1 — [FILL; many organizations use zero tolerance for data-bearing devices]; tier 2 — [FILL].

Common causes to check (PRACTICE), in roughly this order:
1. Timing: movement after cutoff, or record updated late.
2. Wrong bin or zone: asset is elsewhere in the building.
3. Status error: record says In stock but the device was deployed, shipped or sent for RMA without an update.
4. Tag error: duplicate, missing or swapped tags; serial typed wrong at receipt.
5. Unrecorded receipt: device present, no record (often vendor direct deliveries).
6. Loss or theft.

| Outcome | Action | Approval |
|---|---|---|
| Located elsewhere | Correct location; note cause | Stockroom lead |
| Status error found | Correct state with evidence (shipment, ticket) | Stockroom lead |
| Unrecorded asset found | Receive formally (`receiving-sop.md`) | ITAM manager |
| Not found after investigation | Mark missing per lifecycle model; security notified if data-bearing; write-off via finance | [FILL — ITAM manager + finance]; security for data-bearing |

Never adjust the record to match the count without an investigation note (SKILL rule 8).

## 7. Records and evidence

| Record | Stored in | Retention |
|---|---|---|
| Count sheet / scan file with counter, time, zone | [FILL] | [FILL — never infer] |
| Variance and investigation notes | [FILL] | [FILL] |
| Adjustment approvals | [FILL] | [FILL] |
| Access logs | [FILL] | [FILL] |
