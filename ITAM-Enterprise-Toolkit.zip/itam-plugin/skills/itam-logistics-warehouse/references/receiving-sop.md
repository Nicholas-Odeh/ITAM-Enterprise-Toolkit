# Receiving, inspection and tagging (SOP template)

Procedure content is `PRACTICE` except where a CAMP citation is given. Values in `[FILL]` belong to the organization. For a fully controlled SOP document (document control block, approval record, revision history), pass this to `itam-sop-documentation`.

## Contents
1. Purpose and scope
2. Roles
3. Prerequisites and inputs
4. Procedure
5. Decision rules and exceptions
6. Tagging standard
7. Record fields at receipt
8. Records and evidence
9. Measures

## 1. Purpose and scope

Make every IT asset that arrives at [FILL — sites/depots] identified, inspected, tagged, recorded and stored in a known location before anyone can deploy it. Scope: [FILL — asset classes tracked individually; see tracking tiers in `cycle-count-procedure.md`]. Out of scope: [FILL — e.g., consumables received by facilities].

CAMP frames asset identification as uniquely identifying and validating the physical presence of assets, with components including generating unique tags, asset acceptance, receiving notification, order reconciliation, inventory management, RMA and rejections (CAMP M:38; CAMP S:74). Receiving and acceptance, physical inventory and asset tagging are named asset identification functions (CAMP S:76).

## 2. Roles

| Role (CAMP name where one exists) | Responsibility | Org role [FILL] |
|---|---|---|
| Receiver | Inspects packages for damage; rejects damaged shipments or starts acceptance; notifies the right parties (CAMP M:115) | [FILL] |
| Asset identification personnel | Accept assets, assign the unique identifier, tag, record in the ITAM repository and, where applicable, the fixed-asset list (CAMP M:111–112) | [FILL] |
| Acquisition / procurement | Owns the PO; confirms that receiving and RMA processes exist (CAMP M:111) | [FILL] |
| Finance / accounts payable | Uses receipt confirmation for invoice matching and capitalization | [FILL] |
| ITAM manager | Owns the standard, exceptions and metrics | [FILL] |

Segregation of duties (PRACTICE): the person who orders should not be the only person who confirms receipt.

## 3. Prerequisites and inputs

- Open PO or approved order [FILL — system].
- Advance ship notice (ASN) or serial list from the vendor, where the contract requires it [VERIFY contract].
- Tag stock and printer/scanner available.
- Access to the asset system to create or update records.

## 4. Procedure

| # | Step | Who | System action | Evidence |
|---|---|---|---|---|
| 1 | Accept delivery from carrier; count packages against the delivery note; note visible damage on the carrier's document before signing | Receiver | — | Signed delivery note with damage notation |
| 2 | Move to the receiving/quarantine zone; never straight to available stock | Receiver | Location = receiving | — |
| 3 | Match to PO/ASN: vendor, model, quantity | Receiver | Find PO | Match result |
| 4 | Open and inspect: physical damage, correct model/configuration, seals intact, accessories present | Receiver | — | Inspection note; photos of damage |
| 5 | Decide accept, partial accept or reject (section 5) | Receiver | — | Decision recorded |
| 6 | Capture serial numbers by scan (not typing) and compare with the ASN serial list | Asset ID personnel | — | Serial capture file |
| 7 | Apply the asset tag per the tagging standard (section 6); verify vendor-applied tags if pre-tagged | Asset ID personnel | — | — |
| 8 | Create or update the asset record (section 7) | Asset ID personnel | State: In stock (or canonical "Received"); substate per mapping [FILL] | Asset record |
| 9 | Confirm receipt in procurement so invoice matching can proceed | Receiver | PO receipt | Receipt transaction |
| 10 | Put away to the zone and bin matching the record's status; record the bin | Asset ID personnel | Stockroom + bin | Location on record |
| 11 | Notify the requester, build bench (`endpoint-imaging-provisioning`) and finance where applicable (CAMP M:112, M:115) | Receiver | Notification | Notification log |

Target times for each step are `[FILL]`; receiving-to-inventory time is measured in `logistics-metrics.md`.

## 5. Decision rules and exceptions

| Condition | Action | Notify |
|---|---|---|
| Outer packaging damaged | Note on carrier document before signing; photograph; inspect contents immediately | Procurement; carrier claim per contract [VERIFY claim window] |
| Contents damaged or dead on arrival | Reject or quarantine; start vendor RMA (CAMP M:111) | Procurement, vendor |
| Wrong model or configuration | Quarantine; do not tag as a standard asset until procurement decides | Procurement |
| Quantity short or over | Receive what arrived; record discrepancy against PO | Procurement, AP |
| No PO / unknown shipment | Quarantine; do not tag until an owner is identified | ITAM manager |
| Serial missing or unreadable | Record the exception; do not invent an identifier; obtain the serial from the vendor | Vendor |
| Serial doesn't match ASN | Record the asset as received with the actual serial; flag the ASN mismatch | Procurement, vendor |
| Vendor pre-tag wrong, duplicated or missing | Re-tag per standard; log for vendor scorecard (CAMP M:22) | Vendor management |
| Device arrives already enrolled to another organization's management | Quarantine; contact the vendor; do not wipe without approval | Vendor, EUC |
| Swollen or damaged battery visible | Isolate in the designated safe area; do not ship by air; follow the hazardous-material procedure [FILL] | Facilities/EHS, vendor |

## 6. Tagging standard

| Element | Standard |
|---|---|
| Identifier format | [FILL — e.g., prefix + sequential number]; unique; carries no meaning outside the organization (CAMP M:38); never reused |
| Symbology | [FILL — e.g., Code 128 barcode and/or QR code; RFID only if readers are deployed]. QR codes let anyone with a phone reach the record (CAMP M:92) |
| Human-readable text | Identifier printed under the code; optional organization name and service desk contact |
| Material | [FILL — e.g., polyester/foil, tamper-evident where theft risk warrants]; must survive cleaning |
| Placement — laptop | [FILL — e.g., underside, consistent corner]; not on battery doors, vents, removable panels or rubber feet |
| Placement — desktop / monitor / dock | [FILL — e.g., rear or side visible when installed] |
| Placement — phone / tablet | [FILL — many organizations record IMEI/serial instead of tagging the device body; decide and document] |
| Placement — network / data center | [FILL — e.g., front bezel and rear] |
| Who applies | Receiving, or vendor pre-tagging per contract with accuracy checks |
| Replacement | Damaged tags are replaced with the same identifier from a reprint; log the reprint |
| Linking to documents | The identifier is the key that links contracts, warranties and certificates to the asset (CAMP M:39); see `sharepoint-itam-records` |

## 7. Record fields at receipt

Minimum (align names with the canonical `asset-data-model.md` if present): asset tag, serial number, manufacturer, model, asset class/category, PO number, vendor, received date/time, received by, receiving site, stockroom and bin, state/substate, cost (or link to PO line), warranty start/end if known, ASN reference, condition notes. Capture-only-once rule (PRACTICE): every field is captured by scan or import, never retyped downstream.

## 8. Records and evidence

| Record | Created by | Stored in | Retention |
|---|---|---|---|
| Signed delivery note, damage photos | Receiver | [FILL] | [FILL — never infer] |
| Serial capture / ASN comparison | Asset ID personnel | [FILL] | [FILL] |
| Asset record and history | Asset ID personnel | ITAM system [FILL] | [FILL] |
| PO receipt transaction | Receiver | Procurement system | [FILL] |
| Rejection / RMA record | Receiver | [FILL] | [FILL] |

## 9. Measures

Receiving-to-inventory (staging) time, received-vs-placed-into-inventory timestamps, RMA counts by vendor and asset type, and vendor pre-delivery accuracy are CAMP asset identification indicators (CAMP M:22; CAMP S:75). Definitions and formulas are in `logistics-metrics.md`.
