---
name: itam-capacity-planning
description: Use when asking whether ITAM operations can absorb planned work: spare pools and stock for hires, refresh waves and break/fix, stockroom space, imaging bench throughput, technician staffing, shipping volume, reclamation backlog or stock budget, or when the team feels overallocated, workload or utilization is too high, or stockouts, bench queues or overtime appear. Covers demand forecasts, safety stock, utilization targets and scenarios. Not for refresh eligibility or cost forecasts (use itam-hardware-lifecycle or itam-financial-management) or build standards (use endpoint-imaging-provisioning).
---

# ITAM Capacity Planning

Capacity planning answers "will the work fit?" for ITAM operations: stock, imaging bench, people, logistics, backlog and budget. Plan from measured rates and stated demand, size for the peak period, and never plan to 100% utilization. Adapted from the Operations capacity-plan method, for asset managers, stockroom, logistics and end-user computing leads.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Measured rates beat rated rates.** Throughput, touch times and lead times come from the user's records; anything else is `ASSUMPTION`, shown as a range.
7. **Never plan to 100%.** Use the organization's utilization targets, or the `PRACTICE` targets in `references/capacity-model.md` §9.
8. **Calculate with the script.** Run `python3 scripts/capacity_calc.py` and show formula and inputs for every figure.

## When to use

- Quarterly or annual operations planning; sizing a refresh wave, hiring surge or site opening.
- Stockouts, aged stock, bench queues, overtime, or a reclamation backlog that keeps growing.
- "Can we absorb X?", "how many technicians or stations?", "what should our reorder point be?"

**When not to use:** refresh eligibility and volumes (`itam-hardware-lifecycle`); costs, TCO and budget models (`itam-financial-management`); build standards or bench troubleshooting (`endpoint-imaging-provisioning`); stockroom procedures (`itam-logistics-warehouse`); workbook construction (`itam-spreadsheet-models`).

## Workflow

### Step 1: Classify

| Question | Section of `references/capacity-model.md` | Script subcommand |
|---|---|---|
| Stock, spare pool, reorder points, space | §2, §3 | `demand`, `safety-stock` |
| Imaging bench throughput | §4 | `bench` |
| Technician or staff utilization | §5 | `staff` |
| Logistics volume | §6 | `staff`, `bench` form |
| Reclamation or disposal backlog | §7 | `backlog` |
| Budget | §8 | — |
| Options and what-ifs | `references/scenarios-template.md` | any |

### Step 2: Preflight

Read `templates/company-profile.md` if present. Establish horizon and period grain; demand drivers (hiring plan, refresh waves, break/fix rate, returns); stock on hand and on order; observed lead times; measured bench rates and touch times; roster and availability; constraints (budget, space, freeze). Ask once for the largest missing driver, usually the hiring plan or wave dates.

### Step 3: Model

1. Forecast demand per period and model family; find the peak.
2. Set safety stock and reorder point per model.
3. Compute bench, staff, logistics and backlog capacity against that demand.
4. Name the bottleneck: the dimension with the highest peak utilization.
5. Run scenarios: always do-nothing, plus realistic levers, with a sensitivity check on the least certain inputs.

### Step 4: Verify before release

- ★ Every rate cites its source and period, or is labeled `ASSUMPTION` with a range.
- ★ Every figure shows formula and inputs, and comes from the script or is shown worked.
- ★ Availability removes leave, holidays, training and meetings; nothing is planned above target without saying so.
- ★ Demand includes hires, refresh, break/fix, returns and projects, or states each exclusion.
- ★ The peak period is checked, not only totals.
- Scenarios include do-nothing; each recommendation has owner, cost, lead time and start-by date.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "Our bench does 40 a day" | Measured when, on which models, counting rework? Use M-OPS-03 data. |
| "The annual total fits" | Capacity fails in the peak week. |
| "Plan everyone at 100%" | Break/fix and absence will consume the missing buffer. |
| "Returns will cover demand" | Returns need triage, wipe and rebuild. Apply yield and delay. |
| "Lead time is two weeks" | Contracted or observed? Use the observed spread. |

Stop if you are about to: recommend hiring or buying from unlabeled assumed rates; omit safety stock; present an average as the plan.

## Common mistakes

| Mistake | Fix |
|---|---|
| Mean lead time only | Include its spread in safety stock. |
| All technicians treated as interchangeable | Check the skills matrix per platform. |
| Overstocking "to be safe" | Weigh stock aging and warranty (M-LC-09, M-LC-16). |
| Rebuilds of returns left off the bench plan | Add redeploy supply to bench builds. |
| Hire lead time ignored | Start actions by the date they must take effect. |

## If connectors are available

- `~~HR`: read hiring and leaver forecasts as counts only.
- `~~ITSM`: read request, incident and stock volumes with read times.
- `~~endpoint management`: read build and enrollment completions to measure throughput.
- `~~procurement`: read open orders and PO-to-receipt lead times.
- `~~finance`: read approved budget by period.
- `~~project tracker`: read refresh-wave schedules; `~~office suite`: draft the model workbook.

## Output format

1. Header (scope, horizon, grain, data as-of) and verdict: fits, fits below buffer, or does not fit; bottleneck and period.
2. Demand table by period.
3. Capacity by dimension: capacity, demand, utilization, target, gap.
4. Stock plan per model: on hand, safety stock, reorder point, order quantity.
5. Scenarios and sensitivity.
6. Recommendations (owner, cost, lead time, start-by date); assumptions and data notes.

## Reference files

- `references/capacity-model.md`: inputs, formulas, utilization targets, pitfalls and a hand-checked example; read for every plan.
- `references/scenarios-template.md`: scenario set, ITAM levers, sensitivity and recommendation format; read when there is a gap or a choice.
- `scripts/capacity_calc.py`: exact demand, safety-stock, bench, staff and backlog calculations; run `python3 scripts/capacity_calc.py --help`.
