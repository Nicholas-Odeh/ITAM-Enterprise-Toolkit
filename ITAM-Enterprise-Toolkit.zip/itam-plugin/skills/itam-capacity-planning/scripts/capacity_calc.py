#!/usr/bin/env python3
"""ITAM operations capacity calculator (Python 3.8+ standard library only).

Subcommands (formulas in references/capacity-model.md):
  demand        gross device demand per period, redeploy supply, net purchase need, bench builds
  safety-stock  safety stock and reorder point from demand and lead-time variability
  bench         imaging bench capacity vs. builds needed
  staff         workload hours vs. staff capacity, utilization and FTE needed at a target
  backlog       backlog trajectory and time to clear (reclamation, returns, disposal)

Every result echoes its inputs so the calculation can be checked. Add --json for
machine-readable output. Rates you did not measure are assumptions: say so in the plan.

Examples:
  python3 scripts/capacity_calc.py demand --hires 40 --refresh 120 --installed-base 5000 \
      --breakfix-rate-annual 0.03 --periods-per-year 12 --returns 60 --redeploy-yield 0.7
  python3 scripts/capacity_calc.py safety-stock --daily-demand 8 --daily-demand-sd 3 \
      --lead-time-days 10 --lead-time-sd 2 --service-level 0.95
  python3 scripts/capacity_calc.py bench --stations 6 --builds-per-station-day 8 \
      --availability 0.85 --working-days 20 --builds-needed 700
  python3 scripts/capacity_calc.py staff --task deploy:300:45 --task recover:200:30 \
      --fte 4 --hours-per-week 37.5 --weeks 4.33 --availability 0.8 --target-utilization 0.8
  python3 scripts/capacity_calc.py backlog --backlog 400 --inflow 150 --capacity 200 --periods 6
"""
import argparse
import json
import math
import sys
from statistics import NormalDist


def _check_fraction(name, value, allow_zero=True):
    low_ok = value >= 0 if allow_zero else value > 0
    if not (low_ok and value <= 1):
        raise SystemExit(f"error: --{name} must be a fraction between 0 and 1 (got {value})")


def _check_nonneg(name, value):
    if value < 0:
        raise SystemExit(f"error: --{name} must be >= 0 (got {value})")


def cmd_demand(a):
    for n in ("hires", "refresh", "installed_base", "other", "returns"):
        _check_nonneg(n.replace("_", "-"), getattr(a, n))
    _check_fraction("breakfix-rate-annual", a.breakfix_rate_annual)
    _check_fraction("redeploy-yield", a.redeploy_yield)
    _check_fraction("direct-ship-share", a.direct_ship_share)
    if a.periods_per_year <= 0:
        raise SystemExit("error: --periods-per-year must be > 0")
    breakfix = a.installed_base * a.breakfix_rate_annual / a.periods_per_year
    gross = a.hires + a.refresh + breakfix + a.other
    redeploy_supply = a.returns * a.redeploy_yield
    net_purchase = max(0.0, gross - redeploy_supply)
    # Redeployed devices are rebuilt at the bench; only new devices can ship direct.
    new_devices_used = net_purchase
    redeploy_used = min(redeploy_supply, gross)
    bench_builds = new_devices_used * (1 - a.direct_ship_share) + redeploy_used
    return {
        "inputs": vars_clean(a),
        "breakfix_replacements": round(breakfix, 2),
        "gross_demand": round(gross, 2),
        "redeploy_supply": round(redeploy_supply, 2),
        "net_purchase_need": round(net_purchase, 2),
        "bench_builds_needed": round(bench_builds, 2),
        "formula": "gross = hires + refresh + installed_base*breakfix_rate_annual/periods_per_year + other; "
                   "redeploy_supply = returns*redeploy_yield; net_purchase = max(0, gross - redeploy_supply); "
                   "bench_builds = net_purchase*(1-direct_ship_share) + min(redeploy_supply, gross)",
    }


def cmd_safety_stock(a):
    for n in ("daily_demand", "daily_demand_sd", "lead_time_days", "lead_time_sd"):
        _check_nonneg(n.replace("_", "-"), getattr(a, n))
    if not (0.5 <= a.service_level < 1):
        raise SystemExit("error: --service-level must be in [0.5, 1)")
    z = NormalDist().inv_cdf(a.service_level)
    sigma = math.sqrt(a.lead_time_days * a.daily_demand_sd ** 2
                      + (a.daily_demand ** 2) * a.lead_time_sd ** 2)
    ss = z * sigma
    lead_time_demand = a.daily_demand * a.lead_time_days
    rop = lead_time_demand + ss
    return {
        "inputs": vars_clean(a),
        "z": round(z, 4),
        "sigma_lead_time_demand": round(sigma, 2),
        "safety_stock": round(ss, 2),
        "safety_stock_units": math.ceil(ss - 1e-9),
        "lead_time_demand": round(lead_time_demand, 2),
        "reorder_point": round(rop, 2),
        "reorder_point_units": math.ceil(rop - 1e-9),
        "formula": "SS = z * sqrt(LT*sd_d^2 + d^2*sd_LT^2); ROP = d*LT + SS",
    }


def cmd_bench(a):
    _check_nonneg("stations", a.stations)
    _check_nonneg("builds-per-station-day", a.builds_per_station_day)
    _check_fraction("availability", a.availability)
    _check_fraction("first-pass-yield", a.first_pass_yield, allow_zero=False)
    _check_nonneg("working-days", a.working_days)
    _check_nonneg("builds-needed", a.builds_needed)
    raw = a.stations * a.builds_per_station_day * a.availability * a.working_days
    good = raw * a.first_pass_yield if a.rate_basis == "attempts" else raw
    daily_good = good / a.working_days if a.working_days else 0.0
    out = {
        "inputs": vars_clean(a),
        "capacity_builds": round(good, 2),
        "builds_needed": a.builds_needed,
        "utilization": round(a.builds_needed / good, 4) if good else None,
        "gap_builds": round(good - a.builds_needed, 2),
        "working_days_to_clear_demand": round(a.builds_needed / daily_good, 2) if daily_good else None,
        "formula": "capacity = stations * builds_per_station_day * availability * working_days"
                   + (" * first_pass_yield" if a.rate_basis == "attempts" else "")
                   + "; utilization = builds_needed / capacity",
    }
    if a.target_utilization:
        _check_fraction("target-utilization", a.target_utilization, allow_zero=False)
        per_station = a.builds_per_station_day * a.availability * a.working_days
        if a.rate_basis == "attempts":
            per_station *= a.first_pass_yield
        out["stations_needed_at_target"] = (
            math.ceil(a.builds_needed / (per_station * a.target_utilization) - 1e-9) if per_station else None)
    return out


def _parse_task(text):
    try:
        name, volume, minutes = text.split(":")
        volume, minutes = float(volume), float(minutes)
    except ValueError:
        raise SystemExit(f"error: --task must be name:volume:minutes_per_unit (got {text!r})")
    if volume < 0 or minutes < 0:
        raise SystemExit(f"error: negative value in --task {text!r}")
    return name, volume, minutes


def cmd_staff(a):
    _check_fraction("availability", a.availability)
    _check_fraction("target-utilization", a.target_utilization, allow_zero=False)
    for n in ("fte", "hours_per_week", "weeks"):
        _check_nonneg(n.replace("_", "-"), getattr(a, n))
    tasks = [_parse_task(t) for t in a.task]
    lines = [{"task": n, "volume": v, "minutes_per_unit": m, "hours": round(v * m / 60, 2)}
             for n, v, m in tasks]
    workload = sum(v * m / 60 for _, v, m in tasks)
    per_fte = a.hours_per_week * a.weeks * a.availability
    capacity = a.fte * per_fte
    return {
        "inputs": vars_clean(a),
        "tasks": lines,
        "workload_hours": round(workload, 2),
        "available_hours_per_fte": round(per_fte, 2),
        "capacity_hours": round(capacity, 2),
        "utilization": round(workload / capacity, 4) if capacity else None,
        "fte_needed_at_target": round(workload / (per_fte * a.target_utilization), 2) if per_fte else None,
        "formula": "workload = sum(volume*minutes)/60; per_fte = hours_per_week*weeks*availability; "
                   "utilization = workload/(fte*per_fte); fte_needed = workload/(per_fte*target_utilization)",
    }


def cmd_backlog(a):
    for n in ("backlog", "inflow", "capacity"):
        _check_nonneg(n, getattr(a, n))
    if a.periods < 1:
        raise SystemExit("error: --periods must be >= 1")
    rows, b = [], float(a.backlog)
    for p in range(1, a.periods + 1):
        start = b
        b = max(0.0, b + a.inflow - a.capacity)
        rows.append({"period": p, "start": round(start, 2), "inflow": a.inflow,
                     "processed": round(min(start + a.inflow, a.capacity), 2), "end": round(b, 2)})
    net = a.capacity - a.inflow
    return {
        "inputs": vars_clean(a),
        "trajectory": rows,
        "net_burn_per_period": net,
        "periods_to_clear": (round(a.backlog / net, 2) if net > 0 else None),
        "note": None if net > 0 else "capacity <= inflow: backlog never clears at these rates",
        "formula": "end = max(0, start + inflow - capacity); periods_to_clear = backlog/(capacity - inflow)",
    }


def vars_clean(a):
    return {k: v for k, v in vars(a).items() if k not in ("func", "json", "cmd")}


def _print(result, as_json):
    if as_json:
        print(json.dumps(result, indent=2))
        return
    for k, v in result.items():
        if k == "inputs":
            print("inputs: " + ", ".join(f"{ik}={iv}" for ik, iv in v.items()))
        elif isinstance(v, list):
            print(f"{k}:")
            for row in v:
                print("  " + ", ".join(f"{rk}={rv}" for rk, rv in row.items()))
        elif v is not None:
            print(f"{k}: {v}")


def build_parser():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0],
                                epilog="Formulas: references/capacity-model.md")
    sub = p.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("demand", help="device demand per period and bench builds")
    d.add_argument("--hires", type=float, default=0, help="joiners needing a device in the period")
    d.add_argument("--refresh", type=float, default=0, help="refresh units scheduled in the period")
    d.add_argument("--installed-base", type=float, default=0, help="in-use devices exposed to break/fix")
    d.add_argument("--breakfix-rate-annual", type=float, default=0, help="annual replacement rate, fraction")
    d.add_argument("--periods-per-year", type=float, default=12, help="12 for months, 52 for weeks")
    d.add_argument("--other", type=float, default=0, help="other demand (projects, loaners)")
    d.add_argument("--returns", type=float, default=0, help="devices returned in time to reuse")
    d.add_argument("--redeploy-yield", type=float, default=0, help="share of returns redeployable")
    d.add_argument("--direct-ship-share", type=float, default=0,
                   help="share of new devices shipped direct (no bench touch)")
    d.set_defaults(func=cmd_demand)

    s = sub.add_parser("safety-stock", help="safety stock and reorder point")
    s.add_argument("--daily-demand", type=float, required=True, help="mean units per day")
    s.add_argument("--daily-demand-sd", type=float, required=True, help="standard deviation of daily demand")
    s.add_argument("--lead-time-days", type=float, required=True, help="mean replenishment lead time")
    s.add_argument("--lead-time-sd", type=float, default=0, help="standard deviation of lead time, days")
    s.add_argument("--service-level", type=float, default=0.95, help="cycle service level, e.g. 0.95")
    s.set_defaults(func=cmd_safety_stock)

    b = sub.add_parser("bench", help="imaging bench capacity")
    b.add_argument("--stations", type=float, required=True)
    b.add_argument("--builds-per-station-day", type=float, required=True, help="measured rate")
    b.add_argument("--availability", type=float, required=True, help="share of station-days usable")
    b.add_argument("--working-days", type=float, required=True)
    b.add_argument("--builds-needed", type=float, default=0)
    b.add_argument("--rate-basis", choices=["passes", "attempts"], default="passes",
                   help="'passes' if the rate counts validated builds (M-OPS-03); 'attempts' to apply yield")
    b.add_argument("--first-pass-yield", type=float, default=1.0, help="used only with --rate-basis attempts")
    b.add_argument("--target-utilization", type=float, default=None)
    b.set_defaults(func=cmd_bench)

    t = sub.add_parser("staff", help="staff workload and utilization")
    t.add_argument("--task", action="append", required=True, help="name:volume:minutes_per_unit (repeat)")
    t.add_argument("--fte", type=float, required=True)
    t.add_argument("--hours-per-week", type=float, required=True)
    t.add_argument("--weeks", type=float, required=True, help="weeks in the period (4.33 for a month)")
    t.add_argument("--availability", type=float, required=True, help="net of leave, holidays, training")
    t.add_argument("--target-utilization", type=float, default=0.8)
    t.set_defaults(func=cmd_staff)

    k = sub.add_parser("backlog", help="backlog trajectory")
    k.add_argument("--backlog", type=float, required=True)
    k.add_argument("--inflow", type=float, required=True, help="new items per period")
    k.add_argument("--capacity", type=float, required=True, help="items processed per period")
    k.add_argument("--periods", type=int, default=6)
    k.set_defaults(func=cmd_backlog)

    for sp in (d, s, b, t, k):
        sp.add_argument("--json", action="store_true", help="print JSON")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    _print(args.func(args), args.json)
    return 0


if __name__ == "__main__":
    sys.exit(main())
