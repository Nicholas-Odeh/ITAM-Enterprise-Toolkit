# ITAM operations capacity model

Formulas and inputs for planning ITAM operations capacity: device demand, stock levels, imaging bench, staff, logistics, reclamation backlog and budget. `python3 scripts/capacity_calc.py` implements §2–§7 exactly; use it rather than mental arithmetic, and paste its output (inputs included) into the plan.

**Basis:** the planning dimensions (people, budget, time), the utilization targets and the pitfalls adapt the Operations plugin's `capacity-plan` skill. The safety-stock and reorder-point formulas are standard inventory-management practice (`PRACTICE`; they assume demand and lead time vary independently and roughly normally). ServiceNow stock-rule behavior is `DOC` (ServiceNowDocs brazil, `markdown/it-asset-management/asset-management/c_StockRules.md`, as checked 2026-10-20). Metric IDs refer to `itam-data-analysis-reporting/references/metrics-catalog.md`. Every organizational value is `[FILL]`.

## Contents
1. Inputs and where they come from
2. Demand forecast
3. Safety stock and reorder point
4. Imaging bench capacity
5. Staff capacity and utilization
6. Logistics volume
7. Reclamation and disposal backlog
8. Budget
9. Utilization targets (`PRACTICE`)
10. Pitfalls
11. Worked example (hand-checked)

## 1. Inputs and where they come from

| Input | Best source | Measure as | Fallback (label `ASSUMPTION`, give a range) |
|---|---|---|---|
| Hires per period | HR hiring plan (`~~HR`), counts only | Per month, per site | Last 12 months' joiners, seasonally split |
| Refresh units | Refresh schedule (`itam-hardware-lifecycle`, refresh-forecast command) | Per wave, per model | Eligible population ÷ planned quarters |
| Break/fix replacement rate | Incident and RMA history (`~~ITSM`) | Replacements ÷ average in-use base, annualized | M-LC-13 by model |
| Returns and redeploy yield | ITAM history | Returns per period; share triaged redeployable (M-LC-10) | — |
| Lead time (mean and spread) | PO-to-receipt history (`~~procurement`) | Days, mean and standard deviation, or P90 | Contracted lead time, marked as such |
| Bench rate | Imaging logs (M-OPS-03, M-OPS-04, M-OPS-05) | Validated builds per station per day, by model | Pilot measurement over ≥ `[FILL]` days |
| Touch times | Time study or ticket timestamps | Minutes per unit per task | Sampled from a week of work |
| Availability | Roster, leave calendar, training plan | Share of paid hours available | 0.80–0.85 (`ASSUMPTION`) |

A rate measured on one model or one technician doesn't transfer to another; record what it was measured on.

## 2. Demand forecast

Per period (week or month), per model family and site where it matters:

```
break/fix replacements = installed_base × annual_replacement_rate ÷ periods_per_year
gross demand            = hires + refresh units + break/fix replacements + other (projects, loaners)
redeploy supply         = returns × redeploy_yield            (only returns ready in time)
net purchase need       = max(0, gross demand − redeploy supply)
bench builds needed     = net purchase need × (1 − direct_ship_share) + redeploy supply used
```

- Plan the **peak period**, not the annual total. Hiring and refresh cluster (fiscal-year starts, graduate intakes, project go-lives).
- Redeployed devices still need triage, wipe and rebuild (`itam-secure-disposition` for sanitization evidence, `endpoint-imaging-provisioning` for rebuild), so they consume bench capacity.
- Direct-ship (for example vendor-registered Autopilot or ADE devices) skips the bench but not receiving and recording; check `endpoint-imaging-provisioning` for which devices qualify.

## 3. Safety stock and reorder point

```
safety stock (SS) = z × √( LT × σd² + d² × σLT² )
reorder point     = d × LT + SS
```

- `d`: mean daily demand; `σd`: its standard deviation; `LT`: mean lead time in days; `σLT`: its standard deviation; `z`: the normal quantile for the chosen cycle service level (0.90 → 1.28, 0.95 → 1.64, 0.98 → 2.05).
- If lead time is fixed (σLT = 0), SS = z × σd × √LT.
- Heuristic when only extremes are known (`PRACTICE`): SS ≈ (max daily demand × max lead time) − (d × LT). It tends to overstate stock; say which method was used.
- The service level is an organizational choice `[FILL]`, trading stockout risk against stock aging (M-LC-09) and cash.
- Order quantity is a separate choice (pack size, price breaks, storage space, budget). Target stock after a delivery ≈ SS + order quantity.
- **Spare (break/fix and loaner) pools** are sized the same way, with break/fix replacements and loans out as the demand and repair or replacement turnaround (M-LC-14) as the lead time.
- **Stockroom space** at peak ≈ (SS + order quantity + devices awaiting triage, build or disposal) × footprint per unit `[FILL]`, checked per stockroom against usable space `[FILL]`. Refresh waves add the returned devices on top of the new ones.

**ServiceNow (DOC):** stock rules define a threshold per model and stockroom; when stock reaches it, the daily Stock Rule Runner job creates a task, a transfer order from another stockroom, or a purchase order or catalog request, depending on rule type and installed plugins (`asset-management/c_StockRules.md`). The reorder point above is a candidate value for that threshold; confirm the rule configuration with `servicenow-itam`.

## 4. Imaging bench capacity

```
bench capacity (builds/period) = stations × builds per station per day × availability × working days
                                 [× first-pass yield, only if the rate counts attempts]
utilization                    = builds needed ÷ bench capacity
stations needed at target      = ⌈ builds needed ÷ (builds per station per day × availability × working days × target utilization) ⌉
```

- `availability`: share of station-days usable after maintenance, image updates, network outages and technician absence `[FILL]`.
- M-OPS-03 counts devices **passing validation** per bench-day, so first-pass yield (M-OPS-04) is already inside it; apply yield separately only when the rate counts attempts.
- The bench constraint is often people, not stations: check §5 with the same volumes.
- Network and content distribution (PXE, caching, bandwidth) can cap concurrent builds; record any limit the imaging team states.

## 5. Staff capacity and utilization

```
workload hours            = Σ (volume of task × minutes per unit) ÷ 60
available hours per FTE   = contracted hours per week × weeks in period × availability
capacity hours            = FTE × available hours per FTE
utilization               = workload hours ÷ capacity hours
FTE needed at target      = workload hours ÷ (available hours per FTE × target utilization)
```

- `availability` removes leave, public holidays, sickness, training and fixed meetings `[FILL]`.
- Typical ITAM tasks: receive and tag, build, deploy and hand over, IMAC/move, recover and triage, wipe and prepare for disposal, cycle count, record corrections, shipping and kitting.
- Check skills, not just hours: a technician who can't image Macs doesn't add Mac capacity. Keep a simple skills matrix.
- Hiring and contractor onboarding take time `[FILL lead time]`; a gap next month can't be closed by a hire started next month.

## 6. Logistics volume

```
outbound shipments = deployments shipped + loaners shipped + replacements shipped
inbound shipments  = return kits expected back × return-kit return rate (M-OPS-07)
packing capacity   = packing stations × packs per station per day × availability × working days
```

- Use §5 for packing staff hours; use §4's form for packing-station capacity.
- Carrier pickup slots, cut-off times and international paperwork are constraints to record, not compute (`itam-logistics-warehouse`).
- Watch in-transit dwell (M-OPS-11) and loss and damage (M-OPS-08) as volume rises.

## 7. Reclamation and disposal backlog

```
backlog(t+1)     = max(0, backlog(t) + inflow − processing capacity)
periods to clear = backlog ÷ (processing capacity − inflow)     (only if capacity > inflow)
```

- Inflow: leaver returns, refresh returns, break/fix returns, stockroom clear-outs.
- Processing: triage, sanitization, rebuild or disposal preparation, each with its own capacity; the smallest is the constraint.
- If capacity ≤ inflow the backlog never clears; say so plainly.
- Backlog ages devices out of redeployable condition and holds data-bearing devices longer, which is a security exposure (M-DIS-07, M-LC-09).

## 8. Budget

```
stock purchase spend (period) = net purchase need × unit price + safety-stock build-up × unit price
staff cost                    = FTE (or contractor hours) × loaded rate [FILL]
logistics cost                = shipments × cost per shipment (M-OPS-10)
```

Compare with the approved budget by period. Unit prices, loaded rates and capitalization come from `itam-financial-management` and `templates/company-profile.md`; never invent them.

## 9. Utilization targets (`PRACTICE`)

Adapted from the Operations `capacity-plan` skill. Use the organization's targets if set.

| Role type in ITAM operations | Target utilization | Why |
|---|---|---|
| Bench, stockroom or logistics technician (planned work) | 75–80% | Room for rework, urgent requests and improvement work |
| Team lead or asset manager | 60–70% | Coordination, approvals, escalations, reporting |
| Walk-up, break/fix or on-call support | 50–60% | Interrupt-driven work is unpredictable |
| Imaging stations | `[FILL]` | Image updates, model onboarding and outages need slack |

## 10. Pitfalls

From the Operations `capacity-plan` skill, adapted:
- Planning to 100% utilization, leaving no buffer for surprises.
- Ignoring meetings, context switching and travel between sites.
- Forgetting leave, holidays, sickness and training.
- Treating all hours as equal (a Mac build is not a monitor swap).

ITAM-specific:
- Planning totals instead of the peak week (start-date clusters, refresh go-lives).
- Counting returned devices as supply without triage, wipe and rebuild time.
- Using contracted lead time instead of observed lead time and its spread.
- Ignoring stock aging: too much safety stock ages out of warranty or refresh eligibility (M-LC-09, M-LC-16).

## 11. Worked example (hand-checked)

Illustrative inputs, not benchmarks. Each line was computed by hand and matches `scripts/capacity_calc.py`.

| Calculation | Inputs | Hand calculation | Result |
|---|---|---|---|
| Demand (month) | hires 40, refresh 120, base 5,000 at 3%/yr, returns 60 at 70% yield | 5,000 × 0.03 ÷ 12 = 12.5; 40 + 120 + 12.5 = 172.5; 60 × 0.7 = 42; 172.5 − 42 = 130.5 | gross 172.5; buy 130.5; bench builds 172.5 |
| Safety stock | d 8/day, σd 3, LT 10 days, σLT 2, 95% | √(10 × 9 + 64 × 4) = √346 = 18.60; 1.645 × 18.60 = 30.6; 8 × 10 + 30.6 = 110.6 | SS 31 units; ROP 111 units |
| Bench | 6 stations × 8 builds/day × 0.85 × 20 days; need 700 | 6 × 8 × 0.85 × 20 = 816; 700 ÷ 816 = 85.8%; at 80%: 700 ÷ (8 × 0.85 × 20 × 0.8) = 6.43 → 7 | capacity 816; utilization 85.8%; 7 stations at 80% |
| Staff (month) | deploy 300 × 45 min, recover 200 × 30 min; 4 FTE × 37.5 h × 4.33 wk × 0.8 | 225 + 100 = 325 h; 37.5 × 4.33 × 0.8 = 129.9 h/FTE; 4 × 129.9 = 519.6; 325 ÷ 519.6 = 62.5%; 325 ÷ (129.9 × 0.8) = 3.13 | utilization 62.5%; 3.13 FTE needed at 80% |
| Backlog | 400 open, inflow 150/month, capacity 200/month | net burn 50/month; 400 ÷ 50 = 8 | clears in 8 months; 100 left after 6 |

Reading the example: the bench runs above the 75–80% target (85.8%), so it is the bottleneck, while staff sit at 62.5%. The cheapest fix may be a seventh station or a second shift rather than a hire; the scenario table decides.
