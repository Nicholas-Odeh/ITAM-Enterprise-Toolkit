# Capacity scenarios template

Use this to compare options once the base case (`capacity-model.md`) shows a gap or a risk. Every scenario changes named inputs and is recalculated with `python3 scripts/capacity_calc.py`; nothing is estimated by eye.

**Basis:** the scenario set (do nothing, hire, deprioritize) adapts the Operations plugin's `capacity-plan` skill; the ITAM levers and the template are `PRACTICE`. Costs and lead times are organizational `[FILL]`; take them from `itam-financial-management`, procurement and HR.

## Contents
1. Standard scenarios
2. ITAM levers
3. Scenario table template
4. Sensitivity check
5. Recommendation format

## 1. Standard scenarios

Always include the first; add the others that are realistic for the organization.

| # | Scenario | What it changes |
|---|---|---|
| S0 | Do nothing (base case) | Current capacity against forecast demand. Shows when and where the gap bites. |
| S1 | Add capacity | Stations, shifts, staff, contractors or vendor services. |
| S2 | Reduce or move demand | Defer or re-phase a refresh wave, stagger start dates, prioritize by business impact. |
| S3 | Change the method | Direct-ship provisioning, vendor pre-delivery services, redeploy more, automate record updates. |
| S4 | Stress case | Demand at the high end (hiring surge, model failure), or capacity at the low end (absence, supplier delay). |

## 2. ITAM levers

| Lever | Changes input | Lead time to effect | Typical cost driver | Watch-outs |
|---|---|---|---|---|
| Add imaging stations | stations | Hardware and network setup `[FILL]` | Equipment, space | Staff may become the constraint |
| Second shift or overtime | working days, availability | Days to weeks | Premium pay `[FILL]` | Fatigue raises rework (M-OPS-04) |
| Contractors | FTE | Onboarding `[FILL]` | Day rate `[FILL]` | Access, training, records quality |
| Vendor pre-delivery services (tagging, imaging, registration) | direct_ship_share, touch times | Contract change `[FILL]` | Per-unit fee | Verify accuracy (M-OPS-12) |
| Direct-ship provisioning | direct_ship_share | Depends on provisioning method | Licensing and setup | Receiving and recording still needed upstream |
| Raise redeploy yield | redeploy_yield | Process change | Triage and rebuild effort | Sanitization evidence before reuse |
| Increase safety stock | service level | One lead time | Cash, space, stock aging | M-LC-09, M-LC-16 |
| Re-phase refresh wave | refresh units per period | Change approval (`itam-change-request`) | Delay cost, extended warranty | Refresh compliance (M-LC-07) |
| Stagger start dates with HR | hires per period | HR agreement | None direct | Joiner on-time delivery (M-OPS-06) |

## 3. Scenario table template

```markdown
### Scenarios: [Scope] — [Horizon]
| Scenario | Inputs changed | Bottleneck utilization (peak period) | Stockout risk / service level | Backlog end of horizon | Cost [FILL basis] | Lead time to effect | Risks | Verdict |
|---|---|---|---|---|---|---|---|---|
| S0 Do nothing | — | [x% bench / y% staff in [period]] | [ROP vs. stock] | [n] | [0] | — | [What fails, when] | |
| S1 [Add …] | [stations 6→7] | | | | | | | |
| S2 [Defer …] | [refresh 120→80 in Mar] | | | | | | | |
| S4 Stress | [hires +30%] | | | | | | | |
```

Rules:
- Show the **peak** period for each scenario, not the average.
- State the inputs that differ from the base case, and the source or `ASSUMPTION` label for each.
- A scenario that relies on an unmeasured rate gets a range, recalculated at both ends.

## 4. Sensitivity check

For the two or three inputs that are least certain (usually bench rate, lead time and hiring volume), recalculate the recommended scenario at the low and high end of their plausible range. If the verdict flips within that range, say so and recommend measuring that input before committing spend.

| Input | Low | Base | High | Verdict at low | Verdict at high |
|---|---|---|---|---|---|

## 5. Recommendation format

1. **Verdict:** fits / fits with buffer below target / does not fit, and the bottleneck and period.
2. **Recommended scenario** and why, in two sentences.
3. **Actions:** each with owner, cost, lead time and the date by which it must start to be in time.
4. **Triggers to revisit:** the observed values (for example M-OPS-03 below `[n]` for two weeks, or hires above `[n]` in a month) that should reopen the plan.
5. **Assumptions** carried, each with how to replace it with a measurement.
