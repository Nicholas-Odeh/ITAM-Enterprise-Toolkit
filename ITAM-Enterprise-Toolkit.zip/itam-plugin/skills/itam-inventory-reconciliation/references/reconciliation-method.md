# Reconciliation: preflight, run sequence and output

Detail behind Steps 2, 3 and the output format of `itam-inventory-reconciliation`. Read it before any reconciliation whose numbers will be reported to someone else.

## Contents
1. Preflight checklist
2. Run sequence
3. Output: practitioner and executive

## 1. Preflight checklist

Confirm, or state as assumptions:
- **Sources and roles:** which extract is the system of record (repository) and which are discovery/MDM, physical count, finance, procurement or CMDB; each extract's as-of time.
- **Grain and scope** of each extract: one row per device? Which platforms, sites, asset classes, capitalized items only? Absence outside a source's scope is not an exception.
- **Column mapping** to canonical fields, especially serial, tag, hostname, user, state and last seen.
- **State values** in the repository and their canonical meaning (build `state_map`).
- **Rules:** the active window for discovery (days), which states and classes should be discoverable, which locations were counted, which classes need a CI.
- **Purpose:** clean-up work queue, KPI, audit evidence or a one-off question. Audit use needs the as-of date, population definition and retained extracts.

If the user hasn't supplied files, describe exactly which extracts and columns to pull. If one mapping choice changes results materially (for example, which user identifier to join on), ask; otherwise proceed and label assumptions.

## 2. Run sequence

1. **Profile identifiers** per extract with `python3 scripts/normalize_serials.py … --summary-json <file>`; report placeholder, duplicate and empty rates before matching (DataForge rule: inspect keys before joining).
2. **Write the config** (`python3 scripts/match_tiers.py --example-config`): sources with roles and column maps, `state_map`, `date_formats` for day-first sources, rules, `value_maps` for model names. Put the repository first.
3. **Run** `python3 scripts/match_tiers.py --config recon.json --out-dir <dir> --as-of <date>`. If it exits with code 2, fix the config error it names and rerun; don't work around it by hand.
4. **Check the run:** records in = records in `matches.csv` per source; unmapped states (ST-04) resolved; notes in `summary.json` about checks not evaluated.
5. **Triage exceptions** with `exception-codes.md`: sort by severity, then code volume (Pareto); resolve MT-01/MT-02 review items before trusting presence counts that depend on them.
6. **Root cause** the top recurring codes (symptom → contributing factor → root cause → corrective action) and assign owners as roles.
7. **Quantify** with formulas: records per source, matched by tier, unmatched, duplicates, exceptions by code and severity, reconciliation match rate, coverage per source. Inventory accuracy needs a physical sample, not just system matching (`cycle-count-and-audit.md` §3).

## 3. Output: practitioner and executive

**Practitioner (default):**
1. **Result:** two to four sentences: population, match rate, top exception codes, the most important risk.
2. **Scope and method:** sources with as-of dates and roles, mapping, normalization, tiers, config file name.
3. **Metrics:** table with formula, numerator, denominator.
4. **Exceptions:** counts by code and severity, then the register (`exceptions.csv`, with owner and triage fields added) or its top rows: `Exception ID | Asset | Source A | Source B | Conflict | Evidence | Risk | Confidence (tier) | Recommended action | Owner | Priority`.
5. **Root causes and corrective actions** for the top codes.
6. **Limitations and open items:** scope gaps, unevaluated checks, review-required matches.

**Executive variant:** one paragraph on inventory reliability and exposure (devices unrecorded, devices with leavers, retired devices active), three to five actions with owners and dates, and metrics with trend if prior runs exist; method and registers go in an appendix. Recurring status reporting of these figures belongs to `itam-status-report`; metric definitions to `itam-data-analysis-reporting`.

Sources: AssetForge §10.1–10.2, 26.1; DataForge §9.
