# Reconciliation exception codes

The exception taxonomy for inventory reconciliation. `scripts/match_tiers.py` emits every code marked **Script: yes** with the default severity and action shown here; its internal `CODES` table must stay in step with this file. Codes marked **Script: no** come from manual or history-based tests (see `cycle-count-and-audit.md` and the hardware lifecycle skill's broken-transition tests).

**Basis:** `PRACTICE`. The exception list adapts Nicholas's AssetForge §10.3 (exception patterns), §15 (exception record and types) and §16 (root cause). CAMP's asset-identification indicators include reconciliation errors between inventory and electronic discovery, and between inventory and physical inventory results (CAMP M:22; S:75). Default severities are starting points; the organization sets its own in policy.

## Terms

Avoid slang in findings. "Ghost asset" usually means *recorded but not physically present* (PR-02, PR-04, PR-06 side); "zombie" or "shadow" device usually means *present or active but not recorded* (PR-01, PR-03). Usage varies between organizations and finance teams, so report the code and name, and define any slang you use.

## Families

| Prefix | Family | Question it answers |
|---|---|---|
| DQ | Data quality | Is the record itself usable? |
| MT | Matching | Could the record be matched with confidence? |
| PR | Presence | Is the asset where every expected source says it should be? |
| ST | State / lifecycle | Does the recorded state agree with observed activity and policy? |
| AT | Attribute consistency | Do linked sources agree on the same attribute? |
| US | User / ownership | Is the assignee a real, active person? |
| LC, FN | Lifecycle evidence, finance | History- and evidence-based checks outside the script |

## Code table

Severity: H = High, M = Medium, L = Low. "Likely type" uses AssetForge §15 exception types to guide root cause.

| Code | Name | Script | Default severity | Detection rule | Likely type | Typical root cause | Recommended action |
|---|---|---|---|---|---|---|---|
| DQ-01 | MISSING_SERIAL | yes | M (repository), L (other) | Serial column mapped but empty | Data-quality | Intake didn't capture serial; tool doesn't report it | Capture serial from device/packing slip/vendor portal; fix the intake step |
| DQ-02 | INVALID_IDENTIFIER | yes | M | Strong key flagged PLACEHOLDER, TOO_SHORT, EXCEL_MANGLED or INVALID by normalization | Data-quality / integration | OEM placeholder in BIOS; spreadsheet converted serial to a number; typed "N/A" | Replace with the true value; fix the export (text format) or BIOS data |
| DQ-03 | DUPLICATE_KEY_IN_SOURCE | yes | H (repository), M (other) | Same normalized strong key on two or more rows of one source | Data-quality / process | Double receipt, re-tagging, import without duplicate check, reused tag | Determine the real record; merge or retire the duplicate with an audit note |
| DQ-04 | MISSING_COST_CENTER | no | L | Repository record from `IS+` without `cost_center` | Ownership | Cost center not captured at receiving or after a mover | Populate from the request or HR |
| DQ-05 | MISSING_ASSET_TAG | yes | L | Repository record not On order/Cancelled/Disposed with empty tag | Process | Tagging skipped (direct ship to user, vendor didn't tag) | Tag and record; check vendor pre-delivery tagging (CAMP M:22 indicator) |
| DQ-06 | UNPARSEABLE_DATE | yes | L | Date field not parseable with configured formats | Data-quality / integration | Locale format, free text | Add the format to `date_formats` or fix the extract |
| DQ-07 | MISSING_LOCATION | yes | L | Repository In use / In stock with empty location | Data-quality | Remote workers not given a location convention | Record location or the "Remote" convention |
| DQ-08 | INVALID_MODEL | no | L | Model not in the model catalog | Data-quality | Free-text model entry, unnormalized discovery string | Normalize against catalog; add a value map |
| MT-01 | AMBIGUOUS_MATCH | yes | M | A record's keys point to more than one cluster (tier 1 or 2), or a tier 3 tie | Data-quality | Duplicates or reused identifiers in another source | Resolve the duplicate; rerun. Ambiguous records are quarantined and never merged |
| MT-02 | REVIEW_REQUIRED_TIER3 | yes | M | Best tier 3 score ≥ threshold and unique; **proposed only** | — | No strong key in one source | Person confirms with a strong identifier; record the decision; add the key to the source |
| MT-03 | STRONG_KEY_CONFLICT | yes | H | Record matches a cluster on one strong key while another strong key disagrees | Integration / process | Board or unit swap (RMA), tag moved to another device, typo | Check RMA history; correct the wrong key; keep history |
| PR-01 | DISCOVERED_NOT_RECORDED | yes | H if active, else M | Discovery/MDM record with no repository record | Process / control | Device bought outside the process, personal device, receiving skipped, stale repository | Identify device and owner; record via intake or block/remove if unauthorized |
| PR-02 | RECORDED_NOT_DISCOVERED | yes | M | Repository state in `discoverable_states` (default In use), class in scope, no discovery record | Process / integration | Agent broken, device lost or unreturned, record wrong | Contact assignee; check agent; after search period → Missing |
| PR-03 | FOUND_NOT_RECORDED | yes | M | Physical count record with no repository record | Process | Receiving skipped, returned device never re-recorded | Record with an investigation note |
| PR-04 | RECORDED_NOT_FOUND | yes | M | Repository In stock / In use at a counted location, absent from the count | Process / control | Unrecorded move or deployment, theft, count error | Recount; check transfers; escalate to Missing |
| PR-05 | FINANCE_NOT_RECORDED | yes | M | Fixed-asset register entry with no repository record | Process / integration | Disposed without financial closure; capitalized without asset record | Match or retire the register entry with Finance |
| PR-06 | RECORDED_NOT_IN_FINANCE | yes | M | Repository record flagged capitalized, not Disposed/Cancelled, absent from the register | Process | Capitalization step missed; flag wrong | Confirm with Finance; correct register or flag |
| PR-07 | CI_WITHOUT_ASSET | yes | M | CMDB record with no repository record | Integration | Discovery creates CIs; asset creation rule missing | Decide if class needs an asset; link or create through intake |
| PR-08 | ASSET_WITHOUT_CI | yes | M | Repository class in `ci_expected_classes`, active state, no CMDB record | Integration | Model category / CI class mapping, sync failure | Fix mapping; link or create CI |
| PR-09 | PURCHASED_NOT_RECORDED | yes | M | Procurement/receiving line with no repository record | Process | In transit, received not recorded, not delivered | Check receiving; vendor claim if not delivered |
| PR-10 | RECORDED_NO_PURCHASE | yes (opt-in) | L | Repository record with no procurement match (`flag_missing_purchase`) | Process / data-quality | Transfer, donation, legacy data, PO not captured | Document the acquisition source |
| ST-01 | RETIRED_OR_DISPOSED_SEEN_ACTIVE | yes | H | Repository Retired/Disposed and an active discovery record | Control / compliance | Device never left; wrong record retired; disposal control failure | Locate device; check disposal evidence; correct state; consider data-security review |
| ST-02 | IN_STOCK_SEEN_ACTIVE | yes | M | Repository In stock and an active discovery record | Process | Deployed without assignment update; bench/build check-in | Record assignment, or confirm bench activity |
| ST-03 | STALE_DISCOVERY | yes | L | Discovery last seen older than `active_days` | Integration / process | Agent unhealthy; device off network; device lost | Check agent; follow PR-02 path |
| ST-04 | STATE_UNMAPPED | yes | M | Repository state value not in `state_map` (one row per distinct value) | Data-quality / lifecycle design | Custom states; typos | Map to a canonical state or fix the value |
| ST-05 | IN_USE_NO_USER | yes | M | Repository In use, user empty | Ownership | Shared/kiosk devices without custodian; assignment skipped | Record assignee or custodian |
| ST-06 | IN_USE_PAST_WARRANTY | yes | L | Repository In use, `warranty_end` before as-of date | Lifecycle | Refresh backlog; extended support not recorded | Review against refresh policy |
| ST-07 | MISSING_SEEN_ACTIVE | yes | H | Repository Missing and an active discovery record | Control / security | Lost/stolen device back online; leaver still using device | Notify Security and owner; recover |
| AT-01 | ATTRIBUTE_CONFLICT | yes | M (H for user when repository involved) | Linked sources hold different values for a compared field | Process / integration | Unrecorded mover or transfer; naming drift; model strings | Apply the attribute authority table; correct the non-authoritative source |
| US-01 | INACTIVE_USER_ACTIVE_ASSIGNMENT | yes | H | Repository In use assigned to an identity whose HR status is not active | Process / control | Leaver recovery not triggered or failed | Start or escalate leaver recovery; legal hold check before wipe |
| US-02 | ASSIGNED_USER_NOT_IN_HR | yes | M | Repository In use assignee not found in the HR extract | Data-quality / integration | Identifier format mismatch; contractor not in HR feed | Fix identifier normalization or HR scope |
| LC-01 | PROHIBITED_TRANSITION | no | H | State history shows a transition prohibited by the canonical model | Control | Uncontrolled state edits; bulk updates | Correct with approval; restrict who can change state |
| LC-02 | DISPOSED_NO_CERTIFICATE | no | H | Disposed without serial-level certificate reference | Compliance / control | Lot-level certificate; ITAD reporting gap | Obtain serial-level evidence from the vendor |
| LC-03 | RETIRED_NO_SANITIZATION_EVIDENCE | no | H | Retired/Disposed device with storage and no sanitization evidence | Compliance / control | Wipe not logged; vendor report missing | Obtain evidence or escalate as a potential data exposure |
| LC-04 | OUTSIDE_REFRESH_POLICY | no | L | In use beyond refresh eligibility without an approved deferral | Lifecycle / policy | Budget deferral; forecast gap | Add to refresh plan or record deferral |
| LC-05 | DWELL_EXCEEDED | no | M | Time in state beyond its maximum (stock aging, Missing search period, Retired awaiting disposal) | Process | Bottleneck; forgotten records | Work the queue; review threshold |
| FN-01 | DEPLOYED_BUT_FINANCE_INVENTORY | no | M | In use in ITAM while finance still holds it as unissued inventory / not in service | Process | In-service date not passed to Finance | Agree in-service date with Finance |
| FN-02 | COST_MISMATCH | no | L | Repository cost differs from invoice beyond tolerance `[FILL]` | Data-quality | PO price used instead of invoice | Correct from invoice |

## Exception register fields

The script outputs the detection fields. Add the rest during triage so each exception can be managed to closure (AssetForge §15):

`exception_id` · `code` · `date_identified` · `source(s)` · `asset / population` · `expected_state` · `observed_state` · `evidence` · `business_impact` · `risk` · `root_cause` · `control_failure` (Y/N, which control) · `owner` (a role, not "the organization") · `priority` · `remediation` · `target_date` · `age` · `status` · `escalation` · `validation_method` · `closure_evidence`.

Rules:
- Track **aging**; report open exceptions by age band and code.
- An approved, permanent exception (for example, a lab device that is never discovered) must be documented with an approver and review date, so it doesn't become an undocumented alternate process.
- Close only with closure evidence (rerun shows the exception gone, or a documented decision).

## From exceptions to root cause

Don't stop at bad records. For recurring codes (Pareto of the code counts usually shows a few codes carry most of the volume), trace:

`SYMPTOM → CONTRIBUTING FACTOR → ROOT CAUSE → CORRECTIVE ACTION`

Root-cause categories to test: people, process, policy, governance, technology, integration, data architecture, training, vendor, contract, ownership, workflow, automation, incentives, lifecycle design, source-of-truth conflict, control design, control execution (AssetForge §16). Use Five Whys or a causal chain for one code at a time; label the conclusion `INFERENCE` unless the cause was observed.

Example: 140 × PR-01 (symptom) → 80% are new laptops received at one site (contributing factor) → that site ships direct to users and skips the receiving scan (root cause: process design) → require receiving scan before shipment or vendor pre-registration (corrective action), measured by PR-01 count at that site next cycle.
