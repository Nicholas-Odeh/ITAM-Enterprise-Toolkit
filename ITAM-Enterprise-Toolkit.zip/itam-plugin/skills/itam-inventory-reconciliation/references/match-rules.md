# Normalization and matching rules

How records from different extracts are normalized and matched, what each tier means, how to configure `scripts/match_tiers.py`, and how to read its output. Basis: `PRACTICE`, implementing Nicholas's AssetForge §10.1–10.2 (normalize; tiered matching; "never present probabilistic matches as deterministic") and DataForge §9 (preserve raw evidence; check key uniqueness and unmatched counts around joins).

## Contents
1. Before matching
2. Normalization rules
3. Match tiers
4. Running the scripts
5. Config reference
6. Reading the output
7. Known limitations

## 1. Before matching

- **Same as-of moment.** Pull every extract on the same day where possible and record the extract time. A device moved between two extract times looks like an exception.
- **Know each source's grain.** One row per device? Per device per user? Per network interface? A discovery export with one row per NIC multiplies records; deduplicate to one row per device first and say how.
- **Know each source's scope.** An MDM export covers only enrolled platforms; a fixed-asset register covers only capitalized items; a stockroom count covers only counted locations. Out-of-scope absence is not an exception; set the presence rules accordingly.
- **Never edit the source extracts.** Normalization adds columns; the raw value stays beside it as evidence.

## 2. Normalization rules

Implemented in `scripts/normalize_serials.py` (and reused by `match_tiers.py`). Every value gets a normalized form and a flag: `OK`, `EMPTY`, `PLACEHOLDER`, `TOO_SHORT`, `VIRTUAL`, `EXCEL_MANGLED`, `INVALID`, `UNPARSEABLE`. Only `OK` and `VIRTUAL` values are used for matching.

| Type | Rule | Flags worth knowing |
|---|---|---|
| serial | Strip "S/N:", "SN#", "Serial No." prefixes; upper-case; keep letters and digits only; optional leading-zero strip | `PLACEHOLDER` for OEM filler ("To be filled by O.E.M.", "Default string", "System Serial Number", "0", "N/A", repeated single character, "123456789" ...); `EXCEL_MANGLED` for scientific notation such as `1.23E+11`; `VIRTUAL` for VMware-/Parallels-/QEMU-style serials (valid, but a VM isn't a hardware asset); `TOO_SHORT` under 4 characters (configurable) |
| tag | Upper-case; letters and digits only; optional prefix regex strip (`^AT-?`) and leading-zero strip | Use the prefix/zero options only when the organization's tag format makes `AT-000123` and `123` the same tag |
| hostname | Drop `DOMAIN\`; drop DNS suffix after the first dot; upper-case | `localhost`, "unknown" → `PLACEHOLDER` |
| mac | 12 hex digits → `AA:BB:CC:DD:EE:FF` | all-zero / broadcast → `PLACEHOLDER` |
| uuid | 32 hex digits → lower-case 8-4-4-4-12 | all-zero, all-F and a widely reported OEM placeholder UUID → `PLACEHOLDER` |
| user | Lower-case; `DOMAIN\user` and `user@domain` → `user` | Display names ("Smith, John") won't match account names; map them first |
| text | Upper-case; punctuation to spaces; collapse whitespace (model, location, state, class) | Use `value_maps` to equate synonyms (`DELL LATITUDE 7440` → `LATITUDE 7440`) |
| date | Per-source `date_formats` first, then common ISO/US formats, then ISO 8601 with offsets | Day-first sources (`03/04/2026` = 3 April) **must** set `date_formats: ["%d/%m/%Y"]`, otherwise they parse as US month-first |

Document any extra normalization (lookup tables, manual fixes) in the output's method section with the count of rows affected.

## 3. Match tiers

Each source is processed in turn (repository first). A record either joins an existing **cluster** (one physical asset as seen across sources) or seeds a new one.

| Tier | Rule | Default keys | Merges? | Counts as reconciled? |
|---|---|---|---|---|
| **1 — deterministic** | Exact normalized value of a strong, unique identifier matches exactly one cluster | `serial`, `asset_tag`, `uuid`, `device_id` | Yes | Yes |
| **2 — composite** | No tier 1 match; every field in a configured combination agrees with exactly one cluster that has no record from the same source; no strong key disagrees | `hostname + user`, `hostname + model` | Yes | Yes |
| **3 — review-required** | No tier 1/2 match; weak fields score: agreements ≥ `tier3_min_agree` (default 3) and agreements > disagreements; dates agree within `date_tolerance_days` | `model`, `user`, `location`, `purchase_date` | **No** — proposal only | **No** — raises MT-02 for human confirmation |

Safeguards:
- **Strong-key veto.** If both records have a serial (or other strong key) and the values differ, tier 2 and tier 3 can't match them.
- **Ambiguity is never resolved by the script.** Keys pointing to two or more clusters raise MT-01; the record seeds a quarantined cluster whose keys aren't indexed, so one bad record can't make later records ambiguous too.
- **Key conflict inside a tier 1 match** (serial matches, tag differs) merges but raises MT-03.
- **Same-source duplicates** by strong key merge into one cluster and raise DQ-03; tier 2/3 never put two records from one source in a cluster.
- **MAC address is not a default tier 1 key.** Docks and USB network adapters move between laptops, so one MAC can appear on several devices. Use it only inside a tier 2 composite (for example `mac + hostname`).
- **Tier 3 blocking.** Candidates come from clusters sharing a weak value whose posting list is ≤ `tier3_block_cap` (default 200), so a very common value (one model across thousands of devices) doesn't trigger a full scan. Raise the cap only for small datasets.

Tier 3 exists to point a person at likely pairs. A confirmed tier 3 pair should be fixed at the source (add the missing serial), then the rerun matches it at tier 1.

## 4. Running the scripts

```bash
# Optional: inspect identifier quality of one extract before matching
python3 scripts/normalize_serials.py mdm.csv -o mdm_norm.csv \
  --map "Serial number=serial" --map "Device name=hostname" --map "Primary user UPN=user" \
  --summary-json mdm_flags.json

# Write a config (start from the template), then match
python3 scripts/match_tiers.py --example-config > recon.json
python3 scripts/match_tiers.py --config recon.json --out-dir recon_out --as-of 2026-10-20
```

Both scripts: Python 3 standard library only, `--help`, CSV in, CSV/JSON out, deterministic. Exit code 2 with a message on configuration errors (unknown field, missing column, bad state mapping). Run them on the user's machine or in the sandbox; never claim a result you didn't run.

## 5. Config reference

```json
{
  "as_of": "YYYY-MM-DD",
  "sources": [
    {"name": "ITAM", "path": "itam.csv", "role": "repository",
     "columns": {"<canonical field>": "<column header>"},
     "state_map": {"<org state value>": "<CANONICAL_STATE>"},
     "date_formats": ["%Y-%m-%d"]}
  ],
  "users": {"path": "hr.csv", "columns": {"user": "<col>", "status": "<col>"}, "active_values": ["Active"]},
  "matching": {"tier1_keys": [...], "tier2_composites": [[...]], "tier3_fields": [...],
               "tier3_min_agree": 3, "tier3_block_cap": 200, "date_tolerance_days": 45},
  "rules": {"active_days": 30, "discoverable_states": ["IN_USE"], "discoverable_classes": [],
            "physical_expected_states": ["IN_STOCK", "IN_USE"], "physical_scope_locations": [],
            "ci_expected_classes": [], "flag_missing_purchase": false,
            "compare_fields": ["user", "hostname", "model"]},
  "normalize": {"tag_strip_prefix": "", "tag_strip_leading_zeros": false,
                "serial_strip_leading_zeros": false, "serial_min_length": 4},
  "value_maps": {"model": {"<raw>": "<canonical>"}}
}
```

- **Canonical fields:** `record_id, serial, asset_tag, uuid, device_id, hostname, mac, user, model, manufacturer, asset_class, location, cost_center, state, last_seen, purchase_date, warranty_end, capitalized` (definitions in the shared `asset-data-model.md`).
- **Roles:** `repository` (at most one: the ITAM system of record), `discovery` (discovery, MDM, endpoint management, EDR), `physical` (counts, audit scans), `finance` (fixed-asset register), `procurement` (PO/receiving lines), `cmdb`, `other` (matched, no presence rules).
- **State map:** values map to the canonical states `ON_ORDER, IN_TRANSIT, IN_STOCK, IN_USE, IN_MAINTENANCE, MISSING, RETIRED, DISPOSED, CANCELLED`. Values already spelled like a canonical state ("In use") map automatically; everything else raises ST-04 until mapped.
- **Presence rules:** `discoverable_states`/`discoverable_classes` limit PR-02; `physical_expected_states` and `physical_scope_locations` limit PR-04 (default scope = locations present in the physical extract); `ci_expected_classes` enables PR-08; `capitalized` (truthy Y/YES/TRUE/1) enables PR-06; `flag_missing_purchase` enables PR-10.
- **active_days:** a discovery record is active if `last_seen` is within this many days of `as_of`. If a discovery source has no `last_seen`, every record is treated as active and the summary says so.

## 6. Reading the output

| File | Grain | Use |
|---|---|---|
| `matches.csv` | One row per input record | Trace any record: its cluster, tier, matched-on key, normalized identifiers, proposed tier 3 cluster |
| `clusters.csv` | One row per asset cluster | Presence matrix (`in_<SOURCE>` Y/N), representative values (repository first), exception codes, `review_required` |
| `exceptions.csv` | One row per exception | Work queue: code, severity, evidence (`observed`, `detail`), recommended action; add owner and triage fields from `exception-codes.md` |
| `summary.json` | Run | Record counts per source and tier, cluster counts by source combination, match rates with formulas, exception counts, notes on what wasn't evaluated |

Report rates with their formula, numerator, denominator and as-of date. The script's `repository_match_rate_pct` = repository records linked by tier 1 or 2 to at least one other source ÷ repository records × 100. It is a **reconciliation** rate, not inventory accuracy: inventory accuracy needs a physical verification sample (`cycle-count-and-audit.md`).

## 7. Known limitations

- Counts describe the supplied extracts only. Assets that appear in no extract are invisible.
- A replaced motherboard can change serial and UUID together; such a device looks new (PR-01) and the old record looks lost (PR-02) until the RMA is recorded.
- Shared and re-imaged devices change hostname and user frequently; prefer serial-based tier 1.
- User matching assumes account-style identifiers; display names need a lookup table first.
- The script doesn't read state history, so prohibited transitions (LC-01) and evidence gaps (LC-02, LC-03) need separate tests.
- Very large extracts (hundreds of thousands of rows) run in memory; split by region or class if needed and note the split.
