# Cycle counts, physical inventory and audit preparation

Use this file to plan a stockroom cycle count or wall-to-wall physical inventory, measure inventory accuracy, or prepare reconciliation evidence for an internal or external audit.

**Basis:** CAMP positions asset identification as the checkpoint between physical and electronic discovery for audit reconciliation (CAMP M:39), and lists reconciliation errors between inventory and physical inventory results among its indicators (CAMP M:22). The inventory accuracy formula follows Nicholas's AssetForge §26.1. Procedures are `PRACTICE`; cadences, tolerances and sample sizes are `[FILL]` organizational values or are agreed with internal audit.

## 1. Count types

| Type | Scope | Typical use | Cadence |
|---|---|---|---|
| Stockroom cycle count | One stockroom or bin set at a time | Keep stock records right between full counts | `[FILL]` (often monthly per stockroom) |
| Wall-to-wall physical inventory | All stock and deployed devices at a site | Annual verification, site closure, audit request | `[FILL]` |
| Deployed-device attestation | Users confirm the devices they hold | Remote workforce, where floor counts are impractical | `[FILL]` |
| Sample-based accuracy test | Random sample of records and of physical items | Measuring inventory accuracy for KPIs or audit | `[FILL]` |

Electronic discovery (MDM, agent check-in) is evidence that a device exists and is active; it doesn't prove location or custody. Use it alongside, not instead of, physical verification for stock.

## 2. Reconciling a stockroom count

**Ownership split.** The physical count procedure (scheduling, zone freeze, blind count, scanning, recount by a second person, adjustment approval) is owned by `itam-logistics-warehouse` (`references/cycle-count-procedure.md`). This skill owns matching the count file to the records and analyzing the variance. The steps below show the whole sequence from the reconciliation side so the two fit together.

1. **Freeze or cut off.** Stop movements, or record the cut-off time and reconcile movements that crossed it.
2. **Blind count.** Counters scan or record what is physically there (tag and serial) without seeing the expected list. Segregate duties: the custodian of the stockroom shouldn't be the only counter (`PRACTICE`).
3. **Capture** tag, serial, location/bin, condition, and anything untagged (record it; don't tag it on the spot without a receiving record).
4. **Reconcile** the count against the repository with `scripts/match_tiers.py` (physical role, scope = counted locations). Expected exceptions: PR-03 found-not-recorded, PR-04 recorded-not-found, MT-03 tag/serial conflicts, DQ-03 duplicates.
5. **Recount** variances before investigating; many are count errors.
6. **Investigate** each confirmed variance: open transfers, deployments not recorded, returns not received, theft. Record the finding on the exception.
7. **Correct** records only through transactions that carry the count reference. Never edit records to make them match the count without an investigation note.
8. **Report** variance count and value, accuracy rate, root causes, and corrective actions.

## 3. Measuring inventory accuracy

Test both directions; one direction alone hides a class of error.

| Test | Sample from | Check | Fails when |
|---|---|---|---|
| Record-to-floor (existence) | Repository records in scope | Find the device; confirm tag, serial, location, assignee/state | Device not found, or attributes wrong |
| Floor-to-record (completeness) | Physical items in scope | Find the record | No record, or record attributes wrong |

**Inventory accuracy rate** = records verified accurate ÷ records tested × 100. Define "accurate" before testing (for example: exists, and tag, serial, location and state all correct). Report the floor-to-record result separately as **unrecorded rate** = items without a correct record ÷ items tested × 100.

**Sample size.** Agree it with internal audit when the result supports an audit or control assertion `[FILL]`. For a management estimate of a proportion, the usual approximation is n = z² × p(1−p) ÷ e² (z for the chosen confidence, p the expected accuracy, e the margin of error), reduced for small populations with n′ = n ÷ (1 + (n−1)/N). State the confidence, margin and population used. Select randomly (random number on a numbered list), not by convenience.

## 4. Audit preparation: reconciliation evidence pack

What auditors usually ask for (`PRACTICE`; confirm the audit's actual request list):

| Item | Content |
|---|---|
| Population | Repository extract with as-of date, filter used, record count; how completeness of the extract was checked |
| Sources | Each comparison extract with date, owner and scope |
| Method | Normalization rules, match tiers, config used (attach `recon.json`), script version |
| Results | `summary.json` metrics with formulas; exception counts by code and severity |
| Exceptions | Register with owner, status, age and closure evidence; approved permanent exceptions with approver |
| Physical verification | Count sheets or scan files, counter names, dates, variance investigation notes |
| Corrections | List of record changes made from the reconciliation, each with its reference |
| Controls | Which reconciliation control ran, who reviewed it, when; evidence of review (sign-off) |

Rules: give auditors the evidence that a control **operated**, not a description of how it would. Keep the raw extracts unchanged and retained for the period your evidence-retention policy sets `[FILL]`. If an exception class is open at audit time, show it with its remediation plan instead of cleaning it up silently the day before.

## 5. Common causes of count variance

| Variance | Usual causes |
|---|---|
| Found, not recorded | Returns received without a receipt transaction; direct-ship devices returned to stock; vendor replacements (RMA) never recorded |
| Recorded, not found | Deployments not recorded; moves between stockrooms without transfer; theft; devices in repair or at the imaging bench |
| Wrong location | Informal moves between sites or bins |
| Tag/serial mismatch | Tag applied to the wrong device; board replacement; label damage |
| Duplicates | Re-tagging without retiring the old tag; double receiving |
