#!/usr/bin/env python3
"""Match IT asset records across two or more source extracts and emit coded exceptions.

Tiered matching (see references/match-rules.md):
  Tier 1  deterministic: an exact normalized strong key (serial, asset tag, UUID, platform device ID).
  Tier 2  composite: every field of a configured combination agrees (e.g. hostname + user), and no
          strong key disagrees.
  Tier 3  review-required: weak fields (model, user, location, approximate date) score above a
          threshold. Tier 3 results are PROPOSED only: they are never merged, never count as
          reconciled, and always raise exception MT-02 for a person to confirm or reject.

Sources are read in config order, with the repository (system of record) first. Each record either
joins an existing asset cluster (tier 1 or 2) or seeds a new one. Exception codes are defined in
references/exception-codes.md; the code table in this script must stay in step with that file.

Inputs : a JSON config (print a template with --example-config) naming each CSV, its role and a
         mapping from canonical field names to its column headers. Paths are relative to the config.
Outputs (in --out-dir):
  matches.csv     one row per input record: cluster, tier, matched-on key, normalized identifiers
  clusters.csv    one row per asset cluster: which sources hold it, representative values, exceptions
  exceptions.csv  one row per exception: code, severity, evidence, recommended action, status OPEN
  summary.json    counts, match rates with formulas, exception counts, and processing notes

Python 3 standard library only. Deterministic: the same inputs and config give the same output.
Example: python3 match_tiers.py --config recon.json --out-dir out/ --as-of 2026-10-20
"""

import argparse
import csv
import datetime as _dt
import json
import os
import sys
from collections import OrderedDict, defaultdict

sys.dont_write_bytecode = True  # keep the skill folder free of __pycache__
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from normalize_serials import normalize  # noqa: E402  (sibling script)

CANONICAL_STATES = ["ON_ORDER", "IN_TRANSIT", "IN_STOCK", "IN_USE", "IN_MAINTENANCE",
                    "MISSING", "RETIRED", "DISPOSED", "CANCELLED"]
ROLES = ["repository", "discovery", "physical", "finance", "procurement", "cmdb", "other"]

# canonical field -> normalization type (None = keep trimmed raw value)
FIELD_TYPES = OrderedDict([
    ("record_id", None), ("serial", "serial"), ("asset_tag", "tag"), ("uuid", "uuid"),
    ("device_id", "text"), ("hostname", "hostname"), ("mac", "mac"), ("user", "user"),
    ("model", "text"), ("manufacturer", "text"), ("asset_class", "text"), ("location", "text"),
    ("cost_center", "text"), ("state", "text"), ("last_seen", "date"), ("purchase_date", "date"),
    ("warranty_end", "date"), ("capitalized", "text"),
])
DATE_FIELDS = {"last_seen", "purchase_date", "warranty_end"}
VALID_FLAGS = {"OK", "VIRTUAL"}
BAD_ID_FLAGS = {"PLACEHOLDER", "TOO_SHORT", "EXCEL_MANGLED", "INVALID"}
TRUTHY = {"Y", "YES", "TRUE", "1", "T", "X"}

# code -> (name, default severity, category, recommended action). Mirror of references/exception-codes.md.
CODES = OrderedDict([
    ("DQ-01", ("MISSING_SERIAL", "Medium", "Data quality", "Capture the serial from the device, packing slip or vendor portal; fix the intake step that skipped it.")),
    ("DQ-02", ("INVALID_IDENTIFIER", "Medium", "Data quality", "Replace the placeholder or malformed identifier with the true value; check the BIOS/OEM data or the export format (Excel mangling).")),
    ("DQ-03", ("DUPLICATE_KEY_IN_SOURCE", "High", "Data quality", "Investigate which record is real; merge or retire the duplicate in the source system with an audit note.")),
    ("DQ-05", ("MISSING_ASSET_TAG", "Low", "Data quality", "Tag the device and record the tag; check the receiving/tagging step.")),
    ("DQ-06", ("UNPARSEABLE_DATE", "Low", "Data quality", "Fix the date format in the extract or add the source's format to date_formats.")),
    ("DQ-07", ("MISSING_LOCATION", "Low", "Data quality", "Record the location or stockroom; confirm with the assigned user or stockroom count.")),
    ("MT-01", ("AMBIGUOUS_MATCH", "Medium", "Matching", "Review the candidate records; resolve the duplicate or conflicting identifiers that make the match ambiguous.")),
    ("MT-02", ("REVIEW_REQUIRED_TIER3", "Medium", "Matching", "A person confirms or rejects the proposed match using a strong identifier from the device or paperwork; never auto-merge.")),
    ("MT-03", ("STRONG_KEY_CONFLICT", "High", "Matching", "One strong key matches and another disagrees; check for board/serial swap (RMA), re-used tag or data-entry error.")),
    ("PR-01", ("DISCOVERED_NOT_RECORDED", "High", "Presence", "Identify the device and owner; create the asset record through intake (do not bulk-create), or block/remove the device if unauthorized.")),
    ("PR-02", ("RECORDED_NOT_DISCOVERED", "Medium", "Presence", "Contact the assigned user/location to locate the device; check agent health; move to Missing after the search period if not found.")),
    ("PR-03", ("FOUND_NOT_RECORDED", "Medium", "Presence", "Identify the device found in the physical count and record it through intake with an investigation note.")),
    ("PR-04", ("RECORDED_NOT_FOUND", "Medium", "Presence", "Recount and search; check transfers in progress; escalate to Missing after the search period.")),
    ("PR-05", ("FINANCE_NOT_RECORDED", "Medium", "Presence", "Match the fixed-asset entry to a device or confirm it was disposed; agree corrections with Finance.")),
    ("PR-06", ("RECORDED_NOT_IN_FINANCE", "Medium", "Presence", "Confirm capitalization status with Finance; add to the register or correct the capitalized flag.")),
    ("PR-07", ("CI_WITHOUT_ASSET", "Medium", "Presence", "Decide whether an asset record is required for this CI class; link or create the asset through intake.")),
    ("PR-08", ("ASSET_WITHOUT_CI", "Medium", "Presence", "Check the model category/CI class mapping and the asset-CI sync; link or create the CI.")),
    ("PR-09", ("PURCHASED_NOT_RECORDED", "Medium", "Presence", "Check receiving: still in transit, received but not recorded, or never delivered (vendor claim).")),
    ("PR-10", ("RECORDED_NO_PURCHASE", "Low", "Presence", "Find the PO/invoice or the transfer/donation record; document the acquisition source.")),
    ("ST-01", ("RETIRED_OR_DISPOSED_SEEN_ACTIVE", "High", "Lifecycle", "Treat as a possible data-security or disposal-control failure: locate the device, check disposal evidence, correct the state.")),
    ("ST-02", ("IN_STOCK_SEEN_ACTIVE", "Medium", "Lifecycle", "Device is checking in while recorded as stock: confirm deployment and record the assignment, or confirm bench/build activity.")),
    ("ST-03", ("STALE_DISCOVERY", "Low", "Lifecycle", "Device not seen within the active window: check agent health, then follow the not-discovered path.")),
    ("ST-04", ("STATE_UNMAPPED", "Medium", "Lifecycle", "Add the state value to state_map (map it to a canonical state) or correct the source value.")),
    ("ST-05", ("IN_USE_NO_USER", "Medium", "Ownership", "Record the assigned user or custodian; if shared, record the accountable custodian and location.")),
    ("ST-06", ("IN_USE_PAST_WARRANTY", "Low", "Lifecycle", "Check refresh eligibility or extended support coverage under the refresh policy.")),
    ("ST-07", ("MISSING_SEEN_ACTIVE", "High", "Lifecycle", "A device recorded as missing/lost/stolen is checking in: notify Security and the asset owner; recover and update the state.")),
    ("AT-01", ("ATTRIBUTE_CONFLICT", "Medium", "Consistency", "Decide which source is authoritative for this attribute (see the attribute authority table) and correct the other.")),
    ("US-01", ("INACTIVE_USER_ACTIVE_ASSIGNMENT", "High", "Ownership", "Start leaver recovery for the device; confirm the HR status and any legal hold before wiping.")),
    ("US-02", ("ASSIGNED_USER_NOT_IN_HR", "Medium", "Ownership", "Check the user identifier format and the HR extract scope; correct the assignment.")),
])

EXAMPLE_CONFIG = {
    "as_of": "2026-10-20",
    "sources": [
        {"name": "ITAM", "path": "itam_export.csv", "role": "repository",
         "columns": {"record_id": "Asset ID", "serial": "Serial Number", "asset_tag": "Asset Tag",
                     "hostname": "Name", "user": "Assigned To", "model": "Model",
                     "asset_class": "Category", "location": "Location", "state": "State",
                     "purchase_date": "Purchased", "warranty_end": "Warranty Expiration",
                     "capitalized": "Capitalized"},
         "state_map": {"In use": "IN_USE", "In stock": "IN_STOCK", "Retired": "RETIRED",
                       "Disposed": "DISPOSED", "Missing": "MISSING", "In transit": "IN_TRANSIT",
                       "In maintenance": "IN_MAINTENANCE", "On order": "ON_ORDER"},
         "date_formats": ["%Y-%m-%d"]},
        {"name": "MDM", "path": "mdm_export.csv", "role": "discovery",
         "columns": {"record_id": "Device ID", "serial": "Serial number", "hostname": "Device name",
                     "user": "Primary user UPN", "model": "Model", "last_seen": "Last check-in"}},
        {"name": "COUNT", "path": "stockroom_count.csv", "role": "physical",
         "columns": {"asset_tag": "Tag", "serial": "Serial", "location": "Room"}},
    ],
    "users": {"path": "hr_extract.csv", "columns": {"user": "UPN", "status": "Status"},
              "active_values": ["Active", "Leave of absence"]},
    "matching": {
        "tier1_keys": ["serial", "asset_tag", "uuid", "device_id"],
        "tier2_composites": [["hostname", "user"], ["hostname", "model"]],
        "tier3_fields": ["model", "user", "location", "purchase_date"],
        "tier3_min_agree": 3, "tier3_block_cap": 200, "date_tolerance_days": 45},
    "rules": {
        "active_days": 30, "discoverable_states": ["IN_USE"], "discoverable_classes": [],
        "physical_expected_states": ["IN_STOCK", "IN_USE"], "physical_scope_locations": [],
        "ci_expected_classes": [], "flag_missing_purchase": False,
        "compare_fields": ["user", "hostname", "model"]},
    "normalize": {"tag_strip_prefix": "", "tag_strip_leading_zeros": False,
                  "serial_strip_leading_zeros": False, "serial_min_length": 4},
    "value_maps": {"model": {"DELL LATITUDE 7440": "LATITUDE 7440"}},
}

DEFAULT_MATCHING = EXAMPLE_CONFIG["matching"]
DEFAULT_RULES = EXAMPLE_CONFIG["rules"]


class ConfigError(Exception):
    pass


class Record(object):
    __slots__ = ("source", "role", "row", "raw", "norm", "flags", "state", "active",
                 "cluster", "tier", "matched_on", "matched_value", "proposed", "proposed_score")

    def __init__(self, source, role, row):
        self.source, self.role, self.row = source, role, row
        self.raw, self.norm, self.flags = {}, {}, {}
        self.state = ""
        self.active = None
        self.cluster = None
        self.tier = ""
        self.matched_on = ""
        self.matched_value = ""
        self.proposed = ""
        self.proposed_score = ""

    def v(self, field):
        """Valid normalized value or ''."""
        return self.norm.get(field, "") if self.flags.get(field) in VALID_FLAGS else ""


class Cluster(object):
    def __init__(self, cid):
        self.id = cid
        self.members = []
        self.values = defaultdict(set)
        self.sources = defaultdict(int)


def _parse_date(s):
    try:
        return _dt.date.fromisoformat(s)
    except (TypeError, ValueError):
        return None


def load_config(path):
    with open(path, encoding="utf-8") as fh:
        cfg = json.load(fh)
    base = os.path.dirname(os.path.abspath(path))
    if not isinstance(cfg.get("sources"), list) or len(cfg["sources"]) < 2:
        raise ConfigError("config needs a 'sources' list with at least two extracts")
    names = set()
    repo = 0
    for s in cfg["sources"]:
        for k in ("name", "path", "role", "columns"):
            if k not in s:
                raise ConfigError("source %r is missing %r" % (s.get("name", "?"), k))
        if s["name"] in names:
            raise ConfigError("duplicate source name %r" % s["name"])
        names.add(s["name"])
        if s["role"] not in ROLES:
            raise ConfigError("source %r role %r not in %s" % (s["name"], s["role"], ROLES))
        repo += s["role"] == "repository"
        bad = [f for f in s["columns"] if f not in FIELD_TYPES]
        if bad:
            raise ConfigError("source %r maps unknown canonical fields %s; allowed: %s"
                              % (s["name"], bad, list(FIELD_TYPES)))
        s["path"] = os.path.join(base, s["path"])
        for k, v in (s.get("state_map") or {}).items():
            if v not in CANONICAL_STATES:
                raise ConfigError("state_map value %r for %r is not a canonical state %s"
                                  % (v, k, CANONICAL_STATES))
    if repo > 1:
        raise ConfigError("only one source may have role 'repository'")
    if cfg.get("users"):
        cfg["users"]["path"] = os.path.join(base, cfg["users"]["path"])
    m = dict(DEFAULT_MATCHING)
    m.update(cfg.get("matching") or {})
    r = dict(DEFAULT_RULES)
    r.update(cfg.get("rules") or {})
    for k in m["tier1_keys"] + m["tier3_fields"] + [f for c in m["tier2_composites"] for f in c] + r["compare_fields"]:
        if k not in FIELD_TYPES:
            raise ConfigError("matching/rules field %r is not a canonical field" % k)
    cfg["matching"], cfg["rules"] = m, r
    cfg.setdefault("normalize", {})
    cfg.setdefault("value_maps", {})
    return cfg


def read_rows(path):
    if not os.path.exists(path):
        raise ConfigError("file not found: %s" % path)
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise ConfigError("%s has no header row" % path)
        return list(reader.fieldnames), list(reader)


def load_source(src, cfg, notes):
    fields, rows = read_rows(src["path"])
    missing = [c for c in src["columns"].values() if c not in fields]
    if missing:
        raise ConfigError("source %r: columns %s not found in %s (columns present: %s)"
                          % (src["name"], missing, src["path"], fields))
    opts = dict(cfg["normalize"])
    opts["date_formats"] = src.get("date_formats") or []
    vmaps = {}
    for field, mapping in cfg["value_maps"].items():
        kind = FIELD_TYPES.get(field)
        vmaps[field] = {normalize(k, kind, opts)[0] if kind else k: (normalize(v, kind, opts)[0] if kind else v)
                        for k, v in mapping.items()}
    smap = {}
    for k, v in (src.get("state_map") or {}).items():
        smap[normalize(k, "text")[0]] = v
    recs = []
    for i, row in enumerate(rows, start=1):
        r = Record(src["name"], src["role"], i)
        for field, col in src["columns"].items():
            raw = row.get(col, "")
            r.raw[field] = raw
            kind = FIELD_TYPES[field]
            if kind is None:
                r.norm[field], r.flags[field] = raw.strip(), ("OK" if raw.strip() else "EMPTY")
            else:
                r.norm[field], r.flags[field] = normalize(raw, kind, opts)
            if field in vmaps and r.norm[field] in vmaps[field]:
                r.norm[field] = vmaps[field][r.norm[field]]
        if "state" in src["columns"]:
            s = r.norm.get("state", "")
            if s in smap:
                r.state = smap[s]
            elif s.replace(" ", "_") in CANONICAL_STATES:
                r.state = s.replace(" ", "_")
            elif s:
                r.state = "UNMAPPED"
        recs.append(r)
    if src["role"] == "discovery" and "last_seen" not in src["columns"]:
        notes.append("Source %s has no last_seen column mapped: every record is treated as active, "
                     "so ST-01/ST-02/ST-07 may over-report and ST-03 is not evaluated." % src["name"])
    return recs


class Engine(object):
    def __init__(self, cfg, as_of):
        self.cfg = cfg
        self.m = cfg["matching"]
        self.r = cfg["rules"]
        self.as_of = as_of
        self.clusters = []
        self.t1 = defaultdict(set)
        self.t2 = defaultdict(set)
        self.t3 = defaultdict(set)
        self.exceptions = []
        self.review_clusters = set()
        self.notes = []

    # ---------- exceptions ----------
    def ex(self, code, rec=None, cluster=None, field="", observed="", detail="", severity=None):
        name, sev, cat, action = CODES[code]
        self.exceptions.append(OrderedDict([
            ("exception_id", ""), ("code", code), ("name", name), ("severity", severity or sev),
            ("category", cat), ("cluster_id", cluster.id if cluster else (rec.cluster.id if rec and rec.cluster else "")),
            ("source", rec.source if rec else ""), ("source_row", rec.row if rec else ""),
            ("record_id", rec.norm.get("record_id", "") if rec else ""), ("field", field),
            ("observed", observed), ("detail", detail), ("recommended_action", action),
            ("owner", ""), ("status", "OPEN"),
        ]))

    # ---------- clustering ----------
    def new_cluster(self, rec, index=True):
        """Seed a cluster. index=False quarantines an ambiguous record: its keys are not
        registered, so it cannot attract later records and make their matches ambiguous too."""
        c = Cluster("C%06d" % (len(self.clusters) + 1))
        self.clusters.append(c)
        rec.tier = "SEED"
        self.add(c, rec, index)
        return c

    def add(self, c, rec, index=True):
        c.members.append(rec)
        c.sources[rec.source] += 1
        rec.cluster = c
        for f in FIELD_TYPES:
            v = rec.v(f)
            if v:
                c.values[f].add(v)
        if not index:
            return
        for k in self.m["tier1_keys"]:
            if rec.v(k):
                self.t1[(k, rec.v(k))].add(c.id)
        for comp in self.m["tier2_composites"]:
            vals = tuple(rec.v(f) for f in comp)
            if all(vals):
                self.t2[(tuple(comp), vals)].add(c.id)
        for f in self.m["tier3_fields"]:
            if f not in DATE_FIELDS and rec.v(f):
                self.t3[(f, rec.v(f))].add(c.id)

    def cluster_by_id(self, cid):
        return self.clusters[int(cid[1:]) - 1]

    def strong_conflict(self, rec, c):
        out = []
        for k in self.m["tier1_keys"]:
            v = rec.v(k)
            if v and c.values.get(k) and v not in c.values[k]:
                out.append(k)
        return out

    def place(self, rec):
        # Tier 1 -- deterministic
        cand = OrderedDict()
        for k in self.m["tier1_keys"]:
            v = rec.v(k)
            if v:
                for cid in sorted(self.t1.get((k, v), ())):
                    cand.setdefault(cid, []).append(k)
        if len(cand) == 1:
            cid, keys = next(iter(cand.items()))
            c = self.cluster_by_id(cid)
            conflicts = self.strong_conflict(rec, c)
            rec.tier, rec.matched_on = "T1", "+".join(keys)
            rec.matched_value = ";".join(rec.v(k) for k in keys)
            self.add(c, rec)
            for k in conflicts:
                others = ",".join(sorted(c.values[k] - {rec.v(k)}))
                self.ex("MT-03", rec, c, field=k, observed=rec.v(k),
                        detail="matched on %s but %s differs (cluster has %s)" % (rec.matched_on, k, others))
                self.review_clusters.add(c.id)
            return
        if len(cand) > 1:
            c = self.new_cluster(rec, index=False)
            ids = list(cand)
            self.ex("MT-01", rec, c, field="+".join(sorted({k for ks in cand.values() for k in ks})),
                    detail="tier 1 keys match %d clusters: %s; not merged" % (len(ids), ",".join(ids)))
            self.review_clusters.update(ids + [c.id])
            return
        # Tier 2 -- composite
        cand2 = OrderedDict()
        for comp in self.m["tier2_composites"]:
            vals = tuple(rec.v(f) for f in comp)
            if not all(vals):
                continue
            for cid in sorted(self.t2.get((tuple(comp), vals), ())):
                c = self.cluster_by_id(cid)
                if c.sources.get(rec.source) or self.strong_conflict(rec, c):
                    continue
                cand2.setdefault(cid, ("+".join(comp), ";".join(vals)))
        if len(cand2) == 1:
            cid, (on, val) = next(iter(cand2.items()))
            rec.tier, rec.matched_on, rec.matched_value = "T2", on, val
            self.add(self.cluster_by_id(cid), rec)
            return
        if len(cand2) > 1:
            c = self.new_cluster(rec, index=False)
            self.ex("MT-01", rec, c, field="composite",
                    detail="tier 2 composites match %d clusters: %s; not merged" % (len(cand2), ",".join(cand2)))
            self.review_clusters.update(list(cand2) + [c.id])
            return
        # Tier 3 -- proposal only
        c_new = self.new_cluster(rec)
        best = self.tier3(rec, c_new)
        if best:
            (cid, agree, disagree, fields), tie = best
            if tie:
                self.ex("MT-01", rec, c_new, field="tier3",
                        detail="tier 3 tie between clusters %s (agree=%d); not merged" % (",".join(tie), agree))
                self.review_clusters.update(tie + [c_new.id])
            else:
                rec.proposed, rec.proposed_score = cid, "%d/%d" % (agree, agree + disagree)
                self.ex("MT-02", rec, c_new, field="+".join(fields), observed=rec.proposed_score,
                        detail="proposed match to %s on %s; agree %d, disagree %d; not merged"
                        % (cid, "+".join(fields), agree, disagree))
                self.review_clusters.update([cid, c_new.id])

    def tier3(self, rec, own):
        fields = self.m["tier3_fields"]
        cap = int(self.m.get("tier3_block_cap", 200))
        tol = int(self.m.get("date_tolerance_days", 45))
        cands = set()
        for f in fields:
            if f in DATE_FIELDS or not rec.v(f):
                continue
            post = self.t3.get((f, rec.v(f)), set())
            if len(post) <= cap:
                cands |= post
        cands.discard(own.id)
        scored = []
        for cid in sorted(cands):
            c = self.cluster_by_id(cid)
            if c.sources.get(rec.source) or self.strong_conflict(rec, c):
                continue
            agree, disagree, hit = 0, 0, []
            for f in fields:
                v = rec.v(f)
                if not v or not c.values.get(f):
                    continue
                if f in DATE_FIELDS:
                    d = _parse_date(v)
                    ok = d is not None and any(
                        (_parse_date(x) is not None and abs((_parse_date(x) - d).days) <= tol) for x in c.values[f])
                else:
                    ok = v in c.values[f]
                if ok:
                    agree += 1
                    hit.append(f)
                else:
                    disagree += 1
            if agree >= int(self.m.get("tier3_min_agree", 3)) and agree > disagree:
                scored.append((cid, agree, disagree, hit))
        if not scored:
            return None
        scored.sort(key=lambda t: (-t[1], t[2], t[0]))
        top = scored[0]
        tie = [s[0] for s in scored if s[1] == top[1] and s[2] == top[2]]
        return top, (tie if len(tie) > 1 else None)

    # ---------- record-level checks ----------
    def record_checks(self, recs, src, users):
        tier1 = self.m["tier1_keys"]
        unmapped = defaultdict(int)
        for rec in recs:
            if "serial" in rec.flags and rec.flags["serial"] == "EMPTY":
                self.ex("DQ-01", rec, field="serial", severity="Medium" if rec.role == "repository" else "Low")
            for k in tier1:
                if rec.flags.get(k) in BAD_ID_FLAGS:
                    self.ex("DQ-02", rec, field=k, observed=rec.raw.get(k, ""), detail=rec.flags[k])
            for f in DATE_FIELDS:
                if rec.flags.get(f) == "UNPARSEABLE":
                    self.ex("DQ-06", rec, field=f, observed=rec.raw.get(f, ""))
            if rec.role == "discovery":
                if "last_seen" not in src["columns"]:
                    rec.active = True
                else:
                    d = _parse_date(rec.norm.get("last_seen", ""))
                    rec.active = d is not None and (self.as_of - d).days <= int(self.r["active_days"])
                    if d is not None and not rec.active:
                        self.ex("ST-03", rec, field="last_seen", observed=d.isoformat(),
                                detail="%d days before as-of %s (active window %s days)"
                                % ((self.as_of - d).days, self.as_of, self.r["active_days"]))
            if rec.role != "repository":
                continue
            st = rec.state
            if st == "UNMAPPED":
                unmapped[rec.raw.get("state", "")] += 1
            if "asset_tag" in rec.flags and rec.flags["asset_tag"] == "EMPTY" and st not in ("ON_ORDER", "CANCELLED", "DISPOSED"):
                self.ex("DQ-05", rec, field="asset_tag", observed="", detail="state %s" % (st or "unknown"))
            if "location" in rec.flags and rec.flags["location"] in ("EMPTY", "PLACEHOLDER") and st in ("IN_USE", "IN_STOCK"):
                self.ex("DQ-07", rec, field="location", detail="state %s" % st)
            if st == "IN_USE" and "user" in rec.flags and not rec.v("user"):
                self.ex("ST-05", rec, field="user", observed=rec.raw.get("user", ""))
            if st == "IN_USE" and rec.v("warranty_end"):
                d = _parse_date(rec.v("warranty_end"))
                if d and d < self.as_of:
                    self.ex("ST-06", rec, field="warranty_end", observed=d.isoformat())
            if users is not None and st == "IN_USE" and rec.v("user"):
                u = users.get(rec.v("user"))
                if u is None:
                    self.ex("US-02", rec, field="user", observed=rec.raw.get("user", ""))
                elif not u:
                    self.ex("US-01", rec, field="user", observed=rec.raw.get("user", ""),
                            detail="HR status not in active_values")
        for val, n in sorted(unmapped.items()):
            self.ex("ST-04", None, field="state", observed=val,
                    detail="%s: %d records with this state value are not in state_map" % (src["name"], n))
        # duplicates within the source
        for k in tier1:
            groups = defaultdict(list)
            for rec in recs:
                if rec.v(k):
                    groups[rec.v(k)].append(rec)
            for val in sorted(groups):
                g = groups[val]
                if len(g) > 1:
                    self.ex("DQ-03", g[0], field=k, observed=val,
                            detail="%s rows %s share %s" % (src["name"], ",".join(str(x.row) for x in g), k),
                            severity="High" if g[0].role == "repository" else "Medium")

    # ---------- cluster-level checks ----------
    def cluster_checks(self, roles_present, sources_by_name):
        r = self.r
        has_repo = "repository" in roles_present
        disc_states = set(r["discoverable_states"])
        disc_classes = {normalize(x, "text")[0] for x in r.get("discoverable_classes") or []}
        phys_states = set(r["physical_expected_states"])
        ci_classes = {normalize(x, "text")[0] for x in r.get("ci_expected_classes") or []}
        scope = {normalize(x, "text")[0] for x in r.get("physical_scope_locations") or []}
        if not scope:
            scope = {m.v("location") for c in self.clusters for m in c.members
                     if m.role == "physical" and m.v("location")}
        for c in self.clusters:
            roles = defaultdict(list)
            for m in c.members:
                roles[m.role].append(m)
            active_disc = [m for m in roles["discovery"] if m.active]
            if has_repo and not roles["repository"]:
                first = c.members[0]
                note = " (see review exception)" if c.id in self.review_clusters else ""
                if roles["discovery"]:
                    self.ex("PR-01", first, c, detail="seen in %s%s" % ("+".join(sorted({m.source for m in roles['discovery']})), note),
                            severity="High" if active_disc else "Medium")
                if roles["physical"]:
                    self.ex("PR-03", roles["physical"][0], c, detail="found at %s%s" % (roles["physical"][0].v("location") or "unknown location", note))
                if roles["finance"]:
                    self.ex("PR-05", roles["finance"][0], c, detail=note.strip())
                if roles["cmdb"]:
                    self.ex("PR-07", roles["cmdb"][0], c, detail=note.strip())
                if roles["procurement"]:
                    self.ex("PR-09", roles["procurement"][0], c, detail=note.strip())
            for rep in roles["repository"]:
                st = rep.state
                if "discovery" in roles_present and st in disc_states and not roles["discovery"]:
                    if not disc_classes or rep.v("asset_class") in disc_classes:
                        self.ex("PR-02", rep, c, field="state", observed=st)
                if "physical" in roles_present and st in phys_states and not roles["physical"]:
                    loc = rep.v("location")
                    if not scope or loc in scope:
                        self.ex("PR-04", rep, c, field="location", observed=loc)
                if "finance" in roles_present and not roles["finance"] and rep.v("capitalized") in TRUTHY \
                        and st not in ("DISPOSED", "CANCELLED"):
                    self.ex("PR-06", rep, c, field="capitalized", observed=rep.v("capitalized"))
                if "cmdb" in roles_present and ci_classes and not roles["cmdb"] and rep.v("asset_class") in ci_classes \
                        and st not in ("DISPOSED", "CANCELLED", "ON_ORDER"):
                    self.ex("PR-08", rep, c, field="asset_class", observed=rep.v("asset_class"))
                if "procurement" in roles_present and r.get("flag_missing_purchase") and not roles["procurement"] \
                        and st != "CANCELLED":
                    self.ex("PR-10", rep, c)
                if active_disc:
                    seen = "%s last seen %s" % (active_disc[0].source, active_disc[0].v("last_seen") or "(date not mapped)")
                    if st in ("RETIRED", "DISPOSED"):
                        self.ex("ST-01", rep, c, field="state", observed=st, detail=seen)
                    elif st == "MISSING":
                        self.ex("ST-07", rep, c, field="state", observed=st, detail=seen)
                    elif st == "IN_STOCK":
                        self.ex("ST-02", rep, c, field="state", observed=st, detail=seen)
            if len(c.sources) > 1:
                for f in r["compare_fields"]:
                    vals = OrderedDict()
                    for m in c.members:
                        v = m.v(f)
                        if v:
                            vals.setdefault(m.source, set()).add(v)
                    distinct = set().union(*vals.values()) if vals else set()
                    if len(distinct) > 1:
                        det = "; ".join("%s=%s" % (s, "|".join(sorted(v))) for s, v in vals.items())
                        anchor = roles["repository"][0] if roles["repository"] else c.members[0]
                        sev = "High" if f == "user" and roles["repository"] else None
                        self.ex("AT-01", anchor, c, field=f, observed=anchor.v(f), detail=det, severity=sev)


def load_users(ucfg):
    fields, rows = read_rows(ucfg["path"])
    cols = ucfg.get("columns", {})
    for k in ("user", "status"):
        if cols.get(k) not in fields:
            raise ConfigError("users: column for %r (%r) not found in %s" % (k, cols.get(k), ucfg["path"]))
    active = {normalize(v, "text")[0] for v in ucfg.get("active_values", ["Active"])}
    out = {}
    for row in rows:
        u = normalize(row[cols["user"]], "user")[0]
        if u:
            # if a user appears twice, active wins (rehire or duplicate HR rows)
            out[u] = out.get(u, False) or normalize(row[cols["status"]], "text")[0] in active
    return out


def write_csv(path, fields, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def pct(n, d):
    return round(100.0 * n / d, 2) if d else None


def run(cfg, as_of, out_dir):
    eng = Engine(cfg, as_of)
    users = load_users(cfg["users"]) if cfg.get("users") else None
    sources = sorted(cfg["sources"], key=lambda s: 0 if s["role"] == "repository" else 1)
    all_recs = OrderedDict()
    for s in sources:
        all_recs[s["name"]] = load_source(s, cfg, eng.notes)
    if users is None:
        eng.notes.append("No users (HR) extract supplied: US-01 and US-02 not evaluated.")
    if not any(s["role"] == "repository" for s in sources):
        eng.notes.append("No repository source: presence exceptions PR-01..PR-10 not evaluated.")
    for s in sources:
        for rec in all_recs[s["name"]]:
            eng.place(rec)
    for s in sources:
        eng.record_checks(all_recs[s["name"]], s, users)
    roles_present = {s["role"] for s in sources}
    eng.cluster_checks(roles_present, {s["name"]: s for s in sources})

    # ---- outputs ----
    os.makedirs(out_dir, exist_ok=True)
    order = {"DQ": 0, "MT": 1, "PR": 2, "ST": 3, "AT": 4, "US": 5}
    eng.exceptions.sort(key=lambda e: (e["cluster_id"] or "~", order[e["code"][:2]], e["code"], e["source"],
                                       int(e["source_row"] or 0), e["field"]))
    for i, e in enumerate(eng.exceptions, start=1):
        e["exception_id"] = "EX-%06d" % i
    write_csv(os.path.join(out_dir, "exceptions.csv"), list(eng.exceptions[0].keys()) if eng.exceptions else
              ["exception_id", "code", "name", "severity", "category", "cluster_id", "source", "source_row",
               "record_id", "field", "observed", "detail", "recommended_action", "owner", "status"], eng.exceptions)

    mfields = ["cluster_id", "source", "source_row", "record_id", "match_tier", "matched_on", "matched_value",
               "serial_norm", "serial_flag", "asset_tag_norm", "hostname_norm", "user_norm", "state_raw",
               "state_canonical", "discovery_active", "proposed_cluster", "proposed_score"]
    mrows = []
    for name, recs in all_recs.items():
        for r in recs:
            mrows.append({"cluster_id": r.cluster.id, "source": name, "source_row": r.row,
                          "record_id": r.norm.get("record_id", ""), "match_tier": r.tier,
                          "matched_on": r.matched_on, "matched_value": r.matched_value,
                          "serial_norm": r.norm.get("serial", ""), "serial_flag": r.flags.get("serial", ""),
                          "asset_tag_norm": r.norm.get("asset_tag", ""), "hostname_norm": r.norm.get("hostname", ""),
                          "user_norm": r.norm.get("user", ""), "state_raw": r.raw.get("state", ""),
                          "state_canonical": r.state,
                          "discovery_active": "" if r.active is None else ("Y" if r.active else "N"),
                          "proposed_cluster": r.proposed, "proposed_score": r.proposed_score})
    write_csv(os.path.join(out_dir, "matches.csv"), mfields, mrows)

    names = [s["name"] for s in sources]
    ex_by_cluster = defaultdict(set)
    for e in eng.exceptions:
        if e["cluster_id"]:
            ex_by_cluster[e["cluster_id"]].add(e["code"])
    cfields = ["cluster_id", "sources", "record_count"] + ["in_" + n for n in names] + \
              ["join_tiers", "repository_state", "serial", "asset_tag", "hostname", "user", "model", "location",
               "review_required", "exception_codes"]
    crows, combos = [], defaultdict(int)
    for c in eng.clusters:
        rep = next((m for m in c.members if m.role == "repository"), c.members[0])
        srcs = [n for n in names if c.sources.get(n)]
        combos["+".join(srcs)] += 1
        row = {"cluster_id": c.id, "sources": "+".join(srcs), "record_count": len(c.members),
               "join_tiers": "+".join(sorted({m.tier for m in c.members if m.tier != "SEED"})) or "",
               "repository_state": rep.state if rep.role == "repository" else "",
               "serial": rep.v("serial") or next((m.v("serial") for m in c.members if m.v("serial")), ""),
               "asset_tag": rep.v("asset_tag") or next((m.v("asset_tag") for m in c.members if m.v("asset_tag")), ""),
               "hostname": rep.v("hostname"), "user": rep.v("user"), "model": rep.v("model"),
               "location": rep.v("location"), "review_required": "Y" if c.id in eng.review_clusters else "",
               "exception_codes": ";".join(sorted(ex_by_cluster.get(c.id, ())))}
        for n in names:
            row["in_" + n] = "Y" if c.sources.get(n) else "N"
        crows.append(row)
    write_csv(os.path.join(out_dir, "clusters.csv"), cfields, crows)

    # ---- summary ----
    per_source = OrderedDict()
    for s in sources:
        recs = all_recs[s["name"]]
        tiers = defaultdict(int)
        for r in recs:
            tiers[r.tier] += 1
        linked = sum(1 for r in recs if len(r.cluster.sources) > 1)
        per_source[s["name"]] = {"role": s["role"], "records": len(recs), "join_tier_counts": dict(sorted(tiers.items())),
                                 "records_linked_to_another_source": linked,
                                 "tier3_proposals": sum(1 for r in recs if r.proposed)}
    repo = next((s["name"] for s in sources if s["role"] == "repository"), None)
    metrics = OrderedDict()
    if repo:
        rr = all_recs[repo]
        linked = sum(1 for r in rr if len(r.cluster.sources) > 1)
        metrics["repository_match_rate_pct"] = {
            "value": pct(linked, len(rr)), "numerator": linked, "denominator": len(rr),
            "formula": "repository records linked by tier 1 or 2 to at least one other source / repository records x 100"}
        for s in sources:
            if s["name"] == repo:
                continue
            found = sum(1 for r in rr if r.cluster.sources.get(s["name"]))
            other = all_recs[s["name"]]
            in_repo = sum(1 for r in other if r.cluster.sources.get(repo))
            metrics["coverage_%s" % s["name"]] = {
                "repository_records_found_in_source": found,
                "source_records_found_in_repository": in_repo,
                "source_records_found_in_repository_pct": pct(in_repo, len(other)),
                "formula": "%s records linked to a %s record / %s records x 100" % (s["name"], repo, s["name"])}
    sev, codes = defaultdict(int), defaultdict(int)
    for e in eng.exceptions:
        sev[e["severity"]] += 1
        codes[e["code"] + " " + e["name"]] += 1
    summary = OrderedDict([
        ("as_of", as_of.isoformat()), ("sources", per_source),
        ("clusters", {"total": len(eng.clusters),
                      "multi_source": sum(1 for c in eng.clusters if len(c.sources) > 1),
                      "by_source_combination": dict(sorted(combos.items())),
                      "review_required": len(eng.review_clusters)}),
        ("metrics", metrics),
        ("exceptions", {"total": len(eng.exceptions), "by_severity": dict(sorted(sev.items())),
                        "by_code": dict(sorted(codes.items()))}),
        ("notes", eng.notes + ["Tier 3 proposals are not merged and do not count as matched.",
                               "Counts describe the supplied extracts only; they are not a statement about "
                               "assets that no extract contains."]),
    ])
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    return summary


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", help="JSON config describing the sources, column mappings and rules")
    p.add_argument("--out-dir", help="directory for matches.csv, clusters.csv, exceptions.csv, summary.json")
    p.add_argument("--as-of", help="reference date YYYY-MM-DD for staleness and warranty checks "
                                   "(default: config as_of, else today)")
    p.add_argument("--example-config", action="store_true", help="print an example config and exit")
    args = p.parse_args(argv)
    if args.example_config:
        print(json.dumps(EXAMPLE_CONFIG, indent=2))
        return 0
    if not args.config or not args.out_dir:
        p.error("--config and --out-dir are required (or use --example-config)")
    try:
        cfg = load_config(args.config)
        as_of_s = args.as_of or cfg.get("as_of")
        as_of = _parse_date(as_of_s) if as_of_s else _dt.date.today()
        if as_of is None:
            raise ConfigError("as_of %r is not YYYY-MM-DD" % as_of_s)
        summary = run(cfg, as_of, args.out_dir)
    except (ConfigError, json.JSONDecodeError) as exc:
        sys.stderr.write("error: %s\n" % exc)
        return 2
    sys.stderr.write("clusters=%d multi_source=%d exceptions=%d -> %s\n" % (
        summary["clusters"]["total"], summary["clusters"]["multi_source"],
        summary["exceptions"]["total"], args.out_dir))
    return 0


if __name__ == "__main__":
    sys.exit(main())
