#!/usr/bin/env python3
"""Normalize asset identifiers in a CSV extract so records can be matched across sources.

Adds two columns for every column you normalize:
  <column>__norm   the normalized value (empty when the value is unusable)
  <column>__flag   OK, EMPTY, PLACEHOLDER, TOO_SHORT, VIRTUAL, EXCEL_MANGLED, INVALID or UNPARSEABLE

The source columns are never changed, so the output keeps the raw evidence beside
the normalized value. Python 3 standard library only; deterministic.

Identifier types (--map "Column Name=type"):
  serial    upper-case, strip "S/N:"-style prefixes, keep letters and digits only,
            flag OEM placeholders ("To be filled by O.E.M.", "Default string", 0, N/A ...),
            Excel scientific notation (1.23E+11) and virtual-machine serials (VMware-, Parallels-)
  tag       upper-case, letters and digits only; optional prefix strip and leading-zero strip
  hostname  upper-case, drop the DNS domain (PC123.corp.example.com -> PC123)
  mac       12 hex digits -> AA:BB:CC:DD:EE:FF; flags all-zero / broadcast values
  uuid      lower-case 8-4-4-4-12; flags all-zero, all-F and known OEM placeholder UUIDs
  user      lower-case; DOMAIN\\user and user@domain -> user
  text      upper-case, punctuation removed, whitespace collapsed (models, locations, states)
  date      parsed to YYYY-MM-DD using --date-format values, then common formats

Examples:
  normalize_serials.py itam.csv -o itam_norm.csv --map "Serial Number=serial" --map "Asset Tag=tag"
  normalize_serials.py intune.csv -o intune_norm.csv --map "Serial number=serial" \\
      --map "Device name=hostname" --map "Primary user UPN=user" --summary-json flags.json
"""

import argparse
import csv
import datetime as _dt
import json
import re
import sys

# Values seen in BIOS/SMBIOS or typed into tools when the real serial is unknown.
# Compared after upper-casing and removing everything except letters and digits.
SERIAL_PLACEHOLDERS = {
    "", "0", "00", "000", "0000", "00000", "000000", "0000000", "00000000",
    "NA", "NONE", "NULL", "NIL", "UNKNOWN", "UNK", "TBD", "TBA", "INVALID",
    "NOTAPPLICABLE", "NOTAVAILABLE", "NOTSPECIFIED", "NOTPROVIDED", "NOSERIAL",
    "NOSN", "DEFAULTSTRING", "DEFAULT", "TOBEFILLEDBYOEM", "TOBEFILLEDBYOEM1",
    "SYSTEMSERIALNUMBER", "CHASSISSERIALNUMBER", "BASEBOARDSERIALNUMBER",
    "SERIALNUMBER", "SERIAL", "OEM", "XXXXXXXX", "123456789", "1234567890",
    "0123456789", "12345678", "1234567", "123456", "ABCDEFGHIJ", "EMPTY",
    "FFFFFFFF", "NOTDEFINED", "NOTSET",
}
SERIAL_PREFIX_RE = re.compile(r"^\s*(S\s*/\s*N|SERIAL\s*(NO|NUMBER|#)?|SN)\s*[:#.\-]\s*", re.I)
VIRTUAL_SERIAL_RE = re.compile(r"^(VMWARE|PARALLELS|VIRTUALBOX|VBOX|XEN|QEMU|HYPERV|AMAZONEC2|GOOGLECOMPUTE)", re.I)
EXCEL_SCI_RE = re.compile(r"^\s*\d+(\.\d+)?E\+?\d+\s*$", re.I)
NON_ALNUM_RE = re.compile(r"[^A-Z0-9]")
PUNCT_RE = re.compile(r"[^\w\s]", re.UNICODE)
WS_RE = re.compile(r"\s+")
UUID_PLACEHOLDERS = {
    "00000000-0000-0000-0000-000000000000",
    "ffffffff-ffff-ffff-ffff-ffffffffffff",
    "03000200-0400-0500-0006-000700080009",  # widely reported OEM placeholder SMBIOS UUID
}
MAC_PLACEHOLDERS = {"000000000000", "FFFFFFFFFFFF"}
DEFAULT_DATE_FORMATS = [
    "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M", "%Y/%m/%d", "%m/%d/%Y", "%m/%d/%Y %H:%M", "%m/%d/%Y %H:%M:%S",
    "%m/%d/%Y %I:%M %p", "%m/%d/%Y %I:%M:%S %p", "%d-%b-%Y", "%d %b %Y", "%b %d, %Y",
]
TYPES = ("serial", "tag", "hostname", "mac", "uuid", "user", "text", "date")


def normalize(value, kind, opts=None):
    """Return (normalized_value, flag) for one raw value. Never raises on bad input."""
    opts = opts or {}
    raw = "" if value is None else str(value)
    if raw.strip() == "":
        return "", "EMPTY"
    fn = _DISPATCH.get(kind)
    if fn is None:
        raise ValueError("unknown identifier type: %s (use one of %s)" % (kind, ", ".join(TYPES)))
    return fn(raw, opts)


def _serial(raw, opts):
    if EXCEL_SCI_RE.match(raw):
        return "", "EXCEL_MANGLED"
    s = SERIAL_PREFIX_RE.sub("", raw.strip())
    s = NON_ALNUM_RE.sub("", s.upper())
    if opts.get("serial_strip_leading_zeros"):
        s = s.lstrip("0")
    if s in SERIAL_PLACEHOLDERS or (len(s) > 1 and len(set(s)) == 1):
        return "", "PLACEHOLDER"
    if VIRTUAL_SERIAL_RE.match(s):
        return s, "VIRTUAL"
    if len(s) < int(opts.get("serial_min_length", 4)):
        return "", "TOO_SHORT"
    return s, "OK"


def _tag(raw, opts):
    s = raw.strip().upper()
    prefix = opts.get("tag_strip_prefix")
    if prefix:
        s = re.sub(prefix, "", s, flags=re.I)
    s = NON_ALNUM_RE.sub("", s)
    if opts.get("tag_strip_leading_zeros"):
        s = s.lstrip("0")
    if s in SERIAL_PLACEHOLDERS or (len(s) > 1 and len(set(s)) == 1):
        return "", "PLACEHOLDER"
    return s, "OK"


def _hostname(raw, opts):
    s = raw.strip().split("\\")[-1]  # DOMAIN\HOST
    s = s.split(".")[0].upper()
    s = WS_RE.sub("", s)
    if s in ("", "LOCALHOST", "UNKNOWN", "NONE", "NULL", "NA"):
        return "", "PLACEHOLDER"
    return s, "OK"


def _mac(raw, opts):
    s = re.sub(r"[^0-9A-Fa-f]", "", raw).upper()
    if len(s) != 12:
        return "", "INVALID"
    if s in MAC_PLACEHOLDERS:
        return "", "PLACEHOLDER"
    return ":".join(s[i:i + 2] for i in range(0, 12, 2)), "OK"


def _uuid(raw, opts):
    s = re.sub(r"[^0-9A-Fa-f]", "", raw).lower()
    if len(s) != 32:
        return "", "INVALID"
    u = "%s-%s-%s-%s-%s" % (s[0:8], s[8:12], s[12:16], s[16:20], s[20:32])
    if u in UUID_PLACEHOLDERS:
        return "", "PLACEHOLDER"
    return u, "OK"


def _user(raw, opts):
    s = raw.strip().lower()
    if "\\" in s:
        s = s.split("\\")[-1]
    if "@" in s and not opts.get("user_keep_domain"):
        s = s.split("@")[0]
    s = WS_RE.sub(" ", s).strip()
    if s in ("", "none", "null", "n/a", "na", "unknown", "unassigned", "-"):
        return "", "PLACEHOLDER"
    return s, "OK"


def _text(raw, opts):
    s = PUNCT_RE.sub(" ", raw.upper())
    s = WS_RE.sub(" ", s).strip()
    if s in ("", "NONE", "NULL", "N A", "NA", "UNKNOWN"):
        return "", "PLACEHOLDER"
    return s, "OK"


def _date(raw, opts):
    s = raw.strip()
    formats = list(opts.get("date_formats") or []) + DEFAULT_DATE_FORMATS
    for fmt in formats:
        try:
            return _dt.datetime.strptime(s, fmt).date().isoformat(), "OK"
        except ValueError:
            continue
    # ISO 8601 with fractional seconds or offsets (Python 3.7+)
    try:
        return _dt.datetime.fromisoformat(s.replace("Z", "+00:00")).date().isoformat(), "OK"
    except ValueError:
        return "", "UNPARSEABLE"


_DISPATCH = {
    "serial": _serial, "tag": _tag, "hostname": _hostname, "mac": _mac,
    "uuid": _uuid, "user": _user, "text": _text, "date": _date,
}


def read_csv(path, encoding="utf-8-sig"):
    with open(path, newline="", encoding=encoding) as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise SystemExit("error: %s has no header row" % path)
        return list(reader.fieldnames), [row for row in reader]


def main(argv=None):
    p = argparse.ArgumentParser(
        description=__doc__,
        epilog="Normalization rules are documented in references/match-rules.md.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("input", help="input CSV file (header row required)")
    p.add_argument("-o", "--output", required=True, help="output CSV file")
    p.add_argument("--map", action="append", required=True, metavar="COLUMN=TYPE",
                   help="column to normalize and its identifier type; repeat for several columns")
    p.add_argument("--date-format", action="append", default=[], metavar="STRPTIME",
                   help="date format to try first, e.g. %%d/%%m/%%Y for day-first sources; repeatable")
    p.add_argument("--tag-strip-prefix", metavar="REGEX", help="regex removed from asset tags before comparison, e.g. ^AT-?")
    p.add_argument("--tag-strip-leading-zeros", action="store_true", help="treat AT000123 and AT123 as the same tag")
    p.add_argument("--serial-strip-leading-zeros", action="store_true",
                   help="strip leading zeros from serials (use only when one source drops them)")
    p.add_argument("--serial-min-length", type=int, default=4, help="serials shorter than this are flagged TOO_SHORT (default 4)")
    p.add_argument("--encoding", default="utf-8-sig", help="input encoding (default utf-8-sig)")
    p.add_argument("--summary-json", metavar="PATH", help="write flag counts per column to this JSON file")
    args = p.parse_args(argv)

    opts = {
        "date_formats": args.date_format,
        "tag_strip_prefix": args.tag_strip_prefix,
        "tag_strip_leading_zeros": args.tag_strip_leading_zeros,
        "serial_strip_leading_zeros": args.serial_strip_leading_zeros,
        "serial_min_length": args.serial_min_length,
    }
    fields, rows = read_csv(args.input, args.encoding)
    mappings = []
    for m in args.map:
        if "=" not in m:
            p.error("--map needs COLUMN=TYPE, got %r" % m)
        col, kind = m.rsplit("=", 1)
        col, kind = col.strip(), kind.strip().lower()
        if col not in fields:
            p.error("column %r not in %s (columns: %s)" % (col, args.input, ", ".join(fields)))
        if kind not in TYPES:
            p.error("unknown type %r (use one of %s)" % (kind, ", ".join(TYPES)))
        mappings.append((col, kind))

    out_fields = list(fields)
    for col, _ in mappings:
        out_fields += [col + "__norm", col + "__flag"]
    summary = {col: {} for col, _ in mappings}
    for row in rows:
        for col, kind in mappings:
            norm, flag = normalize(row.get(col), kind, opts)
            row[col + "__norm"] = norm
            row[col + "__flag"] = flag
            summary[col][flag] = summary[col].get(flag, 0) + 1

    with open(args.output, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=out_fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    report = {"input": args.input, "rows": len(rows), "flags": summary}
    if args.summary_json:
        with open(args.summary_json, "w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=2, sort_keys=True)
    sys.stderr.write("normalized %d rows\n" % len(rows))
    for col in sorted(summary):
        sys.stderr.write("  %s: %s\n" % (col, ", ".join("%s=%d" % kv for kv in sorted(summary[col].items()))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
