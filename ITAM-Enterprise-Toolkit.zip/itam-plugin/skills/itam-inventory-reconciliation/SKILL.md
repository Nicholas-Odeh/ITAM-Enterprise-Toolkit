---
name: itam-inventory-reconciliation
description: Use when comparing or matching asset lists across systems (ITAM or ServiceNow export, discovery, Intune/SCCM/Jamf, CMDB, fixed-asset register, HR, count files): ghost or unmanaged devices, leavers holding devices, retired devices checking in, duplicate serials, match rate, count-vs-record variance, or audit evidence. Covers normalization, tiered matching scripts, exception codes. Not for the physical count procedure (use itam-logistics-warehouse), lifecycle design (itam-hardware-lifecycle) or KPI dashboards (itam-data-analysis-reporting).
---

# IT Asset Inventory Reconciliation

Decides with stated confidence which records from different systems describe the same device, and turns every disagreement into a coded, owned exception. Core principle: **variance is a finding; report it, never absorb it.** The bundled scripts do the matching, so results are exact and repeatable. For ITAM analysts, CMDB managers and auditors.

## Operating rules

**Required background:** `itam-operating-standard` defines the evidence labels, source hierarchy, quality gates and failure modes used here. Load it for any audit-grade deliverable.

1. **Evidence before claims.** No count, cost, date, contract term, license rule, legal requirement, standards clause or system name without a source. Otherwise label it `PRACTICE`, `INFERENCE` or `ASSUMPTION`, or say what is missing and how to get it.
2. **No completion claims without fresh evidence.** Never say reconciled, compliant, wiped, disposed, fixed, deployed or "works" unless the evidence is in hand in this conversation. Say what was checked.
3. **An asset record is not a CI.** Keep ownership, financial and lifecycle facts apart from operational and dependency facts.
4. **Read-only by default.** Any create, update, delete, bulk change or outbound message needs a dry run, a scope cap, a rollback and explicit approval.
5. **Ask once, only when it matters.** If missing information would change the answer materially, ask one specific question; otherwise proceed and label assumptions.
6. **Match with code, not by eye.** For more than a handful of rows, run `python3 scripts/match_tiers.py`. Report only counts a script or reproducible query produced.
7. **Never present a probabilistic match as deterministic.** Tier 3 results are proposals a person confirms; they never count as reconciled.
8. **Never modify source evidence.** Normalize into new columns, keep raw extracts unchanged, and correct source systems only through their own transactions with a reference.

## When to use

- "Compare our ServiceNow export with Intune", "what's in SCCM but not the CMDB?"
- Ghost or unmanaged devices; leavers holding devices; retired devices checking in.
- "How bad are our serials?"; matching a count file to records; "what does PR-02 mean?"
- Reconciliation evidence for an audit.

**When not to use:** running the physical count itself (`itam-logistics-warehouse`); lifecycle state design (`itam-hardware-lifecycle`); ServiceNow IRE or CMDB configuration (`servicenow-itam`); metric definitions or trends (`itam-data-analysis-reporting`); recurring status reports (`itam-status-report`).

## Workflow

### Step 1 — Classify

| Request | Load / run |
|---|---|
| Match two or more extracts | `references/match-rules.md`; `python3 scripts/match_tiers.py` |
| Identifier quality | `python3 scripts/normalize_serials.py`; `match-rules.md` §2 |
| Interpret or triage exceptions | `references/exception-codes.md` |
| Count results, accuracy, audit pack | `references/cycle-count-and-audit.md` |
| State or field meaning | `references/asset-data-model.md` |

### Step 2 — Preflight

Confirm or assume: each source's role, scope and as-of time (absence outside a source's scope is not an exception); column mapping; `state_map`; discovery window; purpose. Without files, specify the extracts and columns to pull (`references/reconciliation-method.md` §1).

### Step 3 — Do the work

1. Profile identifiers with `python3 scripts/normalize_serials.py … --summary-json <file>`.
2. Write the config (`python3 scripts/match_tiers.py --example-config`), repository first.
3. Run `python3 scripts/match_tiers.py --config recon.json --out-dir <dir> --as-of <date>`. Exit code 2: fix the named config error and rerun.
4. Check records in = rows in `matches.csv` per source; read `summary.json` notes.
5. Triage by severity then volume; root-cause the top codes; quantify with formulas.

Full sequence: `references/reconciliation-method.md` §2.

### Step 4 — Verify before release

- ★ Every count and rate comes from script output or a reproducible query, with formula, numerator, denominator and as-of date.
- ★ Tier 3 proposals are review-required and excluded from matched counts.
- ★ Source extracts unchanged; every normalization and value map documented.
- ★ Out-of-scope absences excluded by configuration, not deleted afterwards; any manual exclusion listed with its reason.
- ★ No exception called theft, a security incident or a breach without evidence; ST-01, ST-07 and US-01 flagged for Security or HR review.
- Unmapped states, unparseable dates and unevaluated checks disclosed; asset vs. CI findings kept apart.

## Red flags: stop and re-check

| Thought | Reality |
|---|---|
| "The count is close enough" | Variance is a finding; report it, don't absorb it. |
| "These 40 are obviously the same devices" | Unconfirmed Tier 3 stays review-required. |
| "Those exceptions are noise; drop them" | Exclude by configured scope with a reason, or keep them. |
| "The script ran, so it's reconciled" | Read the counts and residual exceptions first. |

Stop if you are about to: quote a match rate you didn't compute; delete exceptions from the register; edit a raw extract; call an unmatched device stolen.

## Common mistakes

| Mistake | Fix |
|---|---|
| MAC address as a match key on its own | Docks move; use it only inside a composite |
| Treating PR-07/PR-08 as missing devices | They are asset-CI integration issues |
| Match rate without denominator | State population and formula |
| Inventory accuracy from system matching alone | Needs a physical sample both ways |
| Trusting presence counts before MT-01/MT-02 review | Resolve review items first |

## If connectors are available

- **~~ITSM / ~~CMDB:** pull repository and CI extracts with filter and read time; draft corrections as referenced transactions.
- **~~endpoint management / ~~HR:** pull the device export and employment status (minimum fields).
- **~~finance / ~~procurement:** read the fixed-asset register and receipts as further sources.
- **~~document repository:** store the evidence pack, with approval.

## Output format

1. **Result:** population, match rate, top codes, main risk.
2. **Scope and method.**
3. **Metrics** with formulas.
4. **Exceptions** by code and severity, then the register.
5. **Root causes and corrective actions.**
6. **Limitations and open items.**

Executive variant: `references/reconciliation-method.md` §3.

## Reference files

- `references/reconciliation-method.md`: preflight, run sequence, output variants. Read before any reported reconciliation.
- `references/match-rules.md`: normalization, tiers, config, outputs. Read before matching.
- `references/exception-codes.md`: codes, severity, root cause, register fields. Read when triaging.
- `references/cycle-count-and-audit.md`: reconciling counts, accuracy sampling, audit pack. Read for counts and audits.
- `references/asset-data-model.md`: shared canonical fields and states (source: `itam-hardware-lifecycle`). Read for state or field meaning.
- `scripts/normalize_serials.py`: normalizes and flags identifiers; `python3 scripts/normalize_serials.py --help`.
- `scripts/match_tiers.py`: tiered matching; writes matches, clusters, exceptions, summary; `--example-config` prints a template.
